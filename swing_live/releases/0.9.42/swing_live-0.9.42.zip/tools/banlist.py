                       
"""Банлист на лицензни ключове (owner blacklist).

Две копия, пазят се синхронно от собственика:
  - Drive:  G:\\My Drive\\AdmiralAI_Shared\\swing_live\\banlist.json
    (клиентите го свалят през scripts\\update_client.py при всяка проверка за ъпдейт)
  - локално: <BASE_DIR>\\config\\banlist.json
    (проверява се от engine\\licensing.py при всяка is_licensed() проверка)

Формат:
  {"schema": 1, "updated_utc": "<iso>", "banned_sha256": ["<sha256 hex на точния
   стринг на ключа>", ...]}

Грешки при Drive пътя (G: липсва, мрежов проблем) НЕ спират операцията — логва се
и продължава с локалното копие.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
DRIVE_PATH = Path(r"G:\My Drive\AdmiralAI_Shared\swing_live\banlist.json")
LOCAL_PATH = BASE_DIR / "config" / "banlist.json"

SCHEMA = 1


def _log(msg: str) -> None:
    print(f"[banlist] {msg}", file=sys.stderr)


def _canonical(key: str) -> str:
    """DEMON- ключове са case-insensitive — нормализирай към upper преди digest."""
    k = str(key).strip()
    return k.upper() if k.upper().startswith("DEMON-") else k


def key_digest(key: str) -> str:
    """SHA-256 (hex) върху каноничния стринг на ключа (utf-8)."""
    return hashlib.sha256(_canonical(key).encode("utf-8")).hexdigest()


def _fresh() -> dict:
    return {"schema": SCHEMA, "updated_utc": "", "banned_sha256": []}


def load_banlist(path) -> dict:
    """Чете banlist. Липсващ/повреден файл -> празен списък със schema полета."""
    path = Path(path)
    if not path.exists():
        return _fresh()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(data, dict):
            return _fresh()
    except (json.JSONDecodeError, UnicodeDecodeError, OSError):
        return _fresh()
    data.setdefault("schema", SCHEMA)
    data.setdefault("updated_utc", "")
    if not isinstance(data.get("banned_sha256"), list):
        data["banned_sha256"] = []
    return data


def save_banlist(path, data: dict) -> None:
    """Atomic запис (tmp + replace), utf-8. Обновява schema и updated_utc."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data["schema"] = SCHEMA
    data["updated_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)


def is_banned(key: str, path) -> bool:
    """True ако digest-ът на ключа (канонизиран) е в списъка."""
    return key_digest(key) in set(load_banlist(path).get("banned_sha256", []))


def _mutate(path, digest: str, add: bool) -> None:
    """Добавя/маха digest в едно копие. OSError -> лог, без raise."""
    try:
        data = load_banlist(path)
        lst = data["banned_sha256"]
        if add and digest not in lst:
            lst.append(digest)
        elif not add and digest in lst:
            lst.remove(digest)
        else:
            return                                  
        save_banlist(path, data)
    except OSError as exc:
        _log(f"{path}: {exc} (продължавам с другото копие)")


def ban_key(key: str) -> None:
    """Блокира ключ: добавя digest-а му и в двете копия (създава ги при нужда)."""
    key = str(key or "")
    if not key.strip():
        return
    digest = key_digest(key)
    _mutate(DRIVE_PATH, digest, add=True)
    _mutate(LOCAL_PATH, digest, add=True)


def unban_key(key: str) -> None:
    """Възстановява ключ: маха digest-а му и от двете копия."""
    key = str(key or "")
    if not key.strip():
        return
    digest = key_digest(key)
    _mutate(DRIVE_PATH, digest, add=False)
    _mutate(LOCAL_PATH, digest, add=False)
