                       
"""Клиентска лицензна активация (влиза във всяка инсталация).

Поток: verify на ключа (нов къс DEMON-…/Ed25519 или стар ASL-…/RSA-3072 — и двата
приети от tools\\license_tool.verify_key, който вгражда публичните ключове от
tools\\license_ed_public.json и tools\\license_public_key.json) -> връзка за машината
(Windows MachineGuid от HKLM) -> activation.json, подпечатан с HMAC-SHA256 с локален
secret (config\\license_secret, генерира се при първа активация; НЕ влиза в
публикуваните zip-ове/Drive).

is_licensed() -> (ok, причина_BG). CLI: --status, --activate <key>.

Банлист: след успешната валидация ключът се проверява срещу config\\banlist.json
(tools\\banlist.is_banned) — блокиран от собственика ключ връща
(False, "ключът е деактивиран от собственика"). Файлът се синхронизира от
scripts\\update_client.py при всяка проверка за обновяване.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac as hmac_mod
import json
import secrets
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = BASE_DIR / "config"
ACTIVATION = CONFIG_DIR / "activation.json"
SECRET_FILE = CONFIG_DIR / "license_secret"
BANLIST = CONFIG_DIR / "banlist.json"
TOOLS_DIR = BASE_DIR / "tools"

                                                                                           
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("license_tool", TOOLS_DIR / "license_tool.py")
license_tool = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(license_tool)

_spec_ban = _ilu.spec_from_file_location("banlist", TOOLS_DIR / "banlist.py")
banlist = _ilu.module_from_spec(_spec_ban)
_spec_ban.loader.exec_module(banlist)


def machine_guid() -> str:
    """HKLM\\SOFTWARE\\Microsoft\\Cryptography\\MachineGuid."""
    import winreg
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                        r"SOFTWARE\Microsoft\Cryptography") as k:
        return str(winreg.QueryValueEx(k, "MachineGuid")[0]).strip().lower()


def _secret() -> bytes:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not SECRET_FILE.exists():
        SECRET_FILE.write_text(secrets.token_hex(32), encoding="ascii")
    return SECRET_FILE.read_text(encoding="ascii").strip().encode("ascii")


def _seal(payload: dict, key: str, guid: str) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    msg = (canonical + "|" + key.strip() + "|" + guid).encode("utf-8")
    return hmac_mod.new(_secret(), msg, hashlib.sha256).hexdigest()


def activate(key: str) -> tuple[bool, str]:
    """Въвеждане на ключ: verify + machine bind + запис. Връща (ok, причина_BG)."""
    payload, err = license_tool.verify_key(key.strip())
    if payload is None or err is not None:
                                                                    
        return False, (err or "невалиден ключ")
    guid = machine_guid()
    rec = {"payload": payload, "key": key.strip(), "machine_guid": guid,
           "seal": _seal(payload, key.strip(), guid)}
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    tmp = ACTIVATION.with_suffix(".tmp")
    tmp.write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(ACTIVATION)
    return True, ""


def is_licensed() -> tuple[bool, str]:
    """(ok, причина_BG): неактивиран / изтекъл на … / за друг компютър / променена активация
    / ключът е деактивиран от собственика (banlist)."""
    if not ACTIVATION.exists():
        return False, "неактивиран"
    try:
        rec = json.loads(ACTIVATION.read_text(encoding="utf-8"))
    except Exception:
        return False, "повреден файл на активацията"
    payload, key, guid, seal = rec.get("payload"), rec.get("key"), rec.get("machine_guid"), rec.get("seal")
    if not (payload and key and guid and seal):
        return False, "непълна активация"
                                         
    vp, verr = license_tool.verify_key(str(key))
    if vp is None:
        return False, f"невалиден ключ ({verr})"
                                                                                    
    if vp != payload:
        return False, "променена активация (payload ≠ ключ)"
                          
    try:
        if str(guid).strip().lower() != machine_guid():
            return False, "за друг компютър — ключът е вързан за друга машина; поискай прехвърляне"
    except Exception as exc:
        return False, f"не мога да прочета MachineGuid: {exc}"
                      
    if not hmac_mod.compare_digest(str(seal), _seal(payload, str(key), str(guid))):
        return False, "променена активация (печат)"
             
    vu = payload.get("valid_until")
    if vu and license_tool.is_expired(vu):
        return False, f"изтекъл на {vu}"
                                                                                           
    if banlist.is_banned(str(key), BANLIST):
        return False, "ключът е деактивиран от собственика"
    return True, ""


def status_line() -> str:
    ok, reason = is_licensed()
    if ok:
        try:
            rec = json.loads(ACTIVATION.read_text(encoding="utf-8"))
            p = rec.get("payload", {})
            return (f"лицензиран: {p.get('customer_name','')} <{p.get('customer_email','')}> "
                    f"до {p.get('valid_until') or 'безсрочно'} (license {p.get('license_id','')[:8]}…)")
        except Exception:
            return "лицензиран"
    return f"НЕЛИЦЕНЗИРАН: {reason}"


def main() -> int:
    ap = argparse.ArgumentParser(description="S5 licensing client")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--activate", metavar="KEY")
    args = ap.parse_args()
    if args.activate:
        ok, reason = activate(args.activate)
        print("активирано." if ok else f"ОТКАЗ: {reason}")
        return 0 if ok else 1
    print(status_line())
    ok, _ = is_licensed()
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
