                       
"""Cash-flow-aware performance accounting за Demon (център за управления).

Чете MT5 история (history_deals_get) САМО read-only.
- logs/deals_journal.jsonl — append-only журнал на всяка сделка (idempotent по ticket).
- logs/cashflows.jsonl     — депозити/тегления/кредити (отделно от търговския P&L).
- logs/equity_daily.json   — дневни снимки: balance, equity, чист търговски equity, DD.

Чистата търговска крива = balance - натрупани парични потоци
(депозитите/тегленията НЕ изкривяват трендлинията).

CLI:
  py -3.12 engine/performance.py --verify    # отчет: парични потоци (30 дни) + последни 10 сделки
  py -3.12 engine/performance.py --snapshot  # записва днешната дневна снимка
Без аргументи = --verify. Идемпотентен, безопасен за повторен старт.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"
DEALS_JOURNAL = LOGS_DIR / "deals_journal.jsonl"
CASHFLOWS = LOGS_DIR / "cashflows.jsonl"
EQUITY_DAILY = LOGS_DIR / "equity_daily.json"

DEAL_TYPE_NAMES = {
    0: "BUY", 1: "SELL", 2: "BALANCE", 3: "CREDIT", 4: "CHARGE",
    5: "CORRECTION", 6: "BONUS", 7: "COMMISSION", 8: "COMMISSION_DAILY",
    9: "COMMISSION_MONTHLY", 10: "AGENT_DAILY", 11: "AGENT_MONTHLY",
    12: "INTEREST", 13: "BUY_CANCELED", 14: "SELL_CANCELED",
    15: "DIVIDEND", 16: "DIVIDEND_FRANKED", 17: "TAX",
}
CASHFLOW_TYPES = {2, 3}                                       


def iso_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out = []
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out


def write_jsonl_atomic(path: Path, rows: list[dict]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    tmp.replace(path)


def write_json_atomic(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=1)
    tmp.replace(path)


def mt5_connect():
    import MetaTrader5 as mt5
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")
    return mt5


def fetch_all_deals(mt5) -> list[dict]:
    now = datetime.now(timezone.utc)
    deals = mt5.history_deals_get(datetime(2000, 1, 1, tzinfo=timezone.utc),
                                  now + timedelta(days=2))
    if deals is None:
        raise RuntimeError(f"history_deals_get failed: {mt5.last_error()}")
    rows = []
    for d in deals:
        t = datetime.fromtimestamp(d.time, tz=timezone.utc)
        rows.append({
            "ticket": int(d.ticket),
            "time": iso_utc(t),
            "symbol": d.symbol or "",
            "type": int(d.type),
            "type_name": DEAL_TYPE_NAMES.get(int(d.type), str(d.type)),
            "profit": float(d.profit),
            "commission": float(d.commission),
            "swap": float(d.swap),
            "magic": int(d.magic),
            "comment": d.comment or "",
        })
    rows.sort(key=lambda r: (r["ticket"]))
    return rows


def sync_journal() -> tuple[int, int]:
    """Append-only синхронизация на журнала. Връща (нови записи, общо записи)."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    existing = read_jsonl(DEALS_JOURNAL)
    known = {row["ticket"] for row in existing}
    mt5 = mt5_connect()
    try:
        fresh = fetch_all_deals(mt5)
    finally:
        mt5.shutdown()
    new_rows = [r for r in fresh if r["ticket"] not in known]
    if new_rows:
        with DEALS_JOURNAL.open("a", encoding="utf-8") as fh:
            for row in new_rows:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    try:
        login = str(mt5.account_info().login)
    except Exception:
        login = "unknown"
    rebuild_cashflows(fresh, login)
    return len(new_rows), len(fresh)


def rebuild_cashflows(all_deals: list[dict], login: str) -> list[dict]:
    flows = []
    for row in all_deals:
        if row["type"] not in CASHFLOW_TYPES:
            continue
        if row["type"] == 3:
            kind = "credit"
        else:
            kind = "deposit" if row["profit"] >= 0 else "withdrawal"
        dt = datetime.fromisoformat(row["time"])
        flows.append({
            "timestamp": row["time"],
            "date": dt.date().isoformat(),
            "amount": round(row["profit"], 2),
            "kind": kind,
            "comment": row["comment"],
            "account": login,
            "ticket": row["ticket"],
        })
                                                                                               
    existing = read_jsonl(CASHFLOWS)
    merged = {(r.get("account", "?"), r.get("ticket", r["timestamp"])): r for r in existing}
    for r in flows:
        merged[(r["account"], r["ticket"])] = r
    out = sorted(merged.values(), key=lambda r: r["timestamp"])
    write_jsonl_atomic(CASHFLOWS, out)
    return out


def clean_equity_series(all_deals: list[dict]) -> list[tuple[str, float, float]]:
    """Връща списък от (timestamp, clean_equity, running_balance) по сделка."""
    rows = sorted(all_deals, key=lambda r: (r["time"], r["ticket"]))
    series = []
    running_balance = 0.0
    running_cash = 0.0
    for row in rows:
        pnl = row["profit"] + row["commission"] + row["swap"]
        running_balance += pnl
        if row["type"] in CASHFLOW_TYPES:
            running_cash += row["profit"]
        series.append((row["time"], running_balance - running_cash, running_balance))
    return series


def week_bounds_utc(day: datetime) -> tuple[str, str]:
    iso = day.isocalendar()
    start = day - timedelta(days=iso.weekday - 1)
    end = start + timedelta(days=7)
    return start.date().isoformat(), end.date().isoformat()


def cmd_snapshot() -> dict:
    flows_before = {(f["timestamp"], f["amount"], f["kind"], f["comment"])
                    for f in read_jsonl(CASHFLOWS)}
    new_count, total = sync_journal()
    deals = read_jsonl(DEALS_JOURNAL)
    flows = read_jsonl(CASHFLOWS)
    series = clean_equity_series(deals)
    clean_now = series[-1][1] if series else 0.0
    balance_now = series[-1][2] if series else 0.0
    peak = max((v for _, v, _ in series), default=clean_now)
    dd_pct = round((peak - clean_now) / peak * 100.0, 2) if peak > 0 else 0.0

    equity_now = None
    try:
        mt5 = mt5_connect()
        try:
            ai = mt5.account_info()
            if ai is not None:
                balance_now = float(ai.balance)
                equity_now = float(ai.equity)
        finally:
            mt5.shutdown()
    except Exception:
        pass

    today = datetime.now(timezone.utc)
    w_start, w_end = week_bounds_utc(today)
    dep_wtd = round(sum(f["amount"] for f in flows
                        if f["kind"] == "deposit" and w_start <= f["date"] < w_end), 2)
    wd_wtd = round(sum(-f["amount"] for f in flows
                       if f["kind"] == "withdrawal" and w_start <= f["date"] < w_end), 2)

    daily = {}
    if EQUITY_DAILY.exists():
        try:
            daily = json.loads(EQUITY_DAILY.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            daily = {}
    key = today.date().isoformat()
    daily[key] = {
        "date": key,
        "balance": round(balance_now, 2),
        "equity": round(equity_now, 2) if equity_now is not None else None,
        "trading_equity_clean": round(clean_now, 2),
        "peak_clean": round(peak, 2),
        "dd_clean_pct": dd_pct,
        "deposits_wtd": dep_wtd,
        "withdrawals_wtd": wd_wtd,
    }
    write_json_atomic(EQUITY_DAILY, daily)
    snap = daily[key]
    print(f"[snapshot] {key}: balance={snap['balance']} equity={snap['equity']} "
          f"clean={snap['trading_equity_clean']} peak={snap['peak_clean']} "
          f"dd={snap['dd_clean_pct']}% deposits_wtd={snap['deposits_wtd']} "
          f"withdrawals_wtd={snap['withdrawals_wtd']}")
    print(f"[journal] нови сделки: {new_count}, общо: {total}")
    notify_snapshot(snap, flows, flows_before, key)
    return snap


def notify_snapshot(snap: dict, flows: list[dict], flows_before: set, day: str) -> None:
    """Нотификации през engine\\notify.py — best-effort, не чупи snapshot-а."""
    try:
        import notify
        notify.send("info", "status",
                    f"Дневна снимка {day}: баланс {snap['balance']:.2f} €, "
                    f"чиста крива {snap['trading_equity_clean']:.2f} €, "
                    f"DD {snap['dd_clean_pct']}% · днес: депозити "
                    f"{snap['deposits_wtd']:.2f} € / тегления {snap['withdrawals_wtd']:.2f} €")
        for f in flows:
            key = (f["timestamp"], f["amount"], f["kind"], f["comment"])
            if key in flows_before:
                continue
            sign = "+" if f["amount"] >= 0 else ""
            notify.send("info", "cashflow",
                        f"Нов паричен поток: {f['kind']} {sign}{f['amount']:.2f} €"
                        + (f" — {f['comment']}" if f["comment"] else ""))
    except Exception:
        pass


def cmd_verify() -> None:
    new_count, total = sync_journal()
    deals = read_jsonl(DEALS_JOURNAL)
    flows = read_jsonl(CASHFLOWS)
    series = clean_equity_series(deals)
    clean_now = series[-1][1] if series else 0.0
    balance_now = series[-1][2] if series else 0.0
    peak = max((v for _, v, _ in series), default=clean_now)
    equity_now = None
    try:
        mt5 = mt5_connect()
        try:
            ai = mt5.account_info()
            if ai is not None:
                balance_now = float(ai.balance)
                equity_now = float(ai.equity)
        finally:
            mt5.shutdown()
    except Exception as exc:
        print(f"[warn] MT5 account_info недостъпен, използвам журнала: {exc}")

    print("=" * 72)
    print("ПРОВЕРКА НА ПАРИЧНИТЕ ПОТОЦИ (последни 30 дни, UTC)")
    print("=" * 72)
    cutoff = datetime.now(timezone.utc) - timedelta(days=30)
    recent = [f for f in flows if datetime.fromisoformat(f["timestamp"]) >= cutoff]
    if not recent:
        print("  (няма парични потоци за периода)")
    for f in recent:
        sign = "+" if f["amount"] >= 0 else ""
        print(f"  {f['date']}  {f['kind']:<10} {sign}{f['amount']:>10.2f} EUR  {f['comment']}")
    print(f"  Общо депозити (всички): "
          f"{round(sum(f['amount'] for f in flows if f['kind'] == 'deposit'), 2)} EUR")
    print(f"  Общо тегления (всички): "
          f"{round(sum(-f['amount'] for f in flows if f['kind'] == 'withdrawal'), 2)} EUR")

    print()
    print("=" * 72)
    print("ПОСЛЕДНИ 10 СДЕЛКИ (от журнала)")
    print("=" * 72)
    for row in deals[-10:]:
        t = row["time"].replace("T", " ").replace("+00:00", "Z")
        print(f"  #{row['ticket']} {t} {row['type_name']:<8} "
              f"{row['symbol']:<10} pnl={row['profit'] + row['commission'] + row['swap']:>8.2f}  {row['comment']}")

    dd_pct = round((peak - clean_now) / peak * 100.0, 2) if peak > 0 else 0.0
    print()
    print("=" * 72)
    print("СВОДКА")
    print("=" * 72)
    print(f"  balance:              {balance_now:.2f} EUR")
    print(f"  equity:               {equity_now if equity_now is not None else 'няма данни'}")
    print(f"  чист търговски equity: {clean_now:.2f} EUR  (balance минус нетни парични потоци)")
    print(f"  връх (clean):         {peak:.2f} EUR")
    print(f"  сегашен DD (clean):   {dd_pct}%")
    print(f"[journal] нови сделки при този run: {new_count}, общо в журнала: {total}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Performance accounting (read-only MT5)")
    parser.add_argument("--verify", action="store_true", help="отчет за парични потоци и сделки")
    parser.add_argument("--snapshot", action="store_true", help="записва днешната дневна снимка")
    args = parser.parse_args()
    try:
        if args.snapshot:
            cmd_snapshot()
        else:
            cmd_verify()
    except Exception as exc:
        print(f"[грешка] {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
