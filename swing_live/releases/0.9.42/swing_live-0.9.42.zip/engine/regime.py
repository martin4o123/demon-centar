                       
"""Режимен класификатор — inference върху живи барове (чист numpy, без зависимости).

Зарежда config/regime_weights.json (обучен от scripts/train_regime.py върху 14 г.
данни). Двигателят пита режима всеки цикъл и мащабира риска:
  trending-up/down → x1.1 · ranging → x0.75 · crisis → x0.5
Плюс гейт: при confidence < 0.55 множителят е 1.0 (не гадаем на несигурен режим).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

BASE_DIR = Path(__file__).resolve().parent.parent
WEIGHTS = BASE_DIR / "config" / "regime_weights.json"


def _ema(v: np.ndarray, n: int) -> np.ndarray:
    a = 2 / (n + 1)
    out = np.empty_like(v, dtype=float)
    out[0] = v[0]
    for i in range(1, len(v)):
        out[i] = a * v[i] + (1 - a) * out[i - 1]
    return out


class RegimeClassifier:
    def __init__(self, path: Path = WEIGHTS):
        self.ok = False
        try:
            d = json.loads(Path(path).read_text(encoding="utf-8"))
            self.classes = d["classes"]
            self.mu = np.array(d["mu"], dtype=float)
            self.sd = np.array(d["sd"], dtype=float)
            self.W = np.array(d["W"], dtype=float)
            self.b = np.array(d["b"], dtype=float)
            self.risk_map = {k: float(v) for k, v in d["risk_map"].items()}
            self.ok = True
        except Exception:
            self.ok = False

    def infer(self, highs: list[float], lows: list[float], closes: list[float]) -> dict:
        """{regime, confidence, risk_mult} — при липса на данни: ranging, 1.0."""
        if not self.ok or len(closes) < 210:
            return {"regime": "ranging", "confidence": 0.0, "risk_mult": 1.0}
        c = np.asarray(closes[-260:], dtype=float)
        h = np.asarray(highs[-260:], dtype=float)
        l = np.asarray(lows[-260:], dtype=float)
        e200 = _ema(c, 200)
        e20 = _ema(c, 20)
        d = np.diff(c, prepend=c[0])
        au = _ema(np.maximum(d, 0), 14)
        ad = _ema(np.maximum(-d, 0), 14)
        r14 = 100 - 100 / (1 + au / np.maximum(ad, 1e-9))
        tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)), np.abs(l - np.roll(c, 1))))
        tr[0] = h[0] - l[0]
        a = np.empty_like(tr)
        a[0] = tr[0]
        for i in range(1, len(tr)):
            a[i] = tr[i] / 14 + (13 / 14) * a[i - 1]
        i = len(c) - 1
        atr_pct = a[i] / c[i]
        slope = (e20[i] - e20[i - 5]) / (5 * max(a[i], 1e-10))
        trend_dist = (c[i] - e200[i]) / max(10 * a[i], 1e-10)
        vol_ratio = a[i] / max(a[max(0, i - 50):i].mean(), 1e-10)
        ma20 = c[max(0, i - 19):i + 1].mean()
        sd20 = c[max(0, i - 19):i + 1].std() or 1e-10
        bb_pos = (c[i] - ma20) / (2 * sd20)
        x = np.array([trend_dist, slope, r14[i] / 100.0, atr_pct, vol_ratio, bb_pos], dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        xz = (x - self.mu) / self.sd
        z = xz @ self.W + self.b
        z = z - z.max()
        p = np.exp(z) / np.exp(z).sum()
        k = int(p.argmax())
        regime = self.classes[k]
        conf = float(p[k])
        mult = self.risk_map.get(regime, 1.0)
        if conf < 0.55:
            mult = 1.0                                       
        return {"regime": regime, "confidence": round(conf, 3), "risk_mult": mult}
