                       
"""Централен нотификационен bus (Telegram-еквивалент).

- append JSON в logs/messages.jsonl: {ts (UTC ISO), level, category, text}
- ротация: >5MB -> messages.jsonl.old (пази се 1 стар)
- Telegram relay: config/notify.json -> telegram.{enabled,token,chat_id};
  best-effort POST към api.telegram.org (timeout 10 s). При грешка се пише
  ПРЕДУПРЕЖДЕНИЕ в същия jsonl (category=system), никога не пада.

CLI:
  py -3.12 engine\notify.py --level warning --category system --text "..."
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"
MESSAGES = LOGS_DIR / "messages.jsonl"
CONFIG = BASE_DIR / "config" / "notify.json"
MAX_BYTES = 5 * 1024 * 1024
TIMEOUT = 10

LEVELS = ("info", "warning", "alert")
CATEGORIES = ("status", "trade", "system", "update", "cashflow", "research")

DEFAULT_CONFIG = {
    "telegram": {
        "enabled": False,
        "token": "",
        "chat_id": "",
        "setup_hint": ("За включване на Telegram нотификациите: създай бот чрез @BotFather "
                       "в Telegram и копирай токена в \"token\"; вземи своя chat_id (напр. от "
                       "@userinfobot) и го сложи в \"chat_id\"; сетни \"enabled\": true. "
                       "Без стойности relay-ът е изключен и съобщенията остават само в "
                       "logs\\messages.jsonl (виж ги в таблото, секция „Съобщения“).")
    }
}


def ensure_config() -> None:
    try:
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        if not CONFIG.exists():
            CONFIG.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2),
                              encoding="utf-8")
    except Exception:
        pass


def rotate_if_needed() -> None:
    try:
        if MESSAGES.exists() and MESSAGES.stat().st_size > MAX_BYTES:
            old = MESSAGES.with_name(MESSAGES.name + ".old")
            if old.exists():
                old.unlink()
            MESSAGES.replace(old)
    except Exception:
        pass


def append(level: str, category: str, text: str) -> dict:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    rotate_if_needed()
    row = {
        "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "level": level,
        "category": category,
        "text": text,
    }
    with MESSAGES.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row


def telegram_settings() -> dict:
    try:
        cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
        return cfg.get("telegram") or {}
    except Exception:
        return {}


def relay(row: dict) -> str | None:
    """Връща None ако няма relay/успех, или текст на грешката."""
    tg = telegram_settings()
    if not tg.get("enabled"):
        return None
    token = (tg.get("token") or "").strip()
    chat_id = str(tg.get("chat_id") or "").strip()
    if not token or not chat_id:
        return "telegram е enabled, но липсват token/chat_id"
    payload = {"chat_id": chat_id,
               "text": f"[{row['level']}/{row['category']}] {row['text']}"}
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            if resp.status != 200:
                return f"HTTP {resp.status}"
    except Exception as exc:
        return f"{type(exc).__name__}: {exc}"
    return None


def send(level: str, category: str, text: str) -> dict:
    """Основна точка за продуцентите. Никога не повдига изключение."""
    ensure_config()
    row = append(level, category, text)
    err = relay(row)
    if err:
                                                                     
        append("warning", "system",
               f"Telegram relay грешка ({row['category']} съобщението не е изпратено): {err}")
    return row


def main() -> int:
    ap = argparse.ArgumentParser(description="Централен нотификационен bus")
    ap.add_argument("--level", choices=LEVELS, default="info")
    ap.add_argument("--category", choices=CATEGORIES, default="status")
    ap.add_argument("--text", required=True)
    args = ap.parse_args()
    try:
        send(args.level, args.category, args.text)
        print(f"[notify] OK {args.level}/{args.category}")
    except Exception as exc:                  
        print(f"[notify] грешка (не пада): {exc}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
