                       
"""Пазителен слой за S5 — чете guard_state.json / guard_events.json (писани от
scripts\\fetch_guard.py) и връща решения за търговията:

  - blackout около High икономически събития (15 мин преди -> 30 мин след);
  - гео риск множител върху risk_pct (EXTREME/CRISIS = пълен блок);
  - news velocity ограничение;
  - контрариан sentiment филтър на посоката (logs\\sentiment.json);
  - социален пулс (logs\\social_pulse.json, писан от scripts\\fetch_social.py):
    crowd консенсус -> контрарианно ограничение на посоката + риск x0.75.

Чисти функции, без MT5 зависимости. Липсващ/счупен файл = няма риск
(engine-ът не спира, просто няма ограничения).
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"

                                     
_GEO_MULT = {"EXTREME": 0.0, "CRISIS": 0.0, "HIGH": 0.5, "MEDIUM": 0.75}

                                              
PRE_MIN = 15
POST_MIN = 30


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _cfg_symbols(logs_dir: Path) -> list[str]:
    """Символите от engine\\config.json (спрямо logs_dir) — за валутния филтър."""
    try:
        cfg = json.loads((logs_dir.parent / "engine" / "config.json").read_text(encoding="utf-8"))
        return [str(s).upper().strip() for s in (cfg.get("symbols") or [])]
    except Exception:
        return []


def symbol_currencies(sym: str) -> set[str]:
    """'USDJPY' -> {'USD','JPY'}; 6+ символа -> две 3-буквени валути."""
    sym = str(sym or "").upper().strip()
    if len(sym) >= 6:
        return {sym[:3], sym[3:6]}
    return {sym} if sym else set()


def guard_snapshot(logs_dir: Path | str | None = None) -> dict:
    """Чете logs\\guard_state.json + logs\\guard_events.json.

    Връща {"fetched_utc","geo_level","velocity","next_high_impact_hours",
    "events_total","events","watch_currencies"}. Липсващи файлове -> defaults
    (няма риск); watch_currencies = валутите на cfg символите (празно = всички)."""
    logs = Path(logs_dir) if logs_dir else LOGS_DIR
    state = _read_json(logs / "guard_state.json")
    events = (_read_json(logs / "guard_events.json").get("events") or [])
    watch: set[str] = set()
    for sym in _cfg_symbols(logs):
        watch |= symbol_currencies(sym)
    return {
        "fetched_utc": state.get("fetched_utc"),
        "geo_level": str(state.get("geo_level") or "NONE"),
        "velocity": str(state.get("velocity") or "NORMAL"),
        "next_high_impact_hours": state.get("next_high_impact_hours") or [],
        "events_total": int(state.get("events_total") or len(events) or 0),
        "events": events,
        "watch_currencies": sorted(watch),
    }


def _event_dt(ev: dict) -> datetime | None:
    try:
        dt = datetime.fromisoformat(str(ev.get("ts_utc") or ""))
    except Exception:
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)


def _event_matches(ev: dict, currencies: set[str]) -> bool:
    cur = str(ev.get("currency") or "").upper().strip()
    if not cur or cur == "ALL":
        return True
    if not currencies:                                           
        return True
    return cur in currencies


def blackout_due_to_events(snapshot: dict, now_utc: datetime, pre_min: int = PRE_MIN,
                           post_min: int = POST_MIN, currencies: set[str] | None = None) -> str | None:
    """Причина (str) ако сме в прозореца преди/след High събитие, иначе None.

    currencies=None -> watch_currencies от snapshot; празен списък = всички валути.
    Важат само High събитията; Medium/Low не пипат търговията."""
    if currencies is None:
        currencies = set(snapshot.get("watch_currencies") or [])
    else:
        currencies = set(currencies)
    for ev in snapshot.get("events") or []:
        if ev.get("impact") != "High":
            continue
        dt = _event_dt(ev)
        if dt is None or not _event_matches(ev, currencies):
            continue
        if dt - timedelta(minutes=pre_min) <= now_utc <= dt + timedelta(minutes=post_min):
            mins = (dt - now_utc).total_seconds() / 60.0
            side = f"след {int(round(mins))} мин" if mins >= 0 else f"преди {int(round(-mins))} мин"
            return (f"блекаут: High събитие „{ev.get('name') or '?'}“ "
                    f"({ev.get('currency') or '?'}) {side}")
    return None


def risk_multiplier(snapshot: dict) -> float:
    """Множител върху risk_pct: EXTREME/CRISIS = 0.0 (пълен блок), HIGH = 0.5,
    MEDIUM = 0.75; velocity HIGH свива до <= 0.5; иначе 1.0."""
    mult = _GEO_MULT.get(str(snapshot.get("geo_level") or "NONE"), 1.0)
    if snapshot.get("velocity") == "HIGH":
        mult = min(mult, 0.5)
    return mult


def sentiment_allowed_direction(logs_dir: Path | str | None = None) -> str | None:
    """Контрариан филтър от logs\\sentiment.json: LONG_HEAVY -> 'SELL',
    SHORT_HEAVY -> 'BUY'; липсващ файл/друга стойност -> None (няма ограничение)."""
    try:
        bias = _read_json(Path(logs_dir) / "sentiment.json" if logs_dir
                          else LOGS_DIR / "sentiment.json").get("retail_bias")
    except Exception:
        return None
                                                                                   
    return _contrarian_direction("LONG" if bias == "LONG_HEAVY" else
                                 "SHORT" if bias == "SHORT_HEAVY" else "")


def sentiment_note(logs_dir: Path | str | None = None) -> str | None:
    """Човешка бележка за контрариан ограничението (за reason/табло); None = няма."""
    direction = sentiment_allowed_direction(logs_dir)
    if direction == "SELL":
        return "sentiment: retail LONG_HEAVY — контрариан, само SELL сигнали"
    if direction == "BUY":
        return "sentiment: retail SHORT_HEAVY — контрариан, само BUY сигнали"
    return None


                                                                                
SOCIAL_MAX_AGE_HOURS = 2.0                                
SOCIAL_MIN_POSTS = 6                                      
SOCIAL_DOMINANCE = 0.7                                 
SOCIAL_RISK_MULT = 0.75                                         

                                              
_CONTRARIAN_DIR = {"LONG": "SELL", "SHORT": "BUY"}


def _contrarian_direction(crowd: str) -> str | None:
    return _CONTRARIAN_DIR.get(str(crowd or "").upper())


def _social_doc(logs_dir: Path | str | None) -> dict:
    try:
        return _read_json(Path(logs_dir) / "social_pulse.json" if logs_dir
                          else LOGS_DIR / "social_pulse.json")
    except Exception:
        return {}


def social_bias(logs_dir: Path | str | None = None) -> dict:
    """Чете logs\\social_pulse.json. Липсващ/счупен/стар (>2 ч) -> {"usable": False}.

    Иначе: при bull+bear >= 6 и max/(bull+bear) >= 0.7 ->
    {"usable": True, "crowd": "LONG"|"SHORT", "ratio": 0.xx, "bull": n, "bear": n};
    без консенсус -> {"usable": True, "crowd": None, "bull": n, "bear": n}."""
    doc = _social_doc(logs_dir)
    if not doc:
        return {"usable": False}
    try:
        dt = datetime.fromisoformat(str(doc.get("fetched_utc") or ""))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    except Exception:
        return {"usable": False}
    if abs((datetime.now(timezone.utc) - dt).total_seconds()) > SOCIAL_MAX_AGE_HOURS * 3600:
        return {"usable": False}
    counts = doc.get("counts") or {}
    bull = int(counts.get("bull") or 0)
    bear = int(counts.get("bear") or 0)
    total = bull + bear
    if total >= SOCIAL_MIN_POSTS:
        top = max(bull, bear)
        if top / total >= SOCIAL_DOMINANCE:
            crowd = "LONG" if bull >= bear else "SHORT"
            return {"usable": True, "crowd": crowd, "ratio": round(top / total, 2),
                    "bull": bull, "bear": bear}
    return {"usable": True, "crowd": None, "bull": bull, "bear": bear}


def social_allowed_direction(logs_dir: Path | str | None = None) -> str | None:
    """Контрариан филтър от социалния пулс: crowd LONG -> 'SELL_only'
    (тълпата е лонг -> само SELL входове), crowd SHORT -> 'BUY_only'; иначе None."""
    bias = social_bias(logs_dir)
    if bias.get("usable") and bias.get("crowd"):
        return _contrarian_direction(bias["crowd"]) + "_only"
    return None


def social_note(logs_dir: Path | str | None = None) -> str | None:
    """Човешка бележка за социалното контрариан ограничение; None = няма."""
    bias = social_bias(logs_dir)
    if bias.get("usable") and bias.get("crowd"):
        direction = _contrarian_direction(bias["crowd"])
        return (f"social: crowd {bias['crowd']} ({bias.get('bull', 0)}B/{bias.get('bear', 0)}S, "
                f"ratio {bias.get('ratio')}) — контрариан, само {direction} сигнали")
    return None
