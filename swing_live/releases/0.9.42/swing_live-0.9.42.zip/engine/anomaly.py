                       
"""Детектор на аномалии (Ниво 1) — „опипва средата“.

Следи три сигнала всеки цикъл:
  spread_jump — текущият спред > spread_atr_max × ATR (пазарът се разтваря опасно)
  ping_high   — ping към сървъра > праг (връзката се влошава; риск от лошо изпълнение)
  slip_high   — проскалзяне при последното затваряне > праг (брокерът изпълнява лошо)

При аномалия: notify + запис в events.jsonl + risk_mult за цикъла (0.7 при една,
0.5 при две+). Никога не блокира сам — само вдига бдителността. Данните за ping/спред
идват от MT5; slippage се мери при record_close.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
EVENTS = BASE_DIR / "logs" / "events.jsonl"
PING_THRESHOLD_MS = 3000                                                                              
SLIP_PIPS_THRESHOLD = 5.0                                          
_NOTIFY_EVERY_S = 3600                                                                   
_last_notify: dict[str, float] = {}


def _throttled(key: str) -> bool:
    now = time.time()
    if now - _last_notify.get(key, 0) < _NOTIFY_EVERY_S:
        return True
    _last_notify[key] = now
    return False


def _log_event(kind: str, detail: str) -> None:
    try:
        EVENTS.parent.mkdir(parents=True, exist_ok=True)
        with EVENTS.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z", time.gmtime()),
                                 "kind": kind, "detail": detail}, ensure_ascii=False) + "\n")
    except Exception:
        pass


def check_cycle(shim, cfg: dict, symbol_examples: list[tuple[str, float]]) -> tuple[float, list[str]]:
    """Връща (risk_mult, [аномалии]). symbol_examples: (символ, текущ спред в цена)."""
    notes: list[str] = []
    mult = 1.0
                        
    try:
        cap = float(cfg.get("spread_atr_max", 0.05))
        for sym, spread_price in symbol_examples:
            rates = shim.rates_d1(sym, 30)
            if not rates:
                continue
            h = [float(r["high"]) for r in rates]
            l = [float(r["low"]) for r in rates]
            c = [float(r["close"]) for r in rates]
            tr = max(h[-1] - l[-1], abs(h[-1] - c[-2]) if len(c) > 1 else 0,
                     abs(l[-1] - c[-2]) if len(c) > 1 else 0)
            atr = tr if tr > 0 else (max(h) - min(l)) / len(h)
            if atr > 0 and spread_price > cap * atr:
                notes.append(f"спред {sym} {spread_price:.5f} > {cap}×ATR {atr:.5f}")
    except Exception:
        pass
                                                                                    
                                        
    try:
        ti = shim.mt5.terminal_info()
        ping = int(getattr(ti, "ping_last", 0) or 0)
        if 1000 < ping <= 30000 and ping > PING_THRESHOLD_MS:
            notes.append(f"ping {ping} ms > {PING_THRESHOLD_MS} ms")
    except Exception:
        pass
    if not notes:
        return 1.0, []
    mult = 0.7 if len(notes) == 1 else 0.5
    _log_event("anomaly", "; ".join(notes) + f" — риск x{mult:.1f} този цикъл")
                                                                            
    fresh = [n for n in notes if not _throttled(n.split()[0])]
    return mult, fresh


def check_slippage(sym: str, expected_price: float, filled_price: float,
                   direction: str, pip: float) -> str | None:
    """След затваряне: ако |filled − expected| > праг → запис + notify текст."""
    try:
        slip = abs(float(filled_price) - float(expected_price)) / max(pip, 1e-10)
        if slip > SLIP_PIPS_THRESHOLD:
            msg = (f"проскалзяне {slip:.1f} пипа при затваряне {sym} "
                   f"({direction}: исках {expected_price:.5f}, получих {filled_price:.5f})")
            _log_event("anomaly_slippage", msg)
            return msg
    except Exception:
        pass
    return None
