                       
"""Сравнява RSI(2) прагове 10/90 vs 15/85 vs 20/80 върху S5 бектеста (4 двойки)."""
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(r"D:\AIRobot\admiral_swing_live")
SRC = (BASE / "scripts" / "backtest_75.py").read_text(encoding="utf-8")

LONG_LINE = "row.prev_rsi2 < 10.0"
SHORT_LINE = "row.prev_rsi2 > 90.0"
assert LONG_LINE in SRC and SHORT_LINE in SRC, "шаблоните липсват в backtest_75.py"

VARIANTS = {"10/90 (текущ)": (10.0, 90.0), "15/85": (15.0, 85.0), "20/80": (20.0, 80.0)}
SYMS = ["EURUSD", "GBPUSD", "AUDUSD", "USDJPY"]

results = {}
for name, (lo, hi) in VARIANTS.items():
    code = SRC.replace(LONG_LINE, f"row.prev_rsi2 < {lo}").replace(SHORT_LINE, f"row.prev_rsi2 > {hi}")
    td = Path(tempfile.mkdtemp(prefix="s5bt_"))
    mod_path = td / "bt_variant.py"
    mod_path.write_text(code, encoding="utf-8")
    spec = importlib.util.spec_from_file_location(f"bt_{int(lo)}_{int(hi)}", mod_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.CACHE = BASE / "data_cache"                                                           
    mod.DATA_DIR = Path(r"C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\MQL5\Files")
    mod.TRADES_DIR = mod.CACHE                                                         
    feat = {s: mod.build_features_s5(s) for s in SYMS}
    tr = mod.run_s5(feat, SYMS, tag="s5")
    last_prices = {s: float(mod.load_csv(s, "D1")["close"].iloc[-1]) for s in SYMS}
    peur = mod.pip_eur_map_for(SYMS, last_prices)
    m = mod.strat_metrics(tr, peur)
    results[name] = m
    print(f"=== {name}: сделки={m.get('n')} ({m.get('trades_month', 0):.2f}/мес) "
          f"win={m.get('wr', 0)*100:.1f}% PF={m.get('pf')} PF_oos={m.get('pf_oos')} "
          f"expR={m.get('exp_r')} maxDD={m.get('maxdd_r')}R ruin17%={m.get('ror17')}")

out = BASE / "report" / "rsi_threshold_variants.json"
out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("записан", out)
