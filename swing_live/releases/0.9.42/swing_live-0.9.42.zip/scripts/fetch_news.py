                       
"""Събирач на икономически новини от GNews -> кеш за news_blackout филтъра.

Чете ключа от config\\news_provider.json (gnews_api_key); пише кеша на пътя
news_blackout.path от engine\\config.json (fallback: стандартният път в
AppData). Форматът на кеша е този, който engine_s5.news_blackout_active()
очаква: {collected_utc, collected_epoch, cached, items:[{provider, source,
title, summary, url, published_utc}]}.

CLI: без аргументи = изтегли + запиши кеша; --check = само проверка на ключа
(печата брой новини, БЕЗ запис). При грешка: ясно съобщение на stderr, exit 1,
съществуващият кеш НЕ се пипа.
"""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
PROVIDER_FILE = BASE_DIR / "config" / "news_provider.json"
ENGINE_CONFIG = BASE_DIR / "engine" / "config.json"
NEWS_CACHE_DEFAULT = Path(r"C:\Users\mgeor\AppData\Local\AdmiralBeta\config\news_cache.json")

API_URL = ("https://gnews.io/api/v4/search?"
           "q=federal%20reserve%20OR%20central%20bank%20OR%20interest%20rates%20OR%20"
           "inflation%20OR%20CPI%20OR%20FOMC&lang=en&max=10&apikey=")
TIMEOUT = 20


def load_api_key(provider_path: Path | None = None) -> str:
    try:
        data = json.loads((provider_path or PROVIDER_FILE).read_text(encoding="utf-8"))
        return str(data.get("gnews_api_key") or "").strip()
    except Exception:
        return ""


def resolve_cache_path(engine_config_path: Path | None = None) -> Path:
    try:
        cfg = json.loads((engine_config_path or ENGINE_CONFIG).read_text(encoding="utf-8"))
        p = str((cfg.get("news_blackout") or {}).get("path") or "").strip()
        if p:
            return Path(p)
    except Exception:
        pass
    return NEWS_CACHE_DEFAULT


def fetch_articles(api_key: str, timeout: int = TIMEOUT) -> tuple[list[dict], str | None]:
    """Връща (items, None) при успех или ([], грешка_BG). Не пипа файлове."""
    req = urllib.request.Request(API_URL + api_key,
                                 headers={"User-Agent": "admiral-swing-live/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return [], f"GNews HTTP грешка {exc.code} ({exc.reason})"
    except urllib.error.URLError as exc:
        return [], f"Няма връзка с GNews: {exc.reason}"
    except Exception as exc:
        return [], f"Грешка при четене от GNews: {exc}"
    items = []
    for art in payload.get("articles") or []:
        src = art.get("source") or {}
        items.append({
            "provider": "gnews",
            "source": str(src.get("name") or ""),
            "title": str(art.get("title") or ""),
            "summary": str(art.get("description") or ""),
            "url": str(art.get("url") or ""),
            "published_utc": str(art.get("publishedAt") or "").replace("Z", "+00:00"),
        })
    return items, None


def build_cache(items: list[dict]) -> dict:
    now = datetime.now(timezone.utc)
    return {"collected_utc": now.isoformat(),
            "collected_epoch": now.timestamp(),
            "cached": False,
            "items": items}


def write_cache(items: list[dict], cache_path: Path) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache_path.with_name(cache_path.name + ".tmp")
    tmp.write_text(json.dumps(build_cache(items), ensure_ascii=False, indent=1) + "\n",
                   encoding="utf-8")
    tmp.replace(cache_path)


def check_key(api_key: str, timeout: int = TIMEOUT) -> tuple[bool, str]:
    """Само проверка (без запис): (ok, 'N новини' | грешка_BG)."""
    items, err = fetch_articles(api_key, timeout=timeout)
    if err:
        return False, err
    return True, f"{len(items)} новини"


def run(argv: list[str] | None = None, *, provider_path: Path | None = None,
        engine_config_path: Path | None = None, cache_path: Path | None = None) -> int:
    argv = list(sys.argv[1:]) if argv is None else list(argv)
    check_only = "--check" in argv
    key = load_api_key(provider_path)
    if not key:
        print("Липсва gnews_api_key в config\\news_provider.json — вземи безплатен "
              "ключ от https://gnews.io и го запиши.", file=sys.stderr)
        return 1
    items, err = fetch_articles(key)
    if err:
        print(err, file=sys.stderr)
        return 1
    if check_only:
        print(f"{len(items)} новини")
    else:
        path = cache_path or resolve_cache_path(engine_config_path)
        write_cache(items, path)
        print(f"{len(items)} новини -> {path}")
    return 0


if __name__ == "__main__":
    sys.exit(run())
