                                                                             
 
             
                                                                           
                                                                                  
                                                               
                                                                                
 
                                                                           
                                                              

import os
import sys
import json
import time
import glob
import subprocess

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PRODUCT = r"C:\Users\mgeor\AppData\Local\AdmiralBeta"
FILES = os.path.join(PRODUCT, "mt5_portable", "MQL5", "Files")
TERMINAL = os.path.join(PRODUCT, "mt5_portable", "terminal64.exe")
ENGINE_START = os.path.join(PRODUCT, "START_ADMIRAL_BETA.cmd")
HB = os.path.join(PRODUCT, "logs", "beta_heartbeat.json")
STATE = os.path.join(PRODUCT, "logs", "account_risk_state.json")
SYMBOLS = ["GBPUSD", "USDCAD", "AUDUSD", "EURNZD", "EURCHF"]
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def notify(level, category, text):
    """Central notification bus (engine\\notify.py) — best-effort."""
    try:
        subprocess.run([sys.executable, os.path.join(BASE_DIR, "engine", "notify.py"),
                        "--level", level, "--category", category, "--text", text],
                       capture_output=True, timeout=60)
    except Exception:
        pass

def ok(name, cond, detail=""):
    mark = "PASS" if cond else "FAIL"
    print(f"[{mark}] {name}" + (f" — {detail}" if detail else ""))
    return cond

def file_age(path):
    return time.time() - os.path.getmtime(path) if os.path.exists(path) else None

def main():
    results = []

    print("=== ADMIRAL PREFLIGHT ===\n")
    stop_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), "STOP.flag")
    results.append(ok("STOP.flag липсва (не сме в ръчен стоп)", not os.path.exists(stop_flag)))

                 
    r = os.popen('tasklist /FI "IMAGENAME eq terminal64.exe" /NH').read()
    term_running = "terminal64.exe" in r.lower()
    results.append(ok("Portable MT5 терминал върви", term_running))
    results.append(ok("terminal64.exe път съществува", os.path.exists(TERMINAL)))

                         
    hb_age = file_age(HB)
    results.append(ok("Engine heartbeat съществува", hb_age is not None))
    if hb_age is not None:
        results.append(ok("Heartbeat свеж (<15 мин)", hb_age < 900, f"преди {int(hb_age)} сек"))
        try:
            hb = json.load(open(HB, encoding="utf-8"))
            results.append(ok("account_mode = LIVE", hb.get("account_mode") == "LIVE", str(hb.get("account_mode"))))
            results.append(ok("execution_enabled = true", hb.get("execution_enabled") is True))
            results.append(ok("safe = true", hb.get("safe") is True, str(hb.get("detail"))))
        except Exception as e:
            results.append(ok("Heartbeat JSON четим", False, str(e)))

                                                                         
    now = time.localtime()
    weekday = now.tm_wday         
    hour = now.tm_hour
    market_open = weekday < 5 and 1 <= hour <= 23                                    
    for sym in SYMBOLS:
        p = os.path.join(FILES, f"mt5_status_{sym}.txt")
        age = file_age(p)
        if market_open:
            results.append(ok(f"status {sym} свеж (<60с)", age is not None and age < 60,
                              f"{'липсва' if age is None else str(int(age)) + ' сек'}"))
        else:
            results.append(ok(f"status {sym} съществува", age is not None))

                                    
    stale = glob.glob(os.path.join(FILES, "ai_signal*.txt"))
    results.append(ok("Няма неизядени ai_signal файлове", len(stale) == 0, f"{len(stale)} бр."))

                   
    try:
        st = json.load(open(STATE, encoding="utf-8"))
        peak = list(st.values())[0] if st else None
        results.append(ok("Peak equity записан", peak is not None, f"peak={peak}"))
        if peak:
            results.append(ok("Баланс в допустим диапазон (20–100)", 20 <= float(peak) <= 100, f"{peak}"))
    except Exception as e:
        results.append(ok("account_risk_state четим", False, str(e)))

             
    free = os.popen('powershell -NoProfile -Command "(Get-PSDrive C).Free"').read().strip()
    try:
        results.append(ok("Свободно място C: > 1 GB", int(free) > 1_000_000_000, f"{int(free)/1e9:.1f} GB"))
    except Exception:
        pass

    print()
    passed = sum(1 for r in results if r)
    print(f"Резултат: {passed}/{len(results)} PASS")
    if all(results):
        print("РЕШЕНИЕ: GO — всички проверки зелени.")
        notify("info", "status", f"Preflight GO — {passed}/{len(results)} проверки зелени.")
        return 0
    fails = len(results) - passed
    print("РЕШЕНИЕ: NO-GO — оправи FAIL-овете и пусни пак.")
    notify("alert", "system",
           f"Preflight NO-GO — {fails} FAIL проверки ({passed}/{len(results)} PASS). "
           "Виж изхода на scripts\\preflight.py.")
    return 1

if __name__ == "__main__":
    sys.exit(main())
