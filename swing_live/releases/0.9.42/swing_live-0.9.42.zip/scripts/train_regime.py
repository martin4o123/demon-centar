                       
"""Обучение на режимния класификатор (логистична регресия, чист numpy).

Етикети (правилни, честни — не от модела):
  crisis        — ATR% в топ 8% на разпределението (волатилностен шок)
  trending-up   — EMA20 наклон > +0.15×ATR/бар И цена > EMA200
  trending-down — EMA20 наклон < −0.15×ATR/бар И цена < EMA200
  ranging       — всичко останало

Изход: config/regime_weights.json (тежести, средни, стандартни отклонения, риск-карта)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE = Path(r"D:\AIRobot\admiral_swing_live")
DATA = BASE / "data_cache"
OUT = BASE / "config" / "regime_weights.json"
CLASSES = ["trending-up", "trending-down", "ranging", "crisis"]
PAIRS = ["USDJPY", "EURUSD", "GBPUSD", "AUDUSD", "USDCAD", "EURCHF", "EURNZD", "XAUUSD"]
FEAT_NAMES = ["trend_dist", "ema_slope", "rsi_n", "atr_pct", "vol_ratio", "bb_pos"]
RISK_MAP = {"trending-up": 1.1, "trending-down": 1.1, "ranging": 0.75, "crisis": 0.5}


def ema(v: np.ndarray, n: int) -> np.ndarray:
    a = 2 / (n + 1)
    out = np.empty_like(v)
    out[0] = v[0]
    for i in range(1, len(v)):
        out[i] = a * v[i] + (1 - a) * out[i - 1]
    return out


def atr(h: np.ndarray, l: np.ndarray, c: np.ndarray, n: int = 14) -> np.ndarray:
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)), np.abs(l - np.roll(c, 1))))
    tr[0] = h[0] - l[0]
    a = 1 / n
    out = np.empty_like(tr)
    out[0] = tr[0]
    for i in range(1, len(tr)):
        out[i] = a * tr[i] + (1 - a) * out[i - 1]
    return out


def rsi(c: np.ndarray, n: int = 14) -> np.ndarray:
    d = np.diff(c, prepend=c[0])
    up = np.maximum(d, 0)
    dn = np.maximum(-d, 0)
    au = ema(up, n)
    ad = ema(dn, n)
    rs = au / np.where(ad == 0, 1e-9, ad)
    return 100 - 100 / (1 + rs)


def features(df: pd.DataFrame) -> np.ndarray:
    c = df["close"].values.astype(float)
    h = df["high"].values.astype(float)
    l = df["low"].values.astype(float)
    e200 = ema(c, 200)
    e20 = ema(c, 20)
    a = atr(h, l, c)
    r14 = rsi(c, 14) / 100.0
    atr_pct = a / c
                                                           
    slope = np.zeros_like(c)
    slope[5:] = (e20[5:] - e20[:-5]) / (5 * np.maximum(a[5:], 1e-10))
    trend_dist = (c - e200) / np.maximum(10 * a, 1e-10)
    vol_ratio = a / np.maximum(pd.Series(a).rolling(50).mean().values, 1e-10)
    ma20 = pd.Series(c).rolling(20).mean().values
    sd20 = pd.Series(c).rolling(20).std().values
    bb_pos = np.where(sd20 > 0, (c - ma20) / (2 * sd20), 0.0)
    return np.column_stack([trend_dist, slope, r14, atr_pct, vol_ratio, bb_pos])


def labels(feat: np.ndarray, atr_pct_idx: int = 3) -> np.ndarray:
    n = len(feat)
    lab = np.full(n, 2, dtype=int)                                   
    crisis_thr = np.nanquantile(feat[:, atr_pct_idx], 0.92)
    for i in range(n):
        if feat[i, atr_pct_idx] >= crisis_thr:
            lab[i] = 3                              
        elif feat[i, 1] > 0.15 and feat[i, 0] > 0.05:
            lab[i] = 0                                   
        elif feat[i, 1] < -0.15 and feat[i, 0] < -0.05:
            lab[i] = 1                                     
    return lab


def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def train(X: np.ndarray, y: np.ndarray, epochs: int = 300, lr: float = 0.5,
          l2: float = 1e-3) -> tuple[np.ndarray, np.ndarray]:
    """Мултиклас логистична регресия с градиентно спускане. Връща (W, b)."""
    n, d = X.shape
    k = len(CLASSES)
    W = np.zeros((d, k))
    b = np.zeros(k)
    Y = np.eye(k)[y]
    for ep in range(epochs):
        p = softmax(X @ W + b)
        g = X.T @ (p - Y) / n + l2 * W
        gb = (p - Y).mean(axis=0)
        W -= lr * g
        b -= lr * gb
    return W, b


def main() -> int:
    Xs, ys = [], []
    for sym in PAIRS:
        p = DATA / f"{sym}_D1.parquet"
        if not p.exists():
            p = DATA / f"candle_history_{sym}_D1.parquet"
        if not p.exists():
            print(f"{sym}: няма данни")
            continue
        df = pd.read_parquet(p).sort_index()
        f = features(df)
        valid = ~np.isnan(f).any(axis=1)
        f = f[valid]
        Xs.append(f)
        ys.append(labels(f))
        print(f"{sym}: {len(f)} бара")
    X = np.vstack(Xs)
    y = np.concatenate(ys)
    mu = X.mean(axis=0)
    sd = X.std(axis=0) + 1e-9
    Xz = (X - mu) / sd
                                                                                      
                                                                 
    W, b = train(Xz, y)
    acc = float((softmax(Xz @ W + b).argmax(axis=1) == y).mean())
    print(f"\nточност върху обучението: {acc*100:.1f}%")
    counts = {CLASSES[k]: int((y == k).sum()) for k in range(len(CLASSES))}
    print("разпределение:", counts)
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(json.dumps({
        "schema": 1, "classes": CLASSES, "features": FEAT_NAMES,
        "mu": mu.tolist(), "sd": sd.tolist(),
        "W": W.tolist(), "b": b.tolist(),
        "risk_map": RISK_MAP, "trained_bars": int(len(X)), "train_acc": round(acc, 4),
    }, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"записано: {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
