"""Read-only MT5 account analytics; never updates strategy/demo state."""
from datetime import datetime,timezone,timedelta
from zoneinfo import ZoneInfo
import math

MAGIC=750501
DISPLAY_ZONE=ZoneInfo('Europe/Bucharest')
LABELS={'manual':'Ръчна','demon':'DEMON','other':'Друг робот','mixed':'Смесена','unknown':'Неизвестен вход'}

def epoch_utc(raw,server):
    # Verified on AdmiralsGroup-Live: Python epoch labels encode EET wall time.
    # Other servers retain the documented UTC convention; never infer from age.
    if not str(server).startswith('AdmiralsGroup-'):return float(raw)
    wall=datetime.fromtimestamp(float(raw),timezone.utc).replace(tzinfo=None)
    a=wall.replace(tzinfo=DISPLAY_ZONE,fold=0);b=wall.replace(tzinfo=DISPLAY_ZONE,fold=1)
    if a.utcoffset()!=b.utcoffset():raise ValueError('Нееднозначен брокерски час при смяна на времето.')
    return a.timestamp()

def stamp(ts):return datetime.fromtimestamp(ts,DISPLAY_ZONE).isoformat(timespec='seconds')

def origin(magic):return 'manual' if magic==0 else 'demon' if magic==MAGIC else 'other'

def money(d):return sum(float(d.get(k,0) or 0) for k in ('profit','commission','swap','fee'))

def collect(mt5,cfg,now=None):
    """One connection snapshot. None/error is not an empty successful history."""
    now=datetime.now(timezone.utc).timestamp() if now is None else now
    try:
        a=mt5.account_info();terminal=mt5.terminal_info()
        if a is None or terminal is None or not terminal.connected:
            return {'ok':False,'error':'Няма връзка с избрания MT5 терминал.'}
        mode=cfg.get('mode');login=cfg.get('live_login') if mode=='live' else cfg.get('demo_login')
        server=cfg.get('live_server') if mode=='live' else cfg.get('demo_server')
        if login is None or int(a.login)!=int(login) or (server and a.server!=server):
            return {'ok':False,'error':'Сметката в MT5 не съвпада с избраната в настройките.'}
        if mode in ('live','demo') and a.trade_mode!={'live':2,'demo':0}[mode]:
            return {'ok':False,'error':'Типът на сметката се различава от избрания режим.'}
        deals=mt5.history_deals_get(int(datetime(2020,1,1,tzinfo=timezone.utc).timestamp()),int(now+86400))
        if deals is None:return {'ok':False,'error':'MT5 не върна историята. Опресни страницата след възстановяване на връзката.'}
        positions=mt5.positions_get()
        if positions is None:return {'ok':False,'error':'MT5 не върна отворените позиции.'}
        again=mt5.account_info()
        if again is None or (again.login,again.server)!=(a.login,a.server):
            return {'ok':False,'error':'Сметката е сменена по време на прочитането. Опресни страницата.'}
        deal_keys=('ticket','position_id','time','time_msc','type','entry','magic','volume','profit','commission','swap','fee','symbol','price')
        pos_keys=('ticket','identifier','magic','type','symbol','volume','price_open','price_current','sl','profit','swap')
        return {'ok':True,'now':now,'account':{'login':a.login,'server':a.server,'currency':a.currency,'trade_mode':a.trade_mode},
                'deals':[{k:getattr(d,k,0) for k in deal_keys} for d in deals],
                'positions':[{k:getattr(p,k,0) for k in pos_keys} for p in positions]}
    except Exception:
        return {'ok':False,'error':'Прочитането на MT5 е неуспешно. Данните не се показват като нулев резултат.'}

def summarize(snapshot,period='today',scope='all'):
    if not snapshot.get('ok'):return snapshot
    if period not in ('today','30d','all') or scope not in ('all','manual','demon','other'):raise ValueError('invalid filter')
    account=snapshot['account'];server=account['server'];now=snapshot['now']
    local=datetime.fromtimestamp(now,DISPLAY_ZONE)
    start=local.replace(hour=0,minute=0,second=0,microsecond=0)
    if period=='30d':start-=timedelta(days=29)
    cutoff=start.timestamp() if period!='all' else 0
    warnings=[];unique={}
    for raw in snapshot['deals']:
        d=dict(raw);ticket=int(d['ticket'])
        if ticket in unique:
            if d!=unique[ticket]:raise ValueError('Противоречиви записи за една MT5 операция.')
            continue
        for k in ('volume','profit','commission','swap','fee','price','time','time_msc'):
            if not math.isfinite(float(d.get(k,0) or 0)):raise ValueError('Невалидни числа в историята на MT5.')
        unique[ticket]=d
    deals=sorted(unique.values(),key=lambda d:(d.get('time_msc') or d['time']*1000,d['ticket']))
    states={};closed=[];cash=[];adjustments=[]
    live_ids={int(p.get('identifier') or p['ticket']) for p in snapshot['positions']}
    def fresh(d,source):
        return {'position_id':int(d['position_id']),'symbol':d['symbol'],'dir':'BUY' if d['type']==0 else 'SELL',
                'remaining':0.,'lots':0.,'profit':0.,'source':source,'opened':d['_ts'],'time':'','incomplete':False}
    def merge_source(rec,source):
        if rec['source']!=source:rec['source']='mixed'
    def finish(rec,ts):
        rec['time']=stamp(ts);rec['closed_ts']=ts
        if not rec['incomplete']:closed.append(dict(rec))
    for d in deals:
        ts=epoch_utc((d.get('time_msc') or d['time']*1000)/1000,server);d['_ts']=ts
        if ts>now+5:raise ValueError('Историята съдържа бъдещи часове. Провери часовата конвенция на брокера.')
        if d['type'] not in (0,1):
            if ts>=cutoff:adjustments.append({'type':int(d['type']),'amount':money(d),'time':stamp(ts)})
            continue
        pid=int(d['position_id']);v=float(d['volume']);entry=int(d['entry']);source=origin(int(d['magic']))
        if pid<=0 or v<=0 or entry not in (0,1,2,3):raise ValueError('Непълен търговски запис в MT5.')
        rec=states.get(pid)
        if entry==0:
            if rec is None:rec=states[pid]=fresh(d,source)
            elif rec['dir']!=('BUY' if d['type']==0 else 'SELL'):raise ValueError('Несъответстващи входове за една позиция.')
            merge_source(rec,source);rec['remaining']+=v;rec['lots']+=v;rec['profit']+=money(d)
            cash.append({'ts':ts,'amount':money(d),'source':rec['source'],'position_id':pid,'owner':rec})
        elif rec is None:
            warnings.append('Има изход без наличен вход в историята; не е преброен като завършена позиция.')
            cash.append({'ts':ts,'amount':money(d),'source':'unknown','position_id':pid})
        elif entry in (1,3):
            cash.append({'ts':ts,'amount':money(d),'source':rec['source'],'position_id':pid,'owner':rec})
            rec['profit']+=money(d);rec['remaining']-=v
            if rec['remaining'] < -1e-7:
                rec['incomplete']=True;warnings.append('Обемът на изходите надвишава наличните входове; позицията е изключена от статистиката за завършени позиции.')
            if rec['remaining']<=1e-7:
                if pid in live_ids:
                    warnings.append('Историята и отворените позиции се обновяват; опресни за съгласуван резултат.')
                else:finish(rec,ts)
                del states[pid]
        else:  # Netting reversal: realize old position; allocate execution costs by volume.
            old=rec['remaining']
            if v<=old+1e-7:raise ValueError('Невалиден обем при обръщане на позиция.')
            fees=float(d.get('commission',0))+float(d.get('fee',0));old_fee=fees*old/v
            realized=float(d['profit'])+float(d['swap'])+old_fee
            rec['profit']+=realized;cash.append({'ts':ts,'amount':realized,'source':rec['source'],'position_id':pid,'owner':rec})
            finish(rec,ts)
            new=fresh(d,source);new['remaining']=new['lots']=v-old;new['profit']=fees-old_fee
            states[pid]=new;cash.append({'ts':ts,'amount':new['profit'],'source':source,'position_id':pid,'owner':new})
    def selected(source):return scope=='all' or source==scope or scope=='other' and source in ('mixed','unknown')
    open_positions=[]
    for p in snapshot['positions']:
        rec=states.get(int(p.get('identifier') or p['ticket']));source=rec['source'] if rec else origin(int(p['magic']))
        if not selected(source):continue
        for k in ('volume','price_open','price_current','sl','profit','swap'):
            if not math.isfinite(float(p.get(k,0))):raise ValueError('Невалидна отворена позиция.')
        open_positions.append(dict(p,source=source,source_label=LABELS[source],pnl=float(p['profit'])+float(p.get('swap',0))))
    closed=[dict(t,source_label=LABELS[t['source']]) for t in closed if t['closed_ts']>=cutoff and selected(t['source'])]
    for flow in cash:
        if 'owner' in flow:flow['source']=flow['owner']['source']
    flows=[x for x in cash if x['ts']>=cutoff and selected(x['source'])]
    realized=sum(x['amount'] for x in flows);floating=sum(p['pnl'] for p in open_positions)
    running=0.;points=[]
    if flows:
        points.append((stamp(flows[0]['ts']-.001),0.))
        for flow in flows:running+=flow['amount'];points.append((stamp(flow['ts']),running))
    gains=sum(max(t['profit'],0) for t in closed);losses=-sum(min(t['profit'],0) for t in closed)
    return {'ok':True,'account':account,'period':period,'scope':scope,'closed':closed,'open':open_positions,'points':points,
            'realized':realized,'floating':floating,'trade_total':sum(t['profit'] for t in closed),
            'wins':sum(t['profit']>0 for t in closed),'pf':gains/losses if losses else None,
            'pf_infinite':gains>0 and losses==0,'adjustments':adjustments,'warnings':sorted(set(warnings)),
            'checked':stamp(now),'history_from':'2020-01-01','flow_count':len(flows)}
