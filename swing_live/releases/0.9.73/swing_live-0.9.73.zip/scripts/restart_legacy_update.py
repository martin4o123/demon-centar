"""Compatibility restart for the updater already running on pre-migration clients."""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "engine"))
import update_state
from update_transaction import processes, stop_processes, start_ui, wait_for_ui


def main():
    version = json.loads((BASE / "VERSION.json").read_text(encoding="utf-8"))["version"]
    try:
        update_state.write(BASE, "restarting", "Отваряне на новата версия…", target_version=version)
        found = [(proc, kind) for proc, kind in processes(BASE) if kind in ("ui", "dashboard")]
        stop_processes(found)
        child = start_ui(BASE, sys.executable)
        wait_for_ui(child, version)
        digest = hashlib.sha256((BASE / "engine/engine_s5.py").read_bytes()).hexdigest()
        (BASE / "logs/repair_pending.json").write_text(
            json.dumps({"engine_build": digest}), encoding="utf-8")
        update_state.write(
            BASE, "complete",
            "Новата версия е отворена. Преминаване от стария обновител: "
            "провери избраната сметка в Настройки преди ръчен рестарт на двигателя.",
            target_version=version, engine_status="manual_start_required")
        return 0
    except Exception as exc:
        update_state.write(BASE, "failed", "Новата версия не потвърди стартиране: " + str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
