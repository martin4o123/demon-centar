"""Verified file transaction. Never selects or starts a different installation."""
import json
import hashlib
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time
import urllib.request
import uuid
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "engine"))
import update_state

MUTABLE = {"engine/config.json", "engine/s5_state.json", "engine/brain_state.json", "engine/kill.switch",
           "stop.flag", "quiet.flag", "kill.switch"}
ALLOWED_ROOTS = {"engine", "dashboard", "scripts", "assets", "tools", "mt5_portable"}
ALLOWED_FILES = {"VERSION.json", "LEGEND.md", "MANIFEST.sha256", "MANIFEST.sig"}
from process_control import processes, stop_processes


def payload_path(name):
    """Reject traversal, Windows devices/ADS, aliases and local customer state."""
    if "\\" in name or ":" in name:
        raise ValueError("Невалиден път в пакета")
    path = PurePosixPath(name)
    parts = path.parts
    if path.is_absolute() or not parts or any(p in ("..", ".") for p in parts):
        raise ValueError("Път извън пакета")
    reserved = {"con", "prn", "aux", "nul"} | {
        f"{prefix}{n}" for prefix in ("com", "lpt") for n in range(1, 10)}
    if any(p.endswith((" ", ".")) or p.split(".")[0].casefold() in reserved for p in parts):
        raise ValueError("Невалидно Windows име")
    lower = path.as_posix().casefold()
    if lower in MUTABLE or parts[0].casefold() == "config":
        raise ValueError("Пакетът съдържа лични настройки или състояние")
    if parts[0] not in ALLOWED_ROOTS and name not in ALLOWED_FILES:
        raise ValueError("Непознат компонент в пакета")
    if any(p.casefold() in {"logs", "backups", "__pycache__", "account_states"} for p in parts):
        raise ValueError("Пакетът съдържа локални данни")
    return Path(*parts)


def extract_verified(zip_path, stage, version):
    stage = Path(stage)
    seen = set()
    total = 0
    with zipfile.ZipFile(zip_path) as archive:
        for item in archive.infolist():
            if item.is_dir():
                continue
            rel = payload_path(item.filename)
            key = rel.as_posix().casefold()
            if key in seen or (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Дублиран файл или символна връзка в пакета")
            seen.add(key)
            total += item.file_size
            if total > 1024 * 1024 * 1024:
                raise ValueError("Пакетът надхвърля допустимия размер")
            target = stage / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
    for name in ("VERSION.json", "MANIFEST.sha256", "MANIFEST.sig",
                 "scripts/app.py", "dashboard/app.py", "engine/engine_s5.py"):
        if not (stage / name).is_file():
            raise ValueError(f"Непълен пакет: {name}")
    if json.loads((stage / "VERSION.json").read_text(encoding="utf-8"))["version"] != version:
        raise ValueError("Версията в пакета не съвпада с подписаното издание")
    import integrity
    ok, reason = integrity.verify_manifest(stage)
    if not ok:
        raise ValueError(reason)




def start_ui(base, runtime):
    env = dict(os.environ)
    env["DEMON_UPDATE_REOPEN"] = "1"
    output = (base / "logs/update_restart.log").open("ab")
    try:
        return subprocess.Popen([runtime, str(base / "scripts/app.py")],
                                cwd=base, env=env, stdout=output, stderr=output,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    finally:
        output.close()


def wait_for_ui(child, version, timeout=45, health_url="http://127.0.0.1:5123/api/update-health"):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if child.poll() is not None:
            raise RuntimeError("Новата програма се затвори при стартиране.")
        try:
            with urllib.request.urlopen(health_url, timeout=2) as resp:
                health = json.load(resp)
            if health.get("pid") == child.pid and health.get("version") == version:
                return
        except (OSError, ValueError):
            pass
        time.sleep(0.5)
    raise RuntimeError("Новата версия не потвърди успешно стартиране.")


def apply(base, stage, version, manual=False):
    base, stage = Path(base).resolve(), Path(stage).resolve()
    pending = base / "logs/update_transaction.json"
    if pending.exists():
        raise RuntimeError("Предишно обновяване е прекъснато. Запазеният архив е посочен "
                           "в logs/update_transaction.json; необходима е проверка преди нов опит.")
    found = processes(base)  # Import/process inspection must succeed before the transaction.
    had_engine = any(kind == "engine" for _, kind in found)
    config_bytes = (base / "engine/config.json").read_bytes()
    config = json.loads(config_bytes)
    # Scheduled updates must not stop/restart active trading. Manual UI warning is explicit.
    if had_engine and not manual:
        update_state.write(base, "deferred", "Има нова версия. Стартирай обновяването от Настройки.",
                           target_version=version)
        return False
    files = [p.relative_to(stage) for p in stage.rglob("*") if p.is_file()]
    files = [rel for rel in files if not (
        rel.as_posix() == "mt5_portable/MQL5/Profiles/Templates/default.tpl"
        and (base / rel).exists())]
    refresh_launcher = ((stage / "assets/ROBOT.bat").is_file()
                        and not (base / "config/telemetry_owner.json").exists())
    if refresh_launcher:
        files.append(Path("ROBOT.bat"))
    for rel in files:
        target = (base / rel).resolve()
        if not target.is_relative_to(base):
            raise ValueError("Инсталацията съдържа връзка извън собствената си папка")
    backup = base / "backups" / ("update_" + uuid.uuid4().hex)
    backup.mkdir(parents=True)
    prior = {}
    for rel in files:
        target = base / rel
        prior[rel.as_posix()] = target.exists()
        if target.exists():
            dest = backup / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, dest)
    (backup / "transaction.json").write_text(json.dumps(prior), encoding="utf-8")
    pending.parent.mkdir(parents=True, exist_ok=True)
    with pending.open("x", encoding="utf-8") as journal:
        json.dump({"backup": str(backup), "target_version": version, "files": prior}, journal)
        journal.flush()
        os.fsync(journal.fileno())
    quiet = base / "QUIET.flag"
    created_quiet = not quiet.exists()
    runtime = sys.executable
    replaced = []
    child = None
    closed = False
    try:
        if created_quiet:
            quiet.write_text("update\n", encoding="ascii")
        update_state.write(base, "closing", "Затваряне на програмата…", target_version=version)
        stop_processes(found)
        closed = True
        update_state.write(base, "installing", "Инсталиране на проверения пакет…")
        for rel in files:
            dest = base / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_name(dest.name + ".update-tmp")
            source = stage / "assets/ROBOT.bat" if refresh_launcher and rel == Path("ROBOT.bat") else stage / rel
            shutil.copy2(source, tmp)
            tmp.replace(dest)
            replaced.append(rel)
        update_state.write(base, "restarting", "Отваряне и проверка на новата версия…")
        child = start_ui(base, runtime)
        wait_for_ui(child, version)
    except Exception:
        if child is not None and child.poll() is None:
            stop_processes([(child, "ui")]) if hasattr(child, "info") else child.terminate()
            child.wait(timeout=10)
        for rel in reversed(replaced):
            if prior[rel.as_posix()]:
                shutil.copy2(backup / rel, base / rel)
            else:
                (base / rel).unlink(missing_ok=True)
        update_state.write(base, "failed", "Обновяването не завърши. Предишните файлове са възстановени.",
                           backup=str(backup))
        pending.unlink()
        if closed:
            start_ui(base, runtime)
        # Leave QUIET in place on failure; never resume trading after a failed update.
        raise
    detail = "Новата версия е инсталирана и програмата е отворена."
    engine_status = "not_running_before_update"
    engine_pid = None
    if had_engine:
        if (base / "engine/config.json").read_bytes() != config_bytes or (base / "STOP.flag").exists():
            engine_status = "manual_start_required"
            detail += " Настройките или STOP са променени; провери ги преди ръчен старт на двигателя."
        else:
            try:
                restarted = subprocess.Popen([runtime, str(base / "engine/engine_s5.py")], cwd=base,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                engine_status = "awaiting_first_cycle"
                engine_pid = restarted.pid
                detail += " Двигателят е стартиран; изчаква се първият му отчет."
            except OSError:
                engine_status = "manual_start_required"
                detail += " Двигателят не се стартира. Провери Готовност."
    if engine_status != "manual_start_required" and created_quiet:
        try:
            if quiet.read_text(encoding="utf-8", errors="replace") == "update\n":
                quiet.unlink()
        except FileNotFoundError:
            pass
    update_state.write(base, "complete", detail, engine_status=engine_status,
                       engine_pid=engine_pid,
                       engine_build=hashlib.sha256((base / "engine/engine_s5.py").read_bytes()).hexdigest()
                           if (base / "engine/engine_s5.py").exists() else None,
                       target_version=version, backup=str(backup))
    pending.unlink()
    return True
