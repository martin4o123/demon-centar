param([Parameter(Mandatory=$true)][string]$Base, [int]$StartEngine = 0)
$ErrorActionPreference = 'Stop'
$Base = (Resolve-Path -LiteralPath $Base).Path
$self = Get-CimInstance Win32_Process -Filter "ProcessId=$PID"
$parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($self.ParentProcessId)"
$runtime = $parent.ExecutablePath
if (-not $runtime -or [IO.Path]::GetFileName($runtime) -notin @('python.exe', 'pythonw.exe')) {
    throw 'Cannot identify the Python runtime that launched this update.'
}
# Compatibility entry point for old clients. Never kills all Python processes
# under a folder and never silently restarts real trading.
& $runtime (Join-Path $Base 'scripts\restart_legacy_update.py')
exit $LASTEXITCODE
