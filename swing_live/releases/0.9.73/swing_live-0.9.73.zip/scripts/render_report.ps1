﻿param([Parameter(Mandatory=$true)][string]$InputFile)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$data = Get-Content -LiteralPath $InputFile -Raw -Encoding UTF8 | ConvertFrom-Json
$font = New-Object System.Drawing.Font('Segoe UI', 19)
$titleFont = New-Object System.Drawing.Font('Segoe UI', 30, [System.Drawing.FontStyle]::Bold)
$probe = New-Object System.Drawing.Bitmap(1, 1)
$measure = [System.Drawing.Graphics]::FromImage($probe)
$height = [int][Math]::Ceiling($measure.MeasureString([string]$data.text, $font, 1016).Height) + 200
if ($height -gt 8000) { throw 'Report too long' }
$measure.Dispose()
$probe.Dispose()
$bitmap = New-Object System.Drawing.Bitmap(1120, $height)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
try {
    $graphics.Clear([System.Drawing.ColorTranslator]::FromHtml('#0c141b'))
    $graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $accent = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#8ef0bf'))
    $body = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#e4ecef'))
    $graphics.DrawString('DEMON / СЪСТОЯНИЕ', $titleFont, $accent, 52, 36)
    $rect = New-Object System.Drawing.RectangleF(52, 140, 1016, ($height - 150))
    $graphics.DrawString([string]$data.text, $font, $body, $rect)
    $bitmap.Save([string]$data.output, [System.Drawing.Imaging.ImageFormat]::Png)
    $accent.Dispose()
    $body.Dispose()
} finally {
    $graphics.Dispose()
    $bitmap.Dispose()
    $font.Dispose()
    $titleFont.Dispose()
}
