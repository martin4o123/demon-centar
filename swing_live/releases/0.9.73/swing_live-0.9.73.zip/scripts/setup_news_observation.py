"""Install per-user hourly observation tasks for this installation only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parents[1]
MARKER = 'DEMON news observation v1 '


def command(base, runtime):
    base = Path(base).resolve()
    runtime = Path(runtime).resolve()
    quote = lambda value: "'" + str(value).replace("'", "''") + "'"
    suffix = hashlib.sha256(str(base).casefold().encode('utf-8')).hexdigest()[:12]
    lines = ["$ErrorActionPreference='Stop'",
             "$user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name",
             "$principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited",
             "$settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries"]
    for group, offset in (('news', 5), ('guard', 10)):
        name = 'DemonObservation_' + suffix + '_' + group
        description = MARKER + str(base) + ' ' + group
        args = '-X utf8 "' + str(base/'scripts'/('observe_'+group+'.py')) + '"'
        lines += [
            '$name='+quote(name), '$description='+quote(description),
            '$existing=Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue',
            "if ($existing -and $existing.Description -ne $description) { throw 'Task ownership mismatch' }",
            '$action=New-ScheduledTaskAction -Execute '+quote(runtime)+' -Argument '+quote(args)+' -WorkingDirectory '+quote(base),
            # Preserve the existing schedule across UI reopens; do not reset it.
            "if ($existing) {",
            "  $a=@($existing.Actions)",
            "  if ($a.Count -ne 1 -or $a[0].Execute -ne $action.Execute -or $a[0].Arguments -ne $action.Arguments -or $a[0].WorkingDirectory -ne $action.WorkingDirectory) {",
            "    Set-ScheduledTask -TaskName $name -Action $action | Out-Null",
            "  }",
            "} else {",
            f'  $trigger=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes({offset}) -RepetitionInterval (New-TimeSpan -Hours 1)',
            '  Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description $description | Out-Null',
            '}']
    return '\n'.join(lines)


def ensure(base=BASE, runtime=None):
    base = Path(base)
    try:
        if os.name != 'nt':
            raise OSError('Windows Task Scheduler required')
        for group in ('news','guard'):
            if not (base/'scripts'/('observe_'+group+'.py')).is_file():
                raise OSError('Missing observation collector')
        powershell = Path(os.environ.get('SystemRoot','C:/Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
        result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive', '-Command',
                                 command(base, runtime or sys.executable)],
                                capture_output=True, timeout=45,
                                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:
            raise OSError('Task registration failed')
        status='configured'
    except Exception:
        # Never copy command output, keys or arbitrary exception text to reports.
        status='failed'
    try:
        sys.path.insert(0,str(base/'engine'))
        from account_state import atomic_write
        atomic_write(base/'logs/news_observation_schedule.json',
                     {'status':status,'checked_utc':datetime.now(timezone.utc).isoformat(),
                      'interval_minutes':60, 'requires_logged_in_user':True})
    except Exception:
        return False
    return status=='configured'


if __name__=='__main__':
    ok=ensure()
    print('News observation schedule: '+('configured' if ok else 'failed'))
    raise SystemExit(0 if ok else 1)
