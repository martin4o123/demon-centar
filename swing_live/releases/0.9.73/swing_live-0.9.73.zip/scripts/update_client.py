"""Клиент за ъпдейти от swing_live канала: локален Drive или HTTP fallback.

--check : само докладва има ли нова версия
--apply : сваля, проверява подпис+sha256, бекъпва, разархивира, събужда watchdog
Проверява RSA подписа на RELEASE.json срещу публичния модул на publisher ключа.

Режим на работа: ако локалният Drive канал съществува (машината на собственика),
файловете се четат от него без промяна. Иначе (клиентски машини без G:) се
свалят по HTTP от RELEASE_BASE_URL — публичното копие на канала.
"""
import argparse
import base64
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

                                                                     
                                                                           
BASE = Path(__file__).resolve().parents[1]
DRIVE = Path(os.environ.get("DEMON_RELEASE_DIR") or (BASE / "offline_updates"))
RELEASE_BASE_URL = "https://martin4o123.github.io/demon-centar/swing_live"
LOCAL_VER = BASE / "VERSION.json"
EVENTS = BASE / "logs" / "events.jsonl"
STOP_FLAG = BASE / "STOP.flag"

MODULUS_HEX = "b663a2203c5bdac9e0778eba9b74a2cd72db245036b571932459490f6fc21283cd3c11f5c146067ada7b931dc08d142b1cd39006aa7bff8d516164391305f3ea5ca9396cb66c05abb332f45d71490035f3f0cee66e02a9386b0cdb38c5ea05f802c5f6a6a3c3e97acf4b309c4c4b8606ca2c31ea9a3c04c7b4223b5e3accdb3957f30af630a13ab55ef77516a1728d62b5d26471dacedd9762b28906baa937e0b4d753b803947e258b3eca8c432e9c2e9234fcbd2330c0a503042e5baf16bfc801470637670fbad5cb27bce20044caa8cda16e8b4bbbc907d7dd6c257f540252abd055c505f6b061963d8833395fbbcc038ff63d8d1914c685057edb4ac85ddf97e50b15fa8ae1f798ebbb9befefccc8a72246995cd447fb86b226c889ac881bddd74b0598c453e4f7ac24bc1a46dd5fd7f00505034b214f5a609621762f9c592c580601c476df82a809baefa2a831b4a62904da7618dea24cff72fb0a0571e106997b47b797a71183f686b705ab7d67f214d34f2607776d88de033cdd64cef1"
KEY_ID = "da6dbc7a152497ac"


def log_event(kind: str, detail: str) -> None:
    EVENTS.parent.mkdir(exist_ok=True)
    with open(EVENTS, "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": datetime.now(timezone.utc).isoformat(),
                            "kind": kind, "detail": detail}, ensure_ascii=False) + "\n")


def notify(level: str, category: str, text: str) -> None:
    """Central notification bus (engine\\notify.py) — best-effort."""
    try:
        subprocess.run([sys.executable, str(BASE / "engine" / "notify.py"),
                        "--level", level, "--category", category, "--text", text],
                       capture_output=True, timeout=60)
    except Exception:
        pass


def version_tuple(v: str):
    return tuple(int(x) for x in v.split("."))


def http_get(url: str) -> bytes:
    """GET с User-Agent и timeout 30; вдига изключение при HTTP грешка/мрежов проблем."""
    req = urllib.request.Request(url, headers={"User-Agent": "admiral-swing-live-updater/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read()


def download(url: str, dest: Path) -> None:
    dest.write_bytes(http_get(url))


def verify_release(rel: dict, rel_bytes: bytes, sig_b64: str) -> str:
    if rel.get("publisher", {}).get("key_id") != KEY_ID:
        return f"key_id {rel.get('publisher', {}).get('key_id')} ≠ {KEY_ID}"
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        pub = rsa.RSAPublicNumbers(
            65537, int(MODULUS_HEX, 16)).public_key(serialization.Encoding.PEM)
        pub.verify(base64.b64decode(sig_b64.strip()), rel_bytes,
                   padding.PKCS1v15(), hashes.SHA256())
    except Exception as e:
        return f"НЕВАЛИДЕН ПОДПИС: {e}"
    return ""


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _validate_banlist(raw: bytes) -> dict:
    data = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("banlist.json не е JSON обект")
    if not isinstance(data.get("banned_sha256", []), list):
        raise ValueError("banned_sha256 не е списък")
    return data


def _write_banlist(data: dict) -> None:
    dest = BASE / "config" / "banlist.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(dest)
    n = len(data.get("banned_sha256", []))
    log_event("banlist_synced", f"{n} блокирани ключа")
    print(f"banlist.json обновен ({n} блокирани ключа).")


def sync_banlist() -> None:
    """Локален режим: banlist.json от Drive root-а -> config\\banlist.json.

    Така блокираните от собственика ключове влизат в сила при всяка проверка.
    Липсващ/повреден файл = предупреждение; НЕ спира ъпдейта.
    """
    src = DRIVE / "banlist.json"
    if not src.exists():
        print("Няма banlist.json в Drive (пропускам синхронизацията).")
        return
    try:
        data = _validate_banlist(src.read_bytes())
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: banlist.json не се чете ({exc}) — продължавам без него.")
        return
    _write_banlist(data)


def sync_banlist_http() -> None:
    """HTTP режим: banlist.json от сървъра -> config\\banlist.json (tmp+replace).

    404/мрежова грешка = предупреждение; НЕ спира ъпдейта.
    """
    try:
        data = _validate_banlist(http_get(RELEASE_BASE_URL + "/banlist.json"))
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: banlist.json не се сваля ({exc}) — продължавам без него.")
        return
    _write_banlist(data)


def _validate_news_cache(raw: bytes) -> dict:
    data = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(data, dict) or not isinstance(data.get("items", []), list):
        raise ValueError("news_cache.json няма items списък")
    return data


def _write_news_cache(data: dict) -> None:
    dest = BASE / "config" / "news_cache.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(dest)
    print(f"news_cache.json обновен ({len(data.get('items', []))} новини).")


def sync_news() -> None:
    """Локален режим: news_cache.json от Drive root-а -> config\\news_cache.json.
    Клиентите получават новините за blackout филтъра без собствен API ключ.
    Грешка = предупреждение; НЕ спира ъпдейта."""
    src = DRIVE / "news_cache.json"
    if not src.exists():
        return
    try:
        _write_news_cache(_validate_news_cache(src.read_bytes()))
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: news_cache.json не се чете ({exc}) — продължавам.")


def sync_news_http() -> None:
    """HTTP режим: news_cache.json от сървъра -> config\\news_cache.json."""
    try:
        _write_news_cache(_validate_news_cache(
            http_get(RELEASE_BASE_URL + "/news_cache.json")))
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: news_cache.json не се сваля ({exc}) — продължавам.")


def sync_report_request(http_mode: bool) -> None:
    """Заявка за отчет от собственика -> config\\report_request.json (само ако е по-нова).
    Двигателят я забелязва по mtime и праща client_state в следващия цикъл."""
    name = "report_request.json"
    try:
        if http_mode:
            try:
                raw = http_get(RELEASE_BASE_URL + "/" + name)
            except Exception:
                return  # 404 = няма заявка — нормално
        else:
            src = DRIVE / name
            if not src.exists():
                return
            raw = src.read_bytes()
        doc = json.loads(raw.decode("utf-8-sig"))
        ts = float(doc.get("ts") or 0)
        if ts <= 0:
            return
        dest = BASE / "config" / "report_request.json"
        cur = 0.0
        try:
            cur = float(json.loads(dest.read_text(encoding="utf-8")).get("ts") or 0)
        except Exception:
            pass
        if ts > cur:
            dest.write_text(json.dumps({"ts": ts}), encoding="utf-8")
            print("Получена е заявка за отчет от собственика.")
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: report_request не се синхронизира ({exc})")


# --- Owner-инициирана смяна на клиентска парола (канал: account_reset_<fp8>.json) ---
# fp8 = първите 8 hex на sha256(лицензния ключ). Съдържанието е AES-256-GCM,
# ключ = sha256(самият лицензен ключ) — чете го само машината с този ключ.

def _own_license_key() -> str:
    try:
        d = json.loads((BASE / "config" / "activation.json").read_text(encoding="utf-8"))
        return str(d.get("key") or "")
    except Exception:
        return ""


def _reset_fp8(key: str) -> str:
    import hashlib
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:8]


def _reset_already_applied(issued_utc: str) -> bool:
    try:
        d = json.loads((BASE / "config" / "account_reset_applied.json")
                       .read_text(encoding="utf-8"))
        return str(d.get("issued_utc") or "") == issued_utc
    except Exception:
        return False


def sync_account_reset(http_mode: bool) -> None:
    """Дърпа и прилага (веднъж) owner-зададена нова парола за таблото."""
    key = _own_license_key()
    if not key:
        return
    name = f"account_reset_{_reset_fp8(key)}.json"
    try:
        if http_mode:
            try:
                raw = http_get(RELEASE_BASE_URL + "/" + name)
            except Exception:
                return  # 404 = няма зададена смяна — нормално
        else:
            src = DRIVE / name
            if not src.exists():
                return
            raw = src.read_bytes()
        doc = json.loads(raw.decode("utf-8-sig"))
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: account_reset не се чете ({exc}) — продължавам.")
        return
    try:
        if doc.get("v") != 1 or doc.get("fp8") != _reset_fp8(key):
            return
        issued = str(doc.get("issued_utc") or "")
        exp = str(doc.get("expires_utc") or "")
        from datetime import datetime, timezone
        if exp:
            try:
                if datetime.now(timezone.utc) > datetime.fromisoformat(
                        exp.replace("Z", "+00:00")):
                    return  # изтекла заявка — не се прилага
            except Exception:
                pass
        if not issued or _reset_already_applied(issued):
            return
        import base64
        import hashlib
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        blob = base64.b64decode(str(doc["sealed"]))
        aes = AESGCM(hashlib.sha256(key.encode("utf-8")).digest())
        payload = json.loads(aes.decrypt(blob[:12], blob[12:], None).decode("utf-8"))
        email = str(payload.get("email") or "")
        sys.path.insert(0, str(BASE / "engine"))
        import auth as _auth
        result = _auth.set_password_hash(
            email, str(payload["salt_hex"]), str(payload["pw_hash"]),
            name=str(payload.get("name") or ""))
        (BASE / "config" / "account_reset_applied.json").write_text(
            json.dumps({"issued_utc": issued, "email": email}, ensure_ascii=False),
            encoding="utf-8")
        log_event("account_reset_applied", f"{email} ({result})")
        notify("info", "system",
               f"Паролата за таблото на {email} е сменена от собственика.")
        print(f"Смяна на парола приложена: {email} ({result}).")
    except Exception as exc:
        print(f"ПРЕДУПРЕЖДЕНИЕ: account_reset не се приложи ({exc}) — продължавам.")


def run_update(args):
    import update_transaction as transaction
    import update_state
    update_state.write(BASE, "checking", "Проверка за нова версия…")
    http_mode = not (DRIVE / "RELEASE.json").exists()
    rel_bytes = http_get(RELEASE_BASE_URL + "/RELEASE.json") if http_mode else (DRIVE / "RELEASE.json").read_bytes()
    rel = json.loads(rel_bytes.decode("utf-8-sig"))
    sig = (http_get(RELEASE_BASE_URL + "/RELEASE.sig").decode("ascii") if http_mode
           else (DRIVE / "RELEASE.sig").read_text(encoding="ascii"))
    error = verify_release(rel, rel_bytes, sig)
    if error:
        raise ValueError(error)
    if rel.get("product_id") != "admiral-swing-live":
        raise ValueError("Пакетът е за друг продукт")
    new_ver = rel["version"]
    local = json.loads(LOCAL_VER.read_text(encoding="utf-8")) if LOCAL_VER.exists() else {"version": "0.0.0"}
    for sync in ((sync_banlist_http if http_mode else sync_banlist),
                 (sync_news_http if http_mode else sync_news),
                 lambda: sync_account_reset(http_mode), lambda: sync_report_request(http_mode)):
        try:
            sync()
        except Exception as exc:
            log_event("update_sync_warning", type(exc).__name__)
    if version_tuple(new_ver) <= version_tuple(local["version"]):
        update_state.write(BASE, "current", "Вече имаш актуалната версия.", current_version=local["version"])
        print("Актуално:", local["version"])
        return 0
    update_state.write(BASE, "available", "Има нова версия.", target_version=new_ver, current_version=local["version"])
    if args.check or not args.apply:
        return 0
    zip_rel = rel["installer"]["file"]
    from pathlib import PurePosixPath
    parsed = PurePosixPath(zip_rel)
    if parsed.is_absolute() or ".." in parsed.parts or ":" in zip_rel or "\\" in zip_rel or not zip_rel.startswith("releases/"):
        raise ValueError("Невалиден адрес на пакета")
    with tempfile.TemporaryDirectory(prefix="demon-update-") as folder:
        temp = Path(folder)
        zip_src = temp / "release.zip"
        update_state.write(BASE, "downloading", "Изтегляне на новата версия…")
        if http_mode:
            download(RELEASE_BASE_URL + "/" + zip_rel, zip_src)
        else:
            shutil.copy2(DRIVE / zip_rel, zip_src)
        if sha256(zip_src) != rel["installer"]["sha256"]:
            raise ValueError("Контролната сума на пакета не съвпада")
        stage = temp / "payload"
        stage.mkdir()
        update_state.write(BASE, "verifying", "Проверка на подписа и съдържанието…")
        transaction.extract_verified(zip_src, stage, new_ver)
        applied = transaction.apply(BASE, stage, new_ver, manual=args.manual)
        if applied:
            log_event("update_applied", new_ver)
        return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--manual", action="store_true")
    args = ap.parse_args()
    sys.path.insert(0, str(BASE / "engine"))
    import update_state
    # An OS lock is released even when the updater crashes. No stale PID lock.
    lock_path = BASE / "logs/update.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1):
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            print("Вече има стартирано обновяване.")
            return 3
        try:
            return run_update(args)
        except Exception as exc:
            # Preserve rollback information, never claim success on network/restart failure.
            detail = str(exc)
            update_state.write(BASE, "failed", "Обновяването не завърши: " + detail)
            log_event("update_failed", detail)
            print("ГРЕШКА:", detail)
            return 2


if __name__ == "__main__":
    sys.exit(main())
