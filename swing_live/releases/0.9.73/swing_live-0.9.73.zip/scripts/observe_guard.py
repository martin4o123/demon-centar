"""Observation-only news collector. --check never writes.
Writes logs/guard_observation.json; never changes live news/guard inputs or publishes data.
Deployment requires a reviewed migration of the old scheduled collectors.
"""
from __future__ import annotations
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR / "engine"))
import news_pipeline as core
import news_observer as observer

def collect(keys_path=None, now=None):
    return observer.collect("guard", base_dir=BASE_DIR, keys_path=keys_path, now=now)


def check_now(keys_path=None):
    doc = observer.run_group("guard", base_dir=BASE_DIR, keys_path=keys_path, check_only=True)
    return observer.successful(doc), observer.summary(doc)


def run(argv=None, *, keys_path=None, logs_dir=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if any(arg != "--check" for arg in argv):
        print("Only --check is supported. This collector is observation-only.")
        return 2
    try:
        doc = observer.run_group("guard", base_dir=BASE_DIR, keys_path=keys_path,
                                 logs_dir=logs_dir, check_only="--check" in argv)
        print(observer.summary(doc))
        return 0 if observer.successful(doc) else 1
    except core.FetchFailure as exc:
        print(exc.code, file=sys.stderr)
    except Exception:
        print("Local observation failed; previous complete snapshot retained.", file=sys.stderr)
    return 1

if __name__ == "__main__":
    raise SystemExit(run())
