"""Explicit adapter for observed Admirals server-wall-clock timestamps.

Raw files remain unchanged. Admirals documents EET/EEST platform time; this
installation was verified to return server-wall-clock epoch labels, not UTC.
Never infer a new offset from a stale quote or silently use this for any broker.
"""
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import math

ZONE=ZoneInfo('Europe/Helsinki')

def server_to_utc(raw):
    if not math.isfinite(raw) or raw<=0: raise ValueError('invalid market timestamp')
    wall=datetime.fromtimestamp(raw,timezone.utc).replace(tzinfo=None)
    first=wall.replace(tzinfo=ZONE,fold=0)
    second=wall.replace(tzinfo=ZONE,fold=1)
    if first.utcoffset()!=second.utcoffset():
        raise ValueError('ambiguous/nonexistent DST market time')
    converted=first.timestamp()
    if datetime.fromtimestamp(converted,ZONE).replace(tzinfo=None)!=wall:
        raise ValueError('nonexistent market time')
    return converted

def normalize_rates(raw):
    result=raw.copy()
    result['time']=[int(server_to_utc(float(x))) for x in raw['time']]
    return result

def normalize_ticks(raw):
    result=raw.copy()
    result['time_msc']=[round(server_to_utc(float(x)/1000)*1000) for x in raw['time_msc']]
    result['time']=result['time_msc']//1000
    return result

def quote_time(raw_msc,now,max_age=10):
    tick_utc=server_to_utc(raw_msc/1000)
    if not 0<=now-tick_utc<=max_age:
        raise ValueError('stale/future quote after explicit server-time conversion')
    return tick_utc
