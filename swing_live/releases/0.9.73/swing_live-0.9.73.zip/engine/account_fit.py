"""Pure account capacity estimates; no broker access, settings writes or orders.

Amounts are in the account currency. The broker loss must refer to the exact
entry and unchanged protective stop supplied in calculation. Decimal arithmetic
floors volumes to the broker lattice; it never lifts a volume to the minimum.
An estimate, including FIT, is never permission to trade.
"""
from decimal import Decimal, InvalidOperation, ROUND_FLOOR, localcontext

SCHEMA = 'demon.account-fit/1'
ZERO = Decimal('0')
HUNDRED = Decimal('100')


class MissingData(ValueError):
    pass


def number(value, name, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or value is None or not isinstance(value, (str, int, float, Decimal)):
        raise MissingData('Липсва валидна стойност: ' + name)
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise MissingData('Невалидна стойност: ' + name) from None
    if not result.is_finite() or len(result.as_tuple().digits) > 40:
        raise MissingData('Невалидна крайна стойност: ' + name)
    if abs(result) > Decimal('1e18') or (result and abs(result) < Decimal('1e-18')):
        raise MissingData('Стойността е извън поддържания диапазон: ' + name)
    if (positive and result <= 0) or (nonnegative and result < 0):
        raise MissingData('Невалиден знак или нулева стойност: ' + name)
    return result


def percentage(value, name):
    result = number(value, name, nonnegative=True)
    if result > HUNDRED:
        raise MissingData('Процентът е над 100: ' + name)
    return result


def round_down_volume(value, step):
    """Exact nonnegative floor. A nondecimal lattice such as .25 is supported."""
    with localcontext() as context:
        context.prec = 90
        value = number(value, 'обем', nonnegative=True)
        step = number(step, 'стъпка на обема', positive=True)
        return (value / step).to_integral_value(rounding=ROUND_FLOOR) * step


def policy_from_config(cfg, layer='D1', *, risk_ceiling_pct=None):
    """Extract only existing sizing limits; do not invent an account profile."""
    if not isinstance(cfg, dict) or layer not in ('D1', 'H1'):
        raise MissingData('Липсват настройки за избраната стратегия')
    source = cfg if layer == 'D1' else cfg.get('h1_layer')
    if not isinstance(source, dict):
        raise MissingData('Липсват настройки за избраната стратегия')
    result = {'risk_pct': source.get('risk_pct'), 'max_lot': cfg.get('max_lot'), 'layer': layer}
    if risk_ceiling_pct is not None:
        result['risk_ceiling_pct'] = risk_ceiling_pct
    # A total-risk ceiling is applied only when it already exists explicitly.
    if 'max_open_risk_pct' in cfg:
        result['max_open_risk_pct'] = cfg['max_open_risk_pct']
    return result


def _same_account(value, account, label):
    if not isinstance(value, dict):
        raise MissingData('Липсва ' + label)
    if value.get('currency') != account['currency']:
        raise MissingData('Валутата не съвпада: ' + label)
    if str(value.get('login', '')) != str(account['login']) or value.get('server') != account['server']:
        raise MissingData('Сметката или сървърът не съвпадат: ' + label)


def _put(result, **values):
    for name, value in values.items():
        result[name] = None if value is None else float(value)
        result['exact'][name] = None if value is None else format(value, 'f')


def _format(value, places=2):
    return format(value, f'.{places}f').rstrip('0').rstrip('.') if places > 2 else format(value, '.2f')


def evaluate(account, policy, symbol, calculation, *, costs=None, portfolio=None):
    """Return capacity for one already chosen instrument/stop, never a signal.

    account: balance, equity, margin_free, currency, login, server.
    policy: risk_pct, max_lot; optional lower risk_ceiling_pct, risk_multiplier
      in [0,1], max_open_risk_pct and margin_reserve_money.
    symbol: name, volume_min, volume_max, volume_step.
    calculation: matching currency/login/server, symbol, direction, entry, stop,
      loss_per_lot (>0 at that stop), margin_per_lot (>=0). These estimates must
      be captured by the coordinated broker adapter, not guessed from balance.
    costs: matching currency, complete bool, per_lot and fixed nonnegative known
      reserves. Missing/incomplete costs make the result PRELIMINARY, not FIT.
    portfolio: matching currency/login/server, known bool, risk_money >=0;
      includes all open positions AND pending orders, manual and automated.
      Missing SL, unknown cost reserve or missing order makes this unknown.
    Returned float fields are for display; `exact` contains Decimal strings for
      invariant checks. Actual-lot broker verification remains mandatory.
    """
    result = {
        'schema': SCHEMA, 'status': 'NO_DATA', 'message_bg': 'Данните липсват.',
        'execution_authorized': False, 'automatic_trading_authorized': False,
        'currency': None, 'symbol': None, 'lot': None, 'risk_money': None,
        'risk_with_cost_reserve': None, 'margin': None, 'risk_budget': None,
        'capital_basis': None, 'required_balance_for_minlot': None,
        'required_margin_free_for_minlot': None, 'minimum_lot_risk': None,
        'open_risk_money': None, 'portfolio_risk_known': False,
        'costs_complete': False, 'margin_is_estimate': True,
        'required_balance_is_lower_bound': True,
        'required_balance_basis': 'min(balance, equity); conditional on unchanged stop and percentage',
        'checks': [], 'limitations': [], 'exact': {},
    }
    def check(code, text):
        result['checks'].append({'code': code, 'message_bg': text})
    try:
        with localcontext() as context:
            context.prec = 90
            if not all(isinstance(x, dict) for x in (account, policy, symbol, calculation)):
                raise MissingData('Липсват данни за сметка, настройки, инструмент или брокерска оценка')
            currency = account.get('currency')
            if not isinstance(currency, str) or not currency.strip() or len(currency) > 12:
                raise MissingData('Липсва валута на сметката')
            login = account.get('login')
            login_valid = (type(login) is int and login > 0) or (isinstance(login, str) and login.isascii() and login.isdecimal() and int(login) > 0)
            if not isinstance(account.get('server'), str) or not account['server'].strip() or not login_valid:
                raise MissingData('Липсва идентичност на сметката')
            result['currency'] = currency
            if not isinstance(symbol.get('name'), str) or not symbol['name']:
                raise MissingData('Липсва брокерско име на инструмента')
            result['symbol'] = symbol['name']
            balance = number(account.get('balance'), 'баланс')
            equity = number(account.get('equity'), 'средства')
            free_margin = max(ZERO, number(account.get('margin_free'), 'свободен маржин'))
            capital = max(ZERO, min(balance, equity))
            risk_pct = percentage(policy.get('risk_pct'), 'риск за сделка')
            if 'risk_ceiling_pct' in policy:
                risk_pct = min(risk_pct, percentage(policy['risk_ceiling_pct'], 'таван на риска'))
            multiplier = number(policy.get('risk_multiplier', 1), 'намаление на риска', nonnegative=True)
            if multiplier > 1:
                raise MissingData('Множителят не може да увеличава зададения риск')
            risk_pct *= multiplier
            max_lot = number(policy.get('max_lot'), 'максимален лот', nonnegative=True)
            min_lot = number(symbol.get('volume_min'), 'минимален лот', positive=True)
            vol_max = number(symbol.get('volume_max'), 'брокерски максимален лот', positive=True)
            step = number(symbol.get('volume_step'), 'стъпка на обема', positive=True)
            if min_lot > vol_max or min_lot % step:
                raise MissingData('Брокерските граници и стъпката на обема са несъвместими')
            _same_account(calculation, account, 'брокерската оценка')
            if calculation.get('symbol') != symbol['name']:
                raise MissingData('Брокерската оценка е за друг инструмент')
            direction = calculation.get('direction')
            entry = number(calculation.get('entry'), 'входна цена', positive=True)
            stop = number(calculation.get('stop'), 'защитен стоп', positive=True)
            if direction not in ('BUY', 'SELL') or (direction == 'BUY' and stop >= entry) or (direction == 'SELL' and stop <= entry):
                raise MissingData('Стопът не е защитен за тази посока')
            loss = number(calculation.get('loss_per_lot'), 'брокерска загуба за лот', positive=True)
            margin = number(calculation.get('margin_per_lot'), 'брокерски маржин за лот', nonnegative=True)
            reserve = number(policy.get('margin_reserve_money', 0), 'запазен свободен маржин', nonnegative=True)
            margin_available = max(ZERO, free_margin - reserve)

            cost_per_lot = fixed_cost = ZERO
            if costs is not None:
                if not isinstance(costs, dict) or type(costs.get('complete')) is not bool or costs.get('currency') != currency:
                    raise MissingData('Липсва еднозначна оценка на разходите във валутата на сметката')
                cost_per_lot = number(costs.get('per_lot'), 'разходи за лот', nonnegative=True)
                fixed_cost = number(costs.get('fixed'), 'фиксирани разходи', nonnegative=True)
                result['costs_complete'] = costs['complete']
            if not result['costs_complete']:
                result['limitations'].append('Не всички комисиони, суап и приплъзване са оценени; показаният лот е само горна предварителна граница.')

            open_risk = None
            if portfolio is not None:
                if not isinstance(portfolio, dict) or type(portfolio.get('known')) is not bool:
                    raise MissingData('Липсва еднозначен статус за общия отворен риск')
                if portfolio['known']:
                    _same_account(portfolio, account, 'отворения риск')
                    open_risk = number(portfolio.get('risk_money'), 'общ отворен риск', nonnegative=True)
                    result['portfolio_risk_known'] = True
            if open_risk is None:
                result['limitations'].append('Общият риск от позиции и чакащи поръчки е неизвестен; липсващ стоп не се приема за нулев риск.')
            result['required_balance_is_lower_bound'] = not result['costs_complete'] or not result['portfolio_risk_known']

            per_trade_budget = capital * risk_pct / HUNDRED
            budget = per_trade_budget
            min_price_loss = min_lot * loss
            min_total_loss = min_lot * (loss + cost_per_lot) + fixed_cost
            required_capital = min_total_loss * HUNDRED / risk_pct if risk_pct > 0 else None
            total_pct = None
            if 'max_open_risk_pct' in policy:
                total_pct = percentage(policy['max_open_risk_pct'], 'таван на общия риск')
                if open_risk is not None:
                    budget = min(budget, max(ZERO, capital * total_pct / HUNDRED - open_risk))
                    if total_pct > 0:
                        needed = (open_risk + min_total_loss) * HUNDRED / total_pct
                        required_capital = max(required_capital, needed) if required_capital is not None else None
                    else:
                        required_capital = None
            _put(result, capital_basis=capital, effective_risk_pct=risk_pct,
                 per_trade_risk_budget=per_trade_budget, risk_budget=budget,
                 required_balance_for_minlot=required_capital,
                 required_margin_free_for_minlot=min_lot * margin + reserve,
                 minimum_lot_risk=min_price_loss, minimum_lot_with_cost_reserve=min_total_loss,
                 open_risk_money=open_risk, entry=entry, stop=stop, margin_available=margin_available)
            if total_pct is not None and open_risk is None:
                raise MissingData('Не може да се провери зададеният таван на общия риск без отворените позиции и чакащите поръчки')

            cap = min(max_lot, vol_max)
            if cap < min_lot:
                check('MAX_LOT_BELOW_MINIMUM', 'Зададеният максимален лот е под брокерския минимум.')
            if min_total_loss > budget or risk_pct == 0:
                check('MINIMUM_EXCEEDS_RISK', 'Минималният лот надвишава оставащия бюджет при този непроменен стоп.')
            if min_lot * margin > margin_available:
                check('INSUFFICIENT_MARGIN', 'Свободният маржин не стига за минималния лот.')
            if result['checks']:
                result['status'] = 'BLOCKED'
                result['message_bg'] = f'Минималната сделка е {format(min_lot, "f")} лота с риск до стопа {_format(min_price_loss)} {currency}; не се побира в текущите ограничения.'
                return result
            volume_by_risk = max(ZERO, budget - fixed_cost) / (loss + cost_per_lot)
            raw = min(cap, volume_by_risk)
            if margin > 0:
                raw = min(raw, margin_available / margin)
            lot = (raw / step).to_integral_value(rounding=ROUND_FLOOR) * step
            if lot < min_lot:
                result['status'] = 'BLOCKED'
                result['message_bg'] = 'Минималната сделка е над допустимия обем след закръгляне към брокерската стъпка.'
                check('MINIMUM_EXCEEDS_ROUNDED_CAPACITY', result['message_bg'])
                return result
            price_risk = lot * loss
            total_risk = lot * (loss + cost_per_lot) + fixed_cost
            estimated_margin = lot * margin
            # These are invariants, not relaxed broker-size tolerances.
            if total_risk > budget or estimated_margin > margin_available or lot > cap:
                raise MissingData('Изчисленият обем не преминава повторната аритметична проверка')
            _put(result, lot=lot, risk_money=price_risk, risk_with_cost_reserve=total_risk, margin=estimated_margin,
                 portfolio_risk_after=None if open_risk is None else open_risk + total_risk)
            preliminary = not result['costs_complete'] or not result['portfolio_risk_known']
            result['status'] = 'PRELIMINARY' if preliminary else 'FIT'
            qualifier = 'предварително до' if preliminary else 'до'
            result['message_bg'] = f'Сметката позволява {qualifier} {format(lot, "f")} лота по този стоп; риск до стопа {_format(price_risk)} {currency}, оценен маржин {_format(estimated_margin)} {currency}.'
            result['limitations'].append('Маржинът е оценка по лот; преди поръчка е нужна нова брокерска проверка за точния обем, сметка, котировка и всички предпазители.')
            return result
    except (MissingData, InvalidOperation, TypeError, ValueError, KeyError, ArithmeticError) as exc:
        result['status'] = 'NO_DATA'
        result['lot'] = result['risk_money'] = result['risk_with_cost_reserve'] = result['margin'] = None
        for field in ('lot', 'risk_money', 'risk_with_cost_reserve', 'margin'):
            result['exact'][field] = None
        result['message_bg'] = 'Данните липсват: ' + str(exc) + '.'
        check('MISSING_OR_INVALID_DATA', str(exc))
        return result
