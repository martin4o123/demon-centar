"""Read-only research evidence. This module never grants execution permission."""
import hashlib
import html
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from decision_core import SYMBOLS, effective_config, fingerprint

SCHEMA = 'demon.research/1'


def validate(data):
    # Reject nonfinite numbers anywhere, including optional audit/cost metadata.
    json.dumps(data, allow_nan=False)
    def finite(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    if not isinstance(data, dict) or data.get('schema') != SCHEMA:
        raise ValueError('Неподдържан формат на изследването')
    for name in ('generated_utc', 'data_asof_utc', 'config_hash', 'rules_sha256'):
        if not isinstance(data.get(name), str):
            raise ValueError('Липсва произход на изследването')
    for name in ('generated_utc', 'data_asof_utc'):
        stamp = datetime.fromisoformat(data[name])
        if stamp.tzinfo is None or stamp.timestamp() > datetime.now(timezone.utc).timestamp() + 5:
            raise ValueError('Невалиден час на изследването')
    rows = data.get('results')
    if not isinstance(rows, list):
        raise ValueError('Липсват резултати')
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('Невалиден резултат')
        key = row.get('symbol'), row.get('strategy')
        if key[0] not in SYMBOLS or key[1] not in ('S5-D1', 'S5-H1') or key in seen:
            raise ValueError('Неподдържан или повторен резултат')
        seen.add(key)
        if not isinstance(row.get('configured'), bool):
            raise ValueError('Непотвърдени настройки')
        if not isinstance(row.get('periods'), dict) or not isinstance(row.get('bars'), dict):
            raise ValueError('Липсват периоди или покритие')
        for tf in ('D1', 'H1'):
            n = row['bars'].get(tf)
            if type(n) is not int or n < 0:
                raise ValueError('Невалиден брой свещи')
        for period in ('development', 'holdout'):
            item = row['periods'].get(period)
            if not isinstance(item, dict) or type(item.get('trades')) is not int or item['trades'] < 0:
                raise ValueError('Невалиден брой сделки')
            if not finite(item.get('r_after_spread')):
                raise ValueError('Невалиден резултат в R')
            pf = item.get('pf_after_spread')
            if pf is not None and (not finite(pf) or pf < 0):
                raise ValueError('Невалиден profit factor')
            # Current report has no calibrated all-in execution model.
            if item.get('full_net_after_all_costs') is not None:
                raise ValueError('Неподдържан модел на пълните разходи')
    if seen != {(s, 'S5-' + tf) for s in SYMBOLS for tf in ('D1', 'H1')}:
        raise ValueError('Непълно покритие на инструментите')
    audit = data.get('audit')
    if not isinstance(audit, dict) or audit.get('schema') != 'demon.history-quality/1' or not isinstance(audit.get('instruments'), dict):
        raise ValueError('Липсва проверка на историческите данни')
    for symbol in SYMBOLS:
        instrument = audit['instruments'].get(symbol)
        if not isinstance(instrument, dict) or not isinstance(instrument.get('issues'), list):
            raise ValueError('Непълна проверка на инструмент')
        for issue in instrument['issues']:
            if not isinstance(issue, dict) or not isinstance(issue.get('message_bg'), str):
                raise ValueError('Невалидна причина за ограничение')
    return data


def load(root):
    root = Path(root)
    try:
        data = validate(json.loads((root / 'research/baseline.json').read_text('utf-8')))
        settings = json.loads((root / 'engine/config.json').read_text('utf-8-sig'))
        if not isinstance(settings, dict):
            raise ValueError('Настройките не са валиден обект')
        data['settings_match'] = fingerprint(effective_config(settings)) == data['config_hash']
        data['rules_match'] = hashlib.sha256((root / 'engine/decision_rules.py').read_bytes()).hexdigest() == data['rules_sha256']
        data['available'] = True
        data['execution_authorized'] = False
        data['qualification'] = 'UNVERIFIED'
        return data
    except (OSError, ValueError, TypeError, KeyError, AttributeError, OverflowError):
        return {'schema': SCHEMA, 'available': False, 'results': [], 'execution_authorized': False,
                'qualification': 'UNVERIFIED', 'error': 'Няма валиден отчет за изпитванията. Резултатите не могат да се потвърдят.'}


def render(data, symbol='', strategy=''):
    e = lambda v: html.escape(str(v if v is not None else '—'), quote=True)
    if not data.get('available'):
        return f'<div class="card"><h2>Изпитвания</h2><p>{e(data.get("error"))}</p></div>'
    rows = []
    for row in data['results']:
        if (symbol in SYMBOLS and row['symbol'] != symbol) or (strategy in ('S5-D1', 'S5-H1') and row['strategy'] != strategy):
            continue
        dev, hold = row['periods']['development'], row['periods']['holdout']
        def metric(item):
            return 'няма сделки' if not item['trades'] else f"{item['trades']} / {item['pf_after_spread']:.3f}" if item['pf_after_spread'] is not None else f"{item['trades']} / не се определя"
        instrument_audit = data['audit']['instruments'][row['symbol']]
        conflicts = instrument_audit.get('source_conflicts')
        reasons = [i['message_bg'] for i in instrument_audit['issues']]
        reasons += ['Комисиони, исторически суап и приплъзване не са калибрирани.', 'Липсва изпълнен етап с 30 брокерски демо сделки.']
        if not row['configured']:
            reasons.insert(0, 'Стратегията не е включена за този инструмент в изследваните настройки.')
        if dev['trades'] and dev['pf_after_spread'] is not None and dev['pf_after_spread'] < 1.2:
            reasons.append('Разработката до 2020 г. е под изисквания PF 1,20 дори преди всички разходи.')
        if hold['trades'] < 10:
            reasons.append('Отделният период от 2021 г. има по-малко от 10 сделки.')
        if hold['trades'] and hold['pf_after_spread'] is not None and hold['pf_after_spread'] < 1.15:
            reasons.append('Отделният период от 2021 г. е под изисквания PF 1,15 дори преди всички разходи.')
        detail = ''.join(f'<li>{e(x)}</li>' for x in dict.fromkeys(reasons))
        status = 'Конфликтни източници' if conflicts else 'Непроверен'
        rows.append(f"<tr><td>{e(row['symbol'])}</td><td>{e(row['strategy'])}</td><td>{row['bars']['D1']} / {row['bars']['H1']}</td><td>{e(metric(dev))}</td><td>{e(metric(hold))}</td><td>{status}<details><summary>Какво липсва?</summary><ul>{detail}</ul></details></td></tr>")
    options = lambda values, selected: ''.join(f'<option value="{e(v)}"'+(' selected' if v == selected else '')+f'>{e(v)}</option>' for v in values)
    match = data.get('settings_match') and data.get('rules_match')
    context = 'Настройките и сигналните правила съвпадат с изследването.' if match else 'Има промяна в настройките или сигналните правила. Тези резултати са за предишната конфигурация; нужно е ново изпитване.'
    conflict_note = ('<p style="border-left:3px solid #e5484d;padding:12px;background:rgba(229,72,77,.08)"><b>Открито разминаване в историческите източници.</b> Част от старите файлове не съвпадат по час или цени със запазените свещи от терминала. Техните PF стойности са само следа от по-ранната симулация и не доказват ефективност. Нужно е повторно извличане и изпитване с проверен произход.</p>'
                     if any(x.get('source_conflicts') for x in data['audit']['instruments'].values()) else '')
    return f'''<div class="card"><h2>Доказателства за H1/D1 стратегиите</h2>
    <p><b>Няма преминал кандидат за нова автоматизация.</b> Числата по-долу са диагностична симулация след спред, преди останалите разходи.</p>
    {conflict_note}
    <p>{e(context)}</p><p>Изчислено: {e(data['generated_utc'])}; данни до: {e(data['data_asof_utc'])}.</p>
    <p>Проверката на данните е за текущите локални файлове. Точната им версия при по-ранната симулация не е удостоверена; нужен е повторен тест със запазен произход на входните данни.</p>
    <p>PF е отношението на сумата на положителните към абсолютната сума на отрицателните резултати. Тук резултатите са в R — единици първоначален риск. Това не е доходност в пари и не е обещание за бъдещ резултат.</p>
    <form method="get" action="/research" style="display:flex;gap:12px;flex-wrap:wrap"><label>Инструмент <select name="symbol"><option value="">Всички</option>{options(SYMBOLS,symbol)}</select></label>
    <label>Стратегия <select name="strategy"><option value="">Всички</option>{options(('S5-D1','S5-H1'),strategy)}</select></label><button type="submit">Покажи</button></form>
    <div style="overflow-x:auto"><table><thead><tr><th>Инструмент</th><th>Стратегия</th><th>Свещи D1 / H1</th><th>До 2020: сделки / PF</th><th>От 2021: сделки / PF</th><th>Готовност</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></div>
    <div class="card"><h3>Следващи условия за приемане</h3><p>Пълни проверени данни и разходи → разработка до 2020 г. с PF ≥ 1,20 → отделен период от 2021 г. с PF ≥ 1,15 и поне 10 сделки → поне 30 брокерски демо сделки с положително очакване.</p>
    <p>Ръчните сделки и докосването на прогнозното квадратче не заменят тези изпитвания. Тази страница не променя риска и не разрешава поръчки.</p></div>'''
