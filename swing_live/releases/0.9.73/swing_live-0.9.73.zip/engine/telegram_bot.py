"""Read-only Telegram answers based on this installation's recorded engine state."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import threading
import time
from datetime import datetime, timezone

import notify

BASE = Path(__file__).resolve().parents[1]


def status_text(base=BASE):
    try:
        state = json.loads((Path(base) / "logs/state.json").read_text(encoding="utf-8"))
        stamp = datetime.fromisoformat(state["last_cycle_utc"].replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            raise ValueError("missing timezone")
    except (OSError, ValueError, KeyError):
        return "Няма потвърдени данни от двигателя. Отвори DEMON → Готовност и провери връзката с MT5."
    config = state.get("active_config") or {}
    age = max(0, (datetime.now(timezone.utc) - stamp).total_seconds())
    stale = age > max(180, float(config.get("cycle_seconds") or 800) * 2 + 60)
    account = state.get("account") or {}
    kind = {"live": "РЕАЛНА", "demo": "ДЕМО"}.get(state.get("account_mode"), "непотвърдена")
    action = {"WAIT": "Изчаква", "OPEN": "Отворена сделка", "CLOSE": "Затворена сделка"}.get(
        state.get("last_action"), str(state.get("last_action") or "няма решение"))
    positions = (state.get("position") or {}).get("all")
    count = len(positions) if isinstance(positions, list) else "няма данни"
    return (
        ("ВНИМАНИЕ: данните са остарели; не потвърждават, че двигателят работи.\n\n" if stale else "") +
        f"Сметка: {kind} · {account.get('login', 'няма данни')}\n"
        f"Сървър: {account.get('server', 'няма данни')}\n"
        f"Последен цикъл: {stamp.astimezone().strftime('%d.%m.%Y %H:%M:%S %Z')}\n"
        f"Решение: {action}\n"
        f"Причина: {state.get('last_reason') or 'няма записана причина'}\n"
        f"Позиции на DEMON при последния цикъл: {count}\n\n"
        "Това е отчет от последния цикъл. Изчакване без сделка само по себе си не означава повреда."
    )


def report_png(text, output):
    """Render an actual status report, never an invented market chart."""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return windows_report_png(text, output)
    windows = Path(os.environ.get("SystemRoot") or "C:/Windows")
    font_path = windows / "Fonts/segoeui.ttf"
    bold_path = windows / "Fonts/segoeuib.ttf"
    regular = ImageFont.truetype(str(font_path) if font_path.exists() else "DejaVuSans.ttf", 25)
    bold = ImageFont.truetype(str(bold_path) if bold_path.exists() else "DejaVuSans.ttf", 42)
    probe = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    lines = []
    for paragraph in text.splitlines():
        line = ""
        for word in paragraph.split():
            candidate = (line + " " + word).strip()
            if probe.textlength(candidate, font=regular) > 1016 and line:
                lines.append(line)
                line = word
            else:
                line = candidate
        lines.append(line)
    image = Image.new("RGB", (1120, 170 + len(lines) * 38), "#0c141b")
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((36, 30, 1084, 110), radius=18, fill="#15372e")
    draw.text((56, 43), "DEMON  /  СЪСТОЯНИЕ", fill="#8ef0bf", font=bold)
    for i, line in enumerate(lines):
        draw.text((52, 140 + i * 38), line, fill="#e4ecef", font=regular)
    image.save(output, "PNG")
    return Path(output)


def windows_report_png(text, output):
    """Windows built-in renderer for clients that do not have Pillow installed."""
    import subprocess
    windows = Path(os.environ.get("SystemRoot") or "C:/Windows")
    shell = windows / "System32/WindowsPowerShell/v1.0/powershell.exe"
    with tempfile.TemporaryDirectory(prefix="demon-image-") as temp:
        spec = Path(temp) / "report.json"
        spec.write_text(json.dumps({"text": text, "output": str(Path(output).resolve())},
                                   ensure_ascii=False), encoding="utf-8")
        subprocess.run([str(shell), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
                        str(BASE / "scripts/render_report.ps1"), "-InputFile", str(spec)],
                       capture_output=True, check=True, timeout=30,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return Path(output)


def answer(text, base=BASE):
    query = str(text).strip().casefold().split("@")[0]
    if query in ("/status", "статус", "състояние", "как е", "работи ли", "какво става"):
        return status_text(base), False
    if query in ("/photo", "/report", "снимка", "отчет", "доклад"):
        return status_text(base), True
    return ("Мога да покажа реалните данни от DEMON:\n"
            "/status — сметка, последен цикъл и причина за изчакване\n"
            "/report — същият отчет като изображение\n"
            "/help — тези команди\n\n"
            "За въпрос извън тези команди нямам достатъчно данни. "
            "Не изпълнявам сделки или промени по настройките през Telegram."), False


def poll_once(base=BASE):
    if os.environ.get("DEMON_NOTIFY_OFF"):
        return
    tg = notify.telegram_settings()
    if not tg.get("enabled") or not tg.get("token") or not tg.get("chat_id"):
        return
    base = Path(base)
    identity = hashlib.sha256(str(tg["token"]).encode()).hexdigest()[:16]
    cursor = base / "logs" / ("telegram_cursor_" + identity + ".json")
    try:
        offset = int(json.loads(cursor.read_text(encoding="utf-8"))["offset"])
    except (OSError, ValueError, KeyError):
        offset = None
    payload = {"timeout": 0, "allowed_updates": ["message"], "limit": 30}
    if offset is not None:
        payload["offset"] = offset
    updates = notify.request_api(tg["token"], "getUpdates", payload)
    if not isinstance(updates, list):
        raise RuntimeError("Telegram: невалиден списък със съобщения")
    for update in updates:
        next_offset = int(update["update_id"]) + 1
        message = update.get("message") or {}
        authorized = str((message.get("chat") or {}).get("id")) == str(tg["chat_id"])
        # Ignore historical backlog and non-text updates. Never reply to another chat.
        fresh = 0 <= time.time() - float(message.get("date") or 0) <= 300
        if authorized and fresh and isinstance(message.get("text"), str):
            text, photo = answer(message["text"], base)
            with tempfile.TemporaryDirectory(prefix="demon-report-") as temp:
                picture = None
                if photo:
                    try:
                        picture = report_png(text, Path(temp) / "report.png")
                    except Exception:
                        text += "\n\nИзображението не можа да бъде създадено; показвам текстовия отчет."
                result = notify.send("info", "status", text, photo=picture)
                if result.get("delivery") == "failed":
                    # Keep cursor for bounded retry on the next poll; do not silently lose a request.
                    raise RuntimeError(result.get("delivery_error", "Telegram: отговорът не е доставен"))
        cursor.parent.mkdir(parents=True, exist_ok=True)
        tmp = cursor.with_suffix(".tmp")
        tmp.write_text(json.dumps({"offset": next_offset}), encoding="utf-8")
        tmp.replace(cursor)


def start():
    if os.environ.get("DEMON_NOTIFY_OFF"):
        return

    def run():
        # One poller per token on this computer, even with two DEMON installations.
        import socket
        tg = notify.telegram_settings()
        identity = hashlib.sha256(str(tg.get("token") or "").encode()).digest()
        port = 53000 + int.from_bytes(identity[:2], "big") % 10000
        with socket.socket() as lock:
            try:
                if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                    lock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                lock.bind(("127.0.0.1", port))
            except OSError:
                return
            previous_error = None
            while True:
                current = notify.telegram_settings()
                if hashlib.sha256(str(current.get("token") or "").encode()).digest() != identity:
                    timer = threading.Timer(1, start)
                    timer.daemon = True
                    timer.start()
                    return
                try:
                    poll_once()
                    previous_error = None
                except Exception as exc:
                    error = str(exc) if isinstance(exc, RuntimeError) else type(exc).__name__
                    if error != previous_error:
                        try:
                            notify.append("warning", "system", "Telegram отговори: " + error)
                        except OSError:
                            pass
                    previous_error = error
                time.sleep(10 if previous_error is None else 60)
    threading.Thread(target=run, name="telegram-read-only", daemon=True).start()
