"""Read-only MT5 observation; called under the Center's existing MT5 lock.
No engine import, order_send, account switch, or legacy signal output.
"""
import json, time, threading, socket
from datetime import datetime,timezone,timedelta
from pathlib import Path
from decision_core import SYMBOLS,effective_config,evaluate,fingerprint,settings_comparison,normalized_time
from decision_store import Store,atomic
from market_data_capture import capture_source,capture_existing,ClockPolicy,ClosedBarCache,same_source

def read(path):
    try:return json.loads(Path(path).read_text('utf-8'))
    except (OSError,ValueError):return {}

def capture(mt5,cfg,root,now=None):
    now=time.time() if now is None else now
    ai=mt5.account_info();term=mt5.terminal_info()
    if ai is None or term is None or not term.connected:raise ValueError('MT5 няма връзка')
    account={k:getattr(ai,k) for k in ('login','server','balance','equity','margin_free','currency','trade_mode')}
    expected=cfg.get('demo_login') if cfg['mode']=='demo' else cfg.get('live_login')
    if expected and account['login']!=int(expected):raise ValueError('Сметката е различна от записаната')
    if cfg['mode']=='live' and account['server']!=cfg.get('live_server'):raise ValueError('Сървърът е различен от записания')
    if Path(term.path).resolve()!=Path(cfg['terminal_path']).parent.resolve():raise ValueError('Грешен терминал')
    expected_mode={'demo':0,'live':2}.get(cfg['mode'])
    if expected_mode is not None and account['trade_mode']!=expected_mode:raise ValueError('Типът на сметката не съвпада с режима')
    source=capture_source(mt5)
    policy=ClockPolicy('server_wall','Europe/Helsinki','installation-specific AdmiralsGroup-Live observation; historical DST unverified',False) if account['server']=='AdmiralsGroup-Live' else ClockPolicy()
    packets=[];capture_errors=[]
    positions=mt5.positions_get()
    state=read(Path(root)/'logs/state.json')
    try: state_age=now-datetime.fromisoformat(state['last_cycle_utc']).timestamp()
    except (KeyError,ValueError,TypeError): state_age=1e99
    state_valid=0<=state_age<=max(180,cfg['cycle_seconds']*3) and state.get('account')=={'login':account['login'],'server':account['server']}
    settings=settings_comparison(cfg,state.get('active_config') if state_valid else {})
    guards=state.get('guards',{}) if state_valid else {}
    guard_blocks=[]
    if not state_valid:guard_blocks.append('Няма актуален отчет за предпазителите от двигателя')
    for key,label in [('stop_flag','STOP е активен'),('paused','Двигателят е в защитна пауза'),('news_blackout','Новинарски blackout')]:
        if guards.get(key):guard_blocks.append(label)
    for key,label in [('session_ok','Извън разрешена сесия'),('data_fresh','Двигателят отчита остарели данни')]:
        if guards.get(key) is False:guard_blocks.append(label)
    if any(r['state']=='DIFFERENT' for r in settings):guard_blocks.append('Записаните и активните настройки се различават')
    daily=guards.get('daily_realized_pct');peak=guards.get('dd_from_peak_pct')
    if daily is not None and daily<=-float(cfg['guards']['max_daily_loss_pct']):guard_blocks.append(f'Дневният спад на equity {daily:.2f}% надвишава лимита {cfg["guards"]["max_daily_loss_pct"]}%')
    if peak is not None and peak>=float(cfg['guards']['max_peak_dd_pct']):guard_blocks.append(f'Спадът от върха {peak:.2f}% надвишава лимита {cfg["guards"]["max_peak_dd_pct"]}%')

    available=mt5.symbols_get()
    if available is None:raise ValueError('Списъкът с инструменти е недостъпен')
    byname={s.name:s for s in available}
    markets={};rows=[]
    for symbol in SYMBOLS:
        aliases=[symbol]+(['XAUUSD'] if symbol=='GOLD' else [])
        matches=[s for s in aliases if s in byname]
        # Exact alias only; do not silently pick a suffix/CFD with different specifications.
        broker=matches[0] if matches else None
        market={'broker_symbol':broker,'execution_blocks':['Общото изпълнение не е активирано; квалификацията и всички предпазители предстоят'],
                'positions':None if positions is None else [int(p.ticket) for p in positions if p.symbol==broker]}
        market['execution_blocks'].extend(guard_blocks)
        try:
            if broker is None:raise ValueError('Няма проверено брокерско име')
            info=mt5.symbol_info(broker)
            if info is None or not info.visible:raise ValueError('Инструментът не е наличен в Market Watch')
            tick=mt5.symbol_info_tick(broker)
            if tick is None:raise ValueError('Липсва котировка')
            market['spec']={k:getattr(info,k) for k in ('point','digits','trade_tick_size','trade_tick_value','volume_min','volume_max','volume_step','trade_stops_level','trade_mode','swap_long','swap_short')}
            market['quote']={'time':float(tick.time_msc)/1000 if tick.time_msc else tick.time,'bid':tick.bid,'ask':tick.ask}
            for layer,count in [('d1',400),('h1',300)]:
                rates=mt5.copy_rates_from_pos(broker,mt5.TIMEFRAME_D1 if layer=='d1' else mt5.TIMEFRAME_H1,0,count)
                packet=capture_existing(mt5,source,symbol,broker,layer.upper(),rates,policy,now,price_tolerance=float(info.point))
                packets.append(packet)
                market[layer+'_provenance']={'packet_id':packet['packet_id'],'position_one_match':True,'clock_verified':policy.verified,'source_id':source['source_id']}
                market[layer]=None if rates is None else [{k:float(r[k]) if k!='time' else int(r[k]) for k in ('time','open','high','low','close')} for r in rates]
            if info.trade_mode!=mt5.SYMBOL_TRADE_MODE_FULL:market['execution_blocks'].append('Брокерът ограничава търговията с инструмента')
            if not ai.trade_allowed or not term.trade_allowed:market['execution_blocks'].append('Терминалът или сметката не разрешават автоматична търговия')
        except (ValueError,TypeError,AttributeError) as exc:
            market['error']=str(exc)
            for failed_layer in ('D1','H1'):
                capture_errors.append({'source_id':source['source_id'],'symbol':symbol,'timeframe':failed_layer,'code':type(exc).__name__,'message':str(exc),'utc':now})
        for layer in ('D1','H1'):
            # Calculate loss/margin using the exact pure decision's snapped stop.
            preliminary=evaluate(cfg,account,symbol,layer,market,now)
            direction=preliminary['direction']
            local=dict(market)
            if direction and preliminary['entry'] is not None:
                typ=mt5.ORDER_TYPE_BUY if direction=='BUY' else mt5.ORDER_TYPE_SELL
                loss=mt5.order_calc_profit(typ,broker,1.,preliminary['entry'],preliminary['stop'])
                margin=mt5.order_calc_margin(typ,broker,1.,preliminary['entry'])
                local['loss_per_lot']={direction:None if loss is None else abs(float(loss))}
                local['margin_per_lot']={direction:None if margin is None else float(margin)}
            row=evaluate(cfg,account,symbol,layer,local,now)
            if direction and preliminary['entry'] is not None:
                from account_fit import evaluate as account_capacity, policy_from_config
                calculation={k:account[k] for k in ('currency','login','server')}
                calculation.update(symbol=broker,direction=direction,entry=preliminary['entry'],stop=preliminary['stop'],
                    loss_per_lot=local.get('loss_per_lot',{}).get(direction),margin_per_lot=local.get('margin_per_lot',{}).get(direction))
                row['account_fit']=account_capacity(account,policy_from_config(cfg,layer),dict(market.get('spec',{}),name=broker),calculation)
            rows.append(row)
            markets[symbol+'/'+layer]=local
    broker_deals=[];history_error=None
    try:
        deals=mt5.history_deals_get(datetime.fromtimestamp(now,timezone.utc)-timedelta(days=30),datetime.fromtimestamp(now,timezone.utc)+timedelta(days=1))
        if deals is None:raise ValueError('Брокерската история е недостъпна')
        for d in deals:
            if d.type not in (0,1):continue # deposits/withdrawals are not trade results
            origin='manual' if d.magic==0 else 'automatic_python' if d.magic==750501 else 'automatic_legacy' if d.magic==20260318 else 'other'
            raw=float(d.time_msc)/1000 if d.time_msc else d.time
            broker_deals.append({'ticket':int(d.ticket),'position_id':int(d.position_id),'entry':int(d.entry),'symbol':d.symbol,
              'origin':origin,'raw_time':raw,'utc_time':normalized_time(raw,ai.server),'volume':float(d.volume),
              'profit':float(d.profit),'commission':float(d.commission),'swap':float(d.swap),'fee':float(d.fee),
              'net':float(d.profit+d.commission+d.swap+d.fee),'slippage':None})
    except (ValueError,AttributeError,TypeError) as exc:history_error=str(exc);broker_deals=[]
    end=mt5.account_info()
    if end is None or (end.login,end.server)!=(ai.login,ai.server):raise ValueError('Сметката е сменена по време на снимката')
    if not same_source(source,capture_source(mt5)):raise ValueError('Източникът се смени по време на снимката')
    snapshot={'schema':'demon.snapshot/1','generated_utc':now,'account':account,'decisions':rows,
              'settings':settings,'active_config_observed_utc':state.get('last_cycle_utc'),'engine_build':state.get('engine_build'),'engine_last_reason':state.get('last_reason') if state_valid else None,'reported_guards':guards,
              'execution_enabled':False,'qualification':'UNVERIFIED','execution_scope':'observer_only','clock_policy':'AdmiralsGroup-Live EET/EEST; ambiguous/nonexistent local times rejected',
              'news':news_summary(root),'broker_history_status':'UNKNOWN' if history_error else 'OK','broker_history_error':history_error,'broker_deals':broker_deals,'position_times':[{'symbol':p.symbol,'raw':p.time,'utc':normalized_time(p.time,ai.server)} for p in positions or []]}
    snapshot['revision']=fingerprint(snapshot)[:24]
    fixture={'cfg':cfg,'account':account,'now':now,'markets':markets,'revision':snapshot['revision']}
    fixture['_market_packets']=packets
    fixture['_market_errors']=capture_errors
    return snapshot,Path(term.data_path)/'MQL5/Files',fixture

def news_summary(root):
    result=[]
    for name in ('gnews_observation.json','guard_observation.json'):
        p=Path(root)/'logs'/name;doc=read(p)
        for provider, assessment in doc.get('providers',{}).items():
            result.append({'source':provider,'updated_utc':doc.get('fetched_utc'),
                'age_seconds':max(0,time.time()-p.stat().st_mtime),'status':assessment.get('status','UNKNOWN'),
                'newest_age_hours':assessment.get('newest_age_hours'),'current':assessment.get('current'),
                'affects_trading':False})
    return result

def run_once(root,mt5_reader):
    root=Path(root);folder=root/'logs/decisions';folder.mkdir(parents=True,exist_ok=True)
    try:
        # Missing/corrupt settings must not silently become defaults or leave healthy output.
        saved=json.loads((root/'engine/config.json').read_text('utf-8-sig'))
        if not isinstance(saved,dict):raise ValueError('Настройките трябва да са JSON обект')
        cfg=effective_config(saved)
        captured=mt5_reader(lambda mt5:capture(mt5,cfg,root))
        if captured is None:raise ValueError('MT5 адаптерът е недостъпен')
        snapshot,files,fixture=captured
        packets=fixture.pop('_market_packets',[])
        capture_errors=fixture.pop('_market_errors',[])
        cache=ClosedBarCache(root/'logs/market_data')
        try:
            series=[cache.record(packet) for packet in packets]
            series.extend(cache.record_error(**error) for error in capture_errors)
        finally:cache.close()
        snapshot['market_data']={'captured_series':len(series),'conflicting_series':sum(s['status']=='CONFLICT' for s in series),'error_series':len(capture_errors),'clock_verified':False}
        snapshot['revision']=fingerprint(snapshot)[:24]
        fixture['revision']=snapshot['revision']
        store=Store(folder)
        try:
            store.commit(snapshot);store.broker_deals(snapshot['account'],snapshot.get('broker_deals',[]));store.project(files)
        finally:store.close()
        # Last input permits exact observation/replay parity checks, not training.
        atomic(folder/'last_input.json',json.dumps(fixture,allow_nan=False).encode())
        atomic(folder/'terminal_projection.json',json.dumps({'files':str(files)}).encode())
        atomic(folder/'health.json',json.dumps({'ok':True,'utc':time.time(),'revision':snapshot['revision'],
            'degraded':snapshot.get('broker_history_status')!='OK',
            'broker_history_status':snapshot.get('broker_history_status','UNKNOWN'),
            'broker_history_error':snapshot.get('broker_history_error')}).encode())
        return snapshot
    except Exception as exc:
        # Invalidate BOTH views immediately after failure, keeping original journal records.
        try:
            previous=read(folder/'snapshot.json')
            if previous.get('decisions'):
                previous['generated_utc']=time.time()
                for row in previous['decisions']:
                    row['status']='EXPIRED';row['expires_utc']=0;row['error']='Неуспешно обновяване: '+str(exc)
                previous['revision']=fingerprint(previous)[:24]
                store=Store(folder)
                try:store.commit(previous);store.project(read(folder/'terminal_projection.json').get('files'))
                finally:store.close()
        except Exception:pass # Disk failure leaves previous file; TTL/account checks still fail closed.
        atomic(folder/'health.json',json.dumps({'ok':False,'utc':time.time(),'error':str(exc)}).encode())
        raise

def history_cycle(root,mt5_reader,snapshot):
    """One bounded, durable history step after current analysis, on same adapter."""
    from market_history import run_once as collect_history
    from history_runner import run_guarded
    root=Path(root)
    identity={key:snapshot['account'][key] for key in ('login','server')}
    jobs=sorted({(row['symbol'],row['broker_symbol'],row['timeframe']) for row in snapshot.get('decisions',[]) if row.get('broker_symbol')})
    policy=ClockPolicy('server_wall','Europe/Helsinki','installation-specific AdmiralsGroup-Live observation; historical DST unverified',False) if identity['server']=='AdmiralsGroup-Live' else ClockPolicy()
    def checked_reader(callback):
        def collect(api):
            account=api.account_info()
            if account is None or {'login':account.login,'server':account.server}!=identity:raise ValueError('History account differs from current analysis')
            result=callback(api)
            account=api.account_info()
            if account is None or {'login':account.login,'server':account.server}!=identity:raise ValueError('History account changed during request')
            return result
        return mt5_reader(collect)
    output=run_guarded(checked_reader,root/'logs/market_data',jobs,policy,runner=collect_history,chunk_size=128)
    atomic(root/'logs/history_backfill.json',json.dumps(dict(output,updated_utc=time.time()),allow_nan=False).encode())
    return output


_worker=None

def start(root,mt5_reader):
    """App-owned read-only worker. A loopback bind makes a second process fail closed."""
    global _worker
    if _worker and _worker.is_alive():return
    def work():
        lease=socket.socket()
        if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):lease.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        try:lease.bind(('127.0.0.1',5129))
        except OSError:lease.close();return
        try:
            while True:
                try:
                    snapshot=run_once(root,mt5_reader)
                    history_cycle(root,mt5_reader,snapshot)
                except Exception:pass # persisted health, stale projections never become ready
                time.sleep(30)
        finally:lease.close()
    _worker=threading.Thread(target=work,name='DEMON-readonly-analysis',daemon=True);_worker.start()
