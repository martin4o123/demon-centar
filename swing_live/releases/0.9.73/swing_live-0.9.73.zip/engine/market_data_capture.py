"""Provenanced closed-bar capture, only through an injected existing MT5 reader.

No MetaTrader5 import, initialize, login, shutdown, order API or scheduler.
Native MT5 calls are synchronous: small requests bound work, NOT elapsed time.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import time
import uuid
from zoneinfo import ZoneInfo

SCHEMA = 'demon.market-capture/1'
TIMEFRAMES = ('D1', 'H1')
PRICE_FIELDS = ('open', 'high', 'low', 'close')
EXTRA_FIELDS = ('tick_volume', 'spread', 'real_volume')


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def finite(value, name, positive=False):
    if isinstance(value, bool):
        raise ValueError(f'{name}: boolean is not a number')
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f'{name}: invalid number') from exc
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f'{name}: nonfinite/nonpositive number')
    return value


def stamp(value):
    value = finite(value, 'timestamp', True)
    if not value.is_integer() or value > 4102444800:
        raise ValueError('timestamp: outside plausible integer epoch range')
    return int(value)


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('xb') as handle:
            handle.write(encoded(value))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


@dataclass(frozen=True)
class ClockPolicy:
    """Declared clock mapping; verification requires separate evidence.

    'unknown' preserves raw time and UTC=None. 'documented_utc' follows MT5
    docs; 'server_wall' is an explicit installation-specific hypothesis.
    No policy is inferred from stale quotes or a file/column name.
    """
    mode: str = 'unknown'
    zone: str | None = None
    evidence_ref: str | None = None
    verified: bool = False

    def validate(self):
        if not isinstance(self.verified, bool):
            raise ValueError('Clock verified flag must be boolean')
        if self.evidence_ref is not None and (not isinstance(self.evidence_ref, str) or not self.evidence_ref.strip()):
            raise ValueError('Clock evidence must be a nonempty reference')
        if self.mode not in ('unknown', 'documented_utc', 'server_wall'):
            raise ValueError('Unsupported clock policy')
        if self.verified and (not self.evidence_ref or self.mode == 'unknown'):
            raise ValueError('Verified clock requires a known mapping and evidence reference')
        if self.mode == 'server_wall' and not self.zone:
            raise ValueError('Explicit server-wall policy requires an IANA zone')
        if self.mode != 'server_wall' and self.zone is not None:
            raise ValueError('IANA zone only applies to server-wall policy')
        if self.zone:
            ZoneInfo(self.zone)
        return asdict(self)

    def normalize(self, raw):
        self.validate()
        raw = stamp(raw)
        if self.mode == 'unknown':
            return None
        if self.mode == 'documented_utc':
            return raw
        zone = ZoneInfo(self.zone)
        wall = datetime.fromtimestamp(raw, timezone.utc).replace(tzinfo=None)
        first, second = wall.replace(tzinfo=zone, fold=0), wall.replace(tzinfo=zone, fold=1)
        if first.utcoffset() != second.utcoffset():
            raise ValueError('Ambiguous/nonexistent server-wall timestamp')
        normalized = int(first.timestamp())
        if datetime.fromtimestamp(normalized, zone).replace(tzinfo=None) != wall:
            raise ValueError('Nonexistent server-wall timestamp')
        return normalized


def capture_source(api):
    """Call only inside the application's existing reader lock/session."""
    account, terminal = api.account_info(), api.terminal_info()
    if account is None or terminal is None or not getattr(terminal, 'connected', False):
        raise ValueError('Existing MT5 reader is disconnected')
    server, broker = str(account.server), str(getattr(account, 'company', ''))
    if not server or not getattr(terminal, 'path', None):
        raise ValueError('Missing source server/terminal identity')
    identity = {'broker': broker, 'server': server, 'account_ref': digest({'login': int(account.login), 'server': server}),
                'terminal_path': str(Path(terminal.path)), 'terminal_data_path': str(Path(terminal.data_path))}
    return {**identity, 'source_id': digest(identity), 'terminal_build': getattr(terminal, 'build', None),
            'python_package_version': str(getattr(api, '__version__', 'UNKNOWN')),
            'source_kind': 'active_mt5_reader', 'provenance_status': 'DIRECT_API_CAPTURE'}


def same_source(before, after):
    return before['source_id'] == after['source_id']


def rows_as_dicts(rows):
    if rows is None:
        raise ValueError('Rates unavailable (None), not an empty historical series')
    result = []
    for item in rows:
        fields = item.keys() if isinstance(item, dict) else (getattr(getattr(item, 'dtype', None), 'names', None) or ())
        if not fields:
            raise ValueError('Unsupported rate row type')
        row = {'time': stamp(item['time'])}
        for key in PRICE_FIELDS:
            row[key] = finite(item[key], key, True)
        if row['low'] > min(row['open'], row['close']) or row['high'] < max(row['open'], row['close']) or row['low'] > row['high']:
            raise ValueError('Invalid OHLC bounds')
        for key in EXTRA_FIELDS:
            row[key] = finite(item[key], key) if key in fields and item[key] is not None else None
            if row[key] is not None and row[key] < 0:
                raise ValueError(f'Negative {key}')
        result.append(row)
    if any(a['time'] >= b['time'] for a, b in zip(result, result[1:])):
        raise ValueError('Duplicate or unordered rate timestamps')
    return result


def price_equal(first, second, tolerance):
    return all(abs(first[key] - second[key]) <= tolerance for key in PRICE_FIELDS)


def make_packet(source, symbol, broker_symbol, timeframe, rates, pos1_sample, clock_policy,
                captured_utc, *, mode='position_zero_buffer', price_tolerance=0.0, request=None):
    """Pure conversion. Original raw timestamps never change.

    A position-zero buffer discards its final forming bar and must agree with
    the independently read single position-one bar. Historical closed chunks
    must not contain anything newer than that position-one anchor.
    """
    captured_utc = finite(captured_utc, 'capture UTC', True)
    if timeframe not in TIMEFRAMES or not symbol or not broker_symbol:
        raise ValueError('Unsupported instrument/timeframe')
    tolerance = finite(price_tolerance, 'price tolerance')
    if tolerance < 0:
        raise ValueError('Negative price tolerance')
    policy = clock_policy.validate()
    rows, sample = rows_as_dicts(rates), rows_as_dicts(pos1_sample)
    if len(sample) != 1:
        raise ValueError('Exactly one independent position-one sample is required')
    if mode == 'position_zero_buffer':
        if len(rows) < 2:
            raise ValueError('Position-zero buffer requires forming and closed bars')
        forming, closed = rows[-1], rows[:-1]
        if closed[-1]['time'] != sample[0]['time']:
            raise ValueError('Position-one anchor changed during capture; retry on next cycle')
        if not price_equal(closed[-1], sample[0], tolerance):
            raise ValueError('Latest closed-bar OHLC differs from independent position-one sample')
    elif mode == 'closed_history_chunk':
        forming, closed = None, rows
        if any(row['time'] > sample[0]['time'] for row in closed):
            raise ValueError('Historical chunk contains a bar newer than the last closed anchor')
        for row in closed:
            if row['time'] == sample[0]['time'] and not price_equal(row, sample[0], tolerance):
                raise ValueError('Historical latest closed bar differs from position-one sample')
    else:
        raise ValueError('Unsupported rate capture mode')
    captured_rows = []
    for row in closed:
        values = {key: row[key] for key in PRICE_FIELDS + EXTRA_FIELDS}
        normalized = clock_policy.normalize(row['time'])
        captured_rows.append({'schema': 'demon.closed-bar/1', 'source': source,
                              'symbol': symbol, 'broker_symbol': broker_symbol, 'timeframe': timeframe,
                              'time_raw': row['time'], 'time_utc': normalized, 'clock_policy': policy,
                              'capture_utc': captured_utc, 'closed': True,
                              'closure_basis': 'independent_position_one_anchor',
                              **values, 'ohlc_sha256': digest({k: row[k] for k in PRICE_FIELDS}),
                              'data_sha256': digest({'time_raw': row['time'], **values})})
    packet = {'schema': SCHEMA, 'source': source, 'symbol': symbol, 'broker_symbol': broker_symbol,
              'timeframe': timeframe, 'capture_utc': captured_utc, 'clock_policy': policy,
              'request': request or {'mode': mode}, 'forming_raw_excluded': forming['time'] if forming else None,
              'position_one_raw': sample[0]['time'], 'position_one_sha256': digest(sample[0]),
              'position_one_match': True, 'bars': captured_rows,
              'input_sha256': digest(rows), 'price_tolerance': tolerance}
    packet['packet_id'] = digest(packet)
    return packet


def capture_existing(api, source, symbol, broker_symbol, timeframe, rates_pos0,
                     clock_policy, captured_utc=None, price_tolerance=0.0):
    """One extra rates call; integrate within the SAME existing reader callback.

    Caller must finish its account/terminal consistency check before persisting.
    The returned packet has no disk side effects.
    """
    enum = getattr(api, 'TIMEFRAME_' + timeframe)
    sample = api.copy_rates_from_pos(broker_symbol, enum, 1, 1)
    return make_packet(source, symbol, broker_symbol, timeframe, rates_pos0, sample,
                       clock_policy, time.time() if captured_utc is None else captured_utc,
                       price_tolerance=price_tolerance,
                       request={'method': 'existing copy_rates_from_pos', 'start_pos': 0,
                                'count': len(rates_pos0) if rates_pos0 is not None else None,
                                'verification': {'start_pos': 1, 'count': 1}})


class ClosedBarCache:
    """Immutable first capture plus immutable conflicts, SQLite FULL durability.

    JSON health is an atomic rebuildable projection. A failing projection does
    not erase committed evidence. No conflicting bar is silently overwritten.
    """
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.directory / 'closed_bars.sqlite', timeout=1)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS bars(
          source_id TEXT,symbol TEXT,timeframe TEXT,time_raw INTEGER,data_sha256 TEXT,
          ohlc_sha256 TEXT,payload TEXT NOT NULL,
          PRIMARY KEY(source_id,symbol,timeframe,time_raw));
        CREATE TABLE IF NOT EXISTS conflicts(
          source_id TEXT,symbol TEXT,timeframe TEXT,time_raw INTEGER,kind TEXT,
          original_sha256 TEXT,observed_sha256 TEXT,payload TEXT NOT NULL,
          PRIMARY KEY(source_id,symbol,timeframe,time_raw,observed_sha256));
        CREATE TABLE IF NOT EXISTS packets(packet_id TEXT PRIMARY KEY,payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS errors(
          source_id TEXT,symbol TEXT,timeframe TEXT,utc REAL,code TEXT,message TEXT);
        CREATE TABLE IF NOT EXISTS health(
          source_id TEXT,symbol TEXT,timeframe TEXT,payload TEXT,
          PRIMARY KEY(source_id,symbol,timeframe));
        ''')
        for table in ('bars', 'conflicts', 'packets', 'errors'):
            for verb in ('UPDATE', 'DELETE'):
                self.db.execute(f"CREATE TRIGGER IF NOT EXISTS immutable_{table}_{verb} BEFORE {verb} ON {table} BEGIN SELECT RAISE(ABORT,'immutable market evidence'); END")
        self.db.commit()

    def close(self):
        self.db.close()

    def _health(self, source_id, symbol, timeframe, data):
        self.db.execute('INSERT INTO health VALUES(?,?,?,?) ON CONFLICT(source_id,symbol,timeframe) DO UPDATE SET payload=excluded.payload',
                        (source_id, symbol, timeframe, encoded(data).decode()))

    def record(self, packet):
        if packet.get('schema') != SCHEMA or packet.get('position_one_match') is not True:
            raise ValueError('Unverified capture packet')
        expected_id = digest({k: v for k, v in packet.items() if k != 'packet_id'})
        if expected_id != packet.get('packet_id'):
            raise ValueError('Capture packet checksum mismatch')
        source_id, symbol, tf = packet['source']['source_id'], packet['symbol'], packet['timeframe']
        counts = {'inserted': 0, 'unchanged': 0, 'ohlc_conflicts': 0, 'identity_or_clock_conflicts': 0, 'metadata_variants': 0}
        with self.db:
            for bar in packet['bars']:
                if bar['source']['source_id'] != source_id or bar['symbol'] != symbol or bar['timeframe'] != tf or not bar['closed']:
                    raise ValueError('Bar identity differs from packet')
                key = (source_id, symbol, tf, stamp(bar['time_raw']))
                existing = self.db.execute('SELECT data_sha256,ohlc_sha256,payload FROM bars WHERE source_id=? AND symbol=? AND timeframe=? AND time_raw=?', key).fetchone()
                if existing is None:
                    self.db.execute('INSERT INTO bars VALUES(?,?,?,?,?,?,?)', (*key, bar['data_sha256'], bar['ohlc_sha256'], encoded(bar).decode()))
                    counts['inserted'] += 1
                else:
                    previous = json.loads(existing['payload'])
                    if previous['broker_symbol'] != bar['broker_symbol']:
                        kind = 'SOURCE_MAPPING_CONFLICT'
                    elif previous['clock_policy'] != bar['clock_policy']:
                        kind = 'CLOCK_POLICY_CONFLICT'
                    elif existing['data_sha256'] == bar['data_sha256']:
                        counts['unchanged'] += 1
                        continue
                    else:
                        kind = 'OHLC_CONFLICT' if existing['ohlc_sha256'] != bar['ohlc_sha256'] else 'METADATA_VARIANT'
                    observed_hash = digest({'data': bar['data_sha256'], 'broker_symbol': bar['broker_symbol'], 'clock_policy': bar['clock_policy']})
                    self.db.execute('INSERT OR IGNORE INTO conflicts VALUES(?,?,?,?,?,?,?,?)', (*key, kind, existing['data_sha256'], observed_hash, encoded(bar).decode()))
                    counts['ohlc_conflicts' if kind == 'OHLC_CONFLICT' else 'metadata_variants' if kind == 'METADATA_VARIANT' else 'identity_or_clock_conflicts'] += 1
            header = {k: v for k, v in packet.items() if k != 'bars'}
            header['bar_count'] = len(packet['bars'])
            self.db.execute('INSERT OR IGNORE INTO packets VALUES(?,?)', (packet['packet_id'], encoded(header).decode()))
            conflict_count = self.db.execute("SELECT COUNT(*) FROM conflicts WHERE source_id=? AND symbol=? AND timeframe=? AND kind='OHLC_CONFLICT'", (source_id, symbol, tf)).fetchone()[0]
            serious_conflicts = self.db.execute("SELECT COUNT(*) FROM conflicts WHERE source_id=? AND symbol=? AND timeframe=? AND kind!='METADATA_VARIANT'", (source_id, symbol, tf)).fetchone()[0]
            bars_total = self.db.execute('SELECT COUNT(*) FROM bars WHERE source_id=? AND symbol=? AND timeframe=?', (source_id, symbol, tf)).fetchone()[0]
            health = {'symbol': symbol, 'timeframe': tf, 'source_id': source_id, 'capture_utc': packet['capture_utc'],
                      'status': 'CONFLICT' if serious_conflicts else 'CAPTURED', 'bars_total': bars_total,
                      'unresolved_ohlc_conflicts': conflict_count, 'unresolved_data_conflicts': serious_conflicts, 'latest_closed_raw': packet['position_one_raw'],
                      'clock_verified': packet['clock_policy']['verified'], 'clock_policy': packet['clock_policy'],
                      'packet_id': packet['packet_id'], 'last_capture_counts': counts,
                      'message_bg': 'Има конфликт в OHLC, брокерското име или часовата политика; първият запис е запазен.' if serious_conflicts else 'Затворените свещи са сверени с позиция 1 и записани с произход.'}
            self._health(source_id, symbol, tf, health)
        self.project_health()
        return health

    def record_error(self, source_id, symbol, timeframe, code, message, utc=None):
        utc = time.time() if utc is None else finite(utc, 'error UTC', True)
        health = {'source_id': source_id, 'symbol': symbol, 'timeframe': timeframe,
                  'status': 'ERROR', 'capture_utc': utc, 'code': code, 'message_bg': str(message)}
        with self.db:
            self.db.execute('INSERT INTO errors VALUES(?,?,?,?,?,?)', (source_id, symbol, timeframe, utc, code, str(message)))
            self._health(source_id, symbol, timeframe, health)
        self.project_health()
        return health

    def project_health(self):
        records = [json.loads(r['payload']) for r in self.db.execute('SELECT payload FROM health ORDER BY source_id,symbol,timeframe')]
        result = {'schema': 'demon.market-data-health/1', 'generated_utc': time.time(), 'series': records,
                  'execution_authorized': False, 'source_of_truth': 'closed_bars.sqlite',
                  'summary': {'series': len(records), 'errors': sum(r['status'] == 'ERROR' for r in records),
                              'conflicting': sum(r['status'] == 'CONFLICT' for r in records),
                              'clock_verified_series': sum(bool(r.get('clock_verified')) for r in records)}}
        atomic_json(self.directory / 'health.json', result)
        return result

    def export_series(self, source_id, symbol, timeframe, destination):
        rows = [json.loads(r['payload']) for r in self.db.execute('SELECT payload FROM bars WHERE source_id=? AND symbol=? AND timeframe=? ORDER BY time_raw', (source_id, symbol, timeframe))]
        value = {'schema': 'demon.closed-bars-export/1', 'source_id': source_id, 'symbol': symbol, 'timeframe': timeframe,
                 'generated_utc': time.time(), 'bars': rows, 'payload_sha256': digest(rows),
                 'qualification': 'UNVERIFIED', 'execution_authorized': False}
        atomic_json(destination, value)
        return value


@dataclass
class BackfillCursor:
    source_id: str | None = None
    before_raw: int | None = None
    done: bool = False
    steps: int = 0
    halted_reason: str | None = None


class HistoryBackfill:
    """At most one bounded historical request per explicit step, plus pos1.

    A cursor uses the returned RAW epoch, so no timezone shift is guessed.
    It is immutable on failure. The caller decides when to persist/schedule it.
    Slow native calls cannot be cancelled here; budget overruns stop subsequent
    steps and are surfaced, never worked around with parallel MT5 threads.
    """
    def __init__(self, chunk_size=128, max_step_seconds=5):
        if isinstance(chunk_size, bool) or not isinstance(chunk_size, int) or not 2 <= chunk_size <= 128:
            raise ValueError('Chunk size must be 2..128')
        self.chunk_size = chunk_size
        self.max_step_seconds = finite(max_step_seconds, 'step time budget', True)

    def step(self, existing_reader, cursor, cache, symbol, broker_symbol, timeframe, policy):
        if cursor.halted_reason:
            return {'status': 'HALTED', 'continue_allowed': False, 'cursor': asdict(cursor), 'error': cursor.halted_reason}
        if cursor.done:
            return {'status': 'DONE', 'cursor': asdict(cursor)}
        if timeframe not in TIMEFRAMES:
            raise ValueError('Unsupported timeframe')
        started = time.monotonic()
        if cursor.before_raw is not None:
            stamp(cursor.before_raw)
        def collect(api):
            source = capture_source(api)
            if cursor.source_id and cursor.source_id != source['source_id']:
                raise ValueError('Source/account changed while resuming history')
            enum = getattr(api, 'TIMEFRAME_' + timeframe)
            sample = api.copy_rates_from_pos(broker_symbol, enum, 1, 1)
            if sample is None or len(sample) != 1:
                raise ValueError('Independent latest-closed sample unavailable; history request skipped')
            if time.monotonic() - started > self.max_step_seconds:
                raise TimeoutError('Position-one call exceeded budget; no history request issued')
            if cursor.before_raw is None:
                rates = api.copy_rates_from_pos(broker_symbol, enum, 1, self.chunk_size)
                request = {'method': 'copy_rates_from_pos', 'start_pos': 1, 'count': self.chunk_size}
            else:
                rates = api.copy_rates_from(broker_symbol, enum, cursor.before_raw, self.chunk_size)
                request = {'method': 'copy_rates_from', 'before_raw_inclusive': cursor.before_raw,
                           'count': self.chunk_size, 'date_basis': 'exact raw API cursor; no inferred UTC conversion'}
            if rates is not None and len(rates) > self.chunk_size:
                raise ValueError('Reader exceeded bounded requested bar count')
            packet = make_packet(source, symbol, broker_symbol, timeframe, rates, sample, policy,
                                 time.time(), mode='closed_history_chunk', request=request)
            if cursor.before_raw is not None and any(r['time_raw'] > cursor.before_raw for r in packet['bars']):
                raise ValueError('Historical API returned bars beyond requested raw cursor')
            if not same_source(source, capture_source(api)):
                raise ValueError('Source/account changed during history capture')
            return packet
        try:
            packet = existing_reader(collect)
            if packet is None:
                raise ValueError('Existing reader unavailable or rejected capture')
            health = cache.record(packet)
            duration = time.monotonic() - started
            rows = packet['bars']
            cursor.source_id = packet['source']['source_id']
            cursor.steps += 1
            cursor.before_raw = rows[0]['time_raw'] - 1 if rows else cursor.before_raw
            # Short responses are NOT proof of complete broker history.
            cursor.done = not rows
            if duration > self.max_step_seconds:
                cursor.halted_reason = 'Native reader exceeded time budget; explicit reviewed resume required'
            return {'status': 'BUDGET_EXCEEDED' if duration > self.max_step_seconds else ('EXHAUSTED_VISIBLE_HISTORY' if not rows else 'CAPTURED'),
                    'elapsed_seconds': duration, 'continue_allowed': duration <= self.max_step_seconds and bool(rows),
                    'cursor': asdict(cursor), 'health': health,
                    'completeness': 'UNKNOWN; terminal history/max-bars limits apply'}
        except Exception as exc:
            if isinstance(exc, TimeoutError):
                cursor.halted_reason = str(exc)
            cache.record_error(cursor.source_id or 'unresolved', symbol, timeframe, type(exc).__name__, str(exc))
            return {'status': 'ERROR', 'continue_allowed': False, 'cursor': asdict(cursor),
                    'error': str(exc), 'elapsed_seconds': time.monotonic() - started}
