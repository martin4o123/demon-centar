"""Observation runner and escaped dashboard panel. Never writes engine inputs."""
from __future__ import annotations
import html
from pathlib import Path
import news_pipeline as core

BASE_DIR = Path(__file__).resolve().parent.parent
FILES = {"gnews": "gnews_observation.json", "guard": "guard_observation.json"}


def load_credentials(path, fields):
    doc, error = core.read_doc(path)
    if error == "missing_file":
        return {k: "" for k in fields}, None
    if error or any(not isinstance(doc.get(k, ""), str) for k in fields):
        return {k: "" for k in fields}, "invalid_credentials_file"
    return {k: doc.get(k, "").strip() for k in fields}, None


def collect(group, *, base_dir=None, keys_path=None, provider_path=None,
            previous=None, now=None, opener=None):
    if group not in FILES:
        raise ValueError("invalid_group")
    base = Path(base_dir or BASE_DIR)
    now = now or core.utcnow()
    previous = previous if isinstance(previous, dict) else {}
    previous_providers = previous.get("providers")
    previous_providers = previous_providers if isinstance(previous_providers, dict) else {}
    opt_doc, opt_error = core.read_doc(base / "config" / "news_options.json")
    try:
        options = core.options_from(opt_doc)
    except ValueError:
        options, opt_error = core.options_from({}), "invalid_options"
    config_error = opt_error if opt_error and opt_error != "missing_file" else None
    cred_path = (provider_path or base / "config" / "news_provider.json") if group == "gnews" else (keys_path or base / "config" / "guard_keys.json")
    credentials, key_error = load_credentials(cred_path, ("gnews_api_key",) if group == "gnews" else ("newsapi_key", "finnhub_key"))
    secrets = tuple(credentials.values())
    providers, items, events = {}, [], []
    for name in (("gnews",) if group == "gnews" else ("newsapi", "finnhub")):
        key = credentials.get("gnews_api_key" if name == "gnews" else name + "_key", "")
        arts, status = core.collect_provider(name, key, options, now, previous_providers.get(name),
                                             opener=opener, secrets=secrets, config_error=config_error or key_error)
        items.extend(arts)
        providers[name] = status
    if group == "guard":
        events, providers["forexfactory"] = core.collect_calendar(now, previous_providers.get("forexfactory"), opener=opener)
    cfg, cfg_error = core.read_doc(base / "engine" / "config.json")
    # Retain each provider's observations for its health counts. Evaluation
    # deduplicates across providers, so reprints never count as consensus.
    assessment = core.evaluate(items, events, providers, now, core.watch_currencies(cfg))
    if group == "gnews":
        assessment["calendar_quality"] = "not_collected_in_this_group"
    legacy, _ = core.read_doc(base / "logs" / "guard_state.json")
    legacy_ts = core.parse_time(legacy.get("fetched_utc"))
    legacy_geo, legacy_vel = legacy.get("geo_level"), legacy.get("velocity")
    comparison = {"geo_level": legacy_geo if legacy_geo in ("NONE", "LOW", "MEDIUM", "HIGH", "CRISIS", "EXTREME") else "UNKNOWN",
                  "velocity": legacy_vel if legacy_vel in ("NORMAL", "ELEVATED", "HIGH") else "UNKNOWN",
                  "fetched_utc": core.stamp(legacy_ts) if legacy_ts else None}
    return {"schema_version": 2, "fetched_utc": core.stamp(now), "group": group,
            "providers": providers, "items": items, "events": events,
            "assessment": assessment, "legacy_comparison": comparison,
            "configuration_status": cfg_error or "loaded",
            "options_status": config_error or "loaded_or_default"}


def successful(doc):
    statuses = [p for p in doc["providers"].values() if p["configured"]]
    return bool(statuses) and all(p["status"] == "current" and not p["rejected"] for p in statuses)


def summary(doc):
    return " · ".join(f"{name}: {p['status']}, текущи {p['current']}, фон {p['background']}, "
                      f"отхвърлени {p['rejected']}" + (f", {p['error_code']}" if p['error_code'] else "")
                      for name, p in doc["providers"].items())


def run_group(group, *, base_dir=None, logs_dir=None, check_only=False, **kwargs):
    base = Path(base_dir or BASE_DIR)
    output = Path(logs_dir or base / "logs") / FILES[group]
    previous, _ = core.read_doc(output)
    if check_only:
        doc = collect(group, base_dir=base, previous=previous, **kwargs)
    else:
        with core.WriterLock(output.with_suffix(".lock")):
            previous, _ = core.read_doc(output)
            doc = collect(group, base_dir=base, previous=previous, **kwargs)
            core.atomic_json(output, doc)
    return doc


def save_options(path, form):
    raw = {}
    for key in core.DEFAULT_OPTIONS:
        value = str(form.get(key, "")).strip()
        if not value and key.endswith("delay_hours"):
            raw[key] = None
        elif not value:
            raw[key] = core.DEFAULT_OPTIONS[key]
        else:
            try:
                raw[key] = float(value)
            except ValueError:
                raise ValueError("invalid_options") from None
    options = core.options_from(raw)
    core.atomic_json(path, options)
    return options


def render_options(path, csrf_token=""):
    doc, error = core.read_doc(path)
    try:
        options = core.options_from(doc)
    except ValueError:
        options, error = dict(core.DEFAULT_OPTIONS), "invalid_options"
    fields = []
    for key, label in (("gnews_delay_hours", "GNews — забавяне по план (ч)"),
                       ("newsapi_delay_hours", "NewsAPI — забавяне по план (ч)"),
                       ("finnhub_delay_hours", "Finnhub — забавяне по план (ч)"),
                       ("newsapi_lookback_hours", "NewsAPI — период на заявката (ч)")):
        value = options[key]
        lo, hi = (1, 168) if key.endswith("lookback_hours") else (0, 48)
        fields.append(f'<div class="field"><label for="{key}">{label}</label><input id="{key}" '
                      f'name="{key}" type="number" min="{lo}" max="{hi}" step="0.5" '
                      f'value="{value if value is not None else ""}" placeholder="неуточнено"></div>')
    warning = "<p>Записаните параметри не могат да се прочетат. Проверете стойностите.</p>" if error and error != "missing_file" else ""
    return ('<div class="card"><h3>Достъп до новини</h3><p>Въведете забавянето от своя абонамент. '
            'Празно означава неуточнено; 0 означава заявен достъп без забавяне. Тези стойности не премахват '
            'ограниченията на доставчика и не превръщат старите новини в пресни. Правата за използване '
            'на данните се определят от вашия план.</p>' + warning +
            '<form method="post" action="/settings/news/options" class="form">' +
            '<input type="hidden" name="csrf_token" value="' + html.escape(csrf_token, quote=True) + '">' + ''.join(fields) +
            '<button type="submit" class="btn">Запази достъпа до новини</button></form></div>')


LABELS = {"current": "актуални данни", "delayed": "само закъснял фон", "empty": "празен отговор",
          "stale": "остарели данни", "invalid_data": "невалидни данни", "error": "грешка",
          "backoff": "изчакване след ограничение", "partial": "непълен календар",
          "not_configured": "няма въведен ключ"}


def readiness_rows(logs_dir, now=None):
    rows = []
    for group, filename in FILES.items():
        doc = core.read_snapshot(Path(logs_dir) / filename, now)
        for name in (("gnews",) if group == "gnews" else ("newsapi", "finnhub", "forexfactory")):
            p = doc.get("providers", {}).get(name, {})
            current = doc["health"] == "current" and p.get("status") == "current" and not p.get("rejected")
            detail = LABELS.get(p.get("status"), "няма надеждна проверка") if doc["health"] == "current" else "няма свежа надеждна проверка"
            row = {"key": "news_observation_" + name, "title": name + " — качество на данните (пробно)",
                   "status": "ok" if current else "warn"}
            if current:
                row["detail"] = detail + "; не влияе на сделките"
            else:
                row.update(problem=detail, fix="Настройки → Проверка на новините. Тестовият бутон проверява без запис; постоянният отчет изисква пробния събирач.")
            rows.append(row)
    return rows


def render_panel(logs_dir, now=None):
    """Pure HTML. No requests, broker imports or writes."""
    now = now or core.utcnow()
    esc = lambda x: html.escape(str(x if x is not None else "няма данни"), quote=True)
    rows, notes = [], []
    schedule, schedule_error = core.read_doc(Path(logs_dir) / "news_observation_schedule.json")
    if schedule_error or schedule.get("status") != "configured":
        notes.append("Автоматичното наблюдение не е потвърдено. Отвори Центъра от ROBOT и провери планираните задачи.")
    else:
        notes.append("Планирано наблюдение веднъж на час при влязъл Windows потребител; свежестта се проверява по отчетите по-долу.")
    for group, filename in FILES.items():
        doc = core.read_snapshot(Path(logs_dir) / filename, now)
        health = doc["health"]
        if health != "current":
            notes.append(f"{esc(group)}: {esc(health)} — няма надеждна текуща оценка.")
        for name in (("gnews",) if group == "gnews" else ("newsapi", "finnhub", "forexfactory")):
            p = doc.get("providers", {}).get(name)
            if not isinstance(p, dict):
                rows.append(f"<tr><td>{esc(name)}</td><td colspan='6'>няма данни</td></tr>")
                continue
            status = LABELS.get(p.get("status"), "неизвестно състояние") if health == "current" else "проверката е остаряла или невалидна"
            if p.get("rejected"):
                status += " / има отхвърлени записи"
            details = f"получени {p.get('returned', 0)}, текущи {p.get('current', 0)}, фон {p.get('background', 0)}"
            delay = p.get("configured_delay_hours")
            delay_txt = "неуточнено" if delay is None else f"{delay} ч"
            error = str(p.get("error_code") or "—")
            if p.get("retry_after_utc"):
                error += " / следващ опит след " + str(p["retry_after_utc"])
            rows.append(f"<tr><td>{esc(name)}</td><td>{esc(status)}</td><td>{esc(p.get('last_attempt_utc'))}<br>"
                        f"Успешен отговор: {esc(p.get('last_success_utc'))}</td><td>{esc(details)}</td>"
                        f"<td>{esc(p.get('newest_age_hours'))} ч</td><td>{esc(delay_txt)}</td><td>{esc(error)}</td></tr>")
        if group == "guard" and health == "current":
            a = doc["assessment"]
            notes.append(f"Геополитика: {esc(a.get('geo_signal'))}; поток: {esc(a.get('velocity'))}; "
                         f"източник за потока: {esc(a.get('velocity_source'))}. UNKNOWN означава липса на достатъчни данни.")
            legacy = doc.get("legacy_comparison", {})
            if isinstance(legacy, dict):
                notes.append(f"Текущият пазител е записал geo={esc(legacy.get('geo_level'))}, "
                             f"velocity={esc(legacy.get('velocity'))} към {esc(legacy.get('fetched_utc'))}.")
            for event in a.get("calendar_blackouts", []) or []:
                if isinstance(event, dict):
                    notes.append(f"Пробно предупреждение: {esc(event.get('name'))} ({esc(event.get('currency'))}); "
                                 f"от {esc(event.get('starts_utc'))} до {esc(event.get('expires_utc'))}.")
    return ("<div class='card' id='news-observation'><h3>Проверка на новините — пробно наблюдение</h3>"
            "<p>Тези оценки са само за преглед и не променят сделките или риска. Часовете са UTC. "
            "Успешна връзка не означава пресни новини. Прогнозна посока не се извежда от заглавия.</p>"
            "<div style='overflow-x:auto'><table><thead><tr><th>Доставчик</th><th>Качество</th><th>Проверка</th>"
            "<th>Статии</th><th>Възраст на последната</th><th>Зададено забавяне</th><th>Грешка / лимит</th>"
            "</tr></thead><tbody>" + "".join(rows) + "</tbody></table></div><p>" + "<br>".join(notes) + "</p></div>")
