"""Exact-installation process discovery, with a Windows built-in fallback."""
import json
import os
from pathlib import Path
import subprocess
import time

POWERSHELL = str(Path(os.environ.get("SystemRoot", "C:/Windows")) /
                 "System32/WindowsPowerShell/v1.0/powershell.exe")


class WindowsProcess:
    """Fallback for clients without psutil. Match creation time before termination."""
    def __init__(self, pid, created):
        self.pid, self.created = int(pid), str(created)

    def terminate(self):
        command = (
            f"$p=Get-CimInstance Win32_Process -Filter \"ProcessId={self.pid}\"; "
            "if ($p) { if ($p.CreationDate.ToUniversalTime().ToString('o') -ne $env:DEMON_PROCESS_CREATED) "
            "{ throw 'Process identity changed' }; Stop-Process -Id $p.ProcessId -ErrorAction Stop }")
        env = dict(os.environ, DEMON_PROCESS_CREATED=self.created)
        subprocess.run([POWERSHELL, "-NoProfile", "-Command", command], env=env,
                       check=True, capture_output=True, timeout=15,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))

    def is_running(self):
        import ctypes
        kernel = ctypes.windll.kernel32
        kernel.OpenProcess.restype = ctypes.c_void_p
        handle = kernel.OpenProcess(0x100000, False, self.pid)  # SYNCHRONIZE
        if not handle:
            return False
        try:
            return kernel.WaitForSingleObject(ctypes.c_void_p(handle), 0) == 258
        finally:
            kernel.CloseHandle(ctypes.c_void_p(handle))


def windows_processes(base, targets):
    import ctypes
    from ctypes import wintypes
    command = ("[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); "
               "Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='pythonw.exe'\" | "
               "Select-Object ProcessId,CommandLine,@{Name='Created';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} | ConvertTo-Json -Compress")
    result = subprocess.run([POWERSHELL, "-NoProfile", "-Command", command],
                            check=True, capture_output=True, text=True, encoding="utf-8", timeout=20,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    rows = json.loads(result.stdout or "[]")
    if isinstance(rows, dict):
        rows = [rows]
    parse = ctypes.windll.shell32.CommandLineToArgvW
    parse.argtypes = (wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int))
    parse.restype = ctypes.POINTER(wintypes.LPWSTR)
    found = []
    for row in rows or []:
        if int(row["ProcessId"]) == os.getpid() or not row.get("CommandLine"):
            continue
        count = ctypes.c_int()
        argv = parse(row["CommandLine"], ctypes.byref(count))
        if not argv:
            raise RuntimeError("Не могат да се проверят работещите процеси")
        try:
            # Product launchers use absolute script paths. Never guess another process's cwd.
            for arg in [argv[i] for i in range(1, count.value)]:
                path = Path(arg)
                if not path.is_absolute() and path.name.casefold() in {"app.py", "engine_s5.py"}:
                    raise RuntimeError("Има процес с относителен път. Затвори DEMON и го отвори чрез неговия ROBOT.bat преди обновяване.")
                kind = targets.get(str(path.resolve()).casefold()) if path.is_absolute() else None
                if kind:
                    found.append((WindowsProcess(row["ProcessId"], row["Created"]), kind))
                    break
        finally:
            ctypes.windll.kernel32.LocalFree(ctypes.cast(argv, ctypes.c_void_p))
    return found


def processes(base):
    """psutil is required before changing any files; no substring PID matching."""
    base = Path(base).resolve()
    targets = {str((base / rel).resolve()).casefold(): kind for rel, kind in (
        ("scripts/app.py", "ui"), ("dashboard/app.py", "dashboard"),
        ("engine/engine_s5.py", "engine"))}
    try:
        import psutil
    except ImportError:
        if os.name != "nt":
            raise RuntimeError("Не могат да се проверят процесите на тази система")
        return windows_processes(base, targets)
    found = []
    for proc in psutil.process_iter(["pid", "cmdline", "cwd"]):
        try:
            if proc.pid == os.getpid():
                continue
            args = proc.info["cmdline"] or []
            cwd = Path(proc.info["cwd"] or base)
            for arg in args[1:]:
                candidate = Path(arg)
                if not candidate.is_absolute():
                    candidate = cwd / candidate
                kind = targets.get(str(candidate.resolve()).casefold())
                if kind:
                    found.append((proc, kind))
                    break
        except (OSError, ValueError, psutil.Error):
            continue
    return found


def stop_processes(found):
    if found and isinstance(found[0][0], WindowsProcess):
        for proc, _ in found:
            proc.terminate()
        deadline = time.monotonic() + 10
        while any(proc.is_running() for proc, _ in found):
            if time.monotonic() >= deadline:
                raise RuntimeError("Програмата не се затвори.")
            time.sleep(0.2)
        return
    if not found:
        return
    import psutil
    for proc, _ in found:
        try:
            proc.terminate()
        except psutil.NoSuchProcess:
            pass
    _, alive = psutil.wait_procs([proc for proc, _ in found], timeout=10)
    if alive:
        raise RuntimeError("Програмата не се затвори. Обновяването е прекратено.")

