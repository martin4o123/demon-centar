def ema_adjust_false(values, n: int):
    """pandas ewm(span=n, adjust=False): първа стойност = първи вход, после рекурсия."""
    alpha = 2.0 / (n + 1.0)
    out = []
    ema = None
    for v in values:
        ema = v if ema is None else alpha * v + (1 - alpha) * ema
        out.append(ema)
    return out

def last_closed_rate_index(rates):
    """For MT5 copy_rates_from_pos(start_pos=0), oldest-first snapshots.

    Position zero is the forming bar, regardless of broker timezone/session.
    Preserve raw bar IDs: never compare server wall-clock labels with UTC or
    migrate persisted IDs. Historical feeds without position zero must not use
    this adapter. Existing connection/freshness checks remain separate.
    """
    if rates is None or len(rates) < 2:
        return None
    try:
        times = [int(r["time"]) for r in rates]
        if any(t <= 0 for t in times) or any(b <= a for a, b in zip(times, times[1:])):
            return None
    except (KeyError, TypeError, ValueError, OverflowError):
        return None
    return len(rates) - 2

def wilder_adjust_false(values, n: int, min_periods: int):
    """pandas ewm(alpha=1/n, adjust=False, min_periods=n) — както wilder() в backtest_75.py."""
    alpha = 1.0 / n
    out = []
    ema = None
    valid = 0
    for v in values:
        if v is None:
            out.append(None)
            continue
        valid += 1
        ema = v if ema is None else alpha * v + (1 - alpha) * ema
        out.append(ema if valid >= min_periods else None)
    return out

def rsi2(closes) -> list:
    """RSI(2) с Wilder smoothing — огледално на build_features_s5."""
    deltas = [None] + [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [None if d is None else max(d, 0.0) for d in deltas]
    losses = [None if d is None else max(-d, 0.0) for d in deltas]
    ag = wilder_adjust_false(gains, 2, 2)
    al = wilder_adjust_false(losses, 2, 2)
    out = []
    for g, l in zip(ag, al):
        if g is None or l is None:
            out.append(None)
        elif l == 0.0 and g == 0.0:
            out.append(None)                       
        elif l == 0.0:
            out.append(100.0)                                      
        elif g == 0.0:
            out.append(0.0)
        else:
            out.append(100.0 - 100.0 / (1.0 + g / l))
    return out

def atr14(highs, lows, closes) -> list:
    """ATR14 Wilder (ewm alpha=1/14, adjust=False, min_periods=14) — огледално на add_d1."""
    trs = [None]
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i],
                 abs(highs[i] - closes[i - 1]),
                 abs(lows[i] - closes[i - 1]))
        trs.append(tr)
    return wilder_adjust_false(trs, 14, 14)

def clamp_sl_pips(atr_value: float, pip_size: float, sl_mult=0.75,
                  lo=40.0, hi=80.0) -> float:
    """SL = clamp(sl_mult x ATR14(D1), 40, 80) пипса — както в run_s5."""
    if atr_value <= 0 or pip_size <= 0:
        return lo
    return round(float(min(max(sl_mult * atr_value / pip_size, lo), hi)), 6)

class SignalRules:
    def evaluate_symbol(self, sym):
        """Връща dict с индикатори за последния ЗАТВОРЕН D1 бар + сигнала."""
        rates = self.shim.rates_d1(sym)
        if rates is None or len(rates) < 210:
            return None
        closes = [float(r["close"]) for r in rates]
        highs = [float(r["high"]) for r in rates]
        lows = [float(r["low"]) for r in rates]
        ema200 = ema_adjust_false(closes, 200)
        atr = atr14(highs, lows, closes)
        rsi = rsi2(closes)
        i = last_closed_rate_index(rates)
        if i is None:
            return None
        return {
            "bar_time": int(rates[i]["time"]), "close": closes[i],
            "ema200": ema200[i], "atr": atr[i], "rsi2": rsi[i],
            "prev_bar_time": int(rates[i - 1]["time"]) if i > 0 else None,
        }

    def signal(self, ev, sym):
        """(dir, checks) — dir: 'BUY'|'SELL'|None. Огледално на run_s5."""
        checks = []
        if ev is None or ev["rsi2"] is None or ev["ema200"] is None or ev["atr"] is None:
            checks.append({"name": "Данни", "passed": False,
                           "detail": "няма затворен D1 бар с валидни RSI(2)/EMA200/ATR"})
            return None, checks
        c, e, r = ev["close"], ev["ema200"], ev["rsi2"]
        ov = (self.cfg.get("symbol_overrides") or {}).get(sym, {})
        rsi_long = float(ov.get("rsi_entry_long", self.cfg["rsi_entry_long"]))
        rsi_short = float(ov.get("rsi_entry_short", self.cfg["rsi_entry_short"]))
        long_ok = c > e and r < rsi_long
        short_ok = c < e and r > rsi_short
        checks.append({"name": "Тренд (EMA200)", "passed": True,
                       "detail": f"close {c:.5f} vs EMA200 {e:.5f} -> "
                                 f"{'лонг режим' if c > e else 'шорт режим' if c < e else 'равни'}"})
        checks.append({"name": "RSI(2) реверсия", "passed": bool(long_ok or short_ok),
                       "detail": f"RSI(2)={r:.2f}; лонг <{rsi_long:.0f} / "
                                 f"шорт >{rsi_short:.0f}"})
        if long_ok:
            return "BUY", checks
        if short_ok:
            return "SELL", checks
        return None, checks

    def evaluate_h1(self, sym):
        """RSI(2) върху последния ЗАТВОРЕН H1 бар. Трендът/ATR идват от D1 оценката."""
        rates = self.shim.rates_h1(sym, 300)
        if rates is None or len(rates) < 60:
            return None
        closes = [float(r["close"]) for r in rates]
        rsi = rsi2(closes)
        i = last_closed_rate_index(rates)
        if i is None:
            return None
        bar_rsi = rsi[i]
        if bar_rsi is None or not (0 <= bar_rsi <= 100):
            return None
        return {"bar_time": int(rates[i]["time"]), "rsi2": bar_rsi}

    def signal_h1(self, h1ev, d1ev):
        """(dir, checks) — D1 задава посока, H1 RSI(2) дава входа."""
        h = self.cfg["h1_layer"]
        checks = []
        if h1ev is None or d1ev is None or d1ev["rsi2"] is None:
            checks.append({"name": "Данни", "passed": False,
                           "detail": "няма затворен H1 бар с валиден RSI(2)"})
            return None, checks
        c, e = d1ev["close"], d1ev["ema200"]
        r = h1ev["rsi2"]
        if e is None:
            checks.append({"name": "Тренд (EMA200 D1)", "passed": False,
                           "detail": "няма EMA200(D1)"})
            return None, checks
        long_ok = c > e and r < float(h["rsi_entry_long"])
        short_ok = c < e and r > float(h["rsi_entry_short"])
        regime = "лонг режим" if c > e else "шорт режим" if c < e else "равни"
        checks.append({"name": "Тренд (EMA200 D1)", "passed": True,
                       "detail": f"D1 close {c:.5f} vs EMA200 {e:.5f} -> {regime}"})
        checks.append({"name": "RSI(2) H1 pullback", "passed": bool(long_ok or short_ok),
                       "detail": f"RSI(2,H1)={r:.2f}; лонг <{float(h['rsi_entry_long']):.0f} / "
                                 f"шорт >{float(h['rsi_entry_short']):.0f}"})
        if long_ok:
            return "BUY", checks
        if short_ok:
            return "SELL", checks
        return None, checks
