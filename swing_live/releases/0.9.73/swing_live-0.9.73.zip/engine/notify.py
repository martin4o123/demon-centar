                       
"""Централен нотификационен bus (Telegram-еквивалент).

- append JSON в logs/messages.jsonl: {ts (UTC ISO), level, category, text}
- ротация: >5MB -> messages.jsonl.old (пази се 1 стар)
- Telegram relay: config/notify.json -> telegram.{enabled,token,chat_id};
  best-effort POST към api.telegram.org (timeout 10 s). При грешка се пише
  ПРЕДУПРЕЖДЕНИЕ в същия jsonl (category=system), никога не пада.

CLI:
  py -3.12 engine\notify.py --level warning --category system --text "..."
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request
import urllib.error
import uuid
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"
MESSAGES = LOGS_DIR / "messages.jsonl"
CONFIG = BASE_DIR / "config" / "notify.json"
MAX_BYTES = 5 * 1024 * 1024
TIMEOUT = 10

LEVELS = ("info", "warning", "alert")
CATEGORIES = ("status", "trade", "system", "update", "cashflow", "research")

DEFAULT_CONFIG = {
    "telegram": {
        "enabled": False,
        "token": "",
        "chat_id": "",
        "setup_hint": ("За включване на Telegram нотификациите: създай бот чрез @BotFather "
                       "в Telegram и копирай токена в \"token\"; вземи своя chat_id (напр. от "
                       "@userinfobot) и го сложи в \"chat_id\"; сетни \"enabled\": true. "
                       "Без стойности relay-ът е изключен и съобщенията остават само в "
                       "logs\\messages.jsonl (виж ги в таблото, секция „Съобщения“).")
    }
}


def ensure_config() -> None:
    try:
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        if not CONFIG.exists():
            CONFIG.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2),
                              encoding="utf-8")
    except Exception:
        pass


def rotate_if_needed() -> None:
    try:
        if MESSAGES.exists() and MESSAGES.stat().st_size > MAX_BYTES:
            old = MESSAGES.with_name(MESSAGES.name + ".old")
            if old.exists():
                old.unlink()
            MESSAGES.replace(old)
    except Exception:
        pass


def append(level: str, category: str, text: str) -> dict:
    row = {
        "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "level": level,
        "category": category,
        "text": text,
    }
    if os.environ.get("DEMON_NOTIFY_OFF"):
        return row  # тестов режим — не пишем в реалния messages.jsonl
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    rotate_if_needed()
    with MESSAGES.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row


def telegram_settings() -> dict:
    try:
        cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
        return cfg.get("telegram") or {}
    except Exception:
        return {}


def chunks(text, limit=3500):
    # Conservative UTF-16 budget also handles emoji without Telegram length errors.
    part, units = [], 0
    for char in text:
        size = 2 if ord(char) > 0xFFFF else 1
        if units + size > limit:
            yield "".join(part)
            part, units = [], 0
        part.append(char)
        units += size
    if part:
        yield "".join(part)


def request_api(token, method, payload, photo=None):
    if photo is None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        content_type = "application/json"
    else:
        image = Path(photo).read_bytes()
        if len(image) > 10 * 1024 * 1024 or not image.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("Изображението трябва да е PNG до 10 MB")
        boundary = "demon" + uuid.uuid4().hex
        fields = []
        for name, value in payload.items():
            fields.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode("utf-8"))
        fields.append((f'--{boundary}\r\nContent-Disposition: form-data; name="photo"; filename="demon-report.png"\r\nContent-Type: image/png\r\n\r\n').encode("ascii") + image + b"\r\n")
        fields.append(f"--{boundary}--\r\n".encode("ascii"))
        data = b"".join(fields)
        content_type = "multipart/form-data; boundary=" + boundary
    req = urllib.request.Request(f"https://api.telegram.org/bot{token}/{method}",
                                 data=data, headers={"Content-Type": content_type})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
            result = json.loads(response.read())
    except urllib.error.HTTPError as exc:
        # Do not log exception URLs: they contain the bot token.
        raise RuntimeError(f"Telegram HTTP {exc.code}") from None
    except (OSError, ValueError):
        raise RuntimeError("Telegram: няма потвърждение за доставка; провери връзката") from None
    if not isinstance(result, dict) or result.get("ok") is not True:
        code = result.get("error_code", "?") if isinstance(result, dict) else "?"
        raise RuntimeError(f"Telegram отказа заявката (код {code})")
    return result.get("result")


def relay(row: dict, photo=None) -> str | None:
    if os.environ.get("DEMON_NOTIFY_OFF"):
        return None
    tg = telegram_settings()
    if not tg.get("enabled"):
        return None
    token = str(tg.get("token") or "").strip()
    chat_id = str(tg.get("chat_id") or "").strip()
    if not token or not chat_id:
        return "Telegram е включен, но липсва токен или получател"
    labels = {"status":"Състояние", "trade":"Сделка", "system":"Система",
              "update":"Обновяване", "cashflow":"Паричен поток", "research":"Анализ"}
    levels = {"info":"Информация", "warning":"Внимание", "alert":"Необходимо действие"}
    stamp = datetime.fromisoformat(row["ts"]).astimezone().strftime("%d.%m.%Y %H:%M %Z")
    text = f"DEMON · {labels.get(row['category'], row['category'])}\n{levels.get(row['level'], row['level'])} · {stamp}\n\n{row['text']}"
    photo_error = None
    try:
        if photo:
            try:
                request_api(token, "sendPhoto", {"chat_id": chat_id, "caption": "DEMON · отчет"}, photo)
            except Exception:
                photo_error = "изображението не е доставено; изпратен е текстовият отчет"
        for part in chunks(text):
            request_api(token, "sendMessage", {"chat_id": chat_id, "text": part})
        return photo_error
    except Exception as exc:
        # Only controlled messages cross into logs; never include bot token/URL.
        return str(exc) if isinstance(exc, RuntimeError) else "Telegram: доставката не е потвърдена"


def send(level: str, category: str, text: str, photo=None) -> dict:
    """Local record + checked delivery; notification failure never breaks trading."""
    row = {"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "level": level, "category": category, "text": str(text)}
    if os.environ.get("DEMON_NOTIFY_OFF"):
        return dict(row, delivery="disabled")
    try:
        ensure_config()
        row = append(level, category, str(text))
    except OSError:
        pass
    err = relay(row, photo)
    row["delivery"] = ("partial" if err and err.startswith("изображението не е доставено;") else "failed") if err else ("sent" if telegram_settings().get("enabled") else "disabled")
    if err:
        row["delivery_error"] = err
        try:
            append("warning", "system", "Telegram: " + err)
        except OSError:
            pass
    try:
        status = LOGS_DIR / "telegram_delivery.json"
        tmp = status.with_name(f"{status.name}.{os.getpid()}.tmp")
        tmp.write_text(json.dumps({k: row[k] for k in ("ts", "delivery", "delivery_error") if k in row}, ensure_ascii=False), encoding="utf-8")
        tmp.replace(status)
    except OSError:
        pass
    return row


def main() -> int:
    ap = argparse.ArgumentParser(description="Централен нотификационен bus")
    ap.add_argument("--level", choices=LEVELS, default="info")
    ap.add_argument("--category", choices=CATEGORIES, default="status")
    ap.add_argument("--text", required=True)
    args = ap.parse_args()
    try:
        result = send(args.level, args.category, args.text)
        if result.get("delivery") in ("failed", "partial"):
            print("[notify] " + result.get("delivery_error", "Доставката не е потвърдена"))
            return 2
        print(f"[notify] OK {args.level}/{args.category}")
    except Exception as exc:                  
        print(f"[notify] грешка (не пада): {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
