"""Candidate replacement for the unsafe legacy cache writer.

Invoke run_once() from the already connected, coordinated Center reader.
The standalone CLI deliberately does not initialize a second MT5 connection.
It writes only the NEW provenanced cache, never legacy candle_history CSVs.
"""
from pathlib import Path
from market_data_capture import BackfillCursor, ClockPolicy, ClosedBarCache, HistoryBackfill, atomic_json


def run_once(existing_reader, destination, jobs, policy, *, chunk_size=128, max_jobs=1):
    """One small historical chunk per selected job, through injected reader.

    jobs is an explicit sequence of (logical_symbol, broker_symbol, H1|D1).
    Cursors and all time mapping evidence are persisted locally. No universal
    +2/+3 transformation, forming candle or overwrite of old partial bars.
    """
    if not callable(existing_reader):
        raise ValueError('An existing coordinated MT5 reader is required')
    if not isinstance(policy, ClockPolicy):
        raise ValueError('Explicit ClockPolicy is required; no offset inference')
    policy.validate()
    if isinstance(max_jobs, bool) or not isinstance(max_jobs, int) or not 1 <= max_jobs <= 20:
        raise ValueError('max_jobs must be 1..20')
    jobs = list(jobs)
    if len(set(jobs)) != len(jobs):
        raise ValueError('Duplicate history jobs')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    # Stable job paths are hashes; broker symbols cannot escape destination.
    from market_data_capture import digest
    import json
    results = []
    rotation_path = destination / 'rotation.json'
    rotation = json.loads(rotation_path.read_text('utf-8')) if rotation_path.exists() else {'next': 0}
    start = int(rotation['next']) % len(jobs) if jobs else 0
    selected = [((start + i) % len(jobs), jobs[(start + i) % len(jobs)]) for i in range(min(max_jobs, len(jobs)))]
    cache = ClosedBarCache(destination)
    try:
        for index, (symbol, broker, timeframe) in selected:
            key = digest([symbol, broker, timeframe])[:24]
            state_path = destination / ('cursor-' + key + '.json')
            if state_path.exists():
                state = json.loads(state_path.read_text('utf-8'))
                cursor = BackfillCursor(**state['cursor'])
                if state['job'] != [symbol, broker, timeframe] or state['clock_policy'] != policy.validate():
                    raise ValueError('History job/clock changed; use a separate cache generation')
            else:
                cursor = BackfillCursor()
            result = HistoryBackfill(chunk_size=chunk_size).step(existing_reader, cursor, cache, symbol, broker, timeframe, policy)
            atomic_json(state_path, {'job': [symbol, broker, timeframe], 'clock_policy': policy.validate(), 'cursor': result['cursor']})
            atomic_json(rotation_path, {'next': (index + 1) % len(jobs)})
            results.append({'symbol': symbol, 'timeframe': timeframe, **result})
            if not result.get('continue_allowed', False) and result['status'] not in ('DONE', 'EXHAUSTED_VISIBLE_HISTORY'):
                break
    finally:
        cache.close()
    return {'schema': 'demon.history-fetch/1', 'results': results, 'execution_authorized': False,
            'legacy_csv_modified': False, 'independent_mt5_connection': False}


if __name__ == '__main__':
    raise SystemExit('This collector requires the existing Center MT5 reader; standalone MT5 initialization is disabled.')
