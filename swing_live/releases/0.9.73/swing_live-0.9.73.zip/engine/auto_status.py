"""Local program assistant built from current evidence; never issues commands.

No model, provider, external requests, eval, shell or trading adapter. Questions
select curated explanations; account figures come from the shared snapshot.
"""
import html
import json
import math
import time
from datetime import datetime
from pathlib import Path

LABELS = {'ATTENTION': 'Нужна е намеса', 'WAITING': 'Изчаква', 'WORKING': 'Работи'}


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def read_object(path):
    try:
        value = json.loads(Path(path).read_text('utf-8-sig'))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def timestamp(value):
    try:
        parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return parsed.timestamp() if parsed.tzinfo is not None else None
    except (ValueError, TypeError, OverflowError):
        return None


def summarize(snapshot, state, *, now=None, stop_flag=False):
    now = time.time() if now is None else now
    result = {'schema': 'demon.automation-status/1', 'status': 'ATTENTION',
              'reason_code': 'DATA_UNKNOWN', 'reason': 'Няма потвърдени актуални данни.',
              'next_step': 'Проверете връзката с избрания MT5 терминал.',
              'account': {}, 'fits': [], 'signal_count': 0, 'instrument_count': 0,
              'updated_utc': None, 'engine_fresh': False, 'data_fresh': False,
              'new_execution_active': False, 'can_trade': False, 'archive_note': ''}
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    state = state if isinstance(state, dict) else {}
    generated = snapshot.get('generated_utc')
    fresh = finite(generated) and 0 <= now - generated <= 120 and not snapshot.get('stale', True)
    result['data_fresh'] = bool(fresh)
    if not fresh:
        return result
    account = snapshot.get('account', {})
    if not isinstance(account, dict) or not account.get('login') or not account.get('server'):
        return result
    # Do not expose credentials, login or server in the simplified API.
    result['account'] = {key: account.get(key) if finite(account.get(key)) else None
                         for key in ('balance', 'equity', 'margin_free')}
    result['account']['currency'] = str(account.get('currency') or '')[:12]
    result['updated_utc'] = generated
    rows = snapshot.get('decisions', [])
    rows = rows if isinstance(rows, list) else []
    rows = [r for r in rows if isinstance(r, dict)]
    result['instrument_count'] = len({r.get('symbol') for r in rows if isinstance(r.get('symbol'), str)})
    result['signal_count'] = sum(r.get('enabled') is True and r.get('direction') in ('BUY', 'SELL') and r.get('status') not in ('EXPIRED', 'NO_DATA') for r in rows)
    archive=snapshot.get('market_data',{})
    if isinstance(archive,dict):
        if archive.get('conflicting_series'):
            result['archive_note']='В историческия архив има разминаващи се свещи. Тези данни не са годни за доказване на резултати.'
        elif archive.get('error_series'):
            result['archive_note']='Част от инструментите не преминаха независимата проверка на свещите.'
        elif archive.get('captured_series'):
            result['archive_note']='Затворените свещи се архивират с проверка срещу MT5. Пълната историческа и часова проверка още не е завършена.'
    for row in rows:
        fit = row.get('account_fit')
        if isinstance(fit, dict) and row.get('enabled') is True and row.get('direction') in ('BUY','SELL') and row.get('status') not in ('EXPIRED','NO_DATA'):
            result['fits'].append({'symbol': str(row.get('symbol', '')), 'strategy': str(row.get('strategy', '')),
                                   'fit': fit})
    observed = timestamp(state.get('last_cycle_utc'))
    result['engine_fresh'] = bool(observed is not None and 0 <= now - observed <= 180)
    if not result['engine_fresh']:
        result.update(reason_code='ENGINE_STALE', reason='Двигателят не е изпратил актуално състояние.',
                      next_step='Отворете „Готовност“ и проверете процеса и връзката.')
        return result
    if state.get('account') != {'login': account['login'], 'server': account['server']}:
        result.update(reason_code='ACCOUNT_CHANGED', reason='Двигателят и анализът сочат различни сметки.',
                      next_step='Сверете избрания терминал и сметка в „Настройки“.')
        return result
    guards = state.get('guards', {})
    if not isinstance(guards, dict):
        return result
    if stop_flag or guards.get('stop_flag'):
        result.update(reason_code='STOP', reason='Новите входове са спрени от бутона Стоп.',
                      next_step='Прегледайте състоянието в „Готовност“ преди промяна.')
        return result
    if guards.get('paused'):
        dd = guards.get('dd_from_peak_pct')
        limit = guards.get('max_total_dd_pct')
        detail = f' Спадът от върха е {dd:.2f}% при лимит {limit:.2f}%.' if finite(dd) and finite(limit) else ''
        result.update(reason_code='PROTECTIVE_PAUSE', reason='Защитата е спряла новите сделки.' + detail,
                      next_step='Прегледайте загубите в „Аналитика“. Повишаването на риска не отстранява причината.')
        return result
    settings = snapshot.get('settings', [])
    if isinstance(settings, list) and any(isinstance(s, dict) and s.get('state') == 'DIFFERENT' for s in settings):
        result.update(reason_code='SETTINGS_PENDING', reason='Записаните настройки още не са активни.',
                      next_step='Вижте разликите в „H1/D1 сценарии“ преди следващо стартиране.')
        return result
    if guards.get('data_fresh') is not True or guards.get('session_ok') is None:
        result.update(reason_code='GUARDS_UNKNOWN', reason='Липсва потвърждение за данните или предпазителите.',
                      next_step='Вижте „Готовност“ за причината.')
        return result
    if guards.get('news_blackout') or guards.get('session_ok') is False:
        result.update(status='WAITING', reason_code='TEMPORARY_GUARD', reason='Изчаква подходящ час или край на новинарско ограничение.',
                      next_step='Не е нужна промяна на риска; следващият цикъл ще провери отново.')
        return result
    if not rows or all(r.get('status') in ('NO_DATA', 'EXPIRED') for r in rows):
        result.update(reason_code='MARKET_DATA_MISSING', reason='Няма годни пазарни данни за анализ.',
                      next_step='Проверете инструментите и историята в MT5.')
        return result
    # The helper is separate from the legacy running engine. Never claim the
    # new execution path is enabled merely because a scenario is a candidate.
    result.update(status='WAITING', reason_code='NO_SETUP', reason='Анализът работи. Изчаква условия за вход.',
                  next_step='Условията се проверяват автоматично при следващия цикъл.')
    if result['signal_count']:
        blocked_fit = next((r for r in result['fits'] if r['fit'].get('status') in ('MIN_LOT_TOO_LARGE', 'BLOCKED', 'NO_CAPACITY')), None)
        if blocked_fit:
            result.update(reason_code='ACCOUNT_CAPACITY', reason='Има сигнал, но сметката не покрива ограниченията за обема.',
                          next_step='Вижте „Размер според сметката“ за конкретната причина.')
        else:
            result.update(reason_code='CANDIDATE_RECHECK', reason='Има кандидат. Входът изисква всички проверки.',
                          next_step='Вижте „H1/D1 сценарии“ за ограниченията на всеки вход.')
    return result


def load(root):
    from decision_view import load as load_decisions
    root = Path(root)
    result=summarize(load_decisions(root), read_object(root / 'logs/state.json'), stop_flag=(root/'STOP.flag').exists())
    history=read_object(root/'logs/history_backfill.json')
    if history.get('status') in ('HALTED','BUSY_OR_UNCLEAN_LOCK','NO_RUNNABLE_JOBS'):
        result['archive_note'] += ' Събирането на по-стара история е спряно за проверка; текущият анализ се обновява отделно.'
    elif history.get('status')=='CAPTURED':
        result['archive_note'] += ' По-старата история се събира на малки части.'
    return result


def answer(data, question):
    """A small, explicit program-only intent router, not a generative model."""
    q = ' '.join(str(question or '').casefold().split())[:240]
    why = data['reason'] + ' ' + data['next_step']
    if not q or any(w in q for w in ('защо', 'чака', 'работи', 'сделк', 'статус', 'проблем')):
        return why
    if any(w in q for w in ('баланс', 'обем', 'лот', 'риск', 'настрой')):
        return ('Обемът се изчислява по наличните средства, определения риск и разстоянието до защитния стоп. '
                'Минималният лот може да е прекалено голям. В „Размер според сметката“ виждате изчислението за текущите сигнали. '
                'Непълните данни са обозначени; помощникът не променя настройките.')
    if any(w in q for w in ('данни', 'цени', 'свещ', 'истори')):
        return ('Текущият анализ чете MT5 и използва затворени свещи. '
                + ('Снимката е актуална. ' if data['data_fresh'] else 'В момента няма актуална снимка. ')
                + 'Историческите резултати се показват отделно в „Изпитвания“. Конфликтни или непълни данни не доказват качество на стратегията.')
    if any(w in q for w in ('печал', 'точн', 'резултат', 'аналитик')):
        return ('„Аналитика“ показва действителните сделки и разходи. Изберете период и „Всички“ за ръчните сделки. '
                'Докосването на нарисувана зона не е спечелена автоматична сделка.')
    if any(w in q for w in ('пусни', 'купи', 'продай', 'спри', 'рестарт', 'изключи', 'изтрий', 'команд')):
        return 'Тук обяснявам състоянието на DEMON. Управлението е чрез отделните бутони; съобщението не изпълнява действие.'
    return 'Мога да обясня защо DEMON чака, размера на поръчката, данните и резултатите. Изберете един от въпросите отдолу.'


def esc(value):
    return html.escape(str(value))


def money(value, currency=''):
    return f'{value:.2f} {esc(currency)}' if finite(value) else 'няма данни'


def card(data):
    return f'''<section class="card" aria-label="Автоматична търговия"><h2>{esc(LABELS[data['status']])}</h2>
    <p style="font-size:1.1rem">{esc(data['reason'])}</p><p>{esc(data['next_step'])}</p>
    <p><a class="btn" href="/automation">Виж причината</a> <a class="btn" href="/automation#helper">Попитай DEMON</a></p></section>'''


def render(data, question=''):
    a = data['account']; currency = a.get('currency', '')
    fit_rows = []
    for row in data['fits']:
        fit = row['fit']; lot = fit.get('lot')
        fit_rows.append(f'''<tr><td>{esc(row['symbol'])}<br>{esc(row['strategy'])}</td>
          <td>{esc(fit.get('message_bg', 'Няма данни'))}</td><td>{esc(lot) if finite(lot) else '—'}</td>
          <td>{money(fit.get('risk_budget'), currency)}</td><td>{money(fit.get('minimum_lot_risk'), currency)}</td></tr>''')
    table = ('''<div style="overflow:auto"><table><thead><tr><th>Инструмент</th><th>Причина</th><th>Обем до</th><th>Допустим риск</th><th>Риск при минимален лот</th></tr></thead><tbody>'''
             + ''.join(fit_rows) + '</tbody></table></div>') if fit_rows else '<p>Няма текущ сигнал с достатъчно данни за изчисляване на обем.</p>'
    buttons = ''.join(f'<button class="btn" name="q" value="{esc(q)}">{esc(q)}</button> ' for q in ('Защо чака?', 'Какъв обем?', 'Верни ли са данните?', 'Къде са резултатите?'))
    return card(data) + f'''<section class="card"><h2>Сметката накратко</h2><p>Баланс: <b>{money(a.get('balance'),currency)}</b> · Текуща стойност: <b>{money(a.get('equity'),currency)}</b> · Свободни средства: <b>{money(a.get('margin_free'),currency)}</b></p>
    <p>{esc(data['archive_note'])}</p>
    <p>{data['instrument_count']} инструмента · {data['signal_count']} кандидата. Новото общо изпълнение още не е включено.</p>
    <a class="btn" href="/analytics">Резултати</a> <a class="btn" href="/readiness">Проверки</a> <a class="btn" href="/scenarios">Всички инструменти</a></section>
    <section class="card"><h2>Размер според сметката</h2><p>Автоматична оценка при всеки нов анализ. „Обем до“ е предварителен таван; разходите и общият отворен риск трябва да са проверени преди поръчка.</p>{table}</section>
    <section class="card" id="helper"><h2>Помощник DEMON</h2><p>Локални обяснения за програмата и текущото ѝ състояние.</p>
    <div role="status" style="padding:16px;border-left:3px solid #d84856">{esc(answer(data, question))}</div>
    <form method="get" action="/automation#helper"><label for="demon-question">Вашият въпрос</label><p><input style="width:100%;max-width:620px;box-sizing:border-box" id="demon-question" name="q" maxlength="240" value="{esc(str(question)[:240])}" placeholder="Например: Защо не отваря сделка?"></p><button class="btn" type="submit">Попитай</button></form>
    <form method="get" action="/automation#helper"><p>{buttons}</p></form></section>'''
