"""Durable update progress shared by the UI and the independent updater."""
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def read(base):
    try:
        return json.loads((Path(base) / "logs/update_status.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def write(base, phase, detail="", **fields):
    path = Path(base) / "logs/update_status.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    state = read(base)
    state.update(phase=phase, detail=detail,
                 checked_utc=datetime.now(timezone.utc).isoformat(), **fields)
    if phase == "complete":
        state["last_success"] = {
            "version": state["target_version"], "utc": state["checked_utc"]}
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    with tmp.open("w", encoding="utf-8") as stream:
        json.dump(state, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    tmp.replace(path)
    return state


def view(base):
    state = read(base)
    if state.get("engine_status") != "awaiting_first_cycle":
        return state
    try:
        runtime = json.loads((Path(base) / "logs/state.json").read_text(encoding="utf-8"))
        if (runtime.get("engine_pid") == state.get("engine_pid")
                and runtime.get("engine_build") == state.get("engine_build")):
            state["engine_status"] = "cycle_confirmed"
            state["detail"] = "Новата версия е отворена. Двигателят потвърди първия си цикъл: " + str(runtime.get("last_reason") or runtime.get("last_action") or "")
            return state
    except (OSError, ValueError):
        pass
    try:
        elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(state["checked_utc"])).total_seconds()
        if elapsed > 120:
            state["engine_status"] = "attention"
            state["detail"] = "Новата версия е отворена, но двигателят не е потвърдил първи цикъл. Провери Готовност и логовете."
    except (ValueError, KeyError):
        pass
    return state
