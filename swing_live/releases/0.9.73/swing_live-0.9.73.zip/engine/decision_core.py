"""Versioned, deterministic decisions. Pure inputs; cannot submit orders."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, math
from types import SimpleNamespace
from decision_rules import SignalRules, clamp_sl_pips
from decision_clock import server_to_utc

SYMBOLS=('EURUSD','GBPUSD','USDJPY','USDCHF','AUDUSD','USDCAD','EURJPY','AUDJPY','GBPJPY','GOLD')
SCHEMA='demon.decision/1'

def fingerprint(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()).hexdigest()

def effective_config(saved):
    cfg=json.loads(Path(__file__).with_name('decision_defaults.json').read_text('utf-8'))
    def merge(a,b):
        for k,v in b.items():
            if isinstance(v,dict) and isinstance(a.get(k),dict): merge(a[k],v)
            else:a[k]=deepcopy(v)
    merge(cfg,saved)
    return cfg

def normalized_time(raw,server):
    # Explicit, observed adapter. Unknown servers remain unavailable, never guess.
    if server!='AdmiralsGroup-Live':raise ValueError('Не е проверен часовият адаптер за този сървър')
    return server_to_utc(float(raw))

def validate_rates(rows,minimum):
    if rows is None or len(rows)<minimum:raise ValueError('Недостатъчно затворени свещи')
    prev=0
    for r in rows:
        t=int(r['time']);o,h,l,c=[float(r[k]) for k in ('open','high','low','close')]
        if t<=prev or not all(math.isfinite(v) and v>0 for v in (o,h,l,c)) or l>min(o,c) or h<max(o,c) or l>h:
            raise ValueError('Повредени или неподредени свещи')
        prev=t

def validate_dependency_time(rows,period,server,now):
    forming=normalized_time(rows[-1]['time'],server)
    next_open=normalized_time(rows[-1]['time']+period,server)
    if forming>now+5 or now>next_open+300:raise ValueError('Липсват актуални свещи за текущата сесия')
    # Missing weekday bars are not silently interpreted as the latest closed signal.
    # Weekend closure is explicit; holidays/short sessions need a verified calendar.
    expected=int(rows[-1]['time'])-period;closed=int(rows[-2]['time'])
    while expected>closed:
        if datetime.fromtimestamp(expected,timezone.utc).weekday()<5:
            raise ValueError('Непотвърден пропуск на последната затворена свещ; проверете сесията')
        expected-=period
    return forming,next_open

class SnapshotRules(SignalRules):
    def __init__(self,cfg,d1,h1):
        self.cfg=cfg
        self.shim=SimpleNamespace(rates_d1=lambda s:d1,rates_h1=lambda s,n:h1)

def settings_comparison(cfg,active):
    # Missing runtime keys are UNKNOWN, never reported as equal.
    out=[]
    def walk(saved,seen,prefix=''):
        for k,v in saved.items():
            if k in ('terminal_path','live_login','demo_login','llm_ai'):continue
            path=prefix+k
            if isinstance(v,dict):walk(v,seen.get(k,{}) if isinstance(seen.get(k),dict) else {},path+'.')
            else:out.append({'name':path,'saved':v,'active':seen.get(k),'state':'UNKNOWN' if k not in seen else 'MATCH' if seen[k]==v else 'DIFFERENT'})
    walk(cfg,active or {})
    return out

def evaluate(cfg,account,symbol,layer,market,now):
    """Both replay and observation supply identical position-zero snapshots."""
    server=account['server'];d1=market.get('d1');h1=market.get('h1');tf=layer.upper()
    enabled=symbol in (cfg['symbols'] if tf=='D1' else cfg['h1_layer']['symbols']) and (tf=='D1' or cfg['h1_layer']['enabled'])
    row={'schema':SCHEMA,'strategy':'S5-'+tf,'strategy_version':'baseline-1','settings_version':fingerprint(cfg),
         'account':{'login':account['login'],'server':server},'symbol':symbol,'broker_symbol':market.get('broker_symbol'),
         'timeframe':tf,'observed_utc':now,'expires_utc':now+120,'bar_raw':None,'bar_utc':None,'direction':None,
         'status':'NO_DATA','checks':[],'execution_blocks':[], 'entry':None,'stop':None,'target':None,
         'volume':None,'risk_money':None,'risk_budget':None,'minimum_lot_risk':None,'spread':None,
         'currency':account.get('currency'),'enabled':enabled,'execution_authorized':False,
         'risk_basis':'Предварителен основен бюджет; активните множители, комисиони и приплъзване се проверяват преди изпълнение.',
         'exit_rules':{},'invalidation':'Следваща затворена свещ, остарели данни или смяна на сметка/настройки.',
         'next_step':'Възстановете валидните пазарни данни.'}
    try:
        if market.get('error'):raise ValueError(market['error'])
        validate_rates(d1,210)
        if tf=='H1':validate_rates(h1,60)
        engine=SnapshotRules(cfg,d1,h1);dev=engine.evaluate_symbol(symbol);hev=engine.evaluate_h1(symbol) if tf=='H1' else None
        direction,checks=engine.signal(dev,symbol) if tf=='D1' else engine.signal_h1(hev,dev)
        ev=dev if tf=='D1' else hev
        if ev is None or dev is None or dev['atr'] is None or dev['rsi2'] is None:raise ValueError('Няма валидни индикатори')
        row.update(direction=direction,checks=checks,bar_raw=ev['bar_time'],bar_utc=normalized_time(ev['bar_time'],server))
        row['indicators']={'d1':dev,'h1':hev}
        validate_dependency_time(d1,86400,server,now)
        forming,next_open=validate_dependency_time(d1 if tf=='D1' else h1,86400 if tf=='D1' else 3600,server,now)
        row['expires_utc']=min(now+120,next_open)
        quote=market['quote'];tickutc=normalized_time(quote['time'],server)
        row['quote_time']={'raw':quote['time'],'utc':tickutc,'clock':'Admirals EET/EEST (explicit)'}
        if now-tickutc>30 or now-tickutc< -5:raise ValueError('Остаряла или бъдеща котировка')
        spec=market['spec'];bid=float(quote['bid']);ask=float(quote['ask'])
        if not all(math.isfinite(float(spec[k])) and float(spec[k])>0 for k in ('point','trade_tick_size','volume_min','volume_max','volume_step')):raise ValueError('Неподдържани спецификации на инструмента')
        if not math.isfinite(bid+ask) or bid<=0 or ask<bid:raise ValueError('Невалидни Bid/Ask')
        row['spread']=ask-bid
        params=cfg if tf=='D1' else cfg['h1_layer']
        row['entry_conditions']=[c['detail'] for c in checks]
        row['exit_rules']={'stop':'При защитния SL','rsi_long_above':params['rsi_exit_long'],'rsi_short_below':params['rsi_exit_short'],
                           'max_hours':cfg['max_days']*24 if tf=='D1' else params['max_hours'],'trailing':cfg['trailing'],'numeric_target':None,
                           'other':'Съществуващите времеви и защитни изходи остават в двигателя.'}
        row['status']='CANDIDATE' if direction else 'NO_SIGNAL'
        row['next_step']='Изчаква се изпълнение на показаните условия за вход.' if not direction else 'Проверка на всички предпазители и квалификация; този изглед не подава поръчки.'
        blocks=row['execution_blocks']
        if not enabled:blocks.append('Стратегията не е включена за този инструмент')
        if market.get('positions') is None:blocks.append('Списъкът с позиции е недостъпен')
        elif market['positions']:blocks.append('Има отворена позиция; анализът продължава')
        if row['spread']>cfg['spread_atr_max']*dev['atr']:blocks.append('Спредът надвишава допустимата част от D1 ATR')
        if direction:
            pip=spec['point']*(10 if int(spec['digits']) in (3,5) else 1)
            ov=cfg.get('symbol_overrides',{}).get(symbol,{})
            dist=clamp_sl_pips(dev['atr'],pip,ov.get('sl_mult',cfg['sl_mult']),ov.get('sl_min_pips',cfg['sl_min_pips']),ov.get('sl_max_pips',cfg['sl_max_pips']))*pip
            entry=ask if direction=='BUY' else bid;tick=float(spec['trade_tick_size'])
            stop=(math.floor((entry-dist)/tick)*tick if direction=='BUY' else math.ceil((entry+dist)/tick)*tick)
            stop=round(stop,int(spec['digits']))
            budget=float(account['equity'])*float(params['risk_pct'])/100
            row.update(entry=entry,stop=stop,risk_budget=budget)
            loss=market.get('loss_per_lot',{}).get(direction)
            # Broker-calculated losses must use THIS exact price/stop; captured separately by adapter.
            if not loss or not math.isfinite(loss) or loss<=0:blocks.append('Липсва брокерска оценка на риска')
            else:
                minimum=spec['volume_min'];step=spec['volume_step'];cap=min(cfg['max_lot'],spec['volume_max'])
                row['minimum_lot_risk']=minimum*loss
                volume=math.floor((min(budget/loss,cap)+1e-12)/step)*step
                if volume+1e-10<minimum:blocks.append('Минималният лот надвишава бюджета или максималния обем')
                else:
                    row['volume']=round(volume,8);row['risk_money']=row['volume']*loss
                    margin=market.get('margin_per_lot',{}).get(direction)
                    if margin is None:blocks.append('Липсва оценка на маржина')
                    elif margin*row['volume']>account['margin_free']:blocks.append('Недостатъчен свободен маржин')
            if abs(entry-stop)<spec.get('trade_stops_level',0)*spec['point']:blocks.append('SL е по-близо от брокерския минимум')
        # This release is an observation assistant, not an alternative route around existing guards.
        blocks.extend(market.get('execution_blocks',[]))
        if direction and blocks:row['status']='BLOCKED'
    except (ValueError,TypeError,KeyError,OverflowError) as exc:
        row.update(status='NO_DATA',direction=None,entry=None,stop=None,volume=None,risk_money=None,error=str(exc))
    row['id']=fingerprint([SCHEMA,row['strategy'],row['settings_version'],row['account'],symbol,row['bar_raw'],row['direction']])[:32]
    return row

def at_time(snapshot,now):
    result=deepcopy(snapshot)
    generated=result.get('generated_utc',0)
    invalid_clock=generated>now+5
    for r in result.get('decisions',[]):
        if invalid_clock or now>=r['expires_utc']:
            r['status']='EXPIRED';r['execution_authorized']=False;r['next_step']='Изчакайте нова успешна снимка от терминала.'
    result['stale']=invalid_clock or now-generated>120
    return result
