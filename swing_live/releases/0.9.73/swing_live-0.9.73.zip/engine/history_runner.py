"""Persistent global stop around an explicitly invoked history runner.

An in-flight marker is durable BEFORE native MT5 work. Crash/disk failure cannot
silently resume on restart. This module has no scheduler or MT5 import.
"""
from dataclasses import asdict
import json
import os
from pathlib import Path
import time
import uuid

from market_data_capture import atomic_json, digest


def control_paths(destination):
    destination = Path(destination)
    return (destination.parent / (destination.name + '_history_control.json'),
            destination.parent / (destination.name + '_history_exclusive.lock'))


def load_control(path):
    if not path.exists():
        return {'schema': 'demon.history-control/1', 'state': 'IDLE', 'local_failures': {}, 'local_halts': {}}
    value = json.loads(path.read_text('utf-8'))
    if not isinstance(value, dict) or value.get('schema') != 'demon.history-control/1' or value.get('state') not in ('IDLE', 'RUNNING', 'HALTED'):
        raise ValueError('Malformed durable history control')
    if not isinstance(value.get('local_failures'), dict) or not isinstance(value.get('local_halts'), dict):
        raise ValueError('Malformed history job state')
    return value


def run_guarded(existing_reader, destination, jobs, policy, *, runner, chunk_size=128):
    """Run exactly one job/chunk; source/clock/DB/budget failures halt globally.

    runner is market_history.run_once (the injected cooperative replacement).
    A repeated position-one roll is local: three occurrences halt that job.
    No automatic resume exists. All output is read-only collection status.
    """
    path, lock = control_paths(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return {'status': 'BUSY_OR_UNCLEAN_LOCK', 'continue_allowed': False,
                'reason': 'Another worker or interrupted run owns the history lease; explicit review is required.'}
    except OSError as exc:
        return {'status': 'HALTED', 'continue_allowed': False, 'reason': 'Cannot acquire durable history lease: ' + str(exc)}
    own_lock = True
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps({'token': token, 'pid': os.getpid(), 'utc': time.time()}))
            handle.flush()
            os.fsync(handle.fileno())
        state = load_control(path)
        if state['state'] == 'HALTED':
            return {'status': 'HALTED', 'continue_allowed': False, 'reason': state.get('reason', 'Global history stop is active')}
        if state['state'] == 'RUNNING':
            state.update(state='HALTED', reason='Previous history request did not commit a clean completion', utc=time.time())
            atomic_json(path, state)
            return {'status': 'HALTED', 'continue_allowed': False, 'reason': state['reason']}
        active = [job for job in jobs if digest(list(job)) not in state['local_halts']]
        if not active:
            return {'status': 'NO_RUNNABLE_JOBS', 'continue_allowed': False, 'local_halts': state['local_halts']}
        state.update(state='RUNNING', started_utc=time.time(), reason=None)
        atomic_json(path, state)  # Must succeed before any injected reader call.
        try:
            output = runner(existing_reader, destination, active, policy, chunk_size=chunk_size, max_jobs=1)
            results = output.get('results') if isinstance(output, dict) else None
            if not isinstance(results, list) or len(results) != 1:
                raise ValueError('History runner did not return exactly one job result')
            result = results[0]
            status = result.get('status')
            job = next((job for job in active if job[0] == result.get('symbol') and job[2] == result.get('timeframe')), None)
            if job is None:
                raise ValueError('History result does not match an active job')
            key = digest(list(job))
            health = result.get('health', {})
            drift = status == 'ERROR' and 'anchor changed during capture' in str(result.get('error', '')).lower()
            if drift:
                state['local_failures'][key] = int(state['local_failures'].get(key, 0)) + 1
                if state['local_failures'][key] >= 3:
                    state['local_halts'][key] = {'job': list(job), 'reason': result['error'], 'utc': time.time()}
                state.update(state='IDLE', reason='Position-one roll: only this job was deferred')
            elif status in ('ERROR', 'BUDGET_EXCEEDED', 'HALTED') or health.get('status') == 'CONFLICT':
                state.update(state='HALTED', reason=result.get('error') or ('Data conflict' if health.get('status') == 'CONFLICT' else str(status)))
            elif status not in ('CAPTURED', 'DONE', 'EXHAUSTED_VISIBLE_HISTORY'):
                state.update(state='HALTED', reason='Unexpected history runner status: ' + str(status))
            else:
                state['local_failures'].pop(key, None)
                state.update(state='IDLE', reason=None)
            state.update(utc=time.time(), last_job=list(job), last_status=status)
            atomic_json(path, state)
            return {'status': 'HALTED' if state['state'] == 'HALTED' else status,
                    'continue_allowed': state['state'] == 'IDLE', 'reason': state.get('reason'),
                    'local_halts': state['local_halts'], 'runner_result': output}
        except Exception as exc:
            state.update(state='HALTED', reason=type(exc).__name__ + ': ' + str(exc), utc=time.time())
            atomic_json(path, state)
            return {'status': 'HALTED', 'continue_allowed': False, 'reason': state['reason']}
    except Exception as exc:
        # The previous RUNNING marker survives a failed completion write. A
        # corrupt/unwritable control also prevents new work on the next call.
        return {'status': 'HALTED', 'continue_allowed': False, 'reason': type(exc).__name__ + ': ' + str(exc)}
    finally:
        if own_lock:
            try:
                current = json.loads(lock.read_text('utf-8'))
                if current.get('token') == token:
                    lock.unlink()
            except (OSError, ValueError):
                pass


def resume_history(destination, *, reason, confirm_no_worker=False, clear_local_halts=False):
    """Explicit operator action only; never call from a recurring worker.

    The operator must verify that no native MT5 call is still running. This
    function does not terminate processes, reinitialize MT5 or change trades.
    """
    if confirm_no_worker is not True or not isinstance(reason, str) or not reason.strip():
        raise ValueError('Explicit reason and confirmed absence of an active worker are required')
    path, lock = control_paths(destination)
    try:
        state = load_control(path)
    except (OSError, ValueError):
        state = {'schema': 'demon.history-control/1', 'local_failures': {}, 'local_halts': {}}
    if clear_local_halts:
        state['local_halts'] = {}
        state['local_failures'] = {}
    state.update(state='IDLE', reason=None, resumed_utc=time.time(), resume_reason=reason)
    atomic_json(path, state)
    lock.unlink(missing_ok=True)
    return state
