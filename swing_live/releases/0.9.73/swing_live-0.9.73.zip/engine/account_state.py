"""Keep trading safeguards and history separate for each broker account."""
import hashlib
import json
import os
import tempfile
import time
import logging
from pathlib import Path


def identity(account):
    result = {"login": int(account.login), "server": str(account.server),
              "trade_mode": int(account.trade_mode)}
    if result["login"] <= 0 or not result["server"] or result["trade_mode"] not in (0, 2):
        raise ValueError("Непотвърдена самоличност на MT5 сметката")
    return result


def path_for(legacy_path, account):
    canonical = json.dumps(account, sort_keys=True, ensure_ascii=False).encode("utf-8")
    name = hashlib.sha256(canonical).hexdigest()
    return Path(legacy_path).parent / "account_states" / (name + ".json")


def read(legacy_path, account, defaults):
    legacy_path = Path(legacy_path)
    target = path_for(legacy_path, account)
    if target.exists():
        data = json.loads(target.read_text(encoding="utf-8"))
        if data.get("account_identity") != account:
            raise ValueError("Статистиката не съответства на избраната MT5 сметка")
        return dict(defaults, **data)
    legacy = None
    if legacy_path.exists():
        # Do not silently clear safeguards after a corrupt state file.
        legacy = json.loads(legacy_path.read_text(encoding="utf-8"))
        if not isinstance(legacy, dict):
            raise ValueError("Повредено състояние на двигателя")
        if legacy.get("account_identity") == account:
            return dict(defaults, **legacy)
    if legacy and not legacy.get("account_identity"):
        raise ValueError("Старата статистика няма номер на сметка. Необходима е проверка "
                         "и прехвърляне към правилната сметка преди нови сделки.")
    return dict(defaults, account_identity=account)


def atomic_write(path, data):
    """Commit a complete snapshot; a failed commit must keep the old state.

    A Windows reader/antivirus may briefly deny replacement. Retry only access
    and sharing errors, for at most 0.75 seconds of scheduled waiting. Other
    failures propagate immediately. This is not a multi-writer transaction.
    """
    path = Path(path)
    payload = json.dumps(data, ensure_ascii=False, indent=1, allow_nan=False)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    try:
        # Unique sibling names avoid collisions between threads or reused PIDs.
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                                         dir=path.parent, prefix=path.name + ".",
                                         suffix=".tmp", delete=False) as stream:
            tmp = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        delays = (0.05, 0.10, 0.20, 0.40)
        for attempt in range(len(delays) + 1):
            try:
                os.replace(tmp, path)
                break
            except OSError as exc:
                retryable = (isinstance(exc, PermissionError)
                             or getattr(exc, "winerror", None) in (5, 32, 33))
                if not retryable or attempt == len(delays):
                    raise
                time.sleep(delays[attempt])
    finally:
        if tmp is not None:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                # Do not mask a failed commit or misreport a successful one.
                logging.getLogger(__name__).warning(
                    "account-state temporary file cleanup failed: %s", tmp.name)


def save(legacy_path, state):
    account = state.get("account_identity")
    if account:
        legacy_path = Path(legacy_path)
        if legacy_path.exists():
            previous = json.loads(legacy_path.read_text(encoding="utf-8"))
            previous_account = previous.get("account_identity")
            if previous_account and previous_account != account:
                old_path = path_for(legacy_path, previous_account)
                if not old_path.exists():
                    atomic_write(old_path, previous)
        atomic_write(path_for(legacy_path, account), state)
    # Compatibility snapshot for the dashboard, tagged with its true account.
    atomic_write(legacy_path, state)
