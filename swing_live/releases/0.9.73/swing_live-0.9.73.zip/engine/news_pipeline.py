"""News ingestion for observation only. No broker, trading or publishing imports.

All persisted diagnostics are allowlisted; upstream error messages/URLs are never
logged. A successful HTTP response is distinct from usable current information.
"""
from __future__ import annotations

import json
import math
import os
import re
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

UTC = timezone.utc
MAX_BYTES = 4 * 1024 * 1024
MAX_ARTICLES = 1000
MAX_CACHE_AGE = 2 * 3600
FRESH_HOURS = 2
BACKGROUND_HOURS = 72
PROVIDERS = ("gnews", "newsapi", "finnhub", "forexfactory")
DEFAULT_OPTIONS = {"gnews_delay_hours": None, "newsapi_delay_hours": None,
                   "finnhub_delay_hours": None, "newsapi_lookback_hours": 48}


def utcnow():
    return datetime.now(UTC)


def stamp(dt):
    return dt.astimezone(UTC).isoformat(timespec="seconds")


def parse_time(value):
    try:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if not math.isfinite(value):
                return None
            return datetime.fromtimestamp(value, UTC)
        if not isinstance(value, str):
            return None
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.astimezone(UTC) if dt.tzinfo else None
    except (ValueError, OverflowError, OSError, TypeError):
        return None


def read_bytes_shared(path):
    """Allow atomic replacement while this reader holds an old file on Windows.

    Python's ordinary open() does not opt into FILE_SHARE_DELETE. The native
    handle remains a consistent snapshot even if a writer replaces the path.
    """
    if os.name != "nt":
        with open(path, "rb") as stream:
            return stream.read(MAX_BYTES + 1)
    import ctypes
    import msvcrt
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    create = kernel.CreateFileW
    create.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                       wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    create.restype = wintypes.HANDLE
    # absolute() is lexical: resolve()/stat() can open a second Windows handle
    # with different sharing flags and defeat FILE_SHARE_DELETE under load.
    handle = create(str(Path(path).absolute()), 0x80000000, 7, None, 3, 0x80, None)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
    except Exception:
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle(handle)
        raise
    with os.fdopen(fd, "rb") as stream:
        return stream.read(MAX_BYTES + 1)


def read_doc(path):
    for attempt in range(4):
        doc, error = _read_doc_once(path)
        if error not in ("missing_file", "unreadable_file") or attempt == 3:
            return doc, error
        time.sleep(0.002 * 2 ** attempt)


def _read_doc_once(path):
    try:
        raw = read_bytes_shared(path)
        if len(raw) > MAX_BYTES:
            return {}, "oversized_file"
        doc = json.loads(raw.decode("utf-8-sig"))
        return (doc, None) if isinstance(doc, dict) else ({}, "invalid_file")
    except FileNotFoundError:
        return {}, "missing_file"
    except (OSError, ValueError, UnicodeError):
        return {}, "unreadable_file"


def options_from(doc):
    out = dict(DEFAULT_OPTIONS)
    if not isinstance(doc, dict):
        raise ValueError("invalid_options")
    for key in out:
        if key not in doc:
            continue
        value = doc[key]
        if value is None and key.endswith("delay_hours"):
            out[key] = None
            continue
        if isinstance(value, bool) or not isinstance(value, (float, int)):
            raise ValueError("invalid_options")
        lo, hi = (1, 168) if key.endswith("lookback_hours") else (0, 48)
        if not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError("invalid_options")
        out[key] = value
    return out


def clean_text(value, secrets=(), limit=2000):
    text = value if isinstance(value, str) else ""
    # Replace before truncation so even a key straddling the size limit is removed.
    for secret in secrets:
        if secret:
            text = text.replace(secret, "[redacted]")
            text = text.replace(urllib.parse.quote(secret, safe=""), "[redacted]")
    text = re.sub(r"(?i)(api[_-]?key|token|authorization)\s*[=:]\s*[^\s&]+",
                  r"\1=[redacted]", text)
    return " ".join(text.split())[:limit]


def clean_url(value, secrets=()):
    text = clean_text(value, secrets, 4096)
    try:
        p = urllib.parse.urlsplit(text)
        if p.scheme.lower() not in ("http", "https") or not p.hostname or p.username or p.password:
            return ""
        query = [(k, v) for k, v in urllib.parse.parse_qsl(p.query)
                 if not k.lower().startswith("utm_") and k.lower() not in
                 ("apikey", "api_key", "token", "key", "access_token", "fbclid", "gclid")]
        return urllib.parse.urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path,
                                       urllib.parse.urlencode(sorted(query)), ""))
    except ValueError:
        return ""


def _retry_seconds(value, now):
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        try:
            seconds = (parsedate_to_datetime(value).astimezone(UTC) - now).total_seconds()
        except (TypeError, ValueError, OverflowError):
            seconds = 1800
    if not math.isfinite(seconds):
        seconds = 1800
    return max(60, min(86400, seconds))


class FetchFailure(Exception):
    def __init__(self, code, retry_seconds=None):
        super().__init__(code)
        self.code = code
        self.retry_seconds = retry_seconds


class NoRedirect(urllib.request.HTTPRedirectHandler):
    # Credentials in a query/header must never follow a redirect to another host.
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def request_bytes(url, headers=None, timeout=15, *, opener=None, now=None):
    req = urllib.request.Request(url, headers={"User-Agent": "DEMON-news-observer/2", **(headers or {})})
    open_request = opener or urllib.request.build_opener(NoRedirect()).open
    deadline = time.monotonic() + timeout
    try:
        with open_request(req, timeout=timeout) as response:
            if hasattr(response, "read1"):
                chunks, size = [], 0
                while size <= MAX_BYTES:
                    if time.monotonic() >= deadline:
                        raise FetchFailure("request_deadline")
                    chunk = response.read1(min(65536, MAX_BYTES + 1 - size))
                    if not chunk:
                        break
                    chunks.append(chunk)
                    size += len(chunk)
                data = b"".join(chunks)
            else:
                data = response.read(MAX_BYTES + 1)
        if len(data) > MAX_BYTES:
            raise FetchFailure("response_too_large")
        return data
    except urllib.error.HTTPError as exc:
        code = int(exc.code)
        retry = _retry_seconds(exc.headers.get("Retry-After") if exc.headers else None, now or utcnow()) if code in (429, 503) else None
        raise FetchFailure(f"http_{code}", retry) from None
    except FetchFailure:
        raise
    except (TimeoutError, ConnectionError):
        raise FetchFailure("timeout_or_connection") from None
    except urllib.error.URLError:
        raise FetchFailure("network_error") from None
    except Exception:
        raise FetchFailure("transport_error") from None


def fetch_articles(provider, key, options=None, now=None, *, opener=None, timeout=15):
    now = now or utcnow()
    options = options_from(options or {})
    if not key:
        raise FetchFailure("not_configured")
    headers = {}
    if provider == "gnews":
        url = "https://gnews.io/api/v4/search?" + urllib.parse.urlencode({
            "q": "federal reserve OR central bank OR interest rates OR inflation OR CPI OR FOMC",
            "lang": "en", "max": 10, "apikey": key})
    elif provider == "newsapi":
        delay = options["newsapi_delay_hours"] or 0
        hours = max(options["newsapi_lookback_hours"], delay + 12)
        url = "https://newsapi.org/v2/everything?" + urllib.parse.urlencode({
            "q": "war OR crisis OR sanctions OR geopolitical", "language": "en",
            "sortBy": "publishedAt", "from": stamp(now - timedelta(hours=hours)), "pageSize": 100})
        headers = {"X-Api-Key": key}
    elif provider == "finnhub":
        url = "https://finnhub.io/api/v1/news?category=general"
        headers = {"X-Finnhub-Token": key}
    else:
        raise FetchFailure("unsupported_provider")
    try:
        doc = json.loads(request_bytes(url, headers, timeout=timeout, opener=opener, now=now))
    except (ValueError, UnicodeError):
        raise FetchFailure("invalid_json") from None
    if provider == "finnhub":
        items = doc
    else:
        if not isinstance(doc, dict):
            raise FetchFailure("invalid_schema")
        if (provider == "newsapi" and doc.get("status") != "ok") or doc.get("errors"):
            raise FetchFailure("api_error")
        items = doc.get("articles")
    if not isinstance(items, list) or len(items) > MAX_ARTICLES:
        raise FetchFailure("invalid_schema")
    return items


_CURRENCY_NAMES = {"USD": ("federal reserve", "fomc"), "EUR": ("ecb", "european central bank"),
                   "GBP": ("bank of england",), "JPY": ("bank of japan",),
                   "CHF": ("swiss national bank",), "CAD": ("bank of canada",),
                   "AUD": ("reserve bank of australia",), "NZD": ("reserve bank of new zealand",)}


def currencies_for(text):
    result = set()
    for cur, names in _CURRENCY_NAMES.items():
        if re.search(r"\b" + cur + r"\b", text, re.I) or any(re.search(r"\b" + re.escape(n) + r"\b", text, re.I) for n in names):
            result.add(cur)
    for pair in re.findall(r"\b([A-Z]{3})[/\-]?([A-Z]{3})\b", text.upper()):
        if all(c in _CURRENCY_NAMES for c in pair):
            result.update(pair)
    return sorted(result)


def normalize_articles(provider, raw, now, secrets=()):
    items, rejected = [], 0
    for art in raw:
        if not isinstance(art, dict):
            rejected += 1
            continue
        title = clean_text(art.get("title") or art.get("headline"), secrets, 500)
        dt = parse_time(art.get("publishedAt") or art.get("published_utc") or art.get("datetime"))
        if not title or dt is None or dt > now:
            rejected += 1
            continue
        source = art.get("source")
        if isinstance(source, dict):
            source = source.get("name")
        url = clean_url(art.get("url"), secrets)
        summary = clean_text(art.get("description") or art.get("summary"), secrets)
        age = (now - dt).total_seconds() / 3600
        category = "current" if age <= FRESH_HOURS else ("background" if age <= BACKGROUND_HOURS else "expired")
        text = title + " " + summary
        items.append({"provider": provider, "source": clean_text(source, secrets, 200),
                      "author": clean_text(art.get("author"), secrets, 200) or None,
                      "title": title, "summary": summary, "url": url,
                      "published_utc": stamp(dt), "fetched_utc": stamp(now),
                      "age_hours": round(age, 3), "usage": category,
                      "currencies": currencies_for(text), "content_kind": "unclassified",
                      "event_type": "unclassified", "direction": None,
                      "horizon": None, "scenario_conditions": None})
    return deduplicate(items), rejected


def deduplicate(items):
    result, urls, titles = [], set(), set()
    # Sorting ensures cross-provider duplicate selection is independent of fetch order.
    for item in sorted(items, key=lambda a: (a["published_utc"], a["provider"]), reverse=True):
        title = re.sub(r"\W+", " ", item["title"].casefold()).strip()
        url = item["url"]
        if (url and url in urls) or (title and title in titles):
            continue
        urls.add(url) if url else None
        titles.add(title)
        result.append(item)
    return result


def provider_status(name, now, previous=None, *, configured=True, items=(), returned=0,
                    rejected=0, error=None, delay=None):
    previous = previous if isinstance(previous, dict) else {}
    fresh = sum(a.get("usage") == "current" for a in items)
    background = sum(a.get("usage") == "background" for a in items)
    state = ("not_configured" if not configured else "error" if error else
             "empty" if not returned else "invalid_data" if not items else
             "current" if fresh else "delayed" if background else "stale")
    last = parse_time(previous.get("last_success_utc"))
    usable = parse_time(previous.get("last_usable_utc"))
    return {"provider": name, "status": state, "configured": configured,
            "last_attempt_utc": stamp(now),
            "last_success_utc": stamp(now) if configured and not error else stamp(last) if last else None,
            "last_usable_utc": stamp(now) if fresh else stamp(usable) if usable else None,
            "returned": returned, "valid": len(items), "current": fresh, "background": background,
            "rejected": rejected, "newest_age_hours": min((a["age_hours"] for a in items), default=None),
            "configured_delay_hours": delay, "error_code": error,
            "retry_after_utc": None, "selected_for_velocity": False}


def collect_provider(name, key, options, now, previous=None, *, opener=None, secrets=(), config_error=None, timeout=15):
    previous = previous if isinstance(previous, dict) else {}
    delay = options.get(name + "_delay_hours")
    if config_error:
        return [], provider_status(name, now, previous, error=config_error, delay=delay)
    if not key:
        return [], provider_status(name, now, previous, configured=False, delay=delay)
    retry = parse_time(previous.get("retry_after_utc"))
    if retry and now < retry <= now + timedelta(days=1):
        status = provider_status(name, now, previous, error="rate_limit_backoff", delay=delay)
        status["status"] = "backoff"
        attempted = parse_time(previous.get("last_attempt_utc"))
        status["last_attempt_utc"] = stamp(attempted) if attempted else None
        status["retry_after_utc"] = stamp(retry)
        return [], status
    try:
        raw = fetch_articles(name, key, options, now, opener=opener, timeout=timeout)
        items, rejected = normalize_articles(name, raw, now, secrets)
        return items, provider_status(name, now, previous, items=items, returned=len(raw), rejected=rejected, delay=delay)
    except FetchFailure as exc:
        status = provider_status(name, now, previous, error=exc.code, delay=delay)
        if exc.retry_seconds:
            status["retry_after_utc"] = stamp(now + timedelta(seconds=exc.retry_seconds))
        return [], status


def parse_ff_time(date, clock):
    local = None
    for fmt in ("%m-%d-%Y %I:%M%p", "%m-%d-%Y %I:%M %p"):
        try:
            local = datetime.strptime(f"{date.strip()} {clock.strip()}", fmt)
            break
        except (ValueError, AttributeError):
            continue
    if local is None:
        return None
    try:
        zone = ZoneInfo("America/New_York")
    except ZoneInfoNotFoundError:
        raise FetchFailure("timezone_database_missing") from None
    candidates = {local.replace(tzinfo=zone, fold=fold).astimezone(UTC) for fold in (0, 1)
                  if local.replace(tzinfo=zone, fold=fold).astimezone(UTC).astimezone(zone).replace(tzinfo=None) == local}
    # Ambiguous autumn hour and nonexistent spring hour are not guessed.
    return next(iter(candidates)) if len(candidates) == 1 else None


def fetch_calendar(now, *, opener=None):
    data = request_bytes("https://nfs.faireconomy.media/ff_calendar_thisweek.xml", opener=opener, now=now)
    if b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
        raise FetchFailure("invalid_xml")
    try:
        root = ET.fromstring(data)
    except (ET.ParseError, ValueError):
        raise FetchFailure("invalid_xml") from None
    if root.tag != "weeklyevents":
        raise FetchFailure("invalid_calendar_schema")
    events, dates, rejected = [], [], 0
    rows = root.findall("event")
    if len(rows) > MAX_ARTICLES:
        raise FetchFailure("calendar_too_large")
    for ev in rows:
        date, clock = ev.findtext("date") or "", ev.findtext("time") or ""
        try:
            dates.append(datetime.strptime(date.strip(), "%m-%d-%Y").date())
        except ValueError:
            pass
        dt = parse_ff_time(date, clock)
        title = clean_text(ev.findtext("title"), limit=500)
        if dt is None or not title:
            rejected += 1
            continue
        impact = (ev.findtext("impact") or "").strip().lower()
        currency = (ev.findtext("country") or "").strip().upper()
        if currency not in _CURRENCY_NAMES and currency != "ALL":
            rejected += 1
            continue
        impact = {"high": "High", "medium": "Medium", "low": "Low", "holiday": "Holiday"}.get(impact, "Unknown")
        if impact == "Unknown":
            rejected += 1
            continue
        if -2 * 3600 <= (dt - now).total_seconds() <= 48 * 3600:
            events.append({"ts_utc": stamp(dt), "currency": currency, "name": title, "impact": impact})
    events = list({(e["ts_utc"], e["currency"], e["name"]): e for e in events}.values())
    # An old weekly calendar must not look like a successful empty current calendar.
    try:
        today = now.astimezone(ZoneInfo("America/New_York")).date()
    except ZoneInfoNotFoundError:
        raise FetchFailure("timezone_database_missing") from None
    monday = today - timedelta(days=today.weekday())
    current_week = any(monday <= d < monday + timedelta(days=7) for d in dates)
    quality = "partial" if rejected else "current"
    if not rows:
        quality = "empty"
    elif not current_week:
        quality = "stale"
    elif rejected == len(rows):
        quality = "invalid_data"
    return sorted(events, key=lambda e: e["ts_utc"]), quality, len(rows), rejected


def collect_calendar(now, previous=None, *, opener=None):
    previous = previous if isinstance(previous, dict) else {}
    retry = parse_time(previous.get("retry_after_utc"))
    if retry and now < retry <= now + timedelta(days=1):
        status = provider_status("forexfactory", now, previous, error="rate_limit_backoff")
        attempted = parse_time(previous.get("last_attempt_utc"))
        status.update(status="backoff", last_attempt_utc=stamp(attempted) if attempted else None, retry_after_utc=stamp(retry))
        return [], status
    try:
        events, quality, count, rejected = fetch_calendar(now, opener=opener)
        status = provider_status("forexfactory", now, previous, returned=count, rejected=rejected)
        status.update(status=quality, valid=len(events), current=len(events))
        if quality == "current":
            status["last_usable_utc"] = stamp(now)
        return events, status
    except FetchFailure as exc:
        status = provider_status("forexfactory", now, previous, error=exc.code)
        if exc.retry_seconds:
            status["retry_after_utc"] = stamp(now + timedelta(seconds=exc.retry_seconds))
        return [], status


def watch_currencies(cfg):
    cfg = cfg if isinstance(cfg, dict) else {}
    symbols = cfg.get("symbols") if isinstance(cfg.get("symbols"), list) else []
    h1 = cfg.get("h1_layer") if isinstance(cfg.get("h1_layer"), dict) else {}
    if h1.get("enabled") is True and isinstance(h1.get("symbols"), list):
        symbols = symbols + h1["symbols"]
    currencies = set()
    for sym in symbols:
        # Broker suffixes allowed; unknown/prefixed symbols stay unknown.
        sym = str(sym).upper()
        if len(sym) >= 6 and sym[:3] in _CURRENCY_NAMES and sym[3:6] in _CURRENCY_NAMES:
            currencies.update((sym[:3], sym[3:6]))
    return sorted(currencies)


def evaluate(items, events, providers, now, currencies):
    current = [a for a in deduplicate(items) if a["usage"] == "current"]
    geo_items = [a for a in current if a["provider"] == "newsapi"]
    evidence = []
    # Keyword matches are evidence for human review, never a directional forecast.
    for a in geo_items:
        matches = re.findall(r"\b(?:war|invasion|nuclear|sanctions|crisis|conflict)\b", a["title"], re.I)
        if matches:
            evidence.append({"title": a["title"], "url": a["url"], "terms": sorted(set(m.lower() for m in matches)),
                             "published_utc": a["published_utc"], "interpretation": "context_requires_review"})
    geo = "REVIEW" if evidence else "NO_MATCH" if geo_items else "UNKNOWN"
    recent = [a for a in current if 0 <= (now - parse_time(a["published_utc"])).total_seconds() <= 3600]
    chosen = next((p for p in ("newsapi", "finnhub") if any(a["provider"] == p for a in recent)), None)
    for p, status in providers.items():
        status["selected_for_velocity"] = p == chosen
    count = sum(a["provider"] == chosen and 0 <= (now - parse_time(a["published_utc"])).total_seconds() <= 3600 for a in current) if chosen else None
    velocity = "UNKNOWN" if count is None else "HIGH" if count >= 6 else "ELEVATED" if count >= 3 else "NORMAL"
    blackouts = []
    for event in events:
        dt = parse_time(event.get("ts_utc"))
        if dt and event.get("impact") == "High" and (not currencies or event["currency"] == "ALL" or event["currency"] in currencies):
            start, end = dt - timedelta(minutes=15), dt + timedelta(minutes=30)
            if start <= now <= end:
                blackouts.append({**event, "starts_utc": stamp(start), "expires_utc": stamp(end)})
    calendar = providers.get("forexfactory", {})
    return {"mode": "observation_only", "affects_trading": False,
            "geo_signal": geo, "geo_evidence": evidence,
            "velocity": velocity, "velocity_count": count, "velocity_source": chosen,
            "calendar_quality": calendar.get("status", "unknown"),
            "watch_currencies": currencies, "calendar_blackouts": blackouts,
            "missing_data_policy": "unapproved_observation_only",
            "direction": None, "risk_multiplier": None}


def replace_snapshot(src, dest):
    if os.name != "nt":
        return os.replace(src, dest)
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    replace = kernel.ReplaceFileW
    replace.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR,
                        wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID]
    replace.restype = wintypes.BOOL
    dest, src = Path(dest).absolute(), Path(src).absolute()
    backup = dest.with_name(dest.name + ".previous")
    if replace(str(dest), str(src), str(backup), 0, None, None):
        return
    error = ctypes.get_last_error()
    if error == 2 and not dest.exists():
        return os.replace(src, dest)  # first write, no replaced file yet
    # ReplaceFile documents a rare failure after moving the old name. Keep the
    # previous generation and try to restore the primary path, never discard it.
    if error in (1176, 1177) and not dest.exists() and backup.exists():
        try:
            os.replace(backup, dest)
        except OSError:
            pass  # read_snapshot exposes the retained previous generation
    raise ctypes.WinError(error)


def atomic_json(path, doc, *, replace=None, sleep=time.sleep):
    """Durable single-file snapshot; bounded retry for transient Windows locks.

    Unique temp avoids cross-writer corruption. Failure preserves the previous
    complete snapshot; reader freshness then marks it stale.
    """
    path = Path(path)
    replace = replace or replace_snapshot
    encoded = (json.dumps(doc, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    if len(encoded) > MAX_BYTES:
        raise ValueError("snapshot_too_large")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(4):
            try:
                replace(tmp, path)
                break
            except PermissionError:
                if attempt == 3:
                    raise
                sleep(0.05 * 2 ** attempt)
    finally:
        try:
            Path(tmp).unlink(missing_ok=True)
        except OSError:
            pass


class WriterLock:
    """OS lock released on crash, with no stale PID/lock deletion race."""
    def __init__(self, path):
        self.path, self.stream = Path(path), None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.stream = self.path.open("a+b")
        self.stream.seek(0, 2)
        if not self.stream.tell():
            self.stream.write(b"0")
            self.stream.flush()
        self.stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.stream.close()
            self.stream = None
            raise FetchFailure("collector_already_running") from None
        return self

    def __exit__(self, *args):
        if self.stream:
            self.stream.close()


def read_snapshot(path, now=None):
    doc, error = read_doc(path)
    now = now or utcnow()
    recovered = False
    if error:
        backup, backup_error = read_doc(Path(path).with_name(Path(path).name + ".previous"))
        if not backup_error:
            doc, error, recovered = backup, None, True
    if error:
        return {"health": error, "providers": {}, "assessment": {"mode": "observation_only", "affects_trading": False}}
    ts = parse_time(doc.get("fetched_utc"))
    if not valid_snapshot(doc):
        return {"health": "invalid_schema", "providers": {}, "assessment": {"mode": "observation_only", "affects_trading": False}}
    age = (now - ts).total_seconds() if ts else None
    health = "recovered_previous" if recovered else "invalid_timestamp" if age is None or age < 0 else "stale" if age > MAX_CACHE_AGE else "current"
    doc["health"] = health
    doc["age_seconds"] = age
    if health == "current":
        # Recalculate ages and event windows at display time, including when the
        # collector has stopped but the last snapshot has not yet expired.
        for item in doc["items"]:
            dt = parse_time(item["published_utc"])
            hours = (now - dt).total_seconds() / 3600
            item["age_hours"] = round(hours, 3)
            item["usage"] = "current" if 0 <= hours <= FRESH_HOURS else "background" if 0 <= hours <= BACKGROUND_HOURS else "expired"
        for name, p in doc["providers"].items():
            if name == "forexfactory":
                continue
            articles = [a for a in doc["items"] if a["provider"] == name]
            p["current"] = sum(a["usage"] == "current" for a in articles)
            p["background"] = sum(a["usage"] == "background" for a in articles)
            p["newest_age_hours"] = min((a["age_hours"] for a in articles), default=None)
            if articles and p["status"] in ("current", "delayed", "stale"):
                p["status"] = "current" if p["current"] else "delayed" if p["background"] else "stale"
        doc["assessment"] = evaluate(doc["items"], doc["events"], doc["providers"], now,
                                     doc["assessment"].get("watch_currencies", []))
    if health != "current":
        doc["assessment"] = {"mode": "observation_only", "affects_trading": False,
                             "geo_signal": "UNKNOWN", "velocity": "UNKNOWN", "calendar_blackouts": [],
                             "calendar_quality": health, "missing_data_policy": "unapproved_observation_only"}
    return doc


def valid_snapshot(doc):
    """Reject malformed nested data before rendering or computing anything."""
    if doc.get("schema_version") != 2 or doc.get("group") not in ("gnews", "guard"):
        return False
    if not isinstance(doc.get("providers"), dict) or not isinstance(doc.get("assessment"), dict):
        return False
    expected = {"gnews"} if doc["group"] == "gnews" else {"newsapi", "finnhub", "forexfactory"}
    if set(doc["providers"]) != expected:
        return False
    statuses = ("current", "delayed", "stale", "empty", "invalid_data", "partial", "error", "backoff", "not_configured")
    for name, p in doc["providers"].items():
        if name not in PROVIDERS or not isinstance(p, dict) or not isinstance(p.get("status"), str) or p["status"] not in statuses:
            return False
        if not isinstance(p.get("configured"), bool):
            return False
        for key in ("returned", "valid", "current", "background", "rejected"):
            value = p.get(key)
            if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_ARTICLES:
                return False
        if p.get("error_code") is not None and (not isinstance(p["error_code"], str) or not re.fullmatch(r"[a-z0-9_]{1,64}", p["error_code"])):
            return False
        for key in ("last_attempt_utc", "last_success_utc", "last_usable_utc", "retry_after_utc"):
            if p.get(key) is not None and parse_time(p[key]) is None:
                return False
        for key in ("newest_age_hours", "configured_delay_hours"):
            value = p.get(key)
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0):
                return False
    for key in ("items", "events"):
        if not isinstance(doc.get(key), list) or len(doc[key]) > MAX_ARTICLES * 3:
            return False
    for a in doc["items"]:
        if not isinstance(a, dict) or a.get("provider") not in ("gnews", "newsapi", "finnhub"):
            return False
        if any(not isinstance(a.get(k), str) for k in ("title", "url", "published_utc")) or parse_time(a["published_utc"]) is None:
            return False
    for e in doc["events"]:
        if not isinstance(e, dict) or any(not isinstance(e.get(k), str) for k in ("ts_utc", "currency", "name", "impact")):
            return False
        if parse_time(e["ts_utc"]) is None:
            return False
    watch = doc["assessment"].get("watch_currencies")
    return isinstance(watch, list) and all(isinstance(c, str) for c in watch)
