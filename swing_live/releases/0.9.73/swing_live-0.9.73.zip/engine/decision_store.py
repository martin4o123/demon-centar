"""Durable append-only scenario journal and atomic read-only projections."""
import json, os, sqlite3, tempfile, time, math
from pathlib import Path
from decision_core import fingerprint, at_time

def atomic(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,prefix=path.name+'.',delete=False) as f:
            tmp=Path(f.name);f.write(data);f.flush();os.fsync(f.fileno())
        for attempt in range(5):
            try:os.replace(tmp,path);return
            except PermissionError:
                if attempt==4:raise
                time.sleep(.05*(attempt+1))
    finally:
        if tmp is not None:tmp.unlink(missing_ok=True)

class Store:
    def __init__(self,folder):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.folder/'journal.sqlite',timeout=3)
        self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY, utc REAL NOT NULL, kind TEXT NOT NULL, decision_id TEXT NOT NULL, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS current(slot TEXT PRIMARY KEY, decision_id TEXT, signature TEXT, payload TEXT);
        CREATE TABLE IF NOT EXISTS generations(revision TEXT PRIMARY KEY,payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS broker_seen(key TEXT PRIMARY KEY,signature TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TRIGGER IF NOT EXISTS immutable_update BEFORE UPDATE ON events BEGIN SELECT RAISE(ABORT,'append only'); END;
        CREATE TRIGGER IF NOT EXISTS immutable_delete BEFORE DELETE ON events BEGIN SELECT RAISE(ABORT,'append only'); END;''')
        self._migrate_broker_identity()
    def _migrate_broker_identity(self):
        if self.db.execute("SELECT 1 FROM metadata WHERE key='broker_identity_v2'").fetchone():return
        canonical={};legacy=0
        for key,payload in self.db.execute("SELECT decision_id,payload FROM events WHERE kind IN ('BROKER_DEAL','BROKER_DEAL_CORRECTION') ORDER BY seq"):
            record=json.loads(payload);a=record['account'];account={'login':a['login'],'server':a['server']}
            new=fingerprint([account,record['deal']['ticket']]);canonical[new]=fingerprint(record['deal'])
            if key!=new:legacy+=1
        with self.db:
            for key,sig in canonical.items():self.db.execute('INSERT OR REPLACE INTO broker_seen VALUES(?,?)',(key,sig))
            if legacy:
                self.db.execute('INSERT INTO events(utc,kind,decision_id,payload) VALUES(?,?,?,?)',
                    (time.time(),'BROKER_IDENTITY_CORRECTION','broker_identity_v2',json.dumps({'legacy_events':legacy,'unique_deal_keys':len(canonical),'rule':'login/server/ticket; never count raw event rows as trades','original_records_preserved':True})))
            self.db.execute("INSERT INTO metadata VALUES('broker_identity_v2','done')")
    def close(self):self.db.close()
    def commit(self,snapshot):
        json.dumps(snapshot, allow_nan=False) # validate before beginning a durable transaction
        seen=set();now=snapshot['generated_utc']
        def event(kind,row):self.db.execute('INSERT INTO events(utc,kind,decision_id,payload) VALUES(?,?,?,?)',(now,kind,row['id'],json.dumps(row,ensure_ascii=False,allow_nan=False)))
        with self.db:
            for row in snapshot['decisions']:
                slot=row['symbol']+'/'+row['strategy'];seen.add(slot)
                old=self.db.execute('SELECT decision_id,signature,payload FROM current WHERE slot=?',(slot,)).fetchone()
                sig=fingerprint({k:row.get(k) for k in ('id','status','execution_blocks','error','enabled','entry','stop','volume','risk_money','risk_budget','minimum_lot_risk','spread','indicators','checks')})
                if old and old[0]!=row['id']:event('EXPIRED',json.loads(old[2]))
                if not old or old[0]!=row['id']:event('CREATED',row)
                elif old[1]!=sig:event('CHANGED',row)
                self.db.execute('INSERT OR REPLACE INTO current VALUES(?,?,?,?)',(slot,row['id'],sig,json.dumps(row,ensure_ascii=False,allow_nan=False)))
            for slot,payload in self.db.execute('SELECT slot,payload FROM current').fetchall():
                if slot not in seen:
                    event('EXPIRED',json.loads(payload));self.db.execute('DELETE FROM current WHERE slot=?',(slot,))
            self.db.execute('INSERT OR REPLACE INTO generations VALUES(?,?)',(snapshot['revision'],json.dumps(snapshot,ensure_ascii=False,allow_nan=False)))
            # Generations are projections, unlike immutable scenario events.
            self.db.execute('DELETE FROM generations WHERE revision != ?',(snapshot['revision'],))
    def broker_deals(self,account,deals):
        # Deal tickets are not scenario IDs. Never attribute a manual trade to an AI forecast.
        account={'login':account['login'],'server':account['server']}
        with self.db:
            for deal in deals:
                key=fingerprint([account,deal['ticket']]);sig=fingerprint(deal)
                old=self.db.execute('SELECT signature FROM broker_seen WHERE key=?',(key,)).fetchone()
                if old and old[0]==sig:continue
                payload=json.dumps({'account':account,'deal':deal,'scenario_id':None},ensure_ascii=False,allow_nan=False)
                self.db.execute('INSERT INTO events(utc,kind,decision_id,payload) VALUES(?,?,?,?)',
                    (time.time(),'BROKER_DEAL_CORRECTION' if old else 'BROKER_DEAL',key,payload))
                self.db.execute('INSERT OR REPLACE INTO broker_seen VALUES(?,?)',(key,sig))
    def project(self,terminal_files=None):
        raw=self.db.execute('SELECT payload FROM generations').fetchone()
        if not raw:return
        data=json.loads(raw[0]);atomic(self.folder/'snapshot.json',raw[0].encode('utf-8'))
        if terminal_files:
            clean=lambda x:str(x if x is not None else '').replace('\t',' ').replace('\n',' ').replace('\r',' ')
            lines=['\t'.join(map(clean,['DEMON_DECISIONS_V1',data['generated_utc'],data['account']['login'],data['account']['server'],data['revision']]))]
            for r in data['decisions']:
                reason=r.get('error') or '; '.join(r['execution_blocks']) or '; '.join(r.get('entry_conditions',[]))
                lines.append('\t'.join(map(clean,[r['broker_symbol'],r['strategy'],r['status'],r['direction'],r['entry'],r['stop'],r['volume'],r['risk_money'],r['bar_raw'],r['expires_utc'],r['id'],reason,r['minimum_lot_risk'],r['risk_budget']])))
            # One atomic file per generation, no order instruction and no legacy AI signal file.
            atomic(Path(terminal_files)/'demon_decisions_v1.tsv',('\n'.join(lines)+'\n').encode('utf-8'))
    def outcome(self,decision_id,origin,net,details):
        if origin not in ('manual','automatic','zone_touch','simulation'):raise ValueError('unknown origin')
        if not self.db.execute('SELECT 1 FROM events WHERE decision_id=?',(decision_id,)).fetchone():raise ValueError('unknown decision')
        payload=json.dumps({'origin':origin,'net':net,'details':details},allow_nan=False)
        with self.db:self.db.execute('INSERT INTO events(utc,kind,decision_id,payload) VALUES(?,?,?,?)',(time.time(),'OUTCOME',decision_id,payload))

def validate_snapshot(data):
    def number(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
    if not isinstance(data,dict) or data.get('schema')!='demon.snapshot/1':raise ValueError('snapshot schema')
    if not number(data.get('generated_utc')) or not isinstance(data.get('revision'),str):raise ValueError('snapshot metadata')
    if not isinstance(data.get('account'),dict) or not isinstance(data['account'].get('server'),str):raise ValueError('account')
    if not isinstance(data.get('decisions'),list):raise ValueError('decisions')
    strings=('id','strategy','symbol','timeframe','settings_version','next_step','invalidation','risk_basis')
    prices=('entry','stop','target','volume','risk_money','risk_budget','minimum_lot_risk','spread','bar_raw','bar_utc')
    for row in data['decisions']:
        if not isinstance(row,dict) or row.get('schema')!='demon.decision/1':raise ValueError('decision schema')
        if any(not isinstance(row.get(k),str) for k in strings):raise ValueError('decision text')
        if any(k not in row or row[k] is not None and not isinstance(row[k],str) for k in ('currency','broker_symbol','direction')):raise ValueError('optional text')
        if not isinstance(row.get('exit_rules',{}),dict):raise ValueError('exit rules')
        if row.get('status') not in ('NO_DATA','NO_SIGNAL','BLOCKED','CANDIDATE','EXPIRED'):raise ValueError('status')
        if not number(row.get('expires_utc')) or not number(row.get('observed_utc')):raise ValueError('decision timestamp')
        if any(k not in row or row[k] is not None and not number(row[k]) for k in prices):raise ValueError('decision number')
        if not isinstance(row.get('execution_blocks'),list) or any(not isinstance(x,str) for x in row['execution_blocks']):raise ValueError('blocks')
        if not isinstance(row.get('checks'),list) or any(not isinstance(c,dict) or not isinstance(c.get('detail'),str) for c in row['checks']):raise ValueError('checks')
    for key in ('settings','news'):
        if key in data and (not isinstance(data[key],list) or any(not isinstance(x,dict) for x in data[key])):raise ValueError(key)
    for row in data.get('settings',[]):
        if not all(k in row for k in ('name','saved','active','state')):raise ValueError('settings row')
    for row in data.get('news',[]):
        if not all(k in row for k in ('source','status','age_seconds')) or not number(row['age_seconds']):raise ValueError('news row')
    return data

def read_snapshot(folder):
    try:
        data=json.loads((Path(folder)/'snapshot.json').read_text('utf-8'))
        validate_snapshot(data)
        return at_time(data,time.time())
    except (OSError,ValueError,KeyError,TypeError,OverflowError):return {'schema':'demon.snapshot/1','stale':True,'decisions':[],'error':'Няма валидна снимка от общия анализ.'}
