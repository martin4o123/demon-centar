"""Escaped read-only presentation for the common analysis API."""
import html,json,time
from datetime import datetime,timezone
from pathlib import Path
from decision_store import read_snapshot

def load(root):
    folder=Path(root)/'logs/decisions';data=read_snapshot(folder)
    try:health=json.loads((folder/'health.json').read_text('utf-8'))
    except (OSError,ValueError):health={'ok':False,'error':'Няма успешна проверка на услугата'}
    if not isinstance(health,dict) or not isinstance(health.get('ok'),bool):health={'ok':False,'error':'Невалиден отчет за обновяването'}
    data['health']=health
    if not health.get('ok'):
        data['stale']=True
        for r in data.get('decisions',[]):r['status']='EXPIRED'
    return data

def render(data):
    e=lambda v:html.escape(str(format(v,'.6g') if isinstance(v,float) else v if v is not None else '—'))
    stamp=lambda v:datetime.fromtimestamp(v,timezone.utc).strftime('%Y-%m-%d %H:%M') if v else '—'
    states={'NO_DATA':'Липсващи данни','NO_SIGNAL':'Няма сигнал','BLOCKED':'Блокиран вход','CANDIDATE':'Кандидат','EXPIRED':'Изтекъл сценарий'}
    rows=[]
    for r in data.get('decisions',[]):
        checks='<br>'.join(e(c['detail']) for c in r['checks'])
        why=r.get('error') or '; '.join(r['execution_blocks']) or 'Условията за вход още не са изпълнени.'
        exits=r.get('exit_rules',{})
        detail=f'''<details><summary>Защо чака? · Какво трябва да се промени?</summary><p>{e(why)}</p><p>{checks}</p><p>{e(r['next_step'])}</p>
        <p>Свещ: {e(stamp(r['bar_raw']))} брокерски час / {e(stamp(r['bar_utc']))} UTC. ID: {e(r['id'])}</p>
        <p>Минимален лот: риск {e(r['minimum_lot_risk'])} {e(r['currency'])}; основен бюджет {e(r['risk_budget'])}. {e(r['risk_basis'])}</p>
        <p>Отпада: {e(r['invalidation'])}</p><p>Изход: SL; RSI BUY &gt; {e(exits.get('rsi_long_above'))}, SELL &lt; {e(exits.get('rsi_short_below'))}; максимум {e(exits.get('max_hours'))} часа. Числова цел няма.</p></details>'''
        rows.append(f"<tr><td>{e(r['symbol'])}<br><small>{e(r['broker_symbol'])}</small></td><td>{e(r['strategy'])}</td><td>{e(states.get(r['status'],r['status']))}<br>{e(r['direction'])}</td><td>{e(r['entry'])}<br>SL {e(r['stop'])}</td><td>{e(r['spread'])}</td><td>{e(r['volume'])}<br>{e(r['risk_money'])} {e(r['currency'])}</td><td>{detail}</td></tr>")
    settings=''.join(f"<tr><td>{e(s['name'])}</td><td>{e(s['saved'])}</td><td>{e(s['active'])}</td><td>{e(s['state'])}</td></tr>" for s in data.get('settings',[]))
    news=''.join(f"<li>{e(n['source'])}: {e(n['status'])}; възраст {n['age_seconds']/60:.0f} минути; само информация.</li>" for n in data.get('news',[])) or '<li>Няма налична оценка с проверим източник.</li>'
    health=data.get('health',{})
    history_status=data.get('broker_history_status','UNKNOWN')
    history_note=(f"Брокерска история: достъпна; {len(data['broker_deals'])} deal записа за последните 30 дни."
                  if history_status=='OK' and isinstance(data.get('broker_deals'),list) else 'Брокерска история недостъпна: '+str(data.get('broker_history_error') or 'няма потвърден успешен прочит')+'. Показаните пазарни сценарии са независими от този отказ; резултатите от сделки не могат да се потвърдят.')
    return f'''<div class="card"><h2>Общ H1/D1 анализ</h2><p>Снимка {e(data.get('revision'))} · Актуалност: {'ОСТАРЯЛА / НЕДОСТЪПНА' if data.get('stale') else 'актуална'} · {e(health.get('error',''))}</p>
    <p>Последно решение на работещия двигател: {e(data.get("engine_last_reason"))}</p><p>Помощник за наблюдение. Общото изпълнение не е включено. Стратегиите още не са квалифицирани за нова автоматизация.</p>
    <p role="status">{e(history_note)}</p>
    <div style="overflow-x:auto"><table><thead><tr><th>Инструмент</th><th>Стратегия</th><th>Състояние</th><th>Вход / SL</th><th>Спред (цена)</th><th>Обем / риск</th><th>Обяснение</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></div>
    <div class="card"><h3>Записани и активни настройки</h3><p>UNKNOWN означава, че текущият двигател не е публикувал тази стойност. Последен отчет: {e(data.get('active_config_observed_utc'))}.</p><details><summary>Сравнение</summary><table><thead><tr><th>Настройка</th><th>Записана</th><th>Активна</th><th>Съвпадение</th></tr></thead><tbody>{settings}</tbody></table></details></div>
    <div class="card"><h3>Новинарски контекст</h3><ul>{news}</ul><p>Този информационен поток не разрешава поръчки.</p></div>'''
