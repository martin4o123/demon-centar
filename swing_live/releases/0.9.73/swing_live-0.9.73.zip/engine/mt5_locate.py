"""Discover installations on this computer; never guess between trading accounts."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

POWERSHELL = str(Path(os.environ.get("SystemRoot", "C:/Windows")) / "System32/WindowsPowerShell/v1.0/powershell.exe")


def localappdata() -> Path:
    return Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))


def installed_terminals() -> list[Path]:
    """Known local roots plus MetaTrader origin registrations, not owner paths."""
    base = Path(__file__).resolve().parents[1]
    candidates = [base / "mt5_portable/terminal64.exe",
                  localappdata() / "AdmiralBeta/mt5_portable/terminal64.exe"]
    for variable in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if root:
            try:
                candidates.extend(Path(root).glob("*/terminal64.exe"))
            except OSError:
                pass
    roaming = Path(os.environ.get("APPDATA") or (Path.home() / "AppData/Roaming"))
    try:
        for origin_file in (roaming / "MetaQuotes/Terminal").glob("*/origin.txt"):
            try:
                raw = origin_file.read_bytes()
                encoding = "utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
                candidates.append(Path(raw.decode(encoding).strip()) / "terminal64.exe")
            except (OSError, UnicodeError):
                continue
    except OSError:
        pass
    return list({str(p.resolve()).casefold(): p.resolve() for p in candidates if p.is_file()}.values())


def available_terminals() -> list[Path]:
    candidates = installed_terminals()
    try:
        candidates.extend(p for p, _ in running_terminals())
    except (RuntimeError, OSError, subprocess.SubprocessError):
        pass
    return list({str(p.resolve()).casefold(): p.resolve() for p in candidates}.values())


def detect_mt5_terminal(configured: str | None = None) -> Path | None:
    try:
        return selected_terminal(configured)
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError):
        return None


def detect_mt5_files_dir(configured: str | None = None) -> Path | None:
    """MQL5\\Files на АКТИВНИЯ терминал (portable → до exe; иначе MetaQuotes hash)."""
    try:
        exe = selected_terminal(configured)
        running = running_terminals()
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError):
        return None
    portable = any(p.resolve() == exe and flag for p, flag in running)
    if portable:
        return exe.parent / "MQL5" / "Files"
    term_root = Path(os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming")) / "MetaQuotes" / "Terminal"
    try:
        for d in term_root.iterdir():
            try:
                raw = (d / "origin.txt").read_bytes()
                encoding = "utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
                origin = raw.decode(encoding).strip()
                if Path(origin).resolve() == exe.parent:
                    return d / "MQL5" / "Files"
            except (OSError, UnicodeError):
                continue
    except OSError:
        pass
    # No guessed destination: an unknown data directory must not receive levels.
    return None


def running_terminals() -> list[tuple[Path, bool]]:
    """All running MT5 installations; never select an arbitrary first process."""
    r = subprocess.run(
        [POWERSHELL, "-NoProfile", "-Command",
         "[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); "
         "Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" "
         "| ForEach-Object { $_.ExecutablePath + '||' + $_.CommandLine }"],
        capture_output=True, text=True, encoding="utf-8", timeout=20,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if r.returncode:
        raise RuntimeError("Не мога да проверя работещите MT5 терминали.")
    result = {}
    for line in (r.stdout or "").splitlines():
        if "||" not in line:
            continue
        exe, cmd = line.split("||", 1)
        path = Path(exe.strip())
        if exe.strip() and path.is_file():
            result[str(path).casefold()] = (path, "/portable" in cmd.lower())
    return list(result.values())


def selected_terminal(configured: str | None = None) -> Path:
    """Explicit selection wins. A missing selection never falls back elsewhere."""
    explicit = str(configured or os.environ.get("DEMON_MT5_TERMINAL") or "").strip()
    if explicit:
        path = Path(explicit)
        if path.name.lower() != "terminal64.exe" or not path.is_file():
            raise ValueError("Избраният MT5 terminal64.exe не съществува: " + explicit)
        return path.resolve()
    running = running_terminals()
    if len(running) > 1:
        raise ValueError("Работят няколко MT5 терминала. Избери конкретен в Настройки.")
    if running:
        return running[0][0].resolve()
    installed = installed_terminals()
    if len(installed) == 1:
        return installed[0]
    raise ValueError("Няма еднозначно избран MT5 терминал. Избери сметка в Настройки.")
