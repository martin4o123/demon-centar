"""Пощальон - тегли новите телеметрични събития от скритото хранилище,
декриптира ги с частния ключ на издателя и ги записва в logs/telemetry_inbox.jsonl.

Пуска се на машината на собственика (ръчно или от планирана задача).
"""
from __future__ import annotations

import base64
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
INBOX = BASE / "logs" / "telemetry_inbox.jsonl"
PRIVATE_KEY = Path(os.environ.get("LOCALAPPDATA", r"C:\Users\mgeor\AppData\Local")) / \
    "AdmiralPublisher" / "publisher_private_key.pem"


def _gh(path: str, token: str, method: str = "GET", body: dict | None = None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(
        f"https://api.github.com/repos/martin4o123/demon-telemetry/contents/{path}"
        + ("?ref=main" if method == "GET" else ""),
        data=data, method=method,
        headers={"Authorization": f"Bearer {token}",
                 "Accept": "application/vnd.github+json",
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode())


def _decrypt(sealed_b64: str) -> dict:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    key = serialization.load_pem_private_key(PRIVATE_KEY.read_bytes(), password=None)
    blob = base64.b64decode(sealed_b64)
    wrapped, nonce, ct = blob[:384], blob[384:396], blob[396:]
    aes_key = key.decrypt(wrapped, padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(), label=None))
    return json.loads(AESGCM(aes_key).decrypt(nonce, ct, None).decode("utf-8"))


def main() -> int:
    token = os.environ.get("DEMON_TELEMETRY_TOKEN", "").strip()
    if not token:
        owner_cfg = BASE / "config" / "telemetry_owner.json"
        try:
            token = str(json.loads(owner_cfg.read_text(encoding="utf-8")).get("token") or "")
        except Exception:
            token = ""
    if not token:
        print("Няма токен (DEMON_TELEMETRY_TOKEN или config/telemetry_owner.json).")
        return 1
    if not PRIVATE_KEY.exists():
        print(f"Няма частен ключ: {PRIVATE_KEY}")
        return 1
    try:
        events = _gh("events", token)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print("Няма нови събития.")
            return 0
        raise
    new_rows = []
    for machine_dir in events:
        if machine_dir.get("type") != "dir":
            continue
        mid = machine_dir["name"]
        files = _gh(f"events/{mid}", token)
        if not isinstance(files, list):
            continue
        for f in files:
            if not f["name"].endswith(".bin"):
                continue
            try:
                payload = _gh(f"events/{mid}/{f['name']}", token)
                event = _decrypt(payload["content"].replace("\n", ""))
                new_rows.append(event)
                _gh(f"events/{mid}/{f['name']}", token, "DELETE",
                    {"message": "processed", "sha": payload["sha"]})
                print(f"  + {mid} / {f['name']}: {event.get('kind')}")
            except Exception as exc:
                new_rows.append({"v": 1, "ts": datetime.now(timezone.utc)
                                 .isoformat(timespec="seconds"),
                                 "machine": mid, "kind": "unreadable",
                                 "text": f"{f['name']}: {exc}"})
                try:
                    _gh(f"events/{mid}/{f['name']}", token, "DELETE",
                        {"message": "unreadable", "sha": payload["sha"]})
                except Exception:
                    pass
                print(f"  ! {mid} / {f['name']}: {exc}")
    if new_rows:
        INBOX.parent.mkdir(parents=True, exist_ok=True)
        with INBOX.open("a", encoding="utf-8") as fh:
            for row in new_rows:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"\n{len(new_rows)} нови събития -> {INBOX}")
    else:
        print("Няма нови събития.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
