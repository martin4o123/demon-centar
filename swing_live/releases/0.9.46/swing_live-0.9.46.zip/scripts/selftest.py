"""DEMON — самопроверка на инсталацията (клиентска).

Проверява цялостта на програмата на ВСЯКА машина: файлове, подпис, библиотеки,
лиценз, MT5, диск. Докладва резултата през криптираната телеметрия:
  - selftest_fail — когато нещо липсва/не работи (заедно с конкретния проблем)
  - selftest_ok   — ежедневен пулс „жив съм, версия X“ (rate-limited до 1/ден)
Изходът на конзолата е за човека; телеметрията е за собственика.

Използване: py -3.12 scripts/selftest.py [--quiet]
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "engine"))

OK, WARN, FAIL = "OK", "WARN", "FAIL"
problems: list[str] = []
rows: list[str] = []
QUIET = "--quiet" in sys.argv


def log(status: str, name: str, detail: str = "") -> None:
    mark = {"OK": "✓", "WARN": "!", "FAIL": "✗"}[status]
    rows.append(f"{mark} {name}" + (f" — {detail}" if detail else ""))
    if status == FAIL:
        problems.append(f"{name}: {detail}")
    elif status == WARN:
        problems.append(f"(warn) {name}: {detail}")


def local_version() -> str:
    try:
        return json.loads((BASE / "VERSION.json").read_text(encoding="utf-8"))["version"]
    except Exception:
        return "?"


def remote_version() -> str | None:
    try:
        req = urllib.request.Request(
            "https://martin4o123.github.io/demon-centar/swing_live/RELEASE.json",
            headers={"User-Agent": "demon-selftest/1"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8-sig"))["version"]
    except Exception:
        return None


def check_files() -> None:
    required = [
        "engine/engine_s5.py", "engine/licensing.py", "engine/telemetry.py",
        "engine/integrity.py", "engine/notify.py",
        "dashboard/app.py", "scripts/app.py", "scripts/update_client.py",
        "tools/license_tool.py", "tools/banlist.py",
        "tools/license_public_key.json", "tools/publisher_public_key.json",
        "assets/demon-desktop-icon.png", "config/telemetry.json",
        "VERSION.json", "LEGEND.md", "OPS_MAP.md",
    ]
    missing = [f for f in required if not (BASE / f).exists()]
    if missing:
        log(FAIL, "файлове", f"липсват: {', '.join(missing[:5])}")
    else:
        log(OK, "файлове", f"{len(required)}/{len(required)} налице")


def check_manifest() -> None:
    try:
        import integrity
        ok, msg = integrity.verify_manifest(BASE)
        log(OK if ok else FAIL, "подпис/манифест",
            "валиден" if ok else (msg or "разминаване")[:120])
    except Exception as exc:
        log(FAIL, "подпис/манифест", f"проверката гръмна: {exc}")


def check_imports() -> None:
    import importlib
    for mod in ("flask", "MetaTrader5", "cryptography", "webview"):
        try:
            importlib.import_module(mod)
            log(OK, f"библиотека {mod}")
        except Exception as exc:
            log(FAIL, f"библиотека {mod}", str(exc)[:80])


def check_license() -> None:
    try:
        import licensing
        ok, reason = licensing.is_licensed()
        log(OK if ok else FAIL, "лиценз", reason or "активен")
    except Exception as exc:
        log(WARN, "лиценз", f"проверката не мина: {exc}")


def check_mt5() -> None:
    try:
        import MetaTrader5 as mt5
        if not mt5.initialize():
            log(WARN, "MT5 връзка", "терминалът не отговаря (спрян или не е логнат)")
            return
        acc = mt5.account_info()
        if acc is None:
            log(WARN, "MT5 връзка", "няма логната сметка")
        else:
            log(OK, "MT5 връзка", f"login …{str(acc.login)[-4:]} · "
                                  f"{'REAL' if acc.trade_mode == 2 else 'demo'}")
        mt5.shutdown()
    except Exception as exc:
        log(WARN, "MT5 връзка", str(exc)[:80])


def check_engine() -> None:
    try:
        out = subprocess.run(
            [r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
             "-NoProfile", "-NonInteractive", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe' OR "
             "Name='python.exe'\" | Where-Object { $_.CommandLine -like "
             "'*engine_s5*' } | Measure-Object | Select-Object -ExpandProperty Count"],
            capture_output=True, text=True, timeout=30).stdout.strip()
        n = int(out or "0")
        log(OK if n == 1 else WARN, "двигател",
            "върви (1 процес)" if n == 1 else f"{n} процеса")
    except Exception as exc:
        log(WARN, "двигател", str(exc)[:60])


def check_disk() -> None:
    try:
        import shutil
        free_gb = shutil.disk_usage(str(BASE)).free / (1 << 30)
        log(OK if free_gb > 0.5 else WARN, "диск",
            f"{free_gb:.1f} GB свободни" + ("" if free_gb > 0.5 else " — малко!"))
    except Exception as exc:
        log(WARN, "диск", str(exc)[:60])


def report() -> None:
    try:
        import telemetry
    except Exception:
        return
    ver = local_version()
    fails = [p for p in problems if not p.startswith("(warn)")]
    if fails:
        telemetry.send_event(
            "selftest_fail",
            f"версия {ver} · {len(fails)} проблема: " + " | ".join(fails)[:4000],
            force=True)
        return
    ok_marker = BASE / "logs" / ".selftest_ok_day"
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        if ok_marker.exists() and ok_marker.read_text(encoding="ascii").strip() == today:
            return
    except Exception:
        pass
    warns = [p for p in problems if p.startswith("(warn)")]
    remote = remote_version()
    behind = f" · НОВА ВЕРСИЯ НА САЙТА: {remote}" if remote and remote != ver else ""
    if telemetry.send_event(
            "selftest_ok",
            f"версия {ver} · всичко наред"
            + (f" · предупреждения: {len(warns)}" if warns else "") + behind):
        try:
            ok_marker.parent.mkdir(parents=True, exist_ok=True)
            ok_marker.write_text(today, encoding="ascii")
        except Exception:
            pass


def main() -> int:
    check_files()
    check_manifest()
    check_imports()
    check_license()
    check_mt5()
    check_engine()
    check_disk()
    ver = local_version()
    remote = remote_version()
    if remote and remote != ver:
        log(WARN, "версия", f"локално {ver}, на сайта {remote} — пусни ROBOT update")
    else:
        log(OK, "версия", ver)
    report()
    if not QUIET:
        print(f"\n=== DEMON самопроверка @ "
              f"{datetime.now().strftime('%Y-%m-%d %H:%M')} · версия {ver} ===")
        for r in rows:
            print(" ", r)
        print("=> ВСИЧКО Е НАРЕД" if not problems else
              f"=> {len(problems)} забележки (докладвани на собственика)")
    return 1 if any(not p.startswith("(warn)") for p in problems) else 0


if __name__ == "__main__":
    sys.exit(main())
