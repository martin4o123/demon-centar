# -*- coding: utf-8 -*-
"""Проверка на целостта на инсталацията (MANIFEST.sha256 + MANIFEST.sig).

Използва се от:
  - update_client.py (преди apply на ъпдейт)
  - dashboard/app.py и engine/engine_s5.py при старт (self-check)

Правила: липсващ манифест = пропуск (dev режим). Наличен манифест без/с лош
подпис или с разминаващ се sha256 = „програмата е променена“ + стоп.
Подписът е RSA-3072 PKCS#1v15+SHA256 срещу вградения публичен модул на
publisher ключа (същия като в update_client.py).
"""
from __future__ import annotations

import base64
import hashlib
from pathlib import Path

PUBLISHER_MODULUS_HEX = (
    "b663a2203c5bdac9e0778eba9b74a2cd72db245036b571932459490f6fc21283cd3c11f5c146067ada7b931dc08d142b1cd39006aa7bff8d516164391305f3ea5ca9396cb66c05abb332f45d71490035f3f0cee66e02a9386b0cdb38c5ea05f802c5f6a6a3c3e97acf4b309c4c4b8606ca2c31ea9a3c04c7b4223b5e3accdb3957f30af630a13ab55ef77516a1728d62b5d26471dacedd9762b28906baa937e0b4d753b803947e258b3eca8c432e9c2e9234fcbd2330c0a503042e5baf16bfc801470637670fbad5cb27bce20044caa8cda16e8b4bbbc907d7dd6c257f540252abd055c505f6b061963d8833395fbbcc038ff63d8d1914c685057edb4ac85ddf97e50b15fa8ae1f798ebbb9befefccc8a72246995cd447fb86b226c889ac881bddd74b0598c453e4f7ac24bc1a46dd5fd7f00505034b214f5a609621762f9c592c580601c476df82a809baefa2a831b4a62904da7618dea24cff72fb0a0571e106997b47b797a71183f686b705ab7d67f214d34f2607776d88de033cdd64cef1"
)
KEY_ID = "da6dbc7a152497ac"
MANIFEST_SUFFIXES = {".py", ".cmd", ".ps1", ".md"}

MSG_TAMPERED = ("Програмата е променена след публикуването ѝ. "
                "За сигурност тя няма да стартира. Свържи се с автора.")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(base: Path, rel_paths: list[str]) -> str:
    """MANIFEST съдържание: '<sha256>  <relpath>' редове, сортирани по път."""
    lines = []
    for rel in sorted(rel_paths):
        lines.append(f"{sha256_file(base / rel)}  {rel}")
    return "\n".join(lines) + "\n"


def sign_manifest(manifest_text: str, signer_py: Path, key_pem: Path) -> bytes:
    """base64 подпис чрез publisher_sign.py (същият subprocess като publish_update)."""
    import subprocess
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        m = Path(td) / "MANIFEST.sha256"
        m.write_bytes(manifest_text.encode("utf-8"))   # байтове 1:1 — без \r\n транслация
        out = Path(td) / "MANIFEST.sig"
        r = subprocess.run([sys.executable, str(signer_py), "--key", str(key_pem),
                            "--input", str(m), "--output", str(out)],
                           capture_output=True, text=True, timeout=120)
        if r.returncode != 0:
            raise RuntimeError(f"подписване на манифест се провали: {r.stderr or r.stdout}")
        return out.read_bytes()


def verify_signature(data_bytes: bytes, sig_b64: bytes) -> str:
    """Връща '' при успех, иначе причина. Копира схемата от update_client.verify_release."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        pub = rsa.RSAPublicNumbers(
            65537, int(PUBLISHER_MODULUS_HEX, 16)).public_key(serialization.Encoding.PEM)
        pub.verify(base64.b64decode(sig_b64.strip()), data_bytes,
                   padding.PKCS1v15(), hashes.SHA256())
    except Exception as exc:
        return f"НЕВАЛИДЕН ПОДПИС НА МАНИФЕСТА: {exc}"
    return ""


def verify_manifest(base: Path) -> tuple[bool, str]:
    """Self-check на инсталацията в base. (ok, message). Липсващ манифест = (True, '')."""
    manifest = base / "MANIFEST.sha256"
    sig = base / "MANIFEST.sig"
    if not manifest.exists():
        return True, ""                       # dev режим — няма какво да проверяваме
    data = manifest.read_bytes()
    if sig.exists():
        err = verify_signature(data, sig.read_bytes())
        if err:
            return False, f"{MSG_TAMPERED} ({err})"
    bad = []
    for line in data.decode("utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        digest, _, rel = line.partition("  ")
        p = base / rel
        if not p.exists():
            bad.append(f"липсва {rel}")
            continue
        if sha256_file(p) != digest:
            bad.append(f"променен {rel}")
    if bad:
        return False, f"{MSG_TAMPERED} ({'; '.join(bad[:3])}{'…' if len(bad) > 3 else ''})"
    return True, ""
