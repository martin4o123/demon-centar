# -*- coding: utf-8 -*-
"""Потребители на таблото: регистрация, вход, забравена парола.

Сигурност (AUTH_DESIGN.md): PBKDF2-HMAC-SHA256, 120 000 итерации, уникална сол
на потребител, сравнение с hmac.compare_digest. Чист stdlib.
Съхранение: config\\users.json (не се публикува в Drive; не влиза в zip-овете).
Първият регистриран на машината = admin.

Забравена парола: имейлът трябва да е регистриран потребител И ключът трякбва да
е ВАЛИДЕН лиценз (който и да е валиден ключ на тази инсталация). Избрано правило
(собственикът преценява): регистриран имейл + валиден ключ — без изискване ключът
да е издаден на същия имейл, защото няма онлайн каса за сверка и ключът е
единственото доказателство „нещо, което само клиентът има“.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = BASE_DIR / "config"
USERS_FILE = CONFIG_DIR / "users.json"

ITERATIONS = 120_000
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PW_RE = re.compile(r"^(?=.*[A-Za-z])(?=.*\d).{8,}$")


class AuthError(Exception):
    """Валидационен отказ с BG съобщение."""


def _load() -> list[dict]:
    if not USERS_FILE.exists():
        return []
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(users: list[dict]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    tmp = USERS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(users, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(USERS_FILE)


def _hash(password: str, salt_hex: str) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                             bytes.fromhex(salt_hex), ITERATIONS)
    return dk.hex()


def _by_email(users: list[dict], email: str):
    email = email.strip().lower()
    for u in users:
        if u.get("email", "").lower() == email:
            return u
    return None


def create_user(name: str, email: str, password: str,
                password2: str | None = None) -> dict:
    name = (name or "").strip()
    email = (email or "").strip().lower()
    if not name:
        raise AuthError("Въведи име.")
    if not EMAIL_RE.match(email):
        raise AuthError("Невалиден имейл адрес.")
    if not PW_RE.match(password or ""):
        raise AuthError("Паролата трябва да е поне 8 символа с буква и цифра.")
    if password2 is not None and password != password2:
        raise AuthError("Паролите не съвпадат.")
    users = _load()
    if _by_email(users, email):
        raise AuthError("Този имейл вече е регистриран на тази машина.")
    salt = secrets.token_hex(16)
    user = {"name": name, "email": email, "pw_hash": _hash(password, salt),
            "salt_hex": salt, "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "admin": len(users) == 0}   # първият = admin
    users.append(user)
    _save(users)
    return user


def verify_login(email: str, password: str) -> dict | None:
    users = _load()
    u = _by_email(users, email or "")
    if u is None:
        return None
    candidate = _hash(password or "", u["salt_hex"])
    if hmac.compare_digest(candidate, u["pw_hash"]):
        return u
    return None


def verify_reset(email: str, license_key: str, is_valid_key_fn) -> bool:
    """Забравена парола: регистриран имейл + валиден ключ (виж правилото в docstring-а)."""
    users = _load()
    if _by_email(users, email or "") is None:
        return False
    try:
        payload, err = is_valid_key_fn((license_key or "").strip())
    except Exception:
        return False
    return payload is not None and err is None


def change_password(email: str, new_password: str, password2: str | None = None) -> None:
    if not PW_RE.match(new_password or ""):
        raise AuthError("Паролата трябва да е поне 8 символа с буква и цифра.")
    if password2 is not None and new_password != password2:
        raise AuthError("Паролите не съвпадат.")
    users = _load()
    u = _by_email(users, email or "")
    if u is None:
        raise AuthError("Няма такъв потребител.")
    u["salt_hex"] = secrets.token_hex(16)
    u["pw_hash"] = _hash(new_password, u["salt_hex"])
    _save(users)


def list_users() -> list[dict]:
    return [{"name": u.get("name"), "email": u.get("email"),
             "created_utc": u.get("created_utc"), "admin": bool(u.get("admin"))}
            for u in _load()]
