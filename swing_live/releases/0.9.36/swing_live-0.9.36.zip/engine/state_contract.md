# State Contract — Demon (център за управления) — моят engine

Авторитетни JSON схеми, които бъдещият търговски engine излъчва.
Дашбордът (`dashboard/app.py`) вече чете и двата формата — този и продуктовия
`decision_history.jsonl`. Промени тук САМО заедно със съответната промяна в dashboard-а.

Всички файлове: UTF-8, в `D:\AIRobot\admiral_swing_live\logs\`.
Всички времена: ISO 8601, UTC (`datetime.now(timezone.utc).isoformat()`).
Числа: JSON numbers (не низове). Пари: float, закръглени до 2 знака.

---

## 1. `logs/state.json` — последно известно състояние (пълен rewrite всеки цикъл)

Атомарен запис (записва се `.tmp` и се преименува). Писане: всеки цикъл на engine-а.

```json
{
  "version": 1,
  "mode": "dry",
  "symbols": ["GBPUSD", "USDCAD", "AUDUSD", "EURNZD", "EURCHF"],
  "position": {
    "open": false,
    "symbol": null,
    "direction": null,
    "lots": null,
    "open_price": null,
    "sl": null,
    "tp": null,
    "opened_utc": null,
    "floating_pnl": null,
    "magic": null
  },
  "guards": {
    "stop_flag": false,
    "max_risk_per_trade_pct": 1.0,
    "max_daily_dd_pct": 3.0,
    "max_total_dd_pct": 10.0,
    "cooldown_until_utc": null,
    "session_ok": true,
    "spread_ok": true,
    "data_fresh": true,
    "guard_geo": "NONE",
    "guard_velocity": "NORMAL",
    "guard_blackout_event": null,
    "guard_risk_mult": 1.0,
    "guard_social": null
  },
  "last_cycle_utc": "2026-09-13T19:00:00+00:00",
  "last_action": "WAIT"
}
```

| Поле | Тип | Изисквано | Бележки |
|---|---|---|---|
| `version` | int | да | версия на схемата; вдигане само с обратна съвместимост в dashboard-а |
| `mode` | string enum `"dry"\|"live"` | да | `dry` = само наблюдение/лог, без поръчки |
| `symbols` | string[] | да | наблюдавани символи |
| `position.open` | bool | да | има ли отворена позиция, управлявана от engine-а |
| `position.direction` | `"BUY"\|"SELL"\|null` | когато open=true | |
| `position.magic` | int\|null | не | филтър срещу чужди позиции; `null` = без magic още |
| `guards.stop_flag` | bool | да | `true` ако `STOP.flag` съществува → engine НЕ търгува |
| `guards.cooldown_until_utc` | ISO\|null | не | след грешка/DD — никакви поръчки преди това време |
| `guards.guard_geo` | string\|null | не | пазителен слой: гео риск от `logs\guard_state.json` (`NONE\|LOW\|MEDIUM\|HIGH\|CRISIS\|EXTREME`); `null` = няма файл/модул |
| `guards.guard_velocity` | string\|null | не | пазителен слой: news velocity (`NORMAL\|ELEVATED\|HIGH`) |
| `guards.guard_blackout_event` | string\|null | не | причина при блекаут около High събитие (15 мин преди → 30 мин след); `null` = няма |
| `guards.guard_risk_mult` | float | не | множител върху `risk_pct` от пазителния слой (0.0 = пълен блок на входовете) |
| `guards.guard_social` | string\|null | не | социален пулс: crowd консенсус от `logs\social_pulse.json` (`LONG`\|`SHORT`); `null` = няма свеж файл/консенсус |
| `last_cycle_utc` | ISO | да | време на последния завършен цикъл |
| `last_action` | string | да | последно избрано действие (WAIT/OPEN_LONG/OPEN_SHORT/CLOSE/…) |

---

## 2. `logs/decisions.jsonl` — append-only журнал на решенията (1 ред = 1 цикъл)

Форматът огледалява продуктовия `decision_history.jsonl`
(`markets[].checks[]` с `name/passed/detail`), за да може dashboard-ът да
рендира и двата източника с един и същ код. Имената на проверките и
`detail` са на български, както при продукта.

```json
{
  "ts": "2026-09-13T19:00:00+00:00",
  "mode": "dry",
  "cycle_id": 42,
  "action": {"type": "WAIT", "reason": "няма валиден setup; EURNZD само SELL сигнал, но RSI 58.0 извън 58–68"},
  "symbols": [
    {
      "symbol": "EURNZD",
      "result": "WAIT",
      "expected_direction": "SELL",
      "signal_score": 33,
      "reason": "RSI 58.0; нужни са 58–68; спред 0.066 ATR; максимум 0.050",
      "checks": [
        {"name": "Спред", "passed": false, "detail": "спред 0.066 ATR; максимум 0.050"},
        {"name": "Сила на дневния тренд", "passed": true, "detail": "тренд 0.40 ATR; минимум 0.20"},
        {"name": "Цена спрямо EMA200", "passed": false, "detail": "цената още не е под EMA200"},
        {"name": "H4 RSI за продажба", "passed": false, "detail": "RSI 58.0; нужни са 58–68"},
        {"name": "Разрешена посока от брокера", "passed": true, "detail": "посоката е разрешена"},
        {"name": "Безопасен размер на позицията", "passed": false, "detail": "минималният обем 0.01 лота надвишава избрания риск"}
      ]
    }
  ],
  "guards_snapshot": {
    "stop_flag": false,
    "spread_ok": true,
    "session_ok": true,
    "data_fresh": true
  }
}
```

| Поле | Тип | Изисквано | Бележки |
|---|---|---|---|
| `ts` | ISO UTC | да | начало/край на цикъла — едно от двете, консистентно |
| `mode` | `"dry"\|"live"` | да | |
| `cycle_id` | int | да | нарастващ пореден номер |
| `action.type` | string enum | да | `WAIT`, `OPEN_LONG`, `OPEN_SHORT`, `CLOSE`, `SKIP` |
| `action.reason` | string | да | кратка причина за избраното действие |
| `symbols[]` | array | да | по един запис за ВСЕКИ наблюдаван символ (не само със сигнал) |
| `symbols[].result` | `"WAIT"\|"ENTER"\|"EXIT"\|"BLOCKED"` | да | |
| `symbols[].checks[]` | array | да | всяка проверка: `name` (bg), `passed` (bool), `detail` (bg, конкретни числа) |
| `guards_snapshot` | object | не | копие на guards към момента на решението |

Правила:
- Един ред на цикъл, append-only; дублирани `cycle_id`-та не се записват.
- Търгуващият engine излъчва `trade` съобщения през `engine\notify.py`
  (`py -3.12 engine\notify.py --level info|warning|alert --category trade --text "..."`);
  те отиват в `logs\messages.jsonl` и се виждат в таблото, секция „Съобщения“.
- Проверките са на български и винаги с конкретни числа в `detail` (реалното
  мислене на робота — не „не мина“, а „RSI 47.7; нужни са 32–42“).
- Поръчки към брокера САМО когато `mode="live"`, `guards.stop_flag=false`,
  няма активен cooldown и ВСИЧКИ checks на символа са `passed`.
