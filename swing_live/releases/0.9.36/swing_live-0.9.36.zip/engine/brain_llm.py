# -*- coding: utf-8 -*-
"""Ниво 3 — LLM мозъчен слой (локален Ollama, безплатно, без облак).

На всеки цикък двигателят подава състояние (позиция, режими, последни R, пазител,
новини) и локалният модел връща СТРОГ JSON:
  {"thoughts": "...", "risk_modifier": 0.5-1.5, "confidence": "low|med|high"}

Кеш 45 мин; таймаут 25 s; при ВСЯКА грешка → неутрално (1.0, без мисли).
Никога не блокира търговията и никога не вдига риска над лимита в config.
Резултатът се пише в logs/brain_llm.json — таблото го чете за „Какво мисли роботът“.
"""
from __future__ import annotations

import json
import re
import time
import urllib.request
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
OUT = BASE_DIR / "logs" / "brain_llm.json"
CACHE_SECONDS = 45 * 60
TIMEOUT = 25

PROMPT_BG = """Ти си мозъкът на търговски робот (DEMON). Ето текущото състояние:

{state}

Отговори САМО с валиден JSON (без markdown, без обяснения извън JSON):
{{"thoughts": "2-3 изречения на български — какво виждаш, какво те притеснява, какво е добре", "risk_modifier": <число 0.5-1.5>, "confidence": "low|med|high"}}
Правила: risk_modifier < 1.0 при опасност (crisis режим, поредни загуби, лоши новини);
1.0 при нормално; 1.1-1.2 само при много чиста картина. Не измисляй факти."""


class LLMBrain:
    def __init__(self, model: str = "qwen2.5:1.5b", url: str = "http://localhost:11434",
                 max_mod: float = 1.2):
        self.model = model
        self.url = url.rstrip("/")
        self.max_mod = max_mod
        self._cache: tuple[float, dict] = (0.0, {})

    def _generate(self, prompt: str) -> str | None:
        body = json.dumps({
            "model": self.model, "prompt": prompt,
            "stream": False, "options": {"temperature": 0.3, "num_predict": 300},
        }).encode("utf-8")
        try:
            req = urllib.request.Request(self.url + "/api/generate", data=body,
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                d = json.loads(r.read().decode("utf-8", errors="replace"))
            return d.get("response", "")
        except Exception:
            return None

    @staticmethod
    def _parse(text: str) -> dict | None:
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if not m:
            return None
        try:
            d = json.loads(m.group(0))
        except Exception:
            return None
        try:
            mod = float(d.get("risk_modifier", 1.0))
        except Exception:
            mod = 1.0
        mod = max(0.5, min(1.5, mod))
        thoughts = str(d.get("thoughts", ""))[:600].strip()
        conf = str(d.get("confidence", "low"))
        if not thoughts:
            return None
        return {"thoughts": thoughts, "risk_modifier": mod,
                "confidence": conf if conf in ("low", "med", "high") else "low",
                "model": "llm"}

    def think(self, state: dict, force: bool = False) -> dict | None:
        """Мисли върху състоянието. None при грешка/липса на модел."""
        now = time.time()
        if not force and now - self._cache[0] < CACHE_SECONDS and self._cache[1]:
            return self._cache[1]
        prompt = PROMPT_BG.format(state=json.dumps(state, ensure_ascii=False, indent=1)[:2500])
        raw = self._generate(prompt)
        if raw is None:
            return self._cache[1] or None     # при мрежен срив — последната мисъл
        res = self._parse(raw)
        if res is None:
            return self._cache[1] or None
        res["risk_modifier"] = min(res["risk_modifier"], self.max_mod)
        res["ts"] = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
        self._cache = (now, res)
        try:
            OUT.parent.mkdir(parents=True, exist_ok=True)
            OUT.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
        return res
