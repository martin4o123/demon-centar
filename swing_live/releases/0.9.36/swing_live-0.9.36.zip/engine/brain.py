# -*- coding: utf-8 -*-
"""Байесов предиктор P(печалба) по контекст — „опипва средата" (Ниво 1).

Beta-биномиален модел per контекст (символ × посока × режим). С всяка затворена
сделка моделът се обновява; с <6 наблюдения в контекст връща неутрален множител.

Множител: 1 + (P − 0.5) × 1.5, clamp [0.6, 1.3]
  P = 0.60 → x1.15 (силен локален edge)
  P = 0.50 → x1.00 (неутрален)
  P = 0.40 → x0.85 · P ≤ 0.35 → x0.60 (минимум)

Състоянието се пази в engine/brain_state.json — оцелява рестарт.
"""
from __future__ import annotations

import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
STATE = BASE_DIR / "engine" / "brain_state.json"
PRIOR_A = 2.0   # слаб информативен приор — 2 „виртуални" печалби/загуби
PRIOR_B = 2.0
MIN_OBS = 6
MULT_MIN, MULT_MAX = 0.6, 1.3


class Brain:
    def __init__(self, path: Path = STATE):
        self.path = Path(path)
        self.ctx: dict[str, dict] = {}
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            self.ctx = {k: {"a": float(v["a"]), "b": float(v["b"])}
                        for k, v in d.get("ctx", {}).items()}
        except Exception:
            self.ctx = {}

    @staticmethod
    def key(symbol: str, direction: str, regime: str) -> str:
        return f"{symbol}|{direction}|{regime}"

    def p_win(self, symbol: str, direction: str, regime: str) -> tuple[float, int]:
        """(P(печалба), брой наблюдения) за контекста."""
        k = self.key(symbol, direction, regime)
        rec = self.ctx.get(k)
        if not rec:
            return 0.5, 0
        a, b = rec["a"], rec["b"]
        n = (a - PRIOR_A) + (b - PRIOR_B)
        return a / (a + b), int(round(n))

    def multiplier(self, symbol: str, direction: str, regime: str) -> tuple[float, float, int]:
        """(множител, P, n). При n < MIN_OBS → (1.0, 0.5, n)."""
        p, n = self.p_win(symbol, direction, regime)
        if n < MIN_OBS:
            return 1.0, p, n
        m = 1.0 + (p - 0.5) * 1.5
        return max(MULT_MIN, min(MULT_MAX, m)), p, n

    def update(self, symbol: str, direction: str, regime: str, won: bool) -> None:
        k = self.key(symbol, direction, regime)
        rec = self.ctx.setdefault(k, {"a": PRIOR_A, "b": PRIOR_B})
        if won:
            rec["a"] += 1.0
        else:
            rec["b"] += 1.0
        self._save()

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps({"ctx": self.ctx}, ensure_ascii=False),
                                 encoding="utf-8")
        except Exception:
            pass
