@echo off
chcp 65001 >nul
title Demon — Генератор на лицензни ключове
cd /d "D:\AIRobot\admiral_swing_live"
py -3.12 tools\license_tool.py %*
echo.
pause
