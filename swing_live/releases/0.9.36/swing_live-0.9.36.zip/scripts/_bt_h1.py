# -*- coding: utf-8 -*-
"""S5-H1: бектест на вътредневен RSI(2) реверсионен слой върху H1 барове.

Правила (огледало на S5-D1, но за H1):
  тренд EMA200(H1) върху затворен бар; RSI(2) Wilder <10/>90 на затворен бар;
  вход на open на следващия бар; SL=clamp(1.0xATR14(H1),10,50)p;
  изход RSI(2) кръстосва 55/45, или 48ч, или преди уикенд гап; 1 позиция/символ.
  Разходи: 1.5п на сделка + 0.6п/нощ суап. Без пазители (консервативно: те само режат).
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(r"D:\AIRobot\admiral_swing_live")

RSI_LO, RSI_HI = 10.0, 90.0
RSI_XL, RSI_XS = 55.0, 45.0
PIP = {"USDJPY": 0.01, "EURUSD": 0.0001, "GBPUSD": 0.0001}
COST_PIPS = 1.5
SWAP_PIP_PER_NIGHT = 0.6
MAX_HOURS = 48
SL_MIN, SL_MAX = 10.0, 50.0


def rsi_wilder(c: pd.Series, n: int = 2) -> pd.Series:
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift()
    tr = pd.concat([df["high"] - df["low"],
                    (df["high"] - pc).abs(),
                    (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def load(sym: str) -> pd.DataFrame:
    df = pd.read_csv(BASE / "data_cache" / f"h1_{sym}.csv", parse_dates=["time"])
    df = df.sort_values("time").reset_index(drop=True)
    df["rsi2"] = rsi_wilder(df["close"])
    df["ema200"] = df["close"].ewm(span=200, adjust=False).mean()
    df["atr"] = atr(df)
    df["pip"] = PIP[sym]
    return df


def run_sym(sym: str) -> pd.DataFrame:
    df = load(sym)
    trades = []
    pos = None
    n = len(df)
    for i in range(201, n - 1):
        row, nxt = df.iloc[i], df.iloc[i + 1]
        t, t_next = row["time"], nxt["time"]
        c, e, r, a = row["close"], row["ema200"], row["rsi2"], row["atr"]
        pip = row["pip"]
        gap_h = (t_next - t).total_seconds() / 3600
        if not np.isfinite(r):
            continue
        # --- управление на отворена позиция ---
        if pos:
            pos["hours"] += gap_h
            hit_sl = (nxt["low"] <= pos["sl"]) if pos["dir"] == 1 else (nxt["high"] >= pos["sl"])
            if hit_sl:
                pnl = -pos["risk_pips"] - COST_PIPS
                trades.append((sym, t_next, "SL", pnl))
                pos = None
                continue
            crossed = (r > RSI_XL) if pos["dir"] == 1 else (r < RSI_XS)
            weekend = gap_h > 26
            if crossed or pos["hours"] >= MAX_HOURS or weekend:
                exit_p = c
                pnl = (exit_p - pos["entry"]) / pip * pos["dir"] - COST_PIPS
                pnl -= SWAP_PIP_PER_NIGHT * (pos["hours"] / 24)
                reason = "RSI" if crossed else ("TIME" if pos["hours"] >= MAX_HOURS else "WEEKEND")
                trades.append((sym, t_next, reason, pnl))
                pos = None
                continue
        # --- вход само ако няма позиция ---
        if pos:
            continue
        sl_pips = float(np.clip(1.0 * a / pip, SL_MIN, SL_MAX))
        if np.isfinite(e) and np.isfinite(a):
            if c > e and r < RSI_LO:
                pos = {"dir": 1, "entry": nxt["open"],
                       "sl": nxt["open"] - sl_pips * pip,
                       "risk_pips": sl_pips, "hours": 0.0}
            elif c < e and r > RSI_HI:
                pos = {"dir": -1, "entry": nxt["open"],
                       "sl": nxt["open"] + sl_pips * pip,
                       "risk_pips": sl_pips, "hours": 0.0}
    return pd.DataFrame(trades, columns=["sym", "time", "reason", "pnl_pips"])


all_tr = pd.concat([run_sym(s) for s in ("USDJPY", "EURUSD", "GBPUSD")],
                   ignore_index=True).sort_values("time")
all_tr["r"] = all_tr["pnl_pips"] / 30  # нормиране грубо към R при риск ~30п


def report(tr: pd.DataFrame, tag: str) -> None:
    if len(tr) == 0:
        print(f"{tag}: 0 сделки")
        return
    days = max((tr["time"].max() - tr["time"].min()).days, 1)
    gross_w = tr.loc[tr.pnl_pips > 0, "pnl_pips"].sum()
    gross_l = -tr.loc[tr.pnl_pips < 0, "pnl_pips"].sum()
    pf = gross_w / gross_l if gross_l > 0 else float("inf")
    wins = (tr.pnl_pips > 0).mean()
    print(f"{tag}: {len(tr)} сделки ({len(tr)/days*30.44:.1f}/мес) "
          f"win={wins*100:.1f}% PF={pf:.2f} exp={tr.pnl_pips.mean():.1f}п "
          f"maxDDп={(-tr.pnl_pips.cumsum().diff().fillna(0).cumsum().min()):.0f}")
    print(f"   причини: {tr['reason'].value_counts().to_dict()}")


print("=== S5-H1 (2023-06 → 2026-09, разходи 1.5п + суап) ===")
report(all_tr, "ОБЩО 3 двойки")
for s in ("USDJPY", "EURUSD", "GBPUSD"):
    report(all_tr[all_tr.sym == s], f"  {s}")
# послени 12 месеца (по-актуален режим)
cut = all_tr["time"].max() - pd.Timedelta(days=365)
report(all_tr[all_tr.time >= cut], "ПОСЛЕДНИ 12 МЕС.")
