# -*- coding: utf-8 -*-
"""Пазителен събирач: ForexFactory календар + NewsAPI гео риск + news velocity.

Task Scheduler го пуска на всеки 30 минути. Пише в logs:
  guard_events.json — събития от ForexFactory за следващите 48ч
  guard_state.json  — geo_level, velocity, next_high_impact_hours, events_total
Ключовете се четат от config\\guard_keys.json (newsapi_key / finnhub_key);
липсващ/празен ключ = източникът се пропуска без грешка. Грешка в един източник
не спира останалите. Engine-ът чете двата файла през engine\\market_guard.py.

CLI: без аргументи = изпълни (запис); --check = само проверка (печата, БЕЗ запис).
"""
from __future__ import annotations

import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
KEYS_FILE = BASE_DIR / "config" / "guard_keys.json"
LOGS_DIR = BASE_DIR / "logs"
EVENTS_FILE = LOGS_DIR / "guard_events.json"
STATE_FILE = LOGS_DIR / "guard_state.json"

# Public XML feed — ForexFactory weekly calendar (без API ключ)
FF_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.xml"
TIMEOUT = 20

# Гео класификация по заглавия — взима се най-високото ниво със съвпадение
_GEO_LEVELS = (
    ("EXTREME", ("war", "invasion", "nuclear", "missile strike")),
    ("CRISIS", ("crisis", "emergency", "sanctions", "default")),
    ("HIGH", ("conflict", "tensions", "coup")),
    ("MEDIUM", ("dispute", "protests")),
)


# ============================ ключове =======================================
def load_keys(keys_path: Path | None = None) -> dict:
    """config\\guard_keys.json -> {"newsapi_key","finnhub_key"}; липса/грешка -> празни."""
    keys = {"newsapi_key": "", "finnhub_key": ""}
    try:
        data = json.loads((keys_path or KEYS_FILE).read_text(encoding="utf-8"))
        for k in keys:
            keys[k] = str(data.get(k) or "").strip()
    except Exception:
        pass
    return keys


# ============================ ForexFactory ==================================
def _parse_ff_datetime(date_str: str, time_str: str) -> datetime | None:
    """FF date='09-14-2026' time='8:30am' -> UTC datetime (времето на FF е US ET)."""
    combined = f"{date_str.strip()} {time_str.strip()}"
    for fmt in ("%m-%d-%Y %I:%M%p", "%m-%d-%Y %I:%M %p", "%m-%d-%Y"):
        try:
            dt = datetime.strptime(combined, fmt)
        except ValueError:
            continue
        # US ET -> UTC: EDT (UTC-4) май–октомври, EST (UTC-5) иначе (рудиментарно)
        offset = 4 if 3 <= dt.month <= 10 else 5
        return (dt + timedelta(hours=offset)).replace(tzinfo=timezone.utc)
    return None


def _normalize_impact(s: str) -> str:
    s = (s or "").strip().lower()
    if "high" in s:
        return "High"
    if "med" in s or "moderate" in s:
        return "Medium"
    if "low" in s:
        return "Low"
    return "Unknown"


def fetch_ff_events(timeout: int = TIMEOUT) -> list[dict]:
    """Свали и парсирай FF календара. Вдига изключение при мрежова грешка."""
    req = urllib.request.Request(FF_URL, headers={"User-Agent": "admiral-swing-live/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        xml_bytes = resp.read()
    root = ET.fromstring(xml_bytes)   # декодира по XML declaration (windows-1252)
    events: list[dict] = []
    for ev in root.findall(".//event"):
        title = (ev.findtext("title") or "").strip()
        dt = _parse_ff_datetime(ev.findtext("date") or "", ev.findtext("time") or "")
        if not title or dt is None:
            continue
        events.append({
            "ts_utc": dt.isoformat(timespec="seconds"),
            "currency": (ev.findtext("country") or "").strip().upper(),
            "name": title,
            "impact": _normalize_impact(ev.findtext("impact") or ""),
        })
    return events


def _event_dt(ev: dict) -> datetime | None:
    try:
        dt = datetime.fromisoformat(str(ev.get("ts_utc") or ""))
    except Exception:
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)


def window_events(events: list[dict], now: datetime, back_hours: float = 2.0,
                  ahead_hours: float = 48.0) -> list[dict]:
    """Събития в прозореца [now-back, now+ahead] — lookback-ът покрива post-прозореца."""
    out = []
    for ev in events:
        dt = _event_dt(ev)
        if dt is None:
            continue
        if -back_hours * 3600 <= (dt - now).total_seconds() <= ahead_hours * 3600:
            out.append(ev)
    out.sort(key=lambda e: e["ts_utc"])
    return out


def next_high_impact_hours(events: list[dict], now: datetime) -> list[float]:
    """Часове до бъдещите High събития (сортирани), за state.json."""
    hours = []
    for ev in events:
        if ev.get("impact") != "High":
            continue
        dt = _event_dt(ev)
        if dt is None:
            continue
        h = (dt - now).total_seconds() / 3600.0
        if h >= 0:
            hours.append(round(h, 1))
    hours.sort()
    return hours


# ============================ NewsAPI / Finnhub =============================
def fetch_newsapi_articles(key: str, timeout: int = TIMEOUT) -> tuple[list[dict], str | None]:
    """NewsAPI everything (гео заявка). (articles, None) или ([], грешка_BG)."""
    frm = (datetime.now(timezone.utc) - timedelta(hours=12)).strftime("%Y-%m-%dT%H:%M:%S")
    url = ("https://newsapi.org/v2/everything?" + urllib.parse.urlencode({
        "q": "war OR crisis OR sanctions OR geopolitical",
        "language": "en", "sortBy": "publishedAt", "from": frm,
        "apiKey": key, "pageSize": 25}))
    req = urllib.request.Request(url, headers={"User-Agent": "admiral-swing-live/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return [], f"NewsAPI HTTP грешка {exc.code}"
    except urllib.error.URLError as exc:
        return [], f"няма връзка с NewsAPI: {exc.reason}"
    except Exception as exc:
        return [], f"грешка при NewsAPI: {exc}"
    return list(payload.get("articles") or []), None


def fetch_finnhub_news(key: str, timeout: int = TIMEOUT) -> tuple[list[dict], str | None]:
    """Finnhub general news (fallback за velocity). (articles, None) или ([], грешка_BG)."""
    url = ("https://finnhub.io/api/v1/news?" + urllib.parse.urlencode(
        {"category": "general", "token": key}))
    req = urllib.request.Request(url, headers={"User-Agent": "admiral-swing-live/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return [], f"Finnhub HTTP грешка {exc.code}"
    except urllib.error.URLError as exc:
        return [], f"няма връзка с Finnhub: {exc.reason}"
    except Exception as exc:
        return [], f"грешка при Finnhub: {exc}"
    if not isinstance(payload, list):
        return [], "неочакван отговор от Finnhub"
    return payload, None


def classify_geo_level(titles: list[str]) -> str:
    """Макс. гео ниво от заглавия (думи с граници); без съвпадения -> LOW."""
    text = " | ".join(titles).lower()
    for level, keywords in _GEO_LEVELS:
        for kw in keywords:
            if re.search(r"\b" + re.escape(kw) + r"\b", text):
                return level
    return "LOW"


def velocity_level(count: int) -> str:
    """0-2 NORMAL, 3-5 ELEVATED, 6+ HIGH."""
    return "NORMAL" if count <= 2 else ("ELEVATED" if count <= 5 else "HIGH")


def velocity_from_articles(articles: list[dict], now: datetime,
                           minutes: int = 60) -> tuple[str, int]:
    """Брой новини за последните `minutes` мин (NewsAPI publishedAt / Finnhub datetime)."""
    cutoff = now.timestamp() - minutes * 60
    n = 0
    for a in articles:
        ts = a.get("datetime")            # finnhub: epoch seconds
        if isinstance(ts, (int, float)):
            n += int(ts >= cutoff)
            continue
        pub = str(a.get("publishedAt") or "").replace("Z", "+00:00")
        dt = _safe_dt(pub)
        if dt is not None:
            n += int(dt.timestamp() >= cutoff)
    return velocity_level(n), n


def velocity_from_ff(events: list[dict], now: datetime) -> tuple[str, int]:
    """Fallback без API ключ: брой High събития в следващите 24ч."""
    n = 0
    for ev in events:
        if ev.get("impact") != "High":
            continue
        dt = _event_dt(ev)
        if dt is None:
            continue
        if 0 <= (dt - now).total_seconds() <= 24 * 3600:
            n += 1
    return velocity_level(n), n


def _safe_dt(iso: str) -> datetime | None:
    try:
        dt = datetime.fromisoformat(iso)
    except Exception:
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)


# ============================ главен цикъл ==================================
def collect(keys_path: Path | None = None, now: datetime | None = None) -> dict:
    """Един пълен цикъл. Връща {"state","events","warnings","ff_ok"}; НЕ пише файлове."""
    now = now or datetime.now(timezone.utc)
    keys = load_keys(keys_path)
    warnings: list[str] = []

    events: list[dict] = []
    ff_ok = False
    try:
        events = window_events(fetch_ff_events(), now)
        ff_ok = True
    except Exception as exc:
        warnings.append(f"ForexFactory: {exc}")

    geo_level = "NONE"
    articles: list[dict] = []
    if keys["newsapi_key"]:
        arts, err = fetch_newsapi_articles(keys["newsapi_key"])
        if err:
            warnings.append(f"NewsAPI: {err}")
        else:
            articles = arts
            geo_level = classify_geo_level([str(a.get("title") or "") for a in arts])

    if articles:
        velocity, _ = velocity_from_articles(articles, now)
    elif keys["finnhub_key"]:
        arts, err = fetch_finnhub_news(keys["finnhub_key"])
        if err:
            warnings.append(f"Finnhub: {err}")
            velocity, _ = velocity_from_ff(events, now)
        else:
            velocity, _ = velocity_from_articles(arts, now)
    else:
        velocity, _ = velocity_from_ff(events, now)

    state = {
        "fetched_utc": now.isoformat(timespec="seconds"),
        "geo_level": geo_level,
        "velocity": velocity,
        "next_high_impact_hours": next_high_impact_hours(events, now)[:10],
        "events_total": len(events),
    }
    return {"state": state, "events": events, "warnings": warnings, "ff_ok": ff_ok}


def _write_atomic(path: Path, doc: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    tmp.replace(path)


def run(argv: list[str] | None = None, *, keys_path: Path | None = None,
        logs_dir: Path | None = None) -> int:
    argv = list(sys.argv[1:]) if argv is None else list(argv)
    check_only = "--check" in argv
    res = collect(keys_path=keys_path)
    st = res["state"]
    for w in res["warnings"]:
        print(f"ПРЕДУПРЕЖДЕНИЕ: {w}", file=sys.stderr)
    high_txt = ", ".join(f"{h}ч" for h in st["next_high_impact_hours"]) or "-"
    print(f"geo_level={st['geo_level']} velocity={st['velocity']} "
          f"събития={st['events_total']} High следващи: {high_txt}")
    if check_only:
        return 0 if res["ff_ok"] else 1
    logs = Path(logs_dir or LOGS_DIR)
    _write_atomic(logs / "guard_events.json",
                  {"fetched_utc": st["fetched_utc"], "events": res["events"]})
    _write_atomic(logs / "guard_state.json", st)
    print(f"записани {logs / 'guard_events.json'} и {logs / 'guard_state.json'}")
    return 0 if res["ff_ok"] else 1


def check_now(keys_path: Path | None = None) -> tuple[bool, str]:
    """Само проверка без запис (за бутона „Провери сега“). (ok, съобщение_BG)."""
    res = collect(keys_path=keys_path)
    st = res["state"]
    n_high = len(st["next_high_impact_hours"])
    msg = (f"geo={st['geo_level']} · velocity={st['velocity']} · "
           f"{st['events_total']} събития ({n_high} High)")
    if res["warnings"]:
        msg += " | " + "; ".join(res["warnings"])
    return res["ff_ok"], msg


if __name__ == "__main__":
    sys.exit(run())
