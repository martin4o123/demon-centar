@echo off
rem Admiral Swing Live — autostart при логин (Task Scheduler -> този файл)
rem Пуска: portable MT5, engine (чрез watchdog), след което watchdog всеки 5 мин през Task Scheduler.
setlocal
set "BASE=D:\AIRobot\admiral_swing_live"
if exist "%BASE%\STOP.flag" (
    echo [autostart] STOP.flag наличен — пропускам.
    exit /b 0
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%BASE%\scripts\admiral_watchdog.ps1"
rem Dashboard on 127.0.0.1:5123 — quiet start via pythonw; exits silently if already running
start "AdmiralDashboard" /min "" "C:\Users\mgeor\AppData\Local\Python\pythoncore-3.12-64\pythonw.exe" "%BASE%\dashboard\app.py"
exit /b 0
