@echo off
rem open_app.bat <URL> — отваря URL в прозорец като самостоятелно приложение
rem (app mode: без адресна лента/раздели). Chrome -> Edge -> default browser.
setlocal
set "URL=%~1"
if "%URL%"=="" exit /b 1

set "CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
set "EDGE1=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
set "EDGE2=C:\Program Files\Microsoft\Edge\Application\msedge.exe"

if exist "%CHROME%" (start "" "%CHROME%" --app="%URL%" & exit /b 0)
if exist "%EDGE1%"  (start "" "%EDGE1%"  --app="%URL%" & exit /b 0)
if exist "%EDGE2%"  (start "" "%EDGE2%"  --app="%URL%" & exit /b 0)
start "" "%URL%"
exit /b 0
