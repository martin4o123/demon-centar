"""Публикува ъпдейт на swing_live канала в Google Drive, подписан с publisher ключа.

Употреба: py -3.12 scripts/publish_update.py 1.0.0 --notes "какво ново"
         py -3.12 scripts/publish_update.py 1.0.0 --check   (локален тест без Drive)
Ползва същия RSA-3072 publisher ключ и схема като продукта 7.5 (AdmiralAI_Shared).

Фаза 2 (цялост): добавя MANIFEST.sha256 (sha256 на всички .py/.cmd/.ps1/.md в пейлоада)
+ MANIFEST.sig (publisher ключа); Release JSON получава "integrity". Секретите
на инсталацията (license_secret, session_secret, users.json, activation.json,
gating.json, notify.json, live_authorization.json, secrets.dat) НЕ влизат в zip-а.
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE = Path(r"D:\AIRobot\admiral_swing_live")
DRIVE = Path(r"G:\My Drive\AdmiralAI_Shared\swing_live")
SIGNER = BASE / "tools" / "publisher_sign.py"
KEY = Path(os.environ.get("LOCALAPPDATA", r"C:\Users\mgeor\AppData\Local")) / "AdmiralPublisher" / "publisher_private_key.pem"
CHANNEL = "admiral-swing-live"
KEY_ID = "da6dbc7a152497ac"
# публичен модул на publisher ключа (за key_id проверка от клиента)
MODULUS_PREFIX = "b663a2203c5bdac9e0778eba9b74a2cd"

PAYLOAD = ["engine", "dashboard", "scripts", "OPS_MAP.md", "VERSION.json", "config"]
# файлове, които отиват вътре в портативния MT5 (под BASE\mt5_portable)
MT5_PAYLOAD = [
    ("tools/mql5/DEMON_Levels.ex5",
     "mt5_portable/MQL5/Indicators/DEMON_Levels.ex5"),
    ("tools/mql5/default.tpl",
     "mt5_portable/MQL5/Profiles/Templates/default.tpl"),
]
# лицензният слой на клиента зарежда тези модули от tools\
# (без тях таблото пада с FileNotFoundError при старт — баг 2026-09-25)
EXTRA_PAYLOAD = [
    ("tools/license_tool.py", "tools/license_tool.py"),
    ("tools/banlist.py", "tools/banlist.py"),
    ("tools/license_public_key.json", "tools/license_public_key.json"),
    ("tools/license_ed_public.json", "tools/license_ed_public.json"),
]
EXCLUDE_DIRS = {"__pycache__", "data_cache", "logs", "backups", "report", "build", "tests"}
# секрети/локално състояние — никога не напускат машината на собственика
EXCLUDE_FILES = {"secrets.dat", "session_secret", "license_secret", "users.json",
                 "activation.json", "gating.json", "notify.json",
                 "live_authorization.json", "s5_state.json", "KILL.switch",
                 "brain_state.json"}

sys.path.insert(0, str(BASE / "engine"))
import integrity as _integrity  # noqa: E402


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def collect_payload_files() -> list[Path]:
    files = []
    for item in PAYLOAD:
        src = BASE / item
        if not src.exists():
            continue
        if src.is_file():
            files.append(src)
            continue
        for p in src.rglob("*"):
            if p.is_dir():
                continue
            if any(part in EXCLUDE_DIRS for part in p.parts):
                continue
            if p.name in EXCLUDE_FILES:
                continue
            files.append(p)
    return sorted(files)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("version")
    ap.add_argument("--notes", default="")
    ap.add_argument("--check", action="store_true",
                    help="локален тест: build + манифест + подпис, БЕЗ Drive/VERSION")
    args = ap.parse_args()

    if not KEY.exists():
        print(f"НЯМА КЛЮЧ: {KEY}")
        return 1
    if not SIGNER.exists():
        print(f"НЯМА ПОДПИСВАЩ ИНСТРУМЕНТ: {SIGNER}")
        return 1

    work = BASE / "build" / args.version
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    zip_path = work / f"swing_live-{args.version}.zip"

    files = collect_payload_files()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, str(p.relative_to(BASE)))
        for src_rel, arc in MT5_PAYLOAD:
            src = BASE / src_rel
            if src.exists():
                z.write(src, arc)
        for src_rel, arc in EXTRA_PAYLOAD:
            src = BASE / src_rel
            if src.exists():
                z.write(src, arc)

    # манифест на целостта (.py/.cmd/.ps1/.md в пейлоада) + подпис
    rels = [str(p.relative_to(BASE)) for p in files
            if p.suffix.lower() in _integrity.MANIFEST_SUFFIXES]
    manifest_text = _integrity.build_manifest(BASE, rels)
    (work / "MANIFEST.sha256").write_bytes(manifest_text.encode("utf-8"))
    sig_bytes = _integrity.sign_manifest(manifest_text, SIGNER, KEY)
    (work / "MANIFEST.sig").write_text(sig_bytes.decode("ascii"), encoding="ascii")
    # добавяме ги и в zip-а, за да стигнат до инсталациите
    with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as z:
        z.write(work / "MANIFEST.sha256", "MANIFEST.sha256")
        z.write(work / "MANIFEST.sig", "MANIFEST.sig")

    release = {
        "schema": 1,
        "product_id": CHANNEL,
        "version": args.version,
        "published_utc": datetime.now(timezone.utc).isoformat(),
        "notes": args.notes,
        "publisher": {
            "algorithm": "RSA-3072-PKCS1v15-SHA256",
            "key_id": KEY_ID,
            "signature_file": "RELEASE.sig",
        },
        "integrity": {
            "manifest": "MANIFEST.sha256",
            "signature": "MANIFEST.sig",
        },
        "installer": {
            "file": f"releases/{args.version}/swing_live-{args.version}.zip",
            "bytes": zip_path.stat().st_size,
            "sha256": sha256(zip_path),
        },
    }
    rel_json = work / "RELEASE.json"
    rel_json.write_text(json.dumps(release, indent=2, ensure_ascii=False), encoding="utf-8")

    r = subprocess.run(
        [sys.executable, str(SIGNER), "--key", str(KEY),
         "--input", str(rel_json), "--output", str(work / "RELEASE.sig")],
        capture_output=True, text=True)
    if r.returncode != 0:
        print("ПОДПИСВАНЕТО СЕ ПРОВАЛИ:", r.stderr or r.stdout)
        return 1

    # самопроверка на манифеста преди публикуване
    err = _integrity.verify_signature(manifest_text.encode("utf-8"), sig_bytes)
    if err:
        print("САМОПРОВЕРКА НА МАНИФЕСТА:", err)
        return 1
    leaked = [f for f in ("license_secret", "session_secret", "users.json", "activation.json")
              if any(str(p.relative_to(BASE)).endswith(f) for p in files)]
    if leaked:
        print("ТЕЧ НА СЕКРЕТИ В ПЕЙЛОАДА:", leaked)
        return 1

    print(f"[check] zip {zip_path.stat().st_size/1e6:.1f} MB, {len(files)} файла, "
          f"{len(rels)} в манифеста, подпис OK")
    if args.check:
        print("--check: локалният тест мина; Drive не е пипнат.")
        return 0

    (DRIVE / "releases" / args.version).mkdir(parents=True, exist_ok=True)
    shutil.copy2(zip_path, DRIVE / "releases" / args.version / zip_path.name)
    shutil.copy2(work / "MANIFEST.sha256", DRIVE / "releases" / args.version / "MANIFEST.sha256")
    shutil.copy2(work / "MANIFEST.sig", DRIVE / "releases" / args.version / "MANIFEST.sig")
    shutil.copy2(rel_json, DRIVE / "RELEASE.json")
    shutil.copy2(work / "RELEASE.sig", DRIVE / "RELEASE.sig")

    # пази последни 3 версии
    def _vkey(p):
        try:
            return tuple(int(x) for x in p.name.split("."))
        except ValueError:
            return (0,)
    vers = sorted((p for p in (DRIVE / "releases").iterdir() if p.is_dir()), key=_vkey)
    for old in vers[:-3]:
        shutil.rmtree(old)

    # локална VERSION.json
    (BASE / "VERSION.json").write_text(json.dumps(
        {"version": args.version, "channel": CHANNEL, "product_id": CHANNEL},
        indent=2), encoding="utf-8")

    print(f"Публикувано: {CHANNEL} {args.version} ({zip_path.stat().st_size/1e6:.1f} MB)")
    print(f"Drive: {DRIVE}\\RELEASE.json + releases\\{args.version}\\")

    # GitHub Pages канал — публичният ъпдейт сървър (build\github-site е git репо)
    site = BASE / "build" / "github-site"
    if (site / ".git").is_dir():
        try:
            sl = site / "swing_live"
            sl.mkdir(exist_ok=True)
            for f in ("RELEASE.json", "RELEASE.sig"):
                shutil.copy2(DRIVE / f, sl / f)
            bl = DRIVE / "banlist.json"
            if bl.exists():
                shutil.copy2(bl, sl / "banlist.json")
            rel_dst = sl / "releases"
            if rel_dst.exists():
                shutil.rmtree(rel_dst)
            shutil.copytree(DRIVE / "releases", rel_dst)
            for junk in site.rglob("desktop.ini"):
                junk.unlink(missing_ok=True)
            subprocess.run(["git", "-C", str(site), "add", "-A"],
                           check=True, capture_output=True)
            subprocess.run(["git", "-C", str(site), "-c", "user.name=martin4o123",
                            "-c", "user.email=270086813+martin4o123@users.noreply.github.com",
                            "commit", "-q", "--allow-empty", "-m", f"release {args.version}"],
                           capture_output=True)
            r = subprocess.run(["git", "-C", str(site), "push", "-q"],
                               capture_output=True, text=True, timeout=120)
            if r.returncode == 0:
                print("GitHub канал обновен: martin4o123.github.io/demon-centar")
            else:
                print(f"ПРЕДУПРЕЖДЕНИЕ: git push върна {r.returncode}: {r.stderr[-200:]}")
        except Exception as exc:
            print(f"ПРЕДУПРЕЖДЕНИЕ: GitHub каналът не се обнови ({exc})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
