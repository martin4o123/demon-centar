# -*- coding: utf-8 -*-
"""Социален пулс: Twitter squawk акаунти (през Nitter RSS) + forex RSS + Reddit.

Пренаписан от admiral\\internet_brain.py (v5.6) — само keyword sentiment, без
Ollama и без API ключове. Task Scheduler може да го пуска периодично; пише
logs\\social_pulse.json, който engine\\market_guard.py чете през social_bias().

Източници:
  - Twitter/X през Nitter RSS огледала (nitter.net, nitter.tiekoetter.com,
    xcancel.com) с fallback — при всеки акаунт се пробват огледалата поред;
    browser User-Agent е задължителен (иначе 403). Всички мъртви -> skip с
    предупреждение, не fatal. Макс 10 поста/акаунт, 1 s пауза между акаунтите.
  - RSS без ключ: FXStreet, ForexLive, DailyFX.
  - Reddit JSON без ключ: r/Forex + r/algotrading hot (.json suffix + UA).

Sentiment: regex с граници върху lowercase текст; пост с и двете полярности
или без нито една -> NEUTRAL (не влиза в bias броенето).

CLI: без аргументи = изпълни (запис в logs\\social_pulse.json);
     --check = само суми на конзолата, БЕЗ запис.
Грешка в един източник не спира останалите. Общ бюджет: 60 s (10 s/заявка).
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"
OUT_FILE = LOGS_DIR / "social_pulse.json"

# реалистичен browser UA — custom UA често връща 403 от Nitter/Reddit
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                         "AppleWebKit/537.36 (KHTML, like Gecko) "
                         "Chrome/120.0.0.0 Safari/537.36"}
TIMEOUT = 10            # per-request timeout (s)
TOTAL_BUDGET_SEC = 60.0 # общ бюджет за всички източници (s)
SLEEP_BETWEEN = 1.0     # пауза между Twitter акаунтите (s); тестовете я нулират
MAX_TEXT = 280          # отрязване на текста на поста
MAX_POSTS = 10          # макс поста на източник

# ─── източници ────────────────────────────────────────────────────────────────
NITTER_INSTANCES = ["https://nitter.net",
                    "https://nitter.tiekoetter.com",
                    "https://xcancel.com"]

TWITTER_ACCOUNTS = ["zaborsky", "FirstSquawk", "DeItaone", "unusual_whales",
                    "ForexLive", "ReutersBiz", "elikilos"]

RSS_FEEDS = [
    ("FXStreet",  "https://www.fxstreet.com/rss/news"),
    ("ForexLive", "https://www.forexlive.com/feed/"),
    ("DailyFX",   "https://www.dailyfx.com/feeds/all"),
]

REDDIT_SUBS = ["Forex", "algotrading"]

# ─── sentiment по ключови думи (regex с граници, lowercase) ──────────────────
_BULLISH = re.compile(r"\b(bullish|breakout|surges|soars|rally|beats|strong|upgrade|long)\b")
_BEARISH = re.compile(r"\b(bearish|plunges|crashes|tumbles|misses|weak|downgrade|short|selloff|fears)\b")


def classify_sentiment(text: str) -> str:
    """'BULL' | 'BEAR' | 'NEUTRAL' — и двете или нито едно -> NEUTRAL."""
    low = str(text or "").lower()
    bull = bool(_BULLISH.search(low))
    bear = bool(_BEARISH.search(low))
    if bull and not bear:
        return "BULL"
    if bear and not bull:
        return "BEAR"
    return "NEUTRAL"


def _http_get(url: str, timeout: float) -> bytes:
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _parse_ts(value: str | None) -> str:
    """RSS pubDate -> ISO UTC; неразпознато -> сега."""
    if value:
        try:
            dt = parsedate_to_datetime(value.strip())
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).isoformat(timespec="seconds")
        except Exception:
            pass
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clean(text: str) -> str:
    return " ".join(str(text or "").split())[:MAX_TEXT]


def _parse_rss_items(xml_bytes: bytes, source: str, author: str) -> list[dict]:
    """RSS/Nitter XML -> постове (макс MAX_POSTS)."""
    root = ET.fromstring(xml_bytes)
    posts = []
    for item in root.findall(".//item")[:MAX_POSTS]:
        title = (item.findtext("title") or "").strip()
        desc = (item.findtext("description") or "").strip()
        text = _clean(f"{title} {desc}")
        if not text:
            continue
        posts.append({
            "source": source,
            "author": author,
            "text": text,
            "ts_utc": _parse_ts(item.findtext("pubDate")),
            "sentiment": classify_sentiment(text),
        })
    return posts


def fetch_twitter_account(user: str, timeout: float = TIMEOUT) -> tuple[list[dict], str | None]:
    """Един акаунт през Nitter огледалата с fallback. (постове, грешка|None)."""
    last_err: str | None = None
    for base in NITTER_INSTANCES:
        url = f"{base}/{user}/rss"
        try:
            xml = _http_get(url, timeout=timeout)
            return _parse_rss_items(xml, "twitter", f"@{user}"), None
        except urllib.error.HTTPError as exc:
            last_err = f"HTTP {exc.code}"
        except Exception as exc:
            last_err = str(exc)
    return [], (last_err or "няма отговор")


def fetch_rss_feed(name: str, url: str, timeout: float = TIMEOUT) -> tuple[list[dict], str | None]:
    try:
        xml = _http_get(url, timeout=timeout)
        return _parse_rss_items(xml, "rss", name), None
    except Exception as exc:
        return [], str(exc)


def fetch_reddit(sub: str, timeout: float = TIMEOUT) -> tuple[list[dict], str | None]:
    """r/{sub} hot JSON (без ключ; UA задължителен)."""
    url = f"https://www.reddit.com/r/{sub}/hot.json?limit=25"
    try:
        raw = _http_get(url, timeout=timeout)
        data = json.loads(raw.decode("utf-8", errors="replace"))
        posts = []
        for child in (data.get("data", {}) or {}).get("children", [])[:MAX_POSTS]:
            pd = child.get("data", {}) or {}
            text = _clean(f"{pd.get('title', '')} {pd.get('selftext', '')}")
            if not text:
                continue
            try:
                ts = datetime.fromtimestamp(int(pd.get("created_utc")),
                                            tz=timezone.utc).isoformat(timespec="seconds")
            except Exception:
                ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
            posts.append({
                "source": "reddit",
                "author": str(pd.get("author") or f"r/{sub}"),
                "text": text,
                "ts_utc": ts,
                "sentiment": classify_sentiment(text),
            })
        return posts, None
    except Exception as exc:
        return [], str(exc)


def _sleep():
    if SLEEP_BETWEEN > 0:
        time.sleep(SLEEP_BETWEEN)


def collect(now: datetime | None = None) -> dict:
    """Един пълен цикъл. Връща {"fetched_utc","posts","counts","warnings","any_ok"}."""
    now = now or datetime.now(timezone.utc)
    deadline = time.monotonic() + TOTAL_BUDGET_SEC
    posts: list[dict] = []
    warnings: list[str] = []
    any_ok = False

    def left() -> float:
        return max(0.5, deadline - time.monotonic())

    for user in TWITTER_ACCOUNTS:
        if time.monotonic() > deadline:
            warnings.append("времето (60 s) изтече — останалите източници се пропускат")
            break
        got, err = fetch_twitter_account(user, timeout=min(TIMEOUT, left()))
        if err:
            warnings.append(f"Twitter/@{user}: всички огледала мъртви ({err})")
        else:
            any_ok = True
            posts.extend(got)
        _sleep()

    for name, url in RSS_FEEDS:
        if time.monotonic() > deadline:
            warnings.append("времето (60 s) изтече — останалите източници се пропускат")
            break
        got, err = fetch_rss_feed(name, url, timeout=min(TIMEOUT, left()))
        if err:
            warnings.append(f"RSS/{name}: {err}")
        else:
            any_ok = True
            posts.extend(got)

    for sub in REDDIT_SUBS:
        if time.monotonic() > deadline:
            warnings.append("времето (60 s) изтече — останалите източници се пропускат")
            break
        got, err = fetch_reddit(sub, timeout=min(TIMEOUT, left()))
        if err:
            warnings.append(f"Reddit/r/{sub}: {err}")
        else:
            any_ok = True
            posts.extend(got)

    bull = sum(1 for p in posts if p["sentiment"] == "BULL")
    bear = sum(1 for p in posts if p["sentiment"] == "BEAR")
    return {"fetched_utc": now.isoformat(timespec="seconds"),
            "posts": posts, "counts": {"bull": bull, "bear": bear},
            "warnings": warnings, "any_ok": any_ok}


def _write_atomic(path: Path, doc: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    tmp.replace(path)


def run(argv: list[str] | None = None, *, logs_dir: Path | None = None) -> int:
    argv = list(sys.argv[1:]) if argv is None else list(argv)
    check_only = "--check" in argv
    res = collect()
    for w in res["warnings"]:
        print(f"ПРЕДУПРЕЖДЕНИЕ: {w}", file=sys.stderr)
    c = res["counts"]
    print(f"постове={len(res['posts'])} BULL={c['bull']} BEAR={c['bear']}")
    if check_only:
        return 0 if res["any_ok"] else 1
    logs = Path(logs_dir or LOGS_DIR)
    _write_atomic(logs / "social_pulse.json", {
        "fetched_utc": res["fetched_utc"],
        "posts": res["posts"],
        "counts": res["counts"],
    })
    print(f"записан {logs / 'social_pulse.json'}")
    return 0 if res["any_ok"] else 1


def check_now() -> tuple[bool, str]:
    """Само проверка без запис (за бутона „Обнови сега“). (ok, съобщение_BG)."""
    res = collect()
    c = res["counts"]
    msg = f"{len(res['posts'])} поста · BULL {c['bull']} · BEAR {c['bear']}"
    if res["warnings"]:
        msg += " | " + "; ".join(res["warnings"][:4])
    return res["any_ok"], msg


if __name__ == "__main__":
    sys.exit(run())
