# -*- coding: utf-8 -*-
"""Авто-research конвейер — роботът изследва сам (всяка неделя нощ).

Пуска батерия от хипотези (нови идеи се добавят в IDEAS) през същия dev/holdout
дисциплиниран бектест. Само идеи с holdout PF>=1.15 и dev PF>=1.2 отиват в
секция „КАНДИДАТИ“. Пише report/auto_research_<дата>.md и нотифицира.

Употреба: py -3.12 scripts/auto_research.py   (Task Scheduler: неделя 02:07)
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import numpy as np
import pandas as pd
from research_ensemble import PAIRS, add_indicators, backtest, load  # noqa: F401

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "engine"))
try:
    from notify import notify
except Exception:
    def notify(level, category, text):  # noqa: D103
        print(f"[{level}/{category}] {text}")

BASE = Path(r"D:\AIRobot\admiral_swing_live")
REPORT = BASE / "report"
GATE_HOLDOUT = 1.15
GATE_DEV = 1.20

# ── батерия хипотези: всяка е промяна срещу базовия ансамбъл ──
# (флагове, които research_ensemble чете от cfg-подобен dict; тук само имена+описания,
#  защото реалните вариации се пускат чрез SCORE/прагове)
IDEAS = [
    {"name": "base_ensemble_v2", "desc": "базов тренд+pullback (контрола)"},
    {"name": "gold_breakout", "desc": "XAUUSD/GOLD ATR-breakout с тренд филтър"},
    {"name": "majors_only", "desc": "само USDJPY+EURUSD+GBPUSD от базовия"},
]


def run_idea_variants() -> list[dict]:
    """Пуска вариациите и връща редове за доклада."""
    rows = []
    # вариант: само мейджори (изключваме кръстосаните и метала)
    majors = ["USDJPY", "EURUSD", "GBPUSD"]
    for sym in majors:
        d1 = load(sym, "D1")
        h4 = load(sym, "H4")
        if d1.empty:
            continue
        d1 = add_indicators(d1)
        if not h4.empty:
            from research_ensemble import rsi as _rsi
            h4d = _rsi(h4["close"], 14).resample("1D").last().reindex(d1.index).ffill()
            d1["htf_dir"] = np.sign(50 - h4d).fillna(0)
        else:
            d1["htf_dir"] = 0
        rdev = backtest(d1, sym, dev=True)
        rho = backtest(d1, sym, dev=False)
        rows.append({"idea": "majors_only", "symbol": sym,
                     "dev_pf": rdev.get("pf"), "holdout_pf": rho.get("pf"),
                     "holdout_trades": rho.get("trades")})
    return rows


def main() -> int:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d")
    REPORT.mkdir(exist_ok=True)
    rows = run_idea_variants()
    lines = [f"# Авто-research {stamp}", "",
             f"Гейт: holdout PF>={GATE_HOLDOUT} И dev PF>={GATE_DEV}", "",
             "| идея | двойка | dev PF | holdout PF | holdout сделки |",
             "|---|---|---|---|---|"]
    candidates = []
    for r in rows:
        dev_pf = r.get("dev_pf") or 0
        ho_pf = r.get("holdout_pf") or 0
        ok = dev_pf >= GATE_DEV and ho_pf >= GATE_HOLDOUT and (r.get("holdout_trades") or 0) >= 10
        mark = " ✅ КАНДИДАТ" if ok else ""
        lines.append(f"| {r['idea']} | {r['symbol']} | {dev_pf:.2f} | {ho_pf:.2f} | "
                     f"{r.get('holdout_trades', 0)} |{mark}")
        if ok:
            candidates.append(f"{r['symbol']} ({r['idea']})")
    out = REPORT / f"auto_research_{stamp}.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    if candidates:
        notify("info", "research",
               f"Авто-research: кандидати за демо — {', '.join(candidates)}. Доклад: {out.name}")
    else:
        notify("info", "research", f"Авто-research {stamp}: няма нови кандидати (доклад {out.name}).")
    print("\n".join(lines[-len(rows) - 2:]))
    print(f"\nДоклад: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
