@echo off
rem License Manager (owner-only) — http://127.0.0.1:5124
set "BASE=D:\AIRobot\admiral_swing_live"
powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',5124);$c.Close();exit 0}catch{exit 1}" >nul 2>&1
if errorlevel 1 (
    start "LicenseManager" /min "" "C:\Users\mgeor\AppData\Local\Python\pythoncore-3.12-64\pythonw.exe" "%BASE%\tools\license_manager\app.py"
    timeout /t 3 /nobreak >nul
)
call "%BASE%\scripts\open_app.bat" http://127.0.0.1:5124/
exit /b 0
