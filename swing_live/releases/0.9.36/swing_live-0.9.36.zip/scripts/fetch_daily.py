"""Нощно обновяване на data_cache свещите от живия MT5 терминал (read-only).
Пуска се планирано сутрин; idempotent — догаря само нови барове.
"""
import json
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import MetaTrader5 as mt5
import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE = Path(r"D:\AIRobot\admiral_swing_live")
CACHE = BASE / "data_cache"
LOG = BASE / "logs" / "fetch_daily.log"

JOBS = [
    ("EURUSD", "D1", mt5.TIMEFRAME_D1),
    ("EURUSD", "H4", mt5.TIMEFRAME_H4),
    ("EURUSD", "H1", mt5.TIMEFRAME_H1),
    ("GBPUSD", "H1", mt5.TIMEFRAME_H1),
    ("USDJPY", "D1", mt5.TIMEFRAME_D1),
    ("USDJPY", "H4", mt5.TIMEFRAME_H4),
    ("XAUUSD", "D1", mt5.TIMEFRAME_D1),
    ("XAUUSD", "H4", mt5.TIMEFRAME_H4),
]


def eu_dst(utc_ts: int) -> int:
    d = datetime.fromtimestamp(utc_ts, timezone.utc)

    def last_sun(y, m):
        d2 = datetime(y, m + 1, 1, tzinfo=timezone.utc) - timedelta(days=1)
        while d2.weekday() != 6:
            d2 -= timedelta(days=1)
        return d2.replace(hour=1)

    return utc_ts + (3 if last_sun(d.year, 3) <= d < last_sun(d.year, 10) else 2) * 3600


def log(msg: str) -> None:
    LOG.parent.mkdir(exist_ok=True)
    line = f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line)


def main() -> int:
    if not mt5.initialize():
        log(f"MT5 init failed: {mt5.last_error()}")
        return 1
    added_total = 0
    for sym, tfname, tf in JOBS:
        path = CACHE / f"candle_history_{sym}_{tfname}.csv"
        if not path.exists():
            log(f"SKIP {sym} {tfname} — липсва {path.name}")
            continue
        old = pd.read_csv(path)
        last_ts = int(old["time_server_epoch"].max())
        # търсим барове от последния известен СЪРВЪРен таймстамп - 1 бар нататък
        start_utc = datetime.fromtimestamp(last_ts, timezone.utc) - timedelta(hours=8)
        rates = mt5.copy_rates_range(sym, tf, start_utc, datetime.now(timezone.utc) + timedelta(days=1))
        if rates is None or len(rates) == 0:
            log(f"{sym} {tfname}: няма нови данни")
            continue
        df = pd.DataFrame(rates)
        df["time_server_epoch"] = df["time"].apply(eu_dst)
        df = df[df["time_server_epoch"] > last_ts]
        if df.empty:
            log(f"{sym} {tfname}: актуално ({len(old)} реда)")
            continue
        add = df[["time_server_epoch", "open", "high", "low", "close", "tick_volume", "spread", "real_volume"]].copy()
        add["real_volume"] = 0
        new = pd.concat([old, add], ignore_index=True).drop_duplicates(subset="time_server_epoch").sort_values("time_server_epoch")
        new.to_csv(path, index=False)
        added_total += len(add)
        log(f"{sym} {tfname}: +{len(add)} бара (общо {len(new)})")
    mt5.shutdown()
    log(f"Готово. Добавени общо {added_total} бара.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
