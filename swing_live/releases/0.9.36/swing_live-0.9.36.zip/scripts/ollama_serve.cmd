@echo off
start "" /min "C:\Users\mgeor\AppData\Local\Programs\Ollama\ollama.exe" serve
