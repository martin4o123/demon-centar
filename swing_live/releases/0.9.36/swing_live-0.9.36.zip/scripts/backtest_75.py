"""
backtest_75.py — Бектест на Admiral 7.5 суинг стратегията (reverse-engineered спецификация).

Източник на данни (READ-ONLY):
    C:\\Users\\mgeor\\AppData\\Local\\AdmiralBeta\\mt5_portable\\MQL5\\Files\\candle_history_<SYM>_<TF>.csv

Стратегия (фиксирани параметри = продуктовите дефолти, без оптимизация):
  - Universe: GBPUSD, USDCAD, AUDUSD, EURNZD, EURCHF
  - Сметка: максимум 1 отворена позиция ОБЩО; оценка на всяко H4 затваряне;
    cooldown 24ч след entry; без entries петък след 20:00 сървърно време.
  - LONG сетъп (SHORT е огледален):
      1) |EMA50(D1) - EMA200(D1)| / ATR14(D1) >= 0.20
      2) D1 close > EMA200(D1)   (SHORT: <)
      3) RSI14(H4) в [32,42]     (SHORT: [58,68])
      4) spread_price / ATR14(D1) <= 0.05   (spread колоната на H4 бара, в price)
      5) Посока позволена (винаги True тук)
  - Entry: на H4 close на бара, изпълняващ всички условия.
  - SL = 1.5 x ATR14(D1), TP = 3.0 x ATR14(D1)  -> R:R 1:2.
  - Вариант B (продуктов дефолт, README §6): BE на +1.8R (заключва +0.10R),
    trailing stop 1.2R след като цената >= +2.5R. Менажиране на H4 closes.
  - Вариант A: чист SL/TP изход.

Модел на разходите (честен):
  - Entry: BUY на ask = close + spread; SELL на bid = close; + slippage 0.3 pip.
    Т.е. пълен спред се начислява веднъж при entry (BUY: +spread; SELL: -spread),
    всички изходи са по bid цени от данните.
  - Spread: собствената spread колона на всеки H4 бар; <=0 -> медиана на двойката.
  - Swap: 0.6 pip/нощ (двупосочно, консервативно); нощ = сървърна полунощ в [entry, exit).
  - Без triple-swap сряда (леко оптимистично за нас - отбелязано).

Апроксимации (неточности срещу реалния продукт):
  - 10-минутната интрабарна оценка се апроксимира с оценка на H4 close.
  - Ако в един H4 бар са ударени и SL, и TP, се приема SL (консервативно).
  - BE/trailing се задействат на H4 close цена (консервативно спрямо intrabar high).
  - Cooldown/Friday правилата важат за нови entry-та.

Стартиране:  py -3.12 scripts/backtest_75.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent.parent
DATA_DIR = Path(r"C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\MQL5\Files")
CACHE = BASE / "data_cache"
TRADES_DIR = CACHE  # запис на сделките за инспекция

PAIRS = ["AUDUSD", "EURCHF", "EURNZD", "GBPUSD", "USDCAD"]  # детерминистичен ред

PIP = 1e-4            # всички двойки са 5-цифрени, non-JPY
POINT = 1e-5
SLIPPAGE = 0.3 * PIP  # 0.3 pip при entry
SWAP_PIPS_PER_NIGHT = 0.6

START_STATS = pd.Timestamp("2015-01-01")   # 2012-07..2014-12 = warm-up за индикатори
END_STATS = pd.Timestamp("2026-10-01")

# --- продуктови дефолти (фиксирани, НЕ оптимизирани) ---
SL_MULT = 1.5
TP_SL_RATIO = 3.0
TREND_MIN = 0.20
RSI_LONG = (32.0, 42.0)
RSI_SHORT = (58.0, 68.0)
SPREAD_ATR_MAX = 0.05
BE_TRIGGER_R = 1.8     # при +1.8R -> SL на entry + 0.10R
BE_LOCK_R = 0.10
TRAIL_TRIGGER_R = 2.5  # при close >= +2.5R -> trail SL = close - 1.2R
TRAIL_DIST_R = 1.2
COOLDOWN = pd.Timedelta(hours=24)
FRIDAY_CUT = pd.Timestamp("2000-01-01 20:00:00").time()  # 20:00 сървърно

EQUITY_EUR = 50.67
EURUSD_ASSUMED = 1.1700  # за превод на pip-стойност в EUR (външна двойка, липсва в данните)

# --- метаданни на двойките (5-цифрени non-JPY vs 3-цифрен JPY vs XAUUSD в USD) ---
PAIR_META = {
    "USDJPY": dict(pip=1e-2, point=1e-3),
    "XAUUSD": dict(pip=1.0, point=0.01),   # злато: печалба в USD; "pip"=1 USD, point=0.01 (спред колоната е в центове)
}
PIP_DEFAULT = 1e-4
POINT_DEFAULT = 1e-5


def pip_of(sym: str) -> float:
    return PAIR_META.get(sym, {}).get("pip", PIP_DEFAULT)


def point_of(sym: str) -> float:
    return PAIR_META.get(sym, {}).get("point", POINT_DEFAULT)


# --------------------------------------------------------------------------
# Данни и индикатори
# --------------------------------------------------------------------------
def load_csv(sym: str, tf: str) -> pd.DataFrame:
    """Зарежда CSV (или parquet кеш). Epoch-ът е времева ос на файла: naive UTC = стенен часовник на файла.
    Суровият CSV се търси първо в DATA_DIR, после в CACHE (EURUSD/USDJPY са качени там)."""
    cache = CACHE / f"{sym}_{tf}.parquet"
    if cache.exists():
        df = pd.read_parquet(cache)
    else:
        src = DATA_DIR / f"candle_history_{sym}_{tf}.csv"
        if not src.exists():
            src = CACHE / f"candle_history_{sym}_{tf}.csv"
        df = pd.read_csv(src)
        df["time"] = pd.to_datetime(df["time_server_epoch"], unit="s").astype("datetime64[ns]")
        df = df.drop(columns=["time_server_epoch"]).sort_values("time").reset_index(drop=True)
        df.to_parquet(cache, index=False)
    return df


def wilder(s: pd.Series, n: int) -> pd.Series:
    """Wilder smoothing (RMA) — както MT5 iATR/iRSI."""
    return s.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()


def add_d1(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ema50"] = out["close"].ewm(span=50, adjust=False).mean()
    out["ema200"] = out["close"].ewm(span=200, adjust=False).mean()
    prev = out["close"].shift(1)
    tr = pd.concat(
        [out["high"] - out["low"], (out["high"] - prev).abs(), (out["low"] - prev).abs()],
        axis=1,
    ).max(axis=1)
    out["atr14"] = wilder(tr, 14)
    out["trend"] = (out["ema50"] - out["ema200"]).abs() / out["atr14"]
    out["d1_close_time"] = out["time"] + pd.Timedelta(days=1)  # D1 барът затваря в start+24ч
    return out


def add_h4(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    delta = out["close"].diff()
    ag = wilder(delta.clip(lower=0.0), 14)
    al = wilder(-delta.clip(upper=0.0), 14)
    out["rsi14"] = 100.0 - 100.0 / (1.0 + ag / al)
    return out


def build_features(sym: str) -> pd.DataFrame:
    """D1 индикатори, прикачени към всеки H4 бар от ПОСЛЕДНИЯ НАПЪЛНО ЗАТВОРЕН D1 бар."""
    d1 = add_d1(load_csv(sym, "D1"))
    h4 = add_h4(load_csv(sym, "H4")).sort_values("time")
    d1f = d1[["d1_close_time", "ema50", "ema200", "atr14", "trend", "close"]].rename(
        columns={"close": "d1_close"}
    )
    h4 = pd.merge_asof(
        h4, d1f, left_on="time", right_on="d1_close_time",
        direction="backward", allow_exact_matches=True,
    )
    # spread: точки -> pips и price; <=0 или липсваща -> медиана на двойката
    sp = h4["spread"].astype(float)
    sp = sp.where(sp > 0)
    med_points = float(sp.median())
    n_filled = int(sp.isna().sum())
    sp = sp.fillna(med_points)
    h4["spread_pips"] = sp / 10.0          # spread колоната е в точки; 10 точки = 1 pip (5- и 3-цифрени)
    h4["spread_price"] = sp * point_of(sym)
    h4["sym"] = sym
    h4.attrs["spread_median_points"] = med_points
    h4.attrs["spread_filled_rows"] = n_filled
    return h4


# --------------------------------------------------------------------------
# Сигнал
# --------------------------------------------------------------------------
def check_signal(row) -> int | None:
    """+1 long, -1 short, None няма сигнал. Всички стойности от бара/затворен D1 — без lookahead."""
    atr = row.atr14
    if not np.isfinite(atr) or atr <= 0:
        return None
    if not (np.isfinite(row.rsi14) and np.isfinite(row.trend) and np.isfinite(row.ema200)):
        return None
    if row.trend < TREND_MIN:
        return None
    if row.spread_price / atr > SPREAD_ATR_MAX:
        return None
    if row.d1_close > row.ema200 and RSI_LONG[0] <= row.rsi14 <= RSI_LONG[1]:
        return 1
    if row.d1_close < row.ema200 and RSI_SHORT[0] <= row.rsi14 <= RSI_SHORT[1]:
        return -1
    return None


# --------------------------------------------------------------------------
# Симулация
# --------------------------------------------------------------------------
def open_position(row, direction: int, sl_mult: float, tp_ratio: float) -> dict:
    atr = float(row.atr14)
    pip = pip_of(row.sym)
    risk = sl_mult * atr
    slip = 0.3 * pip
    if direction == 1:  # BUY на ask = close + spread, + slippage
        entry = float(row.close) + float(row.spread_price) + slip
        sl = entry - risk
        tp = entry + risk * tp_ratio
    else:               # SELL на bid = close - spread, - slippage
        entry = float(row.close) - float(row.spread_price) - slip
        sl = entry + risk
        tp = entry - risk * tp_ratio
    return {
        "sym": row.sym, "dir": direction, "entry_time": row.time,
        "entry": entry, "sl": sl, "tp": tp, "sl0": sl, "risk_price": risk,
        "risk_pips": risk / pip, "atr": atr, "spread_pips": float(row.spread_pips),
        "pip": pip,
        "be_done": False, "sl_kind": "SL",
    }


def process_bar(pos: dict, row, variant: str, swap: bool) -> dict | None:
    """Обработва един H4 бар на позицията: първо изходи (intrabar), после мениджмънт (close)."""
    d = pos["dir"]
    sl, tp = pos["sl"], pos["tp"]
    if d == 1:
        hit_sl = row.low <= sl
        hit_tp = row.high >= tp
    else:
        hit_sl = row.high >= sl
        hit_tp = row.low <= tp
    if hit_sl and hit_tp:
        hit_tp = False  # консервативно: и двата в един бар -> SL
    if hit_sl or hit_tp:
        exit_price = sl if hit_sl else tp
        reason = pos["sl_kind"] if hit_sl else "TP"
        return close_trade(pos, row.time, exit_price, reason, swap)
    if variant == "B":
        r0 = pos["risk_price"]
        be_level = pos["entry"] + d * BE_TRIGGER_R * r0
        trg_level = pos["entry"] + d * TRAIL_TRIGGER_R * r0
        if d == 1:
            if (not pos["be_done"]) and row.close >= be_level:
                new_sl = pos["entry"] + d * BE_LOCK_R * r0
                if new_sl > pos["sl"]:
                    pos["sl"], pos["sl_kind"] = new_sl, "BE"
                pos["be_done"] = True
            if row.close >= trg_level:
                new_sl = row.close - d * TRAIL_DIST_R * r0
                if new_sl > pos["sl"]:
                    pos["sl"], pos["sl_kind"] = new_sl, "TRAIL"
        else:
            if (not pos["be_done"]) and row.close <= be_level:
                new_sl = pos["entry"] + d * BE_LOCK_R * r0
                if new_sl < pos["sl"]:
                    pos["sl"], pos["sl_kind"] = new_sl, "BE"
                pos["be_done"] = True
            if row.close <= trg_level:
                new_sl = row.close + TRAIL_DIST_R * r0  # trailing за short: SL = close + 1.2R
                if new_sl < pos["sl"]:
                    pos["sl"], pos["sl_kind"] = new_sl, "TRAIL"
    return None


def close_trade(pos: dict, exit_time, exit_price: float, reason: str, swap: bool) -> dict:
    d = pos["dir"]
    pip = pos.get("pip", PIP)
    gross_pips = d * (exit_price - pos["entry"]) / pip
    nights = (exit_time.normalize() - pos["entry_time"].normalize()).days
    swap_pn = pos.get("swap_pn", SWAP_PIPS_PER_NIGHT)
    swap_pips = nights * swap_pn if swap else 0.0
    pnl_pips = gross_pips - swap_pips
    r = pnl_pips / pos["risk_pips"]
    return {
        "sym": pos["sym"], "dir": "LONG" if d == 1 else "SHORT",
        "entry_time": pos["entry_time"], "exit_time": exit_time,
        "entry": pos["entry"], "sl0": pos["sl0"], "tp": pos["tp"],
        "exit": exit_price, "reason": reason,
        "atr": pos["atr"], "risk_pips": pos["risk_pips"],
        "spread_pips": pos["spread_pips"], "slip_pips": 0.3,
        "nights": nights, "swap_pips": swap_pips,
        "gross_pips": gross_pips, "pnl_pips": pnl_pips, "r": r,
    }


def run_sim(feat: dict[str, pd.DataFrame], symbols: list[str], *,
            sl_mult: float = SL_MULT, tp_ratio: float = TP_SL_RATIO,
            variant: str = "B", swap: bool = True,
            start: pd.Timestamp = START_STATS, end: pd.Timestamp = END_STATS,
            tag: str = "main") -> pd.DataFrame:
    """Единна хронологична лента от H4 барове на всички двойки; 1 позиция общо."""
    frames = [feat[s].dropna(subset=["atr14", "rsi14", "ema200", "trend"]) for s in symbols]
    df = pd.concat(frames, ignore_index=True)
    df = df[(df["time"] >= start)].sort_values(["time", "sym"]).reset_index(drop=True)

    pos, last_entry, trades = None, None, []
    for row in df.itertuples():
        t = row.time
        if t >= end and pos is None:
            break
        if pos is not None:
            if row.sym == pos["sym"]:
                tr = process_bar(pos, row, variant, swap)
                if tr is not None:
                    trades.append(tr)
                    pos = None
            continue
        if t >= end:
            break
        if last_entry is not None and (t - last_entry) < COOLDOWN:
            continue
        if t.weekday() == 4 and t.time() >= FRIDAY_CUT:
            continue
        sig = check_signal(row)
        if sig is None:
            continue
        pos = open_position(row, sig, sl_mult, tp_ratio)
        last_entry = t

    if pos is not None:  # отворена в края: затваряме на последния наличен close (маркираща)
        last = df[df["sym"] == pos["sym"]].iloc[-1]
        exit_price = float(last["close"]) if pos["dir"] == 1 else float(last["close"]) + float(last["spread_price"])
        tr = close_trade(pos, last["time"], exit_price, "EOD_MARK", swap)
        trades.append(tr)
    out = pd.DataFrame(trades)
    if len(out):
        out.attrs["tag"] = tag
        out.to_csv(TRADES_DIR / f"trades_{tag}.csv", index=False)
    return out


# --------------------------------------------------------------------------
# Метрики
# --------------------------------------------------------------------------
def max_dd_r(tr: pd.DataFrame) -> float:
    if len(tr) == 0:
        return 0.0
    eq = tr.sort_values("exit_time")["r"].cumsum()
    return float(-(eq - eq.cummax()).min())


def metrics(tr: pd.DataFrame) -> dict:
    if len(tr) == 0:
        return dict(n=0, wr=np.nan, pf=np.nan, exp_pips=np.nan, exp_r=np.nan,
                    maxdd_r=np.nan, tot_r=0.0, tot_pips=0.0)
    wins = tr[tr["pnl_pips"] > 0]
    losses = tr[tr["pnl_pips"] < 0]
    gp = wins["pnl_pips"].sum()
    gl = abs(losses["pnl_pips"].sum())
    pf = gp / gl if gl > 0 else np.inf
    eq = tr.sort_values("exit_time")["r"].cumsum()
    return dict(
        n=len(tr), wr=len(wins) / len(tr), pf=pf,
        exp_pips=float(tr["pnl_pips"].mean()), exp_r=float(tr["r"].mean()),
        maxdd_r=float(-(eq - eq.cummax()).min()),
        tot_r=float(tr["r"].sum()), tot_pips=float(tr["pnl_pips"].sum()),
        gp=float(gp), gl=float(gl),
    )


def yearly(tr: pd.DataFrame) -> pd.DataFrame:
    if len(tr) == 0:
        return pd.DataFrame()
    t = tr.copy()
    t["year"] = t["exit_time"].dt.year
    rows = []
    for y, g in t.groupby("year"):
        m = metrics(g)
        rows.append(dict(year=y, n=m["n"], wr=m["wr"], pf=m["pf"],
                         exp_r=m["exp_r"], tot_r=m["tot_r"]))
    return pd.DataFrame(rows)


def fmt_m(m: dict) -> str:
    if m["n"] == 0:
        return "n=0"
    return (f"n={m['n']:>3}  WR={m['wr']*100:5.1f}%  PF={m['pf']:5.2f}  "
            f"exp={m['exp_pips']:6.2f}p/{m['exp_r']:+.3f}R  maxDD={m['maxdd_r']:6.2f}R  "
            f"tot={m['tot_r']:+.1f}R")


# --------------------------------------------------------------------------
# Риск от разорение (Monte Carlo)
# --------------------------------------------------------------------------
def risk_of_ruin(r_vals: np.ndarray, risk_frac: float, horizon: int = 60,
                 ruin: float = -0.40, n_paths: int = 100_000, seed: int = 7) -> dict:
    """Всяка сделка печели/губи risk_frac * R от СТАРТОВИЯ капитал (fixed stake, без компаунд).
    Разорение = equity <= 1+ruin по всяко време в хоризонта."""
    rng = np.random.default_rng(seed)
    if len(r_vals) == 0:
        return dict(ruin=np.nan, med_maxdd=np.nan)
    idx = rng.integers(0, len(r_vals), size=(n_paths, horizon))
    pnl = r_vals[idx] * risk_frac
    eq = 1.0 + np.cumsum(pnl, axis=1)
    trough = np.minimum.accumulate(eq, axis=1)
    hit = trough <= (1.0 + ruin)
    ruin_prob = float(hit.any(axis=1).mean())
    dd = 1.0 - trough[:, -1]  # грубо; точният maxDD по пътя:
    running_peak = np.maximum.accumulate(eq, axis=1)
    maxdd = (running_peak - eq).max(axis=1)
    return dict(ruin=ruin_prob, med_maxdd=float(np.median(maxdd)))


# --------------------------------------------------------------------------
# Главна програма
# --------------------------------------------------------------------------
def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # Windows конзола: кирилица
    except Exception:
        pass
    print("=" * 100)
    print("BACKTEST ADMIRAL 7.5 — суинг стратегия, 5 двойки, 2015-01 .. 2026-09 (warm-up 2012-2014)")
    print(f"pandas {pd.__version__} / numpy {np.__version__}")
    print("=" * 100)

    feat = {}
    for s in PAIRS:
        feat[s] = build_features(s)
        f = feat[s]
        print(f"[data] {s}: H4={len(f)} rows, spread med={f.attrs['spread_median_points']:.0f}pt "
              f"({f.attrs['spread_median_points']/10:.1f} pips), попълнени spread<=0 редове: {f.attrs['spread_filled_rows']}")
        # проверка: няма lookahead — atr14 на H4 реда трябва да е от D1 бар, затворен преди t
        ok = f["d1_close_time"].notna()
        assert (f.loc[ok, "d1_close_time"] <= f.loc[ok, "time"]).all(), "lookahead в merge_asof!"

    # ---- основни рънове: вариант A/B x swap on/off ----
    runs = {}
    for variant in ("A", "B"):
        for swap in (True, False):
            key = f"{variant}{'_swap' if swap else '_noswap'}"
            runs[key] = run_sim(feat, PAIRS, variant=variant, swap=swap, tag=key)
    main_trades = runs["B_swap"]

    print("\n" + "=" * 100)
    print("ОСНОВНИ РЕЗУЛТАТИ — Вариант B (BE 1.8R + trail 1.2R от 2.5R), със суап, 2015-2026")
    print("=" * 100)
    for s in PAIRS:
        m = metrics(main_trades[main_trades["sym"] == s])
        print(f"{s:8s}  {fmt_m(m)}")
    m_all = metrics(main_trades)
    print(f"{'TOTAL':8s}  {fmt_m(m_all)}")

    print("\nВариант A (чист SL/TP), със суап:")
    for s in PAIRS:
        m = metrics(runs["A_swap"][runs["A_swap"]["sym"] == s])
        print(f"{s:8s}  {fmt_m(m)}")
    print(f"{'TOTAL':8s}  {fmt_m(metrics(runs['A_swap']))}")

    print("\nВариант B, БЕЗ суап (ефект на суапа):")
    for s in PAIRS:
        m = metrics(runs["B_noswap"][runs["B_noswap"]["sym"] == s])
        print(f"{s:8s}  {fmt_m(m)}")
    print(f"{'TOTAL':8s}  {fmt_m(metrics(runs['B_noswap']))}")

    # ---- sanity: първите 3 сделки на двойка ----
    print("\n" + "=" * 100)
    print("SANITY CHECK — първите 3 сделки на двойка (B, със суап)")
    print("=" * 100)
    for s in PAIRS:
        cols = ["entry_time", "dir", "entry", "sl0", "tp", "exit", "reason",
                "spread_pips", "slip_pips", "nights", "swap_pips", "pnl_pips", "r"]
        print(f"\n--- {s} ---")
        print(main_trades[main_trades["sym"] == s][cols].head(3).to_string(index=False))

    # ---- годишна разбивка ----
    print("\n" + "=" * 100)
    print("ГОДИШНА РАЗБИВКА (Вариант B, със суап)")
    print("=" * 100)
    for s in PAIRS + ["TOTAL"]:
        t = main_trades if s == "TOTAL" else main_trades[main_trades["sym"] == s]
        y = yearly(t)
        print(f"\n--- {s} ---")
        if len(y):
            print(y.to_string(index=False, float_format=lambda v: f"{v:6.2f}"))

    # ---- причини за изход ----
    print("\n--- Причини за изход (B, swap) ---")
    print(main_trades.groupby(["sym", "reason"]).size().unstack(fill_value=0).to_string())

    # ---- чувствителност: 2-те най-добри двойки ----
    exp = {s: metrics(main_trades[main_trades["sym"] == s]) for s in PAIRS}
    best2 = sorted([s for s in PAIRS if exp[s]["n"] >= 30],
                   key=lambda s: exp[s]["exp_r"], reverse=True)[:2]
    print(f"\n{'=' * 100}\nЧУВСТВИТЕЛНОСТ — двойки {best2} (standalone симулация със същия 1-слот двигател)\n{'=' * 100}")
    print("SL mult x TP/SL ratio -> per-pair n / WR / PF / expR")
    sens_rows = {}
    for slm in (1.2, 1.5, 2.0):
        for tpr in (2.0, 3.0):
            key = (slm, tpr)
            tr = run_sim(feat, best2, sl_mult=slm, tp_ratio=tpr, variant="B", swap=True,
                         tag=f"sens_{slm}_{tpr}")
            sens_rows[key] = tr
            cells = []
            for s in best2:
                m = metrics(tr[tr["sym"] == s])
                cells.append(f"{s}: n={m['n']:>3} WR={m['wr']*100 if m['n'] else float('nan'):5.1f}% "
                             f"PF={m['pf'] if m['n'] else float('nan'):5.2f} expR={m['exp_r'] if m['n'] else float('nan'):+.3f}")
            print(f"SL={slm:3.1f} TP/SL={tpr:3.1f}  |  " + "  |  ".join(cells))

    # ---- таблица 50 EUR ----
    print(f"\n{'=' * 100}")
    print(f"50 EUR СМЕТКА — min-lot (0.01) SL загуба спрямо {EQUITY_EUR} EUR")
    print(f"(ATR14(D1) = средно за последните 90 дни; EURUSD приет = {EURUSD_ASSUMED}; "
          f"pip стойност за 0.01 лота = 0.10 валута на котировката)")
    print("=" * 100)
    last_prices = {s: float(feat[s]["close"].iloc[-1]) for s in PAIRS}
    table50 = []
    for s in PAIRS:
        d1 = add_d1(load_csv(s, "D1"))
        t90 = d1["time"].iloc[-1] - pd.Timedelta(days=90)
        atr_now = float(d1.loc[d1["time"] >= t90, "atr14"].dropna().mean())
        sl_pips = SL_MULT * atr_now / PIP
        # pip стойност в EUR
        if s in ("GBPUSD", "AUDUSD"):
            pip_eur = 0.10 / EURUSD_ASSUMED
        elif s == "USDCAD":
            pip_eur = 0.10 / last_prices["USDCAD"] / EURUSD_ASSUMED
        elif s == "EURNZD":
            pip_eur = 0.10 / last_prices["EURNZD"]
        else:  # EURCHF
            pip_eur = 0.10 / last_prices["EURCHF"]
        loss_eur = sl_pips * pip_eur
        pct = loss_eur / EQUITY_EUR * 100
        need_risk = pct  # risk% за да мине volume check при 0.01 лота
        table50.append(dict(sym=s, atr_now_pips=atr_now / PIP, sl_pips=sl_pips,
                            pip_eur=pip_eur, loss_eur=loss_eur, pct=pct,
                            need_risk=need_risk))
        flag = "  <-- НЕТЪРГУЕМА (>5%)" if need_risk > 5 else ""
        print(f"{s:8s} ATR={atr_now/PIP:6.1f}p  SL(1.5x)={sl_pips:6.1f}p  "
              f"loss={loss_eur:6.2f} EUR  = {pct:5.1f}% от сметката  risk%>={need_risk:4.1f}%{flag}")
    pd.DataFrame(table50).to_csv(CACHE / "table50.csv", index=False)

    # ---- риск от разорение ----
    print(f"\n{'=' * 100}")
    print("РИСК ОТ РАЗОРЕНИЕ — Monte Carlo (100k пъти x 60 сделки, bootstrap на реалните R)")
    print("Метод: всяка сделка = +/- risk_frac * R от стартовия капитал; разорение = спад >= -40% по всяко време.")
    print("=" * 100)
    # инструктираното r=4.9%
    for label, rfrac in [("r = 4.9% (зададен)", 0.049)]:
        res = risk_of_ruin(main_trades["r"].to_numpy(), rfrac)
        print(f"{label}: P(-40% в 60 сделки) = {res['ruin']*100:6.2f}%   (медианен maxDD={res['med_maxdd']*100:.1f}%)")
    # и с реалния min-lot риск на всяка двойка
    print("Реален min-lot риск на двойка (от таблицата по-горе):")
    for row50, s in zip(table50, PAIRS):
        rv = main_trades[main_trades["sym"] == s]["r"].to_numpy()
        if len(rv) < 10:
            continue
        res = risk_of_ruin(rv, row50["pct"] / 100)
        print(f"{s:8s} риск/сделка={row50['pct']:5.1f}%  ->  P(-40% в 60) = {res['ruin']*100:6.2f}%   "
              f"(медианен maxDD={res['med_maxdd']*100:.1f}%)")

    # ---- експорт на обобщение за репорта ----
    summary = dict(
        main={s: metrics(main_trades[main_trades["sym"] == s]) for s in PAIRS},
        main_total=metrics(main_trades),
        A_swap_total=metrics(runs["A_swap"]), B_noswap_total=metrics(runs["B_noswap"]),
        A_swap={s: metrics(runs["A_swap"][runs["A_swap"]["sym"] == s]) for s in PAIRS},
        B_noswap={s: metrics(runs["B_noswap"][runs["B_noswap"]["sym"] == s]) for s in PAIRS},
        yearly={s: yearly(main_trades[main_trades["sym"] == s]).to_dict("records") for s in PAIRS},
        yearly_total=yearly(main_trades).to_dict("records"),
        reasons=main_trades.groupby(["sym", "reason"]).size().unstack(fill_value=0).to_dict(),
        exit_mix={s: metrics(main_trades[(main_trades["sym"] == s) & (main_trades["reason"] == "TP")])["n"]
                  for s in PAIRS},
        best2=best2,
        sens={f"{k[0]}_{k[1]}": {s: metrics(sens_rows[k][sens_rows[k]["sym"] == s]) for s in best2}
              for k in sens_rows},
        table50=table50,
    )
    import json
    with open(CACHE / "summary.json", "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=1, default=float)
    print(f"\n[ok] summary.json и trades_*.csv записани в {CACHE}")


# ==========================================================================
# TIGHT-SL ВАРИАНТ + СКРИНОВЕ S2 (Donchian) / S3 (Range-revert)
# Бриф: followup_brief_tight.md. Честота е първокласна метрика (цел 12-20 сделки/месец).
# ==========================================================================
TIGHT_BANDS = {"F1": ((32.0, 42.0), (58.0, 68.0)),   # строга лента
               "F2": ((30.0, 45.0), (55.0, 70.0))}   # разширена за честота
SL_MIN_PIPS, SL_MAX_PIPS = 18.0, 30.0
TIGHT_COOLDOWN = pd.Timedelta(hours=12)   # след ИЗЛИЗАНЕ от позиция (не след entry)
TP_SL_RATIO_TIGHT = 2.0
BALANCE_EUR = 150.67          # баланс за риск-математика
RISK_LIVE = 0.017             # риск/сделка live (1.7%)
RISK_ALT = 0.045              # сравнение (4.5%)
OOS_START = pd.Timestamp("2025-01-01")   # out-of-sample прозорец
IS22_START = pd.Timestamp("2022-01-01")  # in-sample 2022-2024 по брифа


def add_h4_tight(df: pd.DataFrame) -> pd.DataFrame:
    """RSI14 + ATR14(H4) + ADX14(H4) + Donchian(20, предишни бара) + Bollinger(20, 2σ) — само затворени барове."""
    out = add_h4(df)  # rsi14
    prev = out["close"].shift(1)
    tr = pd.concat(
        [out["high"] - out["low"], (out["high"] - prev).abs(), (out["low"] - prev).abs()],
        axis=1,
    ).max(axis=1)
    out["atr14_h4"] = wilder(tr, 14)
    up = out["high"].diff()
    dn = out["low"].diff()
    plus_dm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=out.index)
    minus_dm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=out.index)
    plus_di = 100.0 * wilder(plus_dm, 14) / out["atr14_h4"]
    minus_di = 100.0 * wilder(minus_dm, 14) / out["atr14_h4"]
    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    out["adx14"] = wilder(dx, 14)
    out["dc_up"] = out["high"].rolling(20).max().shift(1)   # Donchian от предишните 20 бара
    out["dc_dn"] = out["low"].rolling(20).min().shift(1)
    mid = out["close"].rolling(20).mean()
    sd = out["close"].rolling(20).std(ddof=0)
    out["bb_mid"], out["bb_up"], out["bb_dn"] = mid, mid + 2.0 * sd, mid - 2.0 * sd
    return out


def build_features_tight(sym: str) -> pd.DataFrame:
    """Както build_features, но с H4 индикаторния набор и per-pair pip/point."""
    d1 = add_d1(load_csv(sym, "D1"))
    h4 = add_h4_tight(load_csv(sym, "H4")).sort_values("time")
    d1f = d1[["d1_close_time", "ema50", "ema200", "atr14", "trend", "close"]].rename(
        columns={"close": "d1_close"}
    )
    h4 = pd.merge_asof(
        h4, d1f, left_on="time", right_on="d1_close_time",
        direction="backward", allow_exact_matches=True,
    )
    sp = h4["spread"].astype(float)
    sp = sp.where(sp > 0)
    sp = sp.fillna(float(sp.median()))
    h4["spread_pips"] = sp / 10.0
    h4["spread_price"] = sp * point_of(sym)
    h4["sym"] = sym
    return h4


# --- сигнали ----------------------------------------------------------------
def _base_guard(row) -> bool:
    """ATR(D1) валиден + spread филтър (ask-bid)/ATR14(D1) <= 0.05."""
    if not np.isfinite(row.atr14) or row.atr14 <= 0:
        return False
    return row.spread_price / row.atr14 <= SPREAD_ATR_MAX


def tight_signal(row, band: str):
    """Tight swing: посока от ЗНАКА на gap=EMA50-EMA200(D1); цената от правилната
    страна на EMA200; trend |gap|/ATR(D1)>=0.20; RSI14(H4) в лента.
    Връща (dir, tp_override=None) или None."""
    if not _base_guard(row):
        return None
    if not (np.isfinite(row.rsi14) and np.isfinite(row.ema50) and np.isfinite(row.ema200)):
        return None
    gap = row.ema50 - row.ema200
    if abs(gap) / row.atr14 < TREND_MIN:
        return None
    lo, hi = TIGHT_BANDS[band]
    if gap > 0 and row.close > row.ema200 and lo[0] <= row.rsi14 <= lo[1]:
        return 1, None
    if gap < 0 and row.close < row.ema200 and hi[0] <= row.rsi14 <= hi[1]:
        return -1, None
    return None


def s2_signal(row):
    """Donchian breakout: D1 bias close vs EMA200; затваряне над/под Donchian(20,H4); ADX>=20."""
    if not _base_guard(row):
        return None
    if not (np.isfinite(row.adx14) and np.isfinite(row.dc_up) and np.isfinite(row.ema200)):
        return None
    if row.adx14 < 20.0:
        return None
    if row.d1_close > row.ema200 and row.close > row.dc_up:
        return 1, None
    if row.d1_close < row.ema200 and row.close < row.dc_dn:
        return -1, None
    return None


def s3_signal(row):
    """Range-revert: само при ADX<20; затваряне извън Bollinger(20,2σ) към средната лента (TP=mid)."""
    if not _base_guard(row):
        return None
    if not (np.isfinite(row.adx14) and np.isfinite(row.bb_up) and np.isfinite(row.ema200)):
        return None
    if row.adx14 >= 20.0:
        return None
    if row.close < row.bb_dn and row.bb_mid > row.close:
        return 1, row.bb_mid
    if row.close > row.bb_up and row.bb_mid < row.close:
        return -1, row.bb_mid
    return None


# --- двигател ----------------------------------------------------------------
def open_position_tight(row, direction: int, sl_pips: float, tp_override):
    pip = pip_of(row.sym)
    risk = sl_pips * pip
    slip = 0.3 * pip
    if direction == 1:
        entry = float(row.close) + float(row.spread_price) + slip
        sl = entry - risk
        tp = float(tp_override) if tp_override else entry + TP_SL_RATIO_TIGHT * risk
    else:
        entry = float(row.close) - float(row.spread_price) - slip
        sl = entry + risk
        tp = float(tp_override) if tp_override else entry - TP_SL_RATIO_TIGHT * risk
    return {
        "sym": row.sym, "dir": direction, "entry_time": row.time,
        "entry": entry, "sl": sl, "tp": tp, "sl0": sl, "risk_price": risk,
        "risk_pips": sl_pips, "atr": float(row.atr14), "spread_pips": float(row.spread_pips),
        "pip": pip,
    }


def run_tight_sim(feat: dict[str, pd.DataFrame], symbols: list[str], signal_fn, *,
                  sl_mult: float = 1.0, swap: bool = True,
                  sl_min_pips: float = SL_MIN_PIPS, sl_max_pips: float = SL_MAX_PIPS,
                  swap_pn: float = SWAP_PIPS_PER_NIGHT,
                  start: pd.Timestamp = START_STATS, end: pd.Timestamp = END_STATS,
                  tag: str = "tight") -> pd.DataFrame:
    """1 позиция общо; преоценка на всяко H4 затваряне; cooldown 12ч СЛЕД ИЗЛИЗАНЕ;
    без BE/trailing; SL=clamp(sl_mult*ATR14(H4),sl_min,sl_max) в единици на двойката; TP=2xSL (или override)."""
    frames = [feat[s].dropna(subset=["atr14", "rsi14", "ema200", "ema50", "atr14_h4"]) for s in symbols]
    df = pd.concat(frames, ignore_index=True)
    df = df[df["time"] >= start].sort_values(["time", "sym"]).reset_index(drop=True)

    pos, last_exit, trades = None, None, []
    for row in df.itertuples():
        t = row.time
        if t >= end and pos is None:
            break
        if pos is not None:
            if row.sym == pos["sym"]:
                d = pos["dir"]
                sl, tp = pos["sl"], pos["tp"]
                hit_sl = row.low <= sl if d == 1 else row.high >= sl
                hit_tp = row.high >= tp if d == 1 else row.low <= tp
                if hit_sl and hit_tp:
                    hit_tp = False  # консервативно: и двата в един бар -> SL
                if hit_sl or hit_tp:
                    trades.append(close_trade(pos, t, sl if hit_sl else tp,
                                              "SL" if hit_sl else "TP", swap))
                    pos = None
                    last_exit = t
            continue
        if t >= end:
            break
        if last_exit is not None and (t - last_exit) < TIGHT_COOLDOWN:
            continue
        if t.weekday() == 4 and t.time() >= FRIDAY_CUT:
            continue
        sig = signal_fn(row)
        if sig is None:
            continue
        direction, tp_override = sig
        atr_pips = float(row.atr14_h4) / pip_of(row.sym)
        sl_pips = float(np.clip(sl_mult * atr_pips, sl_min_pips, sl_max_pips))
        pos = open_position_tight(row, direction, sl_pips, tp_override)
        pos["swap_pn"] = swap_pn
    if pos is not None:  # отворена в края: маркиращо затваряне на последния close
        last = df[df["sym"] == pos["sym"]].iloc[-1]
        exit_price = float(last["close"]) if pos["dir"] == 1 else float(last["close"]) + float(last["spread_price"])
        trades.append(close_trade(pos, last["time"], exit_price, "EOD_MARK", swap))
    out = pd.DataFrame(trades)
    if len(out):
        out.to_csv(TRADES_DIR / f"trades_{tag}.csv", index=False)
    return out


# --- метрики за трите стратегии ----------------------------------------------
def max_consec_losses(tr: pd.DataFrame) -> int:
    if len(tr) == 0:
        return 0
    lose = (tr.sort_values("exit_time")["r"] < 0).astype(int)
    best = cur = 0
    for v in lose:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best


def pf_of(tr: pd.DataFrame) -> float:
    if len(tr) == 0:
        return np.nan
    gp = tr.loc[tr["pnl_pips"] > 0, "pnl_pips"].sum()
    gl = abs(tr.loc[tr["pnl_pips"] < 0, "pnl_pips"].sum())
    return float(gp / gl) if gl > 0 else np.inf


def strat_metrics(tr: pd.DataFrame, pip_eur_map: dict[str, float] | None = None) -> dict:
    """Подредени по важност: сделки/месец, PF OOS, PF IS, expR, поредни загуби, RoR."""
    if len(tr) == 0:
        return dict(n=0, trades_month=0.0)
    tr = tr.sort_values("exit_time")
    span_days = max((tr["exit_time"].max() - tr["entry_time"].min()).days, 1)
    m = metrics(tr)
    is_all = tr[tr["exit_time"] < OOS_START]
    is22 = tr[(tr["exit_time"] >= IS22_START) & (tr["exit_time"] < OOS_START)]
    oos = tr[tr["exit_time"] >= OOS_START]
    r_vals = tr["r"].to_numpy()
    ror_live = risk_of_ruin(r_vals, RISK_LIVE, horizon=60, ruin=-0.20, n_paths=5000)
    ror_alt = risk_of_ruin(r_vals, RISK_ALT, horizon=60, ruin=-0.20, n_paths=5000)
    out = dict(
        n=len(tr), trades_month=len(tr) / (span_days / 30.44),
        wr=m["wr"], pf=m["pf"], exp_pips=m["exp_pips"], exp_r=m["exp_r"],
        maxdd_r=m["maxdd_r"], tot_r=m["tot_r"],
        pf_is=pf_of(is_all), pf_is22=pf_of(is22), pf_oos=pf_of(oos),
        n_is=len(is_all), n_oos=len(oos),
        exp_oos_r=float(oos["r"].mean()) if len(oos) else np.nan,
        max_consec=max_consec_losses(tr),
        ror17=ror_live["ruin"], ror45=ror_alt["ruin"],
        ror17_dd=ror_live["med_maxdd"],
    )
    if pip_eur_map:  # expectancy в EUR при 0.01 лот
        out["exp_eur"] = float(np.mean([p * pip_eur_map[s] for s, p in zip(tr["sym"], tr["pnl_pips"])]))
    return out


def pip_eur_map_for(symbols: list[str], last_prices: dict[str, float]) -> dict[str, float]:
    """Pip стойност в EUR за 0.01 лот."""
    out = {}
    for s in symbols:
        if s in ("EURUSD", "GBPUSD", "AUDUSD"):
            out[s] = 0.10 / EURUSD_ASSUMED
        elif s == "USDJPY":
            out[s] = 10.0 / last_prices["USDJPY"] / EURUSD_ASSUMED
        elif s == "USDCAD":
            out[s] = 0.10 / last_prices["USDCAD"] / EURUSD_ASSUMED
        elif s == "EURNZD":
            out[s] = 0.10 / last_prices["EURNZD"]
        elif s == "XAUUSD":
            out[s] = 1.0 / EURUSD_ASSUMED   # 1 "pip" = 1 USD за 1 oz (0.01 лот)
        else:  # EURCHF
            out[s] = 0.10 / last_prices["EURCHF"]
    return out


def fmt_strat(name: str, m: dict) -> str:
    if m.get("n", 0) == 0:
        return f"{name}: n=0"
    return (f"{name}: {m['trades_month']:5.1f} сд/мес | n={m['n']} | WR={m['wr']*100:4.1f}% | "
            f"PF {m['pf']:.2f} (IS22-24 {m['pf_is22']:.2f} / OOS {m['pf_oos']:.2f}) | "
            f"exp {m['exp_pips']:+.2f}p/{m['exp_r']:+.3f}R ({m.get('exp_eur', float('nan')):+.3f}€) | "
            f"maxDD {m['maxdd_r']:.1f}R | поредни загуби {m['max_consec']} | "
            f"RoR@1.7% {m['ror17']*100:4.1f}% @4.5% {m['ror45']*100:4.1f}%")


def _yearly_2326(tr: pd.DataFrame) -> str:
    rows = []
    for y in (2023, 2024, 2025, 2026):
        g = tr[tr["exit_time"].dt.year == y]
        rows.append(f"{y}: n={len(g):>3} PF={pf_of(g):5.2f} expR={g['r'].mean() if len(g) else float('nan'):+.2f}")
    return "  ".join(rows)


def _print_yearly_pairs(tr: pd.DataFrame, symbols: list[str], title: str) -> None:
    print(f"\n--- Годишна разбивка 2023–2026: {title} ---")
    for s in symbols:
        print(f"{s:8s} {_yearly_2326(tr[tr['sym'] == s])}")
    print(f"{'TOTAL':8s} {_yearly_2326(tr)}")


def _load_tight_feats(symbols) -> dict:
    feat = {}
    for s in symbols:
        feat[s] = build_features_tight(s)
        f = feat[s]
        print(f"[data] {s}: H4={len(f)} rows, spread med={f['spread_pips'].median():.1f}p "
              f"(последен close={f['close'].iloc[-1]})")
        ok = f["d1_close_time"].notna()
        assert (f.loc[ok, "d1_close_time"] <= f.loc[ok, "time"]).all(), "lookahead!"
    return feat


# --- main-ове ----------------------------------------------------------------
def main_tight() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("TIGHT-SL ВАРИАНТ — RSI лента върху D1 bias от знака на EMA50-EMA200; SL=clamp(1.0xATR(H4),18,30)p; "
          "TP=2xSL; без BE/trailing; cooldown 12ч след изход")
    print("=" * 100)
    core = ["EURUSD", "GBPUSD"]
    feat = _load_tight_feats(core + ["USDJPY"])
    last_prices = {s: float(feat[s]["close"].iloc[-1]) for s in feat}
    peur = pip_eur_map_for(list(feat), last_prices)

    runs: dict[str, pd.DataFrame] = {}
    print("\n== Основни рънове ==")
    for band in ("F1", "F2"):
        for syms, label in ((core, "EURUSD+GBPUSD"), (core + ["USDJPY"], "EURUSD+GBPUSD+USDJPY")):
            tag = f"tight_{band}_{'2p' if len(syms) == 2 else '3p'}"
            tr = run_tight_sim(feat, syms, lambda r, b=band: tight_signal(r, b), tag=tag)
            runs[tag] = tr
            m = strat_metrics(tr, peur)
            print(fmt_strat(f"{band} {label}", m))
            if len(syms) == 2:
                for s in syms:
                    print("   " + fmt_strat(s, strat_metrics(tr[tr["sym"] == s], peur)))

    # sanity: първи 3 сделки на основния рън
    main_tag = "tight_F2_2p"
    cols = ["sym", "entry_time", "dir", "entry", "sl0", "tp", "exit_time", "exit", "reason",
            "risk_pips", "spread_pips", "nights", "swap_pips", "pnl_pips", "r"]
    print(f"\nSANITY първи 3 сделки ({main_tag}):")
    print(runs[main_tag][cols].head(3).to_string(index=False))

    print("\n== Чувствителност (само tight): SL {0.8,1.0,1.2}xATR(H4) x лента {F1,F2}; EURUSD+GBPUSD ==")
    for band in ("F1", "F2"):
        for slm in (0.8, 1.0, 1.2):
            tag = f"tight_sens_{band}_{slm}"
            tr = run_tight_sim(feat, core, lambda r, b=band: tight_signal(r, b),
                               sl_mult=slm, tag=tag)
            m = strat_metrics(tr, peur)
            print(fmt_strat(f"{band} SL={slm}", m))

    _print_yearly_pairs(runs[main_tag], core, f"{main_tag} (референтен)")
    _print_yearly_pairs(runs["tight_F1_2p"], core, "tight_F1_2p")

    # баланс/риск математика: min-lot риск в EUR при clamp 18-30p
    print("\n== Риск математика @ 150.67 EUR, 0.01 лот ==")
    for s in core + ["USDJPY"]:
        sl_lo, sl_hi = SL_MIN_PIPS * peur[s], SL_MAX_PIPS * peur[s]
        print(f"{s:8s} SL 18-30p -> {sl_lo:.2f}–{sl_hi:.2f} EUR = {sl_lo/BALANCE_EUR*100:.1f}%–{sl_hi/BALANCE_EUR*100:.1f}% от баланса")

    import json
    dump = {tag: strat_metrics(tr, peur) for tag, tr in runs.items()}
    with open(CACHE / "summary_tight.json", "w", encoding="utf-8") as fh:
        json.dump(dump, fh, ensure_ascii=False, indent=1, default=float)
    print(f"\n[ok] summary_tight.json в {CACHE}")


def main_s2() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("S2 СКРИН — Donchian(20,H4) breakout, D1 bias close vs EMA200, ADX>=20, SL=clamp(1.0xATR(H4),18,30)p, TP=2xSL")
    print("=" * 100)
    core = ["EURUSD", "GBPUSD"]
    feat = _load_tight_feats(core)
    last_prices = {s: float(feat[s]["close"].iloc[-1]) for s in feat}
    peur = pip_eur_map_for(core, last_prices)
    tr = run_tight_sim(feat, core, s2_signal, tag="s2")
    print(fmt_strat("S2 TOTAL", strat_metrics(tr, peur)))
    for s in core:
        print("   " + fmt_strat(s, strat_metrics(tr[tr["sym"] == s], peur)))
    _print_yearly_pairs(tr, core, "S2")
    import json
    with open(CACHE / "summary_s2.json", "w", encoding="utf-8") as fh:
        json.dump({"S2": strat_metrics(tr, peur),
                   **{s: strat_metrics(tr[tr["sym"] == s], peur) for s in core}},
                  fh, ensure_ascii=False, indent=1, default=float)
    cols = ["sym", "entry_time", "dir", "entry", "sl0", "tp", "exit_time", "exit", "reason", "pnl_pips", "r"]
    print("\nSANITY първи 3 сделки (S2):")
    print(tr[cols].head(3).to_string(index=False))


def main_s3() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("S3 СКРИН — Range-revert: ADX<20, вход извън Bollinger(20,2σ,H4), TP=средна лента, SL=clamp(1.0xATR(H4),18,30)p")
    print("=" * 100)
    core = ["EURUSD", "GBPUSD"]
    feat = _load_tight_feats(core)
    last_prices = {s: float(feat[s]["close"].iloc[-1]) for s in feat}
    peur = pip_eur_map_for(core, last_prices)
    tr = run_tight_sim(feat, core, s3_signal, tag="s3")
    print(fmt_strat("S3 TOTAL", strat_metrics(tr, peur)))
    for s in core:
        print("   " + fmt_strat(s, strat_metrics(tr[tr["sym"] == s], peur)))
    _print_yearly_pairs(tr, core, "S3")
    import json
    with open(CACHE / "summary_s3.json", "w", encoding="utf-8") as fh:
        json.dump({"S3": strat_metrics(tr, peur),
                   **{s: strat_metrics(tr[tr["sym"] == s], peur) for s in core}},
                  fh, ensure_ascii=False, indent=1, default=float)
    cols = ["sym", "entry_time", "dir", "entry", "sl0", "tp", "exit_time", "exit", "reason", "pnl_pips", "r"]
    print("\nSANITY първи 3 сделки (S3):")
    print(tr[cols].head(3).to_string(index=False))


# ==========================================================================
# S4 — London Open Breakout (H1), S5 — RSI-2 дневна реверсия (D1), S6 — XAUUSD H4
# ==========================================================================
S4_ASIAN_LAST = 6        # Asian прозорец: барове 00:00..06:00 (покрива 00:00-07:00)
S4_WIN_FIRST, S4_WIN_LAST = 7, 9   # пробивен прозорец 07:00-10:00 (барове 07,08,09)
S4_EXIT_HOUR = 17        # time-exit 17:00 сървърно
S4_SL_MIN, S4_SL_MAX = 12.0, 30.0
S5_EXIT_RSI_LONG, S5_EXIT_RSI_SHORT = 55.0, 45.0
S5_MAX_DAYS = 7
S5_SL_MULT, S5_SL_MIN, S5_SL_MAX = 0.75, 40.0, 80.0
XAU_SWAP_PN = 0.015      # $0.015/oz/нощ (1.5 цента) — златен суап по спека


def build_features_s4(sym: str) -> pd.DataFrame:
    """H1 + SMA50(H1) + ATR14(D1) ресемплиран от H1 (същата времева ос)."""
    h1 = load_csv(sym, "H1")
    d1 = (
        h1.set_index("time")
        .resample("1D")
        .agg(open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last"))
        .dropna(how="any")
        .reset_index()
    )
    d1 = add_d1(d1)
    h1 = h1.copy()
    h1["sma50"] = h1["close"].rolling(50, min_periods=50).mean()
    sp = h1["spread"].astype(float)
    sp = sp.where(sp > 0).fillna(float(sp.median()))
    h1["spread_pips"] = sp / 10.0
    h1["spread_price"] = sp * point_of(sym)
    h1 = pd.merge_asof(
        h1.sort_values("time"), d1[["d1_close_time", "atr14"]],
        left_on="time", right_on="d1_close_time", direction="backward", allow_exact_matches=True,
    )
    h1["sym"] = sym
    return h1


def run_s4(feat: dict[str, pd.DataFrame], symbols: list[str], *, tag: str = "s4") -> pd.DataFrame:
    """Asian range 00-07; пробив на close в 07-10 прозореца с SMA50 филтър; SL=clamp(1xrange,12,30)p;
    TP=2xrange; time-exit 17:00; 1 сделка/ден/двойка; max 1 позиция общо; без суап (интрадей).
    Вход на close на първия H1 бар в прозореца с пробив (H1-close апроксимация)."""
    days = {}
    ranges = {}
    for s in symbols:
        f = feat[s]
        f = f.assign(date=f["time"].dt.normalize())
        by_day = dict(tuple(f.groupby("date")))
        days[s] = by_day
        rng = {}
        for date, day in by_day.items():
            asian = day[day["time"].dt.hour <= S4_ASIAN_LAST]
            if len(asian) >= 5:
                rh, rl = float(asian["high"].max()), float(asian["low"].min())
                if rh > rl:
                    rng[date] = (rh, rl)
        ranges[s] = rng
    all_dates = sorted(set().union(*[set(d) for d in days.values()]))

    pos, trades = None, []
    for date in all_dates:
        if date.weekday() >= 5:
            continue
        # последователност от баровете на двойките за деня, хронологично
        seq = pd.concat([d[date] for d in days.values() if date in d], ignore_index=True)
        seq = seq.sort_values("time")
        traded_today = set()
        for row in seq.itertuples():
            h = row.time.hour
            if pos is not None:
                if row.sym != pos["sym"]:
                    continue
                d = pos["dir"]
                sl, tp = pos["sl"], pos["tp"]
                hit_sl = row.low <= sl if d == 1 else row.high >= sl
                hit_tp = row.high >= tp if d == 1 else row.low <= tp
                if hit_sl and hit_tp:
                    hit_tp = False
                if hit_sl or hit_tp:
                    trades.append(close_trade(pos, row.time, sl if hit_sl else tp,
                                              "SL" if hit_sl else "TP", swap=False))
                    pos = None
                    continue
                if h >= S4_EXIT_HOUR or row.time == seq["time"].max():
                    trades.append(close_trade(pos, row.time, float(row.close), "TIME", swap=False))
                    pos = None
                continue
            # няма позиция: опит за вход само в пробивния прозорец
            if not (S4_WIN_FIRST <= h <= S4_WIN_LAST):
                continue
            if row.sym in traded_today or date not in ranges[row.sym]:
                continue
            if not (np.isfinite(row.atr14) and np.isfinite(row.sma50)):
                continue
            if row.spread_price > SPREAD_ATR_MAX * row.atr14:
                continue
            pip = pip_of(row.sym)
            rh, rl = ranges[row.sym][date]
            rng_pips = (rh - rl) / pip
            sl_pips = float(np.clip(rng_pips, S4_SL_MIN, S4_SL_MAX))
            if row.close > rh and row.close > row.sma50:
                pos = open_position_tight(row, 1, sl_pips, None)
                pos["swap_pn"] = 0.0
                traded_today.add(row.sym)
            elif row.close < rl and row.close < row.sma50:
                pos = open_position_tight(row, -1, sl_pips, None)
                pos["swap_pn"] = 0.0
                traded_today.add(row.sym)
    out = pd.DataFrame(trades)
    if len(out):
        out.to_csv(TRADES_DIR / f"trades_{tag}.csv", index=False)
    return out


def build_features_s5(sym: str) -> pd.DataFrame:
    """D1 + RSI(2) (Wilder) за Connors реверсия."""
    d1 = add_d1(load_csv(sym, "D1"))
    delta = d1["close"].diff()
    ag = wilder(delta.clip(lower=0.0), 2)
    al = wilder(-delta.clip(upper=0.0), 2)
    d1["rsi2"] = 100.0 - 100.0 / (1.0 + ag / al)
    sp = d1["spread"].astype(float)
    sp = sp.where(sp > 0).fillna(float(sp.median()))
    d1["spread_pips"] = sp / 10.0
    d1["spread_price"] = sp * point_of(sym)
    d1["sym"] = sym
    # сигналът се оценява на ПРЕДИШНИЯ затворен D1 бар; входът е при ОТВАРЯНЕ на текущия
    d1["prev_close"] = d1["close"].shift(1)
    d1["prev_rsi2"] = d1["rsi2"].shift(1)
    d1["prev_ema200"] = d1["ema200"].shift(1)
    d1["prev_atr14"] = d1["atr14"].shift(1)
    d1["prev_time"] = d1["time"].shift(1)
    return d1


def run_s5(feat: dict[str, pd.DataFrame], symbols: list[str], *, swap: bool = True,
           tag: str = "s5") -> pd.DataFrame:
    """Лонг: prev close>EMA200 и RSI(2)<10 -> вход при open на текущия D1; изход RSI(2)>55/<45, SL,
    time-exit 7 дни или задължителен изход преди уикенд; max 1 позиция; cooldown 24ч след изход.
    Уикенд-изходът е по ГАП (>26ч до следващия бар на същата двойка) — независим от часовата конвенция
    на файла (старите D1 са 00:00 сървърно, новите 21/22:00 UTC с неделни барове)."""
    frames = []
    for s in symbols:
        f = feat[s].copy()
        nxt = f["time"].diff().dt.total_seconds().shift(-1)
        f["next_gap"] = (nxt > 26 * 3600).fillna(True).astype(bool)  # след този бар -> уикенд/празник
        frames.append(f)
    df = pd.concat(frames, ignore_index=True)
    df = df[df["time"] >= START_STATS].sort_values(["time", "sym"]).reset_index(drop=True)

    def manage(row, pos):
        """SL интрабар, после на close: RSI(2) / 7 дни / преди уикенд. Връще trade или None."""
        d = pos["dir"]
        sl = pos["sl"]
        if row.low <= sl if d == 1 else row.high >= sl:
            return close_trade(pos, row.time, sl, "SL", swap)
        bars_held = pos["bars_held"] + 1
        pos["bars_held"] = bars_held
        rsi_exit = row.rsi2 > S5_EXIT_RSI_LONG if d == 1 else row.rsi2 < S5_EXIT_RSI_SHORT
        if rsi_exit and np.isfinite(row.rsi2):
            return close_trade(pos, row.time, float(row.close), "RSI", swap)
        if bars_held >= S5_MAX_DAYS:
            return close_trade(pos, row.time, float(row.close), "TIME", swap)
        if row.next_gap:
            return close_trade(pos, row.time, float(row.close), "FRI", swap)
        return None

    pos, last_exit, trades = None, None, []
    for row in df.itertuples():
        t = row.time
        if t >= END_STATS and pos is None:
            break
        if pos is not None:
            if row.sym == pos["sym"]:
                tr = manage(row, pos)
                if tr is not None:
                    trades.append(tr)
                    pos = None
                    last_exit = t
            continue
        if t >= END_STATS:
            break
        if last_exit is not None and (t - last_exit) < pd.Timedelta(hours=24):
            continue
        if not (np.isfinite(row.prev_rsi2) and np.isfinite(row.prev_ema200)
                and np.isfinite(row.prev_atr14) and row.prev_atr14 > 0):
            continue
        pip = pip_of(row.sym)
        direction = None
        if row.prev_close > row.prev_ema200 and row.prev_rsi2 < 10.0:
            direction = 1
        elif row.prev_close < row.prev_ema200 and row.prev_rsi2 > 90.0:
            direction = -1
        if direction is None:
            continue
        sl_pips = float(np.clip(S5_SL_MULT * row.prev_atr14 / pip, S5_SL_MIN, S5_SL_MAX))
        # вход при OPEN на текущия бар (+спред+слипидж за лонг; -слипидж за шорт)
        if direction == 1:
            entry = float(row.open) + float(row.spread_price) + 0.3 * pip
            sl = entry - sl_pips * pip
        else:
            entry = float(row.open) - 0.3 * pip
            sl = entry + sl_pips * pip
        pos = {"sym": row.sym, "dir": direction, "entry_time": t, "entry": entry,
               "sl": sl, "tp": np.inf, "sl0": sl, "risk_price": sl_pips * pip,
               "risk_pips": sl_pips, "atr": float(row.prev_atr14),
               "spread_pips": float(row.spread_pips), "pip": pip, "bars_held": 0,
               "swap_pn": SWAP_PIPS_PER_NIGHT}
        tr = manage(row, pos)  # entry бар: SL/RSI/преди-уикенд изходи още на същия бар
        if tr is not None:
            trades.append(tr)
            pos = None
            last_exit = t
    if pos is not None:
        last = df[df["sym"] == pos["sym"]].iloc[-1]
        trades.append(close_trade(pos, last["time"], float(last["close"]), "EOD_MARK", swap))
    out = pd.DataFrame(trades)
    if len(out):
        out.to_csv(TRADES_DIR / f"trades_{tag}.csv", index=False)
    return out


# --- main-ове ----------------------------------------------------------------
def _dump_json(name: str, obj) -> None:
    import json
    with open(CACHE / name, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=1, default=float)


def main_s4() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("S4 — LONDON OPEN BREAKOUT (H1): Asian 00-07; пробив 07-10 с SMA50(H1) филтър; "
          "SL=clamp(1xrange,12,30)p; TP=2xrange; time-exit 17:00; без суап; 1 сделка/ден/двойка")
    print("=" * 100)
    core = ["EURUSD", "GBPUSD"]
    feat = {s: build_features_s4(s) for s in core}
    last_prices = {s: float(feat[s]["close"].iloc[-1]) for s in core}
    peur = pip_eur_map_for(core, last_prices)
    tr = run_s4(feat, core, tag="s4")
    print(fmt_strat("S4 TOTAL", strat_metrics(tr, peur)))
    for s in core:
        print("   " + fmt_strat(s, strat_metrics(tr[tr["sym"] == s], peur)))
    _print_yearly_pairs(tr, core, "S4")
    cols = ["sym", "entry_time", "dir", "entry", "sl0", "tp", "exit_time", "exit", "reason",
            "risk_pips", "spread_pips", "pnl_pips", "r"]
    print("\nSANITY първи 3 сделки (S4):")
    print(tr[cols].head(3).to_string(index=False))
    _dump_json("summary_s4.json", {"S4": strat_metrics(tr, peur),
                                   **{s: strat_metrics(tr[tr["sym"] == s], peur) for s in core}})


def main_s5() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("S5 — RSI-2 ДНЕВНА РЕВЕРСИЯ (Connors): close vs EMA200 + RSI(2)<10/>90; вход next open; "
          "изход RSI(2)>55/<45, SL=clamp(0.75xATR(D1),40,80)p, 7 дни, петък; суап 0.6п/нощ")
    print("=" * 100)
    core = ["EURUSD", "GBPUSD", "AUDUSD", "USDJPY"]
    feat = {s: build_features_s5(s) for s in core}
    last_prices = {s: float(load_csv(s, "D1")["close"].iloc[-1]) for s in core}
    peur = pip_eur_map_for(core, last_prices)
    tr = run_s5(feat, core, tag="s5")
    print(fmt_strat("S5 TOTAL", strat_metrics(tr, peur)))
    for s in core:
        print("   " + fmt_strat(s, strat_metrics(tr[tr["sym"] == s], peur)))
    _print_yearly_pairs(tr, core, "S5")
    cols = ["sym", "entry_time", "dir", "entry", "sl0", "exit_time", "exit", "reason",
            "risk_pips", "spread_pips", "nights", "swap_pips", "pnl_pips", "r"]
    print("\nSANITY първи 3 сделки (S5):")
    print(tr[cols].head(3).to_string(index=False))
    _dump_json("summary_s5.json", {"S5": strat_metrics(tr, peur),
                                   **{s: strat_metrics(tr[tr["sym"] == s], peur) for s in core}})


def main_s6() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("S6 — XAUUSD H4 TREND-PULLBACK: bias=знак(EMA50-EMA200), trend>=0.20, RSI14 32-42/58-68, "
          "SL=clamp(1.0xATR(H4),0.30,0.80)$, TP=2xSL, cooldown 12ч; суап $0.015/oz/нощ (също без суап)")
    print("=" * 100)
    feat = {"XAUUSD": build_features_tight("XAUUSD")}
    f = feat["XAUUSD"]
    print(f"[data] XAUUSD: H4={len(f)} rows, spread med={f['spread_pips'].median():.1f} "
          f"(pts={f['spread'].median():.0f} центa), последен close={f['close'].iloc[-1]}")
    peur = {"XAUUSD": 1.0 / EURUSD_ASSUMED}
    for sl_lo, sl_hi, label in ((0.30, 0.80, "spec 0.30-0.80$"),
                                (3.0, 8.0, "check 3.0-8.0$ (природен диапазон на ATR)")):
        for swap, slabel in ((True, "със суап"), (False, "без суап")):
            tag = f"s6_{'nat' if sl_lo > 1 else 'spec'}_{'swap' if swap else 'noswap'}"
            tr = run_tight_sim(feat, ["XAUUSD"], lambda r: tight_signal(r, "F1"),
                               sl_min_pips=sl_lo, sl_max_pips=sl_hi,
                               swap_pn=XAU_SWAP_PN, swap=swap, tag=tag)
            print(fmt_strat(f"S6 SL={label} {slabel}", strat_metrics(tr, peur)))
    _print_yearly_pairs(pd.read_csv(TRADES_DIR / "trades_s6_spec_swap.csv",
                                    parse_dates=["entry_time", "exit_time"]),
                        ["XAUUSD"], "S6 spec+суап (референтен)")
    cols = ["entry_time", "dir", "entry", "sl0", "tp", "exit_time", "exit", "reason",
            "risk_pips", "spread_pips", "nights", "swap_pips", "pnl_pips", "r"]
    tr = pd.read_csv(TRADES_DIR / "trades_s6_spec_swap.csv", parse_dates=["entry_time", "exit_time"])
    print("\nSANITY първи 3 сделки (S6):")
    print(tr[cols].head(3).to_string(index=False))
    dump = {}
    for sl_lo, sl_hi, label in ((0.30, 0.80, "spec"), (3.0, 8.0, "nat")):
        for swap in (True, False):
            t = pd.read_csv(TRADES_DIR / f"trades_s6_{'nat' if sl_lo > 1 else 'spec'}_{'swap' if swap else 'noswap'}.csv",
                            parse_dates=["entry_time", "exit_time"])
            dump[f"{label}_{'swap' if swap else 'noswap'}"] = strat_metrics(t, peur)
    _dump_json("summary_s6.json", dump)


def main_portfolio() -> None:
    """Портфолио проверки: (1) спека tight-GBPUSD(F1) + S4; (2) S5-комбинации (S5 е реверсивна)."""
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("=" * 100)
    print("ПОРТФОЛИО: max 2 позиции (1 на стратегия); корелации и комбиниран PF")
    print("=" * 100)
    feat_g = {"GBPUSD": build_features_tight("GBPUSD")}
    tight_g = run_tight_sim(feat_g, ["GBPUSD"], lambda r: tight_signal(r, "F1"), tag="port_tight_gbpusd")
    s4 = pd.read_csv(TRADES_DIR / "trades_s4.csv", parse_dates=["entry_time", "exit_time"])
    s5 = pd.read_csv(TRADES_DIR / "trades_s5.csv", parse_dates=["entry_time", "exit_time"])
    peur = {"GBPUSD": 0.10 / EURUSD_ASSUMED, "EURUSD": 0.10 / EURUSD_ASSUMED,
            "AUDUSD": 0.10 / EURUSD_ASSUMED, "USDJPY": 10.0 / 153.503 / EURUSD_ASSUMED}
    combos = [("tight-GBPUSD(F1)", tight_g), ("S4", s4), ("S5", s5),
              ("КОМБИНИРАН tight+S4", pd.concat([tight_g, s4])),
              ("КОМБИНИРАН S5+S4", pd.concat([s5, s4])),
              ("КОМБИНИРАН S5+tight", pd.concat([s5, tight_g]))]
    for name, tr in combos:
        print(fmt_strat(name, strat_metrics(tr, peur)))

    def daily(tr):
        d = tr.copy()
        d["day"] = d["exit_time"].dt.normalize()
        return d.groupby("day")["r"].sum()
    for a_name, a in (("tight", tight_g), ("S5", s5)):
        for b_name, b in (("S4", s4),):
            da, db = daily(a), daily(b)
            j = pd.concat([da, db], axis=1, keys=["a", "b"]).dropna()
            print(f"\nДневна корелация R: {a_name} vs {b_name} (общи дни={len(j)}): {j['a'].corr(j['b']):+.3f}")
    tg = tight_g.sort_values("entry_time")
    overlaps = sum(1 for t0, t1 in zip(tg["entry_time"], tg["exit_time"])
                   if ((s4["entry_time"] < t1) & (s4["exit_time"] > t0)).any())
    print(f"Едновременни tight+S4 позиции: {overlaps} от {len(tg)} tight сделки")
    d_t, d_s = daily(tight_g), daily(s4)
    common = d_t.index.intersection(d_s.index)
    corr_ts = float(d_t.loc[common].corr(d_s.loc[common])) if len(common) > 10 else None
    _dump_json("summary_portfolio.json", {
        **{n: strat_metrics(t, peur) for n, t in combos},
        "corr_tight_s4": corr_ts,
    })


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if arg == "--tight":
        sys.exit(main_tight())
    if arg == "--s2":
        sys.exit(main_s2())
    if arg == "--s3":
        sys.exit(main_s3())
    if arg == "--s4":
        sys.exit(main_s4())
    if arg == "--s5":
        sys.exit(main_s5())
    if arg == "--s6":
        sys.exit(main_s6())
    if arg == "--portfolio":
        sys.exit(main_portfolio())
    sys.exit(main())
