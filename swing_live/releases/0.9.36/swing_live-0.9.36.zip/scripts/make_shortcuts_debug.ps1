﻿$cfg = [IO.File]::ReadAllText('D:\AIRobot\admiral_swing_live\scripts\shortcuts.json', [Text.Encoding]::UTF8) | ConvertFrom-Json
$folder = $cfg.folder
if (-not (Test-Path $folder)) { New-Item -ItemType Directory -Path $folder | Out-Null }
$ws = New-Object -COM WScript.Shell
$idx = 0
foreach ($i in $cfg.items) {
    $idx++
    $tmp = Join-Path $env:TEMP ("demon_sc_" + $idx + ".lnk")
    $final = Join-Path $folder $i.name
    if (Test-Path $final) { Remove-Item $final -Force }
    if (Test-Path $tmp) { Remove-Item $tmp -Force }
    $s = $ws.CreateShortcut($tmp)
    $s.TargetPath = $i.target
    $s.WorkingDirectory = $i.workdir
    $s.IconLocation = $i.icon
    Write-Output ('icon=[' + $s.IconLocation + ']')
    $s.Save()
    [IO.File]::Move($tmp, $final)
}
Get-ChildItem $folder | ForEach-Object { Write-Output $_.Name }
