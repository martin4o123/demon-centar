# -*- coding: utf-8 -*-
"""Два варианта за повече сделки, тествани върху реални данни:

A) D1 тренд + H1 pullback: посока от D1 (close vs EMA200 D1), вход при
   RSI(2,H1) <10/>90, изход RSI(2,H1) 55/45 или 48ч. Разходи 1.5п + суап.
B) D1 15/85 (по-широк праг) върху повече двойки — кои носят edge.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(r"D:\AIRobot\admiral_swing_live")

COST = 1.5
SWAP = 0.6
PIP = {"USDJPY": 0.01, "EURUSD": 0.0001, "GBPUSD": 0.0001,
       "AUDUSD": 0.0001, "USDCAD": 0.0001, "EURJPY": 0.01, "AUDJPY": 0.01}


def rsi_w(c: pd.Series, n: int = 2) -> pd.Series:
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift()
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(),
                    (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def load(sym: str) -> pd.DataFrame:
    df = pd.read_csv(BASE / "data_cache" / f"h1_{sym}.csv", parse_dates=["time"])
    df = df.sort_values("time").reset_index(drop=True)
    return df


def add_d1(df: pd.DataFrame) -> pd.DataFrame:
    d1 = df.set_index("time").resample("1D").agg(
        {"open": "first", "high": "max", "low": "min", "close": "last"}).dropna()
    d1["ema200"] = d1["close"].ewm(span=200, adjust=False).mean()
    d1["rsi2"] = rsi_w(d1["close"])
    d1["atr"] = atr(d1.reset_index()).set_index(d1.index)["atr"] if False else None
    pc = d1["close"].shift()
    tr = pd.concat([d1["high"] - d1["low"], (d1["high"] - pc).abs(),
                    (d1["low"] - pc).abs()], axis=1).max(axis=1)
    d1["atr"] = tr.ewm(alpha=1 / 14, adjust=False).mean()
    df["rsi2h"] = rsi_w(df["close"])
    df["d1_close"] = df["time"].map(d1["close"])
    df["d1_ema"] = df["time"].map(d1["ema200"])
    df["d1_rsi"] = df["time"].map(d1["rsi2"])
    df["d1_atr"] = df["time"].map(d1["atr"])
    return df


def run_a(sym: str) -> pd.DataFrame:  # D1 тренд + H1 pullback
    df = add_d1(load(sym))
    pip = PIP[sym]
    trs, pos = [], None
    for i in range(210, len(df) - 1):
        row, nxt = df.iloc[i], df.iloc[i + 1]
        t, t2 = row["time"], nxt["time"]
        gap = (t2 - t).total_seconds() / 3600
        c, e1, r = row["close"], row["d1_ema"], row["rsi2h"]
        if not np.isfinite(r) or not np.isfinite(e1):
            continue
        if pos:
            pos["h"] += gap
            hit = (nxt["low"] <= pos["sl"]) if pos["d"] == 1 else (nxt["high"] >= pos["sl"])
            crossed = (r > 55) if pos["d"] == 1 else (r < 45)
            if hit:
                trs.append((sym, t2, "SL", -pos["risk"] - COST)); pos = None; continue
            if crossed or pos["h"] >= 48 or gap > 26:
                pnl = (c - pos["e"]) / pip * pos["d"] - COST - SWAP * (pos["h"] / 24)
                trs.append((sym, t2, "X", pnl)); pos = None; continue
            continue
        a = row["d1_atr"]
        if not np.isfinite(a):
            continue
        risk = float(np.clip(0.75 * a / pip, 40, 80))
        if c > e1 and r < 10:
            pos = {"d": 1, "e": nxt["open"], "sl": nxt["open"] - risk * pip,
                   "risk": risk, "h": 0.0}
        elif c < e1 and r > 90:
            pos = {"d": -1, "e": nxt["open"], "sl": nxt["open"] + risk * pip,
                   "risk": risk, "h": 0.0}
    return pd.DataFrame(trs, columns=["sym", "time", "reason", "pnl"])


def report(tr: pd.DataFrame, tag: str) -> None:
    if len(tr) == 0:
        print(f"{tag}: 0 сделки"); return
    days = max((tr.time.max() - tr.time.min()).days, 1)
    gw = tr.loc[tr.pnl > 0, "pnl"].sum()
    gl = -tr.loc[tr.pnl < 0, "pnl"].sum()
    pf = gw / gl if gl > 0 else float("inf")
    print(f"{tag}: {len(tr)} ({len(tr)/days*30.44:.1f}/мес) win={(tr.pnl>0).mean()*100:.1f}% "
          f"PF={pf:.2f} exp={tr.pnl.mean():.1f}п")


print("=== В) D1 тренд + H1 pullback RSI(2) ===")
all_a = pd.concat([run_a(s) for s in PIP], ignore_index=True).sort_values("time")
report(all_a, "ОБЩО 7 двойки")
for s in PIP:
    report(all_a[all_a.sym == s], f"  {s}")
cut = all_a.time.max() - pd.Timedelta(days=365)
report(all_a[all_a.time >= cut], "ПОСЛЕДНИ 12 МЕС.")
