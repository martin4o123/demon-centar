@echo off
"C:\Users\mgeor\AppData\Local\Python\pythoncore-3.12-64\python.exe" "D:\AIRobot\admiral_swing_live\scripts\auto_research.py" >> "D:\AIRobot\admiral_swing_live\logs\auto_research.log" 2>&1
