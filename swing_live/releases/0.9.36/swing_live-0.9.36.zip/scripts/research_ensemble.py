# -*- coding: utf-8 -*-
"""S6 ENSEMBLE — research backtest (ансамбъл от слаби сигнали, методология Renaissance).

Принцип: няма един „гениален" сигнал — има много слаби, комбинирани с тежести.
Никаква оптимизация върху тестовия период (избягваме overfit) — тежестите са
фиксирани предварително; вход само при съгласие (confluence) на мнозинство сигнали.

Използва реалния спред от данните + реалистичен комисионен (1.0 pip рунд-трип).

Изход: report/ensemble_research.json + отпечатана таблица.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE = Path(r"D:\AIRobot\admiral_swing_live")
DATA = BASE / "data_cache"
REPORT = BASE / "report"

# ---------- параметри (фиксирани предварително — не се пипат след гледане на резултата) ----------
SCORE_LONG = 2.0          # RSI pullback (1.5) + поне още едно потвърждение
SCORE_SHORT = -2.0
SL_ATR = 1.5
TP_ATR = 3.0              # R:R = 1:2
COMMISSION_PIPS = 1.0     # рунд-трип на Admirals (пипове)
MAX_HOLD_DAYS = 21        # форсирано затваряне
W_RSI2 = 1.5              # вход на отдръпване
W_TREND = 1.0             # (вградено в gating-а на тренда)
W_MOM = 0.75
W_ZSCORE = 1.0
W_HTF = 1.0               # H4 RSI(14) съгласие
DEV_END = "2020-12-31"    # разработка ≤ тази дата; holdout = след нея (един поглед накрая)
PAIRS = ["USDJPY", "EURUSD", "GBPUSD", "AUDUSD", "USDCAD", "EURCHF", "EURNZD", "XAUUSD"]
PIP = {"USDJPY": 0.01, "XAUUSD": 0.1}   # останалите = 0.0001


def pip_size(sym: str) -> float:
    return PIP.get(sym, 0.0001)


def load(sym: str, tf: str = "D1") -> pd.DataFrame:
    for name in (f"{sym}_{tf}.parquet", f"candle_history_{sym}_{tf}.parquet"):
        p = DATA / name
        if p.exists():
            df = pd.read_parquet(p)
            if "time_server_epoch" in df.columns:
                df["time"] = pd.to_datetime(df["time_server_epoch"], unit="s")
            df["time"] = pd.to_datetime(df["time"])
            return df.set_index("time").sort_index()
    return pd.DataFrame()


def rsi(close: pd.Series, n: int) -> pd.Series:
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift()).abs(),
        (df["low"] - df["close"].shift()).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    c = df["close"]
    df["rsi2"] = rsi(c, 2)
    ema50 = c.ewm(span=50, adjust=False).mean()
    ema200 = c.ewm(span=200, adjust=False).mean()
    df["trend"] = np.where(c > ema200, 1, -1)                       # D1 тренд
    df["trend50"] = np.where(ema50 > ema200, 1, -1)
    df["mom"] = np.sign(c.pct_change(10))                           # ROC(10)
    ma20 = c.rolling(20).mean()
    sd20 = c.rolling(20).std()
    df["zscore"] = np.where((c - ma20) / (2 * sd20) < -0.8, 1,
                    np.where((c - ma20) / (2 * sd20) > 0.8, -1, 0))
    df["atr"] = atr(df)
    return df


def ensemble_score(row) -> float:
    """S6 v2 — „купи дипа в тренда": D1 тренд дефинира посока, RSI(2) е вход на отдръпване.

    +W тренд съгласие (EMA50>EMA200 и цена>EMA200)
    +W RSI pullback в посока на тренда (RSI2<20 при възходящ; >80 при низходящ)
    +W моментум в посока на тренда
    +W HTF (H4 RSI14) в посока на тренда
    ±W z-score само ако потвърждава (не се бие с тренда)
    """
    s = 0.0
    if row.trend != row.trend50:   # трендът не е устойчив — извън пазар
        return 0.0
    t = row.trend
    # pullback в посока на тренда
    if (t == 1 and row.rsi2 < 20) or (t == -1 and row.rsi2 > 80):
        s += W_RSI2 * t
    # моментум + HTF + z-score потвърждение — само ако съвпадат с тренда
    if row.mom == t: s += W_MOM * t
    if row.htf_dir == t: s += W_HTF * t
    if row.zscore == t: s += W_ZSCORE * t
    return s


def backtest(df: pd.DataFrame, sym: str, dev: bool = True) -> dict:
    px = pip_size(sym)
    cutoff = pd.Timestamp(DEV_END)
    trades = []
    pos = None  # dict(dir, entry, sl, tp, entry_i, cost)
    n = len(df)
    for i in range(201, n - 1):
        row = df.iloc[i]
        nxt = df.iloc[i + 1]
        if dev and row.name > cutoff:
            break
        if not dev and row.name <= cutoff:
            continue
        spread = float(row.spread) * 0.1 * px if "spread" in df.columns else 1.0 * px
        if pos:
            # проверка SL/TP в рамките на свещта (консервативно: SL пръв при докоснати двата)
            hit_sl = (nxt.low <= pos["sl"]) if pos["dir"] == 1 else (nxt.high >= pos["sl"])
            hit_tp = (nxt.high >= pos["tp"]) if pos["dir"] == 1 else (nxt.low <= pos["tp"])
            exit_px = None
            if hit_sl and hit_tp: exit_px = pos["sl"]
            elif hit_sl: exit_px = pos["sl"]
            elif hit_tp: exit_px = pos["tp"]
            elif (i - pos["i"]) >= MAX_HOLD_DAYS: exit_px = float(nxt.close)
            if exit_px is not None:
                gross = (exit_px - pos["entry"]) * pos["dir"]
                cost = (pos["cost"] + spread) + COMMISSION_PIPS * px
                net = gross - cost
                trades.append({"r": net / pos["risk"], "pnl": net, "dir": pos["dir"]})
                pos = None
            continue
        score = ensemble_score(row)
        if score >= SCORE_LONG or score <= SCORE_SHORT:
            d = 1 if score >= SCORE_LONG else -1
            entry = float(nxt.open)          # вход на отварянето на следващата свещ
            sl = entry - d * SL_ATR * float(row.atr)
            tp = entry + d * TP_ATR * float(row.atr)
            risk = abs(entry - sl)
            if risk > 0:
                pos = {"dir": d, "entry": entry, "sl": sl, "tp": tp,
                       "i": i + 1, "risk": risk, "cost": float(row.spread) * 0.1 * px if "spread" in df.columns else 1.0 * px}
    if not trades:
        return {"symbol": sym, "trades": 0}
    t = pd.DataFrame(trades)
    wins = t[t.pnl > 0]
    losses = t[t.pnl <= 0]
    pf = wins.pnl.sum() / abs(losses.pnl.sum()) if losses.pnl.sum() != 0 else float("inf")
    eq = t.pnl.cumsum()
    dd = (eq - eq.cummax()).min()
    return {
        "symbol": sym, "trades": len(t),
        "wr_pct": round(len(wins) / len(t) * 100, 1),
        "pf": round(pf, 2),
        "exp_r": round(float(t.r.mean()), 3),
        "total_r": round(float(t.r.sum()), 1),
        "max_dd_r": round(float(dd / (t.r.abs().mean() if t.r.abs().mean() else 1)), 2),
        "avg_win": round(float(wins.pnl.mean()) if len(wins) else 0, 1),
        "avg_loss": round(float(losses.pnl.mean()) if len(losses) else 0, 1),
    }


def main() -> int:
    REPORT.mkdir(exist_ok=True)
    rows = []
    print(f"{'двойка':8} {'DEV 2012-2020':>38} {'HOLDOUT 2021-2026':>38}")
    for sym in PAIRS:
        d1 = load(sym, "D1")
        h4 = load(sym, "H4")
        if d1.empty:
            print(f"{sym:8} няма D1 данни — пропускам")
            continue
        d1 = add_indicators(d1)
        if not h4.empty:
            h4r = rsi(h4["close"], 14)
            h4d = h4r.resample("1D").last().reindex(d1.index).ffill()
            d1["htf_dir"] = np.sign(50 - h4d).fillna(0)
        else:
            d1["htf_dir"] = 0
        rdev = backtest(d1, sym, dev=True)
        rho = backtest(d1, sym, dev=False)
        row = {"symbol": sym, "dev": rdev, "holdout": rho}
        rows.append(row)
        fd = f"{rdev.get('trades',0)} сделки PF={rdev.get('pf','—')} exp={rdev.get('exp_r','—')}R"
        fo = f"{rho.get('trades',0)} сделки PF={rho.get('pf','—')} exp={rho.get('exp_r','—')}R"
        print(f"{sym:8} {fd:>38} {fo:>38}")
    out = REPORT / "ensemble_research.json"
    out.write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    vd = [r["dev"] for r in rows if r["dev"].get("trades", 0) >= 20]
    if vd:
        print(f"\nDEV медиана: PF={float(np.median([r['pf'] for r in vd])):.2f}  "
              f"exp={float(np.median([r['exp_r'] for r in vd])):.3f}R")
    vh = [r["holdout"] for r in rows if r["holdout"].get("trades", 0) >= 10]
    if vh:
        print(f"HOLDOUT медиана: PF={float(np.median([r['pf'] for r in vh])):.2f}  "
              f"exp={float(np.median([r['exp_r'] for r in vh])):.3f}R  "
              f"(минал е през гейта OOS PF>=1.15 ако медианата е над прага)")
    print(f"Изход: {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
