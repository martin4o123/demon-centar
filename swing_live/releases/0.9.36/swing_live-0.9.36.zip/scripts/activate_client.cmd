@echo off
chcp 65001 >nul
title Demon — Активация на клиент
cd /d "D:\AIRobot\admiral_swing_live"
curl -s -o nul -w "" http://127.0.0.1:5123/ 2>nul
if errorlevel 1 (
    echo Пускам таблото...
    start "AdmiralDashboard" /min "" "C:\Users\mgeor\AppData\Local\Python\pythoncore-3.12-64\pythonw.exe" "D:\AIRobot\admiral_swing_live\dashboard\app.py"
    timeout /t 5 /nobreak >nul
)
call "D:\AIRobot\admiral_swing_live\scripts\open_app.bat" http://127.0.0.1:5123/
exit /b 0
