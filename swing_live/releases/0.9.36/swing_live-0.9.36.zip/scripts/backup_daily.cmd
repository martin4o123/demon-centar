@echo off
rem Нощен бекъп на работещата swing_live система + конфигурацията на продукта 7.5
rem Пази последните 10 копия. Стартира се от Task Scheduler 23:40 всеки ден.
setlocal
set "SRC1=D:\AIRobot\admiral_swing_live"
set "SRC2=C:\Users\mgeor\AppData\Local\AdmiralBeta\config"
set "SRC3=C:\Users\mgeor\AppData\Local\AdmiralBeta\logs"
set "DSTROOT=D:\AIRobot\backups\swing_live"
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmm"') do set "STAMP=%%i"
set "DST=%DSTROOT%\%STAMP%"
if not exist "%DST%" mkdir "%DST%"
robocopy "%SRC1%" "%DST%\admiral_swing_live" /MIR /XD "%SRC1%\data_cache" /R:1 /W:2 /NFL /NDL /NJH >nul
robocopy "%SRC2%" "%DST%\AdmiralBeta_config" /MIR /R:1 /W:2 /NFL /NDL /NJH >nul
robocopy "%SRC3%" "%DST%\AdmiralBeta_logs" /MIR /R:1 /W:2 /NFL /NDL /NJH >nul
rem изтрий всичко по-старо от 10 копия
for /f "skip=10 delims=" %%d in ('dir /b /ad /o-n "%DSTROOT%"') do rd /s /q "%DSTROOT%\%%d" 2>nul
echo [%STAMP%] backup done >> "%DSTROOT%\backup.log"
exit /b 0
