# -*- coding: utf-8 -*-
"""Еднократен smoke тест на /control бутоните срещу реалната система."""
import json
import re
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(r"D:\AIRobot\admiral_swing_live")
sys.path.insert(0, str(BASE / "dashboard"))
sys.path.insert(0, str(BASE / "engine"))

import auth  # noqa: E402
import app as dash  # noqa: E402

TEST_EMAIL = "controltest@demon.local"
TEST_PW = "Test1234aA"
results = []


def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(f"{'PASS' if cond else 'FAIL'}  {name}  {extra}")


def csrf_from(html: str) -> str:
    m = re.search(r'name="csrf_token" value="([^"]+)"', html)
    return m.group(1) if m else ""


# --- потребител ---
try:
    auth.create_user("ControlTest", TEST_EMAIL, TEST_PW, TEST_PW)
except auth.AuthError as exc:
    if "вече" not in str(exc):
        raise

client = dash.app.test_client()

# --- логин ---
r = client.post("/login", data={"email": TEST_EMAIL, "password": TEST_PW},
                follow_redirects=True)
check("login", r.status_code == 200 and "Търговска система".encode("utf-8") in r.data,
      f"status={r.status_code}")

html = client.get("/").data.decode("utf-8", "replace")
tok = csrf_from(html)
check("csrf token", bool(tok))

# --- статус ---
r = client.post("/control/status", data={"csrf_token": tok}, follow_redirects=True)
body = r.data.decode("utf-8", "replace")
check("status: РАБОТИ", "РАБОТИ" in body and "S5 engine процеси" in body)

# --- stop ---
r = client.post("/control/stop", data={"csrf_token": tok}, follow_redirects=True)
body = r.data.decode("utf-8", "replace")
time.sleep(3)
flag_on = dash.STOP_FLAG.exists()
pids_after_stop = dash._engine_pids(fresh=True)
check("stop: STOP.flag записан", flag_on)
check("stop: процесът е спрян", len(pids_after_stop) == 0, f"pids={pids_after_stop}")
check("stop: банер", "Системата е спряна" in body)

# --- start ---
r = client.post("/control/start", data={"csrf_token": tok}, follow_redirects=True)
body = r.data.decode("utf-8", "replace")
time.sleep(6)
flag_off = not dash.STOP_FLAG.exists()
pids_after_start = dash._engine_pids(fresh=True)
check("start: STOP.flag махнат", flag_off)
check("start: процес има", len(pids_after_start) == 1, f"pids={pids_after_start}")
check("start: банер", "Системата е стартирана" in body)

# --- повторен start (вече върви) ---
html = client.get("/").data.decode("utf-8", "replace")
tok = csrf_from(html)
r = client.post("/control/start", data={"csrf_token": tok}, follow_redirects=True)
body = r.data.decode("utf-8", "replace")
check("start x2: вече върви", "вече върви" in body)
check("start x2: пак 1 процес", len(dash._engine_pids(fresh=True)) == 1)

# --- readiness + index страници живи ---
for page in ("/", "/readiness", "/journal", "/messages", "/settings", "/legend", "/logs"):
    rr = client.get(page)
    check(f"GET {page}", rr.status_code == 200, f"status={rr.status_code}")

# --- logout + изтриване на тестовия потребител ---
client.get("/logout")
users = [u for u in auth._load() if u.get("email") != TEST_EMAIL]
auth._save(users)
check("cleanup: test user изтрит", all(u.get("email") != TEST_EMAIL for u in auth._load()))

# --- отчет ---
fails = [n for n, ok in results if not ok]
print(f"\n==== {len(results) - len(fails)}/{len(results)} PASS ====")
sys.exit(1 if fails else 0)
