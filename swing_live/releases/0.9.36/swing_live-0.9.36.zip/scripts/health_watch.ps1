﻿# DEMON — автоматичен здравен надзор (Task Scheduler, на всеки 30 мин)
# Рънва health_check.py, пише в logs\health_watch.log и известява при FAIL.
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$base = "D:\AIRobot\admiral_swing_live"
$log  = "$base\logs\health_watch.log"
$stamp = Get-Date -Format "yyyy-MM-dd HH:mm"
$out = & py -3.12 -X utf8 "$base\scripts\health_check.py" 2>&1 | Out-String
$code = $LASTEXITCODE
Add-Content -Path $log -Value ("=== $stamp exit=$code ===" + "`n" + $out.TrimEnd()) -Encoding UTF8
# пазим лога до ~1 MB
try {
  if ((Get-Item $log).Length -gt 1MB) {
    $tail = Get-Content $log -Tail 300
    Set-Content -Path $log -Value $tail -Encoding UTF8
  }
} catch { }
if ($code -ne 0) {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "DEMON: otkrita neizpravnost (podrobnosti v $log).",
    "DEMON — zdraven nadzor", "OK", "Warning") | Out-Null
}
exit $code
