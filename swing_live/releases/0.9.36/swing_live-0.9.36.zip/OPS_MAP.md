# OPS MAP — Demon (център за управления) — работещата система

Авторитетен документ: какво работи, какво пази, какво е пенсионирано.
Всичко извън този списък в D:\AIRobot\ е **история** — не се пуска.

Последна актуализация: 2026-09-13

## 1. Активна система (търгува/пази живите €150.67)

| Компонент | Път | Роля | Как се стартира |
|---|---|---|---|
| Portable MT5 (live …7979) | C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\terminal64.exe | Връзка към AdmiralsGroup-Live; изпълнение на поръчки | AdmiralSwing_Autostart (при логин) или ръчно |
| Admiral 7.5 Control Center | …\AdmiralBeta\Admiral.exe | Табло, live авторизация, Telegram/updates | ръчно (потребител) |
| Admiral 7.5 engine (режим „пазач") | …\AdmiralBeta\swing_engine.pyc чрез START_ADMIRAL_BETA.cmd | Оценява на 10 мин; НЕ търгува (backtest REJECT — няма edge; обем-проверката правилно отказва) | Control Center или watchdog |
| STOP.flag | D:\AIRobot\admiral_swing_live\STOP.flag | Предпазител: докато съществува, watchdog-ът нищо не пуска | създава/трие се ръчно |
| S5 engine (RSI-2 реверсия) | engine\engine_s5.py + engine\config.json | Първата стратегия с положителен expectancy (S5, report_s456_bg.md). USDJPY+EURUSD, D1, max 1 позиция; dry по подразбиране; demo само при whitelist (demo_login); живите €150.67 НЕ се пипат | `py -3.12 engine\engine_s5.py` (демон), `--once`, `--dry-run-now` |

## 2. Моята оперативна ос (admiral_swing_live)

| Компонент | Файл | Роля |
|---|---|---|
| Preflight | scripts\preflight.py | Go/no-go проверка преди търговия: `py -3.12 scripts\preflight.py` |
| Watchdog | scripts\admiral_watchdog.ps1 + Task AdmiralSwing_Watchdog (5 мин) | Държи MT5 жив; уважава STOP.flag; продуктовият engine НЕ се пуска автоматично (осъзнат избор 14.09) |
| Autostart | scripts\admiral_autostart.cmd + Task AdmiralSwing_Autostart (при логин) | Първо стартиране след логин |
| Backup | scripts\backup_daily.cmd + Task AdmiralSwing_Backup (23:40) | Нощен бекъп → D:\AIRobot\backups\swing_live (последни 10); включва и logs\ (пълен снапшот) |
| Data refresh | scripts\fetch_daily.py + Task AdmiralSwing_FetchData (06:10) | Догаря новите барове в data_cache от терминала (idempotent) |
| Backtest | scripts\backtest_75.py + report\*.md | Доказателствена база за всяко решение |
| Performance | engine\performance.py + logs\{deals_journal,cashflows,equity_daily}.* | Чиста търговска крива (без изкривяване от депозити/тегления); Task AdmiralSwing_Performance (23:50, --snapshot) |
| Дашборд | dashboard\app.py (Flask, само 127.0.0.1:5123) | Една страница: сметка/ reasoning на робота / позиция / система; стартира се от admiral_autostart.cmd (pythonw) |
| Research feed | research\weekly_scan.py + research\inbox_*.md | Неделен research скенер (CLI) на публични изследвания; Task AdmiralSwing_Research (неделя 18:00); при грешка пише inbox и exit 0 |
| State contract | engine\state_contract.md | Авторитетни схеми: logs\state.json + logs\decisions.jsonl (двигателят ги пише, дашбордът ги чете) |
| Notify bus | engine\notify.py + logs\messages.jsonl + config\notify.json | Централни нотификации (Telegram-еквивалент): пишат го watchdog/performance/update_client/preflight/weekly_scan; опционален Telegram relay (enabled=false по подразбиране) |
| Легенда | LEGEND.md + /legend в таблото | Човешки език: какво е роботът и как работи; рендира се от вграден md→html конвертор |
| Лицензна система | tools\license_tool.py + licenses_ledger.jsonl + tools\license_public_key.json | Издаване/проверка на ASL ключове (RSA-3072 PKCS#1v15+SHA256); частният ключ е в %LOCALAPPDATA%\AdmiralPublisher\license_private_key.pem (owner-only, не напуска машината) |
| License Manager | tools\license_manager\app.py + scripts\license_manager.cmd | UI на 127.0.0.1:5124: Издаване/Регистър/Проверка на ключове; шорткът в Demon центъра за управления |
| Данни | data_cache\candle_history_*.csv | 14 г. D1/H4 от брокера (5-те на продукта + EURUSD/USDJPY) |

## 3. Решения, взети с данни (не се „оправят“ на инат)

1. **Стратегията на продукта 7.5 (широк SL) = REJECT.** 188 сделки/2015–2026, PF 0.87; преди суап PF 1.00 (нула); всяка двойка губеща standalone; 2026 PF 0.25. Доклад: report\report_bg.md + кръстосана проверка на правилата report\rules_extraction.txt. Продуктът остава само за табло/телеметрия/пазач.
2. **Тight вариант + 2 класически скрина** — REJECT (report\report_tight_bg.md): честотата не постига целта без вреда; PF 0.86–1.00, всички OOS под IS; минималният лот изисква ≥10% риск/сделка.
3. **S4 London breakout / S6 XAUUSD = REJECT; S5 RSI-2 реверсия = първата с положителен expectancy** (report\report_s456_bg.md): S5 PF 1.19 (IS22-24 1.38 / OOS 1.01), exp +0.070R, USDJPY носи edge-а (PF 1.37/OOS 1.62). Live гейт не е минат (OOS < 1.15) → двигателят engine\engine_s5.py е построен и работи в dry; demo само срещу whitelisted demo сметка, след демо-престой с критериите от доклада.

## 4. Пенсионирано (обезвредено 2026-09-13)

| Нещо | Какво стана |
|---|---|
| Старият ensemble engine (ai_engine_v3.py) | Спрян от 04.09; 9-те autostart скрипта в admiral\ преименувани *.disabled_20260913 |
| 6-те стари Task Scheduler задачи (AdmiralAI_*) | XML-експортирани в _archive\zombies_20260913, изтрити от планирача |
| bots\ (backup/daily_analyst/healer/trade_replay) | Архивирани в _archive\zombies_20260913\bots |
| sentinel\ | Архивиран в _archive\zombies_20260913\sentinel |
| start_scout.bat | Преименуван .disabled_20260913 |
| Production MT5 (C:\Program Files\Admirals Group MT5 Terminal) | НЕ се стартира — носи стария v4.6 EA; ако някога тръгне: стари сигнали изтрити, engine спрян, рискът е минимален |
| Стари архиви в D:\AIRobot\ (извън този проект) | Не пипаме |

## 5. Правила за недопускане на зомбита

- Нищо в D:\AIRobot\admiral\ НЕ се пуска повече. Там е музеят.
- Един Telegram токен = един getUpdates получател (продуктовият агент). Старият engine не трябва да върви едновременно с него.
- Не се пипа риск-профилът от Control Center след финалната настройка (презаписва settings.json).
- Нов компонент влиза в системата само след: тест → запис в този OPS MAP → график за наблюдение.

## 6. Източници (прозрачност)

- Правила на продукта: реконструирани от собствените му логове (decision_history.jsonl, 256 цикъла) + юлския отворен код swing_engine.py + README; кръстосано проверени с втори независим анализ → report\rules_extraction.txt
- Данни: bridge CSV-та на продукта (14 г., реални брокерски цени) + MT5 Python API за EURUSD/USDJPY
- Tight/скрин стратегии: класически публични методи (EMA/RSI/ATR trend-pullback, Donchian breakout, Bollinger mean-reversion) — имплементирани на чист Python върху нашите данни, без копиран чужд код
- Двигател за бъдещ live: собствен engine (D:\AIRobot\admiral_swing_live\engine\) по шаблона на безопасността от swing_engine.py (kill-switch, cooldown, Decimal сметки) + официален MetaTrader5 Python API

## 7. Известни проблеми (потвърдени с логове)

### 7.1 Bridge на няколко графики едновременно — ОПАСНО (2026-09-13)
- **Факт от логовете:** 3 инстанции AdmiralBetaBridge (GBPUSD/AUDUSD/USDCAD, H1) вървяха едновременно; всяка публикува състояние за ВСИЧКИ 5 символа (по дизайн — README §3: „една графика подава състояние за всички пет"); 496 „cannot publish" грешки за вечерта (5004 файл зает/5019 tmp съществува) — състезания върху едни и същи файлове.
- **Защо е проблем:** (а) излишен шум и състезателни записи; (б) при реален сигнал (напр. на демо) всички инстанции виждат един и същ ai_signal файл и всяка проверява PositionsTotal()==0 → риск от ДВОЙНИ/ТРОЙНИ поръчки.
- **Лечение:** bridge само на ЕДНА графика (препоръка GBPUSD H1). Проверка след корекция: в MQL5\Logs\<днес>.log трябва да има 1 инстанция и 0 „cannot publish".
- **Статус:** чака потребителско действие (премахване от излишните графики) — виж runbook-а.

## 8. Ъпдейт канал (Google Drive) и ROBOT.bat (2026-09-13)

- **Канал:** `G:\My Drive\AdmiralAI_Shared\swing_live\` — собствен RELEASE.json + RSA-3072 подпис (същият publisher ключ da6dbc7a152497ac, инструментът е `tools\publisher_sign.py` от build папката на продукта). Продуктовият канал (`AdmiralAI_Shared\RELEASE.json` за 7.5) НЕ се пипа.
- **Публикуване:** `py -3.12 scripts\publish_update.py <версия> --notes "..."` (zip на engine+dashboard+scripts+OPS_MAP+VERSION → sha256 → подпис → Drive, пазят се последни 3 версии).
- **Клиент:** `scripts\update_client.py --check|--apply` — проверява RSA подписа срещу вградения публичен модул, сверява sha256, бекъпва преди разархивиране, събужда watchdog. Планиран часово като `AdmiralSwing_UpdateCheck` (--apply). Тествано край-до-край (0.8.0→0.9.0 с реален бекъп).
- **Управление:** `D:\AIRobot\admiral_swing_live\ROBOT.bat start|stop|status|update|backup` — единствената команда, която потребителят помни. start=маха STOP.flag+пуска watchdog+отваря таблото; stop=спира нови сделки/рестартове (позициите не се пипат). S5 engine: същото — STOP.flag го спира, `--once` за тест, демонът се рестартира сам; demo режимът иска `demo_login` в engine\config.json (whitelist) + изтрит KILL.switch.
- **Лицензи/достъп (фаза 2, 0.9.2):** engine\licensing.py (activation.json + MachineGuid + HMAC печат; ключове се издават само тук с tools\license_tool.py), engine\auth.py (users.json, PBKDF2 120k), dashboard гейт (/login /register /forgot /reset /activate /users) срещу config\gating.json `{enabled:false}` — **на тази машината изключен по подразбиране** (owner/dev); клиентите го включват. Секрети (license_secret, session_secret, users.json, activation.json, gating.json, notify.json) са изключени от publish пейлоада (scripts\publish_update.py). Цялост: MANIFEST.sha256+MANIFEST.sig във всеки release; update_client verify-ва преди apply; engine/dashboard self-check при старт (липсващ манифест = dev пропуск).
- **Табло:** http://127.0.0.1:5123 (dashboard\app.py, Flask, само localhost, стартира от autostart) — секции: Сметка (чиста крива + депозити/тегления), „Какво мисли робота“ (последен цикъл по двойки с ✅/❌ причини), Позиция, Система, „Препоръчителни настройки“ (жива чеклист 12 проверки + насоки: акаунт/bridge/live-активиране/риск-профил/engine/машина), „Съобщения (Telegram-еквивалент)“ (logs\messages.jsonl с филтри по ниво/категория), страница „Легенда“ (/legend).
- **Отчетност:** performance.py (deals_journal + cashflows + чиста equity крива, вижда депозита +100) — планиран 23:50 като AdmiralSwing_Performance. Research feed: AdmiralSwing_Research, неделя 18:00.
