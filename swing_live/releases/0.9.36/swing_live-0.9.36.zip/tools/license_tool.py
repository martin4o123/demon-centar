# -*- coding: utf-8 -*-
"""Генератор и проверка на лицензни ключове (owner-only tooling).

Два формата, две ключови двойки (нито едната не пипа другата):

1) НОВ къс формат (по подразбиране за --issue):
       DEMON-XXXX-XXXX-... (групи по 4, Crockford base32)
   payload = 12 символа base32 = 7 байта: id(3 байта, пореден номер от ledger)
   + exp(4 байта, дни от 1970-01-01 до valid_until). Подпис: Ed25519 (64 байта,
   base32 = 103 символа) върху точно тези 7 байта. Името/имейлът НЕ влизат в
   ключа — остават само в ledger-а на собственика; verify ги попълва от там
   по id (празни стрингове, ако ги няма — напр. при клиент без ledger).
   Частен ключ: %LOCALAPPDATA%\\AdmiralPublisher\\license_ed25519_private.pem
   (pycryptodome Ed25519, PKCS#8 PEM). Публичен: tools\\license_ed_public.json.
   Подписва се с pycryptodome, verify-ът е с cryptography (без нова зависимост
   при клиентите — Ed25519 е RFC 8032 и двете библиотеки са съвместими).

2) СТАР формат (--issue-legacy, всички издадени ASL- ключове остават валидни):
       key = "ASL-" + base64url(canonical_payload_json) + "." + base64url(RSA-3072 подпис)
   payload = пълен JSON (license_id, customer_name, customer_email, issued_utc,
   valid_until, seats). RSA-3072, PKCS#1 v1.5 + SHA256. Частен ключ:
   %LOCALAPPDATA%\\AdmiralPublisher\\license_private_key.pem; публичен модул:
   tools\\license_public_key.json.

CLI:
  py -3.12 tools\\license_tool.py --init-key        (RSA двойка, само ако липсва)
  py -3.12 tools\\license_tool.py --init-ed-key     (Ed25519 двойка, само ако липсва)
  py -3.12 tools\\license_tool.py --issue --name "Иван Петров" --email ivan@abv.bg --days 365
  py -3.12 tools\\license_tool.py --issue-legacy ... (стар ASL- формат)
  py -3.12 tools\\license_tool.py --list
  py -3.12 tools\\license_tool.py --verify <key>     (exit 0 валиден / 1 невалиден|изтекъл)
  py -3.12 tools\\license_tool.py --selfcheck

Библиотечен интерфейс: issue_license(name, email, days, legacy=False) -> dict;
verify_key(key, ledger_path=None) -> (payload|None, error|None); read_ledger().
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import sys
import uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
LEDGER = BASE_DIR / "licenses_ledger.jsonl"
PUBLIC_JSON = Path(__file__).resolve().parent / "license_public_key.json"
ED_PUBLIC_JSON = Path(__file__).resolve().parent / "license_ed_public.json"
KEY_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "AdmiralPublisher"
PRIV_KEY = KEY_DIR / "license_private_key.pem"
ED_PRIVATE = KEY_DIR / "license_ed25519_private.pem"

PREFIX = "ASL-"
SHORT_PREFIX = "DEMON-"
SEATS = 1
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

_EPOCH = date(1970, 1, 1)
_SHORT_BODY_LEN = 115  # 12 base32 символа payload (7 байта) + 103 (64 байта подпис)
_PAYLOAD_CHARS = 12

# Crockford base32: без I, L, O, U (няма объркващи символи)
_B32_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_B32_MAP = {c: i for i, c in enumerate(_B32_ALPHABET)}
_B32_MAP.update({c.lower(): i for i, c in enumerate(_B32_ALPHABET)})


# ---------- Crockford base32 (RFC 4648 bit ред, без padding) ----------

def _b32e(raw: bytes) -> str:
    value = int.from_bytes(raw, "big")
    bits = len(raw) * 8
    out = []
    for i in range(0, bits, 5):
        shift = bits - 5 - i
        out.append(_B32_ALPHABET[((value >> shift) & 31) if shift >= 0
                                  else ((value << -shift) & 31)])
    return "".join(out)


def _b32d(s: str) -> bytes:
    acc = 0
    bits = 0
    out = bytearray()
    for ch in s:
        v = _B32_MAP.get(ch)
        if v is None:
            raise ValueError(f"Невалиден символ {ch!r} — допустими са 0-9, A-Z без I, L, O, U.")
        acc = (acc << 5) | v
        bits += 5
        if bits >= 8:
            bits -= 8
            out.append((acc >> bits) & 0xFF)
    if bits and (acc & ((1 << bits) - 1)):
        raise ValueError("Ключът има ненулеви padding битове (не е издаден от този инструмент).")
    return bytes(out)


def _group(s: str) -> str:
    return "-".join(s[i:i + 4] for i in range(0, len(s), 4))


# ---------- RSA ключове (legacy ASL- формат) ----------

def _b64u(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def load_private_key():
    from cryptography.hazmat.primitives import serialization
    if not PRIV_KEY.exists():
        raise FileNotFoundError(
            f"Липсва {PRIV_KEY} — първо: py -3.12 tools\\license_tool.py --init-key")
    return serialization.load_pem_private_key(PRIV_KEY.read_bytes(), password=None)


def load_public_key():
    """RSA публичен ключ от tools\\license_public_key.json (embed point за клиенти)."""
    from cryptography.hazmat.primitives.asymmetric import rsa
    info = json.loads(PUBLIC_JSON.read_text(encoding="utf-8"))
    return rsa.RSAPublicNumbers(int(info["exponent"]), int(info["modulus_hex"], 16)).public_key()


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def _sign(payload: dict, priv) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding
    return priv.sign(_canonical(payload), padding.PKCS1v15(), hashes.SHA256())


def _verify_sig(payload_bytes: bytes, sig: bytes, pub) -> bool:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding
    try:
        pub.verify(sig, payload_bytes, padding.PKCS1v15(), hashes.SHA256())
        return True
    except Exception:
        return False


def build_key(payload: dict, priv) -> str:
    """Стар ASL- формат: base64url(canonical JSON) + RSA подпис."""
    return PREFIX + _b64u(_canonical(payload)) + "." + _b64u(_sign(payload, priv))


# ---------- Ed25519 ключове (нов DEMON- формат) ----------

def load_ed_private_key():
    """Ed25519 частен ключ (pycryptodome) — САМО за подписване на нови ключове."""
    from Crypto.PublicKey import ECC
    if not ED_PRIVATE.exists():
        raise FileNotFoundError(
            f"Липсва {ED_PRIVATE} — първо: py -3.12 tools\\license_tool.py --init-ed-key")
    return ECC.import_key(ED_PRIVATE.read_bytes())


def load_ed_public_key():
    """Ed25519 публичен ключ от tools\\license_ed_public.json (embed point за клиенти).

    Verify-ът е с cryptography — тя вече е зависимост при клиентите (RSA verify-ът
    на стария формат ползва същата библиотека), затова няма нужда клиентите да
    инсталират pycryptodome.
    """
    from cryptography.hazmat.primitives import serialization
    if not ED_PUBLIC_JSON.exists():
        raise FileNotFoundError(
            f"Липсва {ED_PUBLIC_JSON} — издай го на машината на собственика: "
            "py -3.12 tools\\license_tool.py --init-ed-key")
    info = json.loads(ED_PUBLIC_JSON.read_text(encoding="utf-8"))
    return serialization.load_pem_public_key(info["public_key_pem"].encode("ascii"))


def _sign_ed(payload_bytes: bytes, priv) -> bytes:
    """Ed25519 подпис с pycryptodome (RFC 8032, съвместим с cryptography)."""
    from Crypto.Signature import eddsa
    return eddsa.new(priv, "rfc8032").sign(payload_bytes)


def _verify_ed(payload_bytes: bytes, sig: bytes, pub) -> bool:
    from cryptography.exceptions import InvalidSignature
    try:
        pub.verify(sig, payload_bytes)
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False


def build_short_key(lic_id: int, valid_until: date, priv=None) -> str:
    """Нов DEMON- формат: id(24 бита) + exp(дни от epoch, 32 бита) + Ed25519 подпис."""
    if not 0 <= int(lic_id) < 1 << 24:
        raise ValueError(f"id {lic_id} извън 24-битовия диапазон.")
    if priv is None:
        priv = load_ed_private_key()
    exp_days = (valid_until - _EPOCH).days
    if not 0 <= exp_days < 1 << 32:
        raise ValueError(f"Дата {valid_until} извън 32-битовия диапазон (дни от 1970-01-01).")
    payload_bytes = int(lic_id).to_bytes(3, "big") + exp_days.to_bytes(4, "big")
    sig = _sign_ed(payload_bytes, priv)
    return SHORT_PREFIX + _group(_b32e(payload_bytes) + _b32e(sig))


# ---------- ledger ----------

def read_ledger(path: Path | None = None) -> list[dict]:
    path = path if path is not None else LEDGER
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows


def _row_id(row: dict) -> int:
    try:
        return int(row.get("id"))
    except (TypeError, ValueError):
        return 0


def _next_ledger_id(path: Path) -> int:
    return max((_row_id(r) for r in read_ledger(path)), default=0) + 1


def _ledger_row_by_id(lic_id: int, path: Path | None) -> dict | None:
    for row in read_ledger(path):
        if _row_id(row) == lic_id:
            return row
    return None


# ---------- библиотечен интерфейс ----------

def issue_license(name: str, email: str, days: int, priv=None,
                  ledger_path: Path | None = None, legacy: bool = False) -> dict:
    """Издава ключ + записва в ledger-а. Връща реда (dict).

    По подразбиране връща НОВИЯ къс формат (Ed25519); името/имейлът влизат само
    в ledger-а. legacy=True връща стария ASL- формат (RSA), където priv е RSA
    ключ (по подразбиране license_private_key.pem).
    """
    name = (name or "").strip()
    email = (email or "").strip()
    if not name:
        raise ValueError("Името е празно.")
    if not EMAIL_RE.match(email):
        raise ValueError(f"Невалиден имейл: {email!r} (очаква се вида a@b.c).")
    days = int(days)
    if days < 1 or days > 365 * 25:
        raise ValueError(f"Невалиден срок: {days} дни.")
    path = ledger_path if ledger_path is not None else LEDGER
    now = datetime.now(timezone.utc)
    valid_until = (now + timedelta(days=days)).date()
    issued = now.isoformat(timespec="seconds")
    if legacy:
        if priv is None:
            priv = load_private_key()
        payload = {
            "license_id": str(uuid.uuid4()),
            "customer_name": name,
            "customer_email": email,
            "issued_utc": issued,
            "valid_until": valid_until.isoformat(),
            "seats": SEATS,
        }
        key = build_key(payload, priv)
        row = {
            "issued_utc": issued,
            "name": name,
            "email": email,
            "days": days,
            "valid_until": valid_until.isoformat(),
            "license_id": payload["license_id"],
            "key": key,
            "format": "legacy",
        }
    else:
        lic_id = _next_ledger_id(path)
        key = build_short_key(lic_id, valid_until)
        row = {
            "issued_utc": issued,
            "name": name,
            "email": email,
            "days": days,
            "valid_until": valid_until.isoformat(),
            "id": lic_id,
            "license_id": str(uuid.uuid4()),
            "key": key,
            "format": "short",
        }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        fh.flush()
        os.fsync(fh.fileno())
    return row


def parse_key(key: str):
    """Стар ASL- формат -> (payload_bytes, sig) или raises ValueError."""
    key = (key or "").strip()
    if not key.startswith(PREFIX):
        raise ValueError("Ключът не започва с ASL-.")
    body = key[len(PREFIX):]
    parts = body.split(".")
    if len(parts) != 2 or not all(parts):
        raise ValueError("Ключът не е във формат ASL-<payload>.<подпис>.")
    try:
        payload_bytes = _b64u_dec(parts[0])
        sig = _b64u_dec(parts[1])
    except Exception:
        raise ValueError("Ключът не е валиден base64url.")
    return payload_bytes, sig


def parse_short_key(key: str):
    """Нов DEMON- формат -> (payload_bytes, sig) или raises ValueError."""
    key = (key or "").strip().upper()
    if not key.startswith(SHORT_PREFIX):
        raise ValueError("Ключът не започва с DEMON-.")
    body = key[len(SHORT_PREFIX):].replace("-", "")
    if len(body) != _SHORT_BODY_LEN:
        raise ValueError(
            f"Ключът е {len(body)} символа след префикса; очакват се {_SHORT_BODY_LEN} "
            "(12 payload + 103 подпис).")
    # payload и подпис са кодирани ОТДЕЛНО (всеки със собствен padding) —
    # не декодират се като един непрекъснат поток
    payload_bytes = _b32d(body[:_PAYLOAD_CHARS])
    sig = _b32d(body[_PAYLOAD_CHARS:])
    if len(payload_bytes) != 7 or len(sig) != 64:
        raise ValueError("Ключът не декодира до 7 байта payload + 64 байта подпис.")
    return payload_bytes, sig


def _verify_short(key: str, ledger_path: Path | None):
    try:
        payload_bytes, sig = parse_short_key(key)
    except ValueError as exc:
        return None, str(exc)
    try:
        pub = load_ed_public_key()
    except FileNotFoundError as exc:
        return None, str(exc)
    if not _verify_ed(payload_bytes, sig, pub):
        return None, "Невалиден подпис — ключът не е издаден от този издател."
    lic_id = int.from_bytes(payload_bytes[0:3], "big")
    exp_days = int.from_bytes(payload_bytes[3:7], "big")
    valid_until = _EPOCH + timedelta(days=exp_days)
    vu = valid_until.isoformat()
    row = _ledger_row_by_id(lic_id, ledger_path)
    payload = {
        "v": 2,
        "id": lic_id,
        "exp": vu,
        "license_id": str(row.get("license_id", "")) if row else "",
        "customer_name": str(row.get("name", "")) if row else "",
        "customer_email": str(row.get("email", "")) if row else "",
        "issued_utc": str(row.get("issued_utc", "")) if row else "",
        "valid_until": vu,
        "seats": SEATS,
    }
    if valid_until < datetime.now(timezone.utc).date():
        return payload, f"Изтекъл на {vu}."
    return payload, None


def verify_key(key: str, pub=None, ledger_path: Path | None = None):
    """-> (payload dict|None, error str|None). Изтекъл = error, payload върнат.

    Приема И двата формата: DEMON-… (Ed25519) и ASL-… (RSA-3072). За новия
    формат име/имейл се попълват от ledger-а по id (празни стрингове, ако ги
    няма). ledger_path е за тестове; по подразбиране — реалният ledger.
    """
    key = (key or "").strip()
    if key.upper().startswith(SHORT_PREFIX):
        return _verify_short(key, ledger_path)
    if pub is None:
        pub = load_public_key()
    try:
        payload_bytes, sig = parse_key(key)
    except ValueError as exc:
        return None, str(exc)
    if not _verify_sig(payload_bytes, sig, pub):
        return None, "Невалиден подпис — ключът не е издаден от този издател."
    try:
        payload = json.loads(payload_bytes.decode("utf-8"))
    except Exception:
        return None, "Payload-ът не е валиден JSON."
    if not isinstance(payload, dict) or "license_id" not in payload \
            or "customer_email" not in payload or "valid_until" not in payload:
        return None, "Payload-ът няма задължителните полета."
    valid_until = str(payload.get("valid_until") or "")
    try:
        expiry = datetime.strptime(valid_until, "%Y-%m-%d").date()
    except ValueError:
        return payload, f"valid_until {valid_until!r} не е дата (YYYY-MM-DD)."
    if expiry < datetime.now(timezone.utc).date():
        return payload, f"Изтекъл на {valid_until}."
    return payload, None


def is_expired(valid_until) -> bool:
    try:
        return datetime.strptime(str(valid_until), "%Y-%m-%d").date() \
            < datetime.now(timezone.utc).date()
    except ValueError:
        return True


# ---------- CLI ----------

def cmd_init_key() -> int:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    if PRIV_KEY.exists():
        print(f"ОТКАЗ: {PRIV_KEY} вече съществува — не презаписвам.")
        return 1
    KEY_DIR.mkdir(parents=True, exist_ok=True)
    priv = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    PRIV_KEY.write_bytes(priv.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption()))
    numbers = priv.public_key().public_numbers()
    PUBLIC_JSON.write_text(json.dumps({
        "schema": 1,
        "bits": 3072,
        "exponent": numbers.e,
        "modulus_hex": format(numbers.n, "x"),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Готово: {PRIV_KEY}")
    print(f"Публичен модул -> {PUBLIC_JSON}")
    print("Пази частния ключ САМО на тази машина. Публикувай само license_public_key.json.")
    return 0


def cmd_init_ed_key() -> int:
    from Crypto.PublicKey import ECC
    if ED_PRIVATE.exists():
        print(f"ОТКАЗ: {ED_PRIVATE} вече съществува — не презаписвам.")
        return 1
    KEY_DIR.mkdir(parents=True, exist_ok=True)
    priv = ECC.generate(curve="Ed25519")
    ED_PRIVATE.write_text(priv.export_key(format="PEM"), encoding="ascii")
    ED_PUBLIC_JSON.write_text(json.dumps({
        "schema": 2,
        "curve": "Ed25519",
        "public_key_pem": priv.public_key().export_key(format="PEM"),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Готово: {ED_PRIVATE}")
    print(f"Публичен Ed25519 ключ -> {ED_PUBLIC_JSON}")
    print("Пази частния ключ САМО на тази машина. Публикувай само license_ed_public.json.")
    return 0


def cmd_issue(args, legacy: bool = False) -> int:
    try:
        row = issue_license(args.name, args.email, args.days, legacy=legacy)
    except (ValueError, FileNotFoundError) as exc:
        print(f"ГРЕШКА: {exc}", file=sys.stderr)
        return 1
    print("=" * 78)
    print("ЛИЦЕНЗЕН КЛЮЧ (давай целия, без прекъсване):")
    print(row["key"])
    print("=" * 78)
    kind = "стар формат (legacy RSA)" if legacy else "нов къс формат (Ed25519)"
    print(f"Записано в ledger [{kind}]: {row['name']} <{row['email']}> · "
          f"валиден до {row['valid_until']} ({row['days']} дни) · id {row['license_id']}")
    return 0


def cmd_list() -> int:
    rows = read_ledger()
    if not rows:
        print("Няма издадени ключове (ledger-ът е празен).")
        return 0
    today = datetime.now(timezone.utc).date()
    active = 0
    print(f"{'Издаден':<20} {'Име':<22} {'Имейл':<26} {'Валиден до':<12} {'Статус':<10} "
          f"{'№':<5} {'Формат':<8} Префикс")
    print("-" * 118)
    for r in rows:
        expired = is_expired(r.get("valid_until"))
        status = "ИЗТЕКЪЛ" if expired else "АКТИВЕН"
        if not expired:
            active += 1
        fmt = "short" if str(r.get("key", "")).startswith(SHORT_PREFIX) else "legacy"
        num = r.get("id", "—") if fmt == "short" else "—"
        print(f"{r.get('issued_utc', '')[:19]:<20} {r.get('name', '')[:21]:<22} "
              f"{r.get('email', '')[:25]:<26} {r.get('valid_until', ''):<12} "
              f"{status:<10} {str(num):<5} {fmt:<8} {r.get('key', '')[:20]}")
    print("-" * 118)
    print(f"Общо: {len(rows)} издадени · {active} активни · днес {today.isoformat()}")
    return 0


def cmd_verify(args) -> int:
    try:
        payload, err = verify_key(args.key)
    except FileNotFoundError as exc:
        print(f"ГРЕШКА: {exc}", file=sys.stderr)
        return 1
    if payload:
        print("Payload:")
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    if err:
        print(f"РЕЗУЛТАТ: НЕВАЛИДЕН — {err}")
        return 1
    print(f"РЕЗУЛТАТ: ВАЛИДЕН — {payload['customer_name']} <{payload['customer_email']}> "
          f"до {payload['valid_until']}")
    return 0


def cmd_selfcheck() -> int:
    from cryptography.hazmat.primitives.asymmetric import rsa
    import tempfile
    results = []

    def check(name, cond):
        results.append((name, bool(cond)))
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        ledger = tmp / "ledger.jsonl"

        # 1. нов формат: issue -> verify OK (реалната Ed25519 двойка, temp ledger)
        row = issue_license("Selfcheck Тест", "self@check.bg", 30, ledger_path=ledger)
        check("нов ключ с DEMON- префикс", row["key"].startswith(SHORT_PREFIX))
        payload, err = verify_key(row["key"], ledger_path=ledger)
        check("issue -> verify OK (имейл от ledger по id)", err is None
              and payload.get("customer_email") == "self@check.bg")

        # 2. ledger расте + пореден номер
        rows = read_ledger(ledger)
        check("ledger записът е налице с id=1", len(rows) == 1
              and rows[0]["key"] == row["key"] and rows[0].get("id") == 1)

        # 3. корумпиран символ в подписа -> отказ
        key = row["key"]
        bad = key[:-1] + ("0" if key[-1] != "0" else "1")
        payload2, err2 = verify_key(bad, ledger_path=ledger)
        check("корумпиран символ -> отказ", payload2 is None and err2 is not None)

        # 4. подменен payload (първи payload символ) -> отказ на подписа
        i = len(SHORT_PREFIX)
        forged = key[:i] + ("0" if key[i] != "0" else "1") + key[i + 1:]
        payload3, err3 = verify_key(forged, ledger_path=ledger)
        check("подменен payload -> отказ на подписа", payload3 is None and err3 is not None)

        # 5. малки букви -> същия валиден ключ
        payload3b, err3b = verify_key(key.lower(), ledger_path=ledger)
        check("малки букви -> валиден", err3b is None
              and payload3b is not None and payload3b.get("id") == 1)

        # 6. изтекъл ключ (синтетичен payload, валиден подпис)
        past = datetime.now(timezone.utc).date() - timedelta(days=35)
        old_key = build_short_key(999, past)
        payload4, err4 = verify_key(old_key, ledger_path=ledger)
        check("изтекъл ключ -> отказ с дата", payload4 is not None and err4 is not None
              and "Изтекъл" in err4)

        # 7. валидации (общи за двата формата)
        try:
            issue_license("", "a@b.c", 10, ledger_path=tmp / "l2.jsonl")
            check("празно име -> ValueError", False)
        except ValueError:
            check("празно име -> ValueError", True)
        try:
            issue_license("X", "не-имейл", 10, ledger_path=tmp / "l2.jsonl")
            check("лош имейл -> ValueError", False)
        except ValueError:
            check("лош имейл -> ValueError", True)

        # 8. legacy RSA roundtrip (хвърляем ключ, не пипа реалния)
        rsa_priv = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        row_l = issue_license("Legacy Тест", "legacy@check.bg", 30, priv=rsa_priv,
                              ledger_path=tmp / "l3.jsonl", legacy=True)
        check("legacy ключ с ASL- префикс", row_l["key"].startswith(PREFIX))
        payload5, err5 = verify_key(row_l["key"], pub=rsa_priv.public_key())
        check("legacy issue -> verify OK", err5 is None
              and payload5.get("customer_email") == "legacy@check.bg")

        # 9. изтекъл legacy ключ
        now = datetime.now(timezone.utc)
        old = {"license_id": str(uuid.uuid4()), "customer_name": "Old", "customer_email": "o@x.bg",
               "issued_utc": (now - timedelta(days=400)).isoformat(timespec="seconds"),
               "valid_until": (now - timedelta(days=35)).date().isoformat(), "seats": 1}
        old_key = build_key(old, rsa_priv)
        payload6, err6 = verify_key(old_key, pub=rsa_priv.public_key())
        check("изтекъл legacy ключ -> отказ с дата", payload6 is not None and err6 is not None
              and "Изтекъл" in err6)

        # 10. Ed25519 PEM запис/четене (форматът е съвместим)
        from Crypto.PublicKey import ECC
        pem = load_ed_private_key().export_key(format="PEM")
        check("Ed25519 PEM ключът се чете обратно", ECC.import_key(pem) is not None)

    ok = all(r[1] for r in results)
    print(f"{'-' * 50}\nSELFCHECK: {'ВСИЧКИ PASS' if ok else 'ИМА FAIL'} ({sum(1 for r in results if r[1])}/{len(results)})")
    return 0 if ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="Лицензни ключове (owner-only)")
    ap.add_argument("--init-key", action="store_true")
    ap.add_argument("--init-ed-key", action="store_true")
    ap.add_argument("--issue", action="store_true")
    ap.add_argument("--issue-legacy", action="store_true")
    ap.add_argument("--name", default="")
    ap.add_argument("--email", default="")
    ap.add_argument("--days", type=int, default=365)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--verify", dest="key", metavar="KEY", default=None)
    ap.add_argument("--selfcheck", action="store_true")
    args = ap.parse_args()
    if args.init_key:
        return cmd_init_key()
    if args.init_ed_key:
        return cmd_init_ed_key()
    if args.issue_legacy:
        return cmd_issue(args, legacy=True)
    if args.issue:
        return cmd_issue(args, legacy=False)
    if args.list:
        return cmd_list()
    if args.key is not None:
        return cmd_verify(args)
    if args.selfcheck:
        return cmd_selfcheck()
    ap.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
