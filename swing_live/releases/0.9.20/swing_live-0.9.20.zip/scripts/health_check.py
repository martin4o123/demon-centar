# -*- coding: utf-8 -*-
"""DEMON — здравен чек на цялата система.

Проверява всички компоненти и връща компактен доклад. exit 0 = всичко зелено,
exit 1 = има нередности (редовете започват с FAIL/WARN).

Използване: py -3.12 scripts/health_check.py   (и от cron задачата на Kimi)
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE = Path(r"D:\AIRobot\admiral_swing_live")
LOGS = BASE / "logs"
GITHUB_URL = "https://martin4o123.github.io/demon-centar/swing_live"
DRIVE = Path(r"G:\My Drive\AdmiralAI_Shared\swing_live")

OK, WARN, FAIL = "OK", "WARN", "FAIL"
problems: list[str] = []
rows: list[str] = []


def log(status: str, name: str, detail: str = "") -> None:
    mark = {"OK": "✓", "WARN": "!", "FAIL": "✗"}[status]
    rows.append(f"{mark} {name}" + (f" — {detail}" if detail else ""))
    if status == FAIL:
        problems.append(f"{name}: {detail}")
    elif status == WARN:
        problems.append(f"(warn) {name}: {detail}")


def run_ps(ps: str) -> str:
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-NonInteractive",
                              "-Command", ps],
                             capture_output=True, text=True, timeout=60)
        return (out.stdout or "").strip()
    except Exception:
        return ""


def http_get(url: str, timeout: int = 20) -> tuple[bool, bytes]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "demon-health/1"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return True, r.read()
    except Exception:
        return False, b""


def age_min(p: Path) -> float | None:
    try:
        return (time.time() - p.stat().st_mtime) / 60
    except OSError:
        return None


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ---------- 1. процеси ----------
ps_out = run_ps(
    "Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe' OR Name='python.exe'\" "
    "| Where-Object { $_.CommandLine -like '*engine_s5.py*' } "
    "| Select-Object -ExpandProperty ProcessId")
engine_pids = [x for x in ps_out.split() if x.isdigit()]
log(OK if len(engine_pids) == 1 else (FAIL if len(engine_pids) == 0 else FAIL),
    "двигател (процес)",
    f"PID {', '.join(engine_pids)}" if engine_pids else "не върви!")

log(OK if not (BASE / "STOP.flag").exists() else WARN,
    "STOP.flag", "активен — спряно ръчно" if (BASE / "STOP.flag").exists() else "липсва")

# ---------- 2. свежест на цикъла ----------
state_age = age_min(LOGS / "state.json")
if state_age is None:
    log(FAIL, "state.json", "липсва")
elif state_age < 25:
    log(OK, "цикъл на двигателя", f"преди {int(state_age)} мин")
else:
    log(FAIL, "цикъл на двигателя", f"няма запис от {int(state_age)} мин")

# ---------- 3. табло + панел ----------
for name, port in (("табло", 5123), ("панел ключове", 5124)):
    ok, _ = http_get(f"http://127.0.0.1:{port}/login", timeout=8)
    if not ok:
        ok, _ = http_get(f"http://127.0.0.1:{port}/", timeout=8)
    log(OK if ok else FAIL, name, f"порт {port}" + ("" if ok else " не отговаря"))

# ---------- 4. лиценз ----------
sys.path.insert(0, str(BASE))
try:
    from engine import licensing as L  # type: ignore
    ok, reason = L.is_licensed()
    log(OK if ok else FAIL, "лиценз", reason or "активен")
except Exception as exc:
    log(FAIL, "лиценз", f"грешка при проверка: {exc}")

# ---------- 5. MT5 + bridge ----------
term = run_ps("Get-Process terminal64 -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Id")
log(OK if term else WARN, "MT5 терминал", f"PID {term}" if term else "не върви")
# AutoTrading разрешен ли е (иначе всяка поръчка пада с 10027)
mt5_path = r"C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\terminal64.exe"
try:
    import MetaTrader5 as mt5
    if mt5.initialize(mt5_path):
        ti = mt5.terminal_info()
        if ti is not None and not bool(ti.trade_allowed):
            log(FAIL, "MT5 AutoTrading", "изключен — всяка поръчка се отказва! "
                "Отвори терминала и натисни бутона „Algo Trading“.")
        else:
            log(OK, "MT5 AutoTrading", "разрешен")
        mt5.shutdown()
    else:
        log(WARN, "MT5 AutoTrading", "terminal_info недостъпно")
except Exception as exc:
    log(WARN, "MT5 AutoTrading", f"проверката не мина: {exc}")
mt5_files = list((Path(r"C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\MQL5\Files"))
                 .glob("mt5_status_*.txt")) if Path(
    r"C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\MQL5\Files").exists() else []
if mt5_files:
    freshest = min((age_min(f) for f in mt5_files if age_min(f) is not None), default=None)
    if freshest is not None and freshest < 10:
        log(OK, "bridge статус файлове",
            f"{len(mt5_files)} файла, най-нов преди {int(freshest)} мин")
    elif freshest is not None and freshest < 240:
        log(WARN, "bridge статус файлове", f"последен запис преди {int(freshest)} мин")
    else:
        log(FAIL, "bridge статус файлове", "няма свеж запис — bridge-ът не пише!")
else:
    log(WARN, "bridge статус файлове", "няма")

# ---------- 6. пазител / новини / социален ----------
for fname, limit in (("guard_state.json", 45), ("social_pulse.json", 130)):
    a = age_min(LOGS / fname)
    if a is None:
        log(WARN, fname, "липсва")
    elif a < limit:
        log(OK, fname, f"преди {int(a)} мин")
    else:
        log(WARN, fname, f"преди {int(a)} мин (праг {limit})")

# ---------- 7. грешки в лога на двигателя (от последния daemon старт) ----------
today = utcnow().strftime("%Y-%m-%d")
lines = []
try:
    lines = (LOGS / "engine_s5.log").read_text(encoding="utf-8", errors="replace").splitlines()
except OSError:
    pass
start_idx = 0
for i in range(len(lines) - 1, -1, -1):
    if "S5 daemon старт" in lines[i]:
        start_idx = i
        break
errs = [l for l in lines[start_idx:] if "ERROR" in l]
seen: set[str] = set()
uniq = [e for e in errs if not (e.split("ERROR", 1)[1] in seen or seen.add(e.split("ERROR", 1)[1]))]
log(OK if not uniq else WARN, "грешки на текущия daemon",
    f"{len(uniq)} вида" if uniq else "няма")

# ---------- 8. Task Scheduler ----------
tasks_out = run_ps("schtasks /query /fo CSV | Select-String AdmiralSwing")
task_lines = [l for l in tasks_out.splitlines() if "AdmiralSwing" in l]
missing = [t for t in ("Watchdog", "Autostart", "News", "Guard", "Social", "FetchData",
                       "Backup", "Performance", "UpdateCheck")
           if not any(t in l for l in task_lines)]
log(OK if not missing else FAIL, "планирани задачи",
    f"{len(task_lines)} задачи" + (f", липсват: {', '.join(missing)}" if missing else ""))

# ---------- 9. GitHub канал ----------
ok, raw = http_get(GITHUB_URL + "/RELEASE.json", timeout=20)
if ok:
    try:
        ver_web = json.loads(raw)["version"]
        ver_loc = json.loads((BASE / "VERSION.json").read_text(encoding="utf-8"))["version"]
        log(OK if ver_web == ver_loc else WARN, "GitHub канал",
            f"сайт {ver_web} / локално {ver_loc}")
    except Exception as exc:
        log(WARN, "GitHub канал", f"parse: {exc}")
else:
    log(WARN, "GitHub канал", "RELEASE.json не се сваля")

# ---------- 10. дисково място ----------
for drive in ("D:", "G:"):
    try:
        import shutil
        free = shutil.disk_usage(drive + "\\").free / 1e9
        log(OK if free > 2 else WARN, f"място {drive}", f"{free:.1f} GB свободни")
    except Exception:
        log(WARN, f"място {drive}", "не се проверява")

# ---------- доклад ----------
print("==== DEMON ЗДРАВЕН ЧЕК", utcnow().strftime("%Y-%m-%d %H:%M UTC"), "====")
print("\n".join(rows))
print("=" * 50)
if problems:
    print(f"НЕРЕДНОСТИ ({len(problems)}):")
    for p in problems:
        print("  -", p)
else:
    print("Всичко е наред.")
sys.exit(1 if any(not p.startswith("(warn)") for p in problems) else 0)
