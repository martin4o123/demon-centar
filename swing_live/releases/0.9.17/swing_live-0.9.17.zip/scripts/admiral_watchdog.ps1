﻿# Admiral Swing Live — watchdog
# Стартира portable MT5 + engine ако не вървят. Уважава STOP.flag.
# Пише лог в D:\AIRobot\admiral_swing_live\logs\watchdog.log
# Нотификации през engine\notify.py (STOP.flag преходи + рестарти).

$Base    = "D:\AIRobot\admiral_swing_live"
$Product = "C:\Users\mgeor\AppData\Local\AdmiralBeta"
$StopFlag = Join-Path $Base "STOP.flag"
$LogDir  = Join-Path $Base "logs"
$LogFile = Join-Path $LogDir "watchdog.log"
$Terminal = Join-Path $Product "mt5_portable\terminal64.exe"
$EngineStart = Join-Path $Product "START_ADMIRAL_BETA.cmd"
$Heartbeat = Join-Path $Product "logs\beta_heartbeat.json"
$NotifyPy = Join-Path $Base "engine\notify.py"
$StateFile = Join-Path $LogDir ".watchdog_state"

New-Item -ItemType Directory -Force $LogDir | Out-Null

function Log($msg) {
    $line = "{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

function Notify($level, $category, $text) {
    try {
        & py -3.12 $NotifyPy --level $level --category $category --text $text 2>$null | Out-Null
    } catch {}
}

# --- STOP.flag преходи: съобщение само при СМЯНА на състоянието ---
$stopNow = Test-Path $StopFlag
$prevStop = $null
if (Test-Path $StateFile) {
    try { $prevStop = [bool]((Get-Content $StateFile -Raw | ConvertFrom-Json).stop) } catch {}
}
if ($null -ne $prevStop -and $prevStop -ne $stopNow) {
    if ($stopNow) {
        Notify warning status "STOP.flag създаден — търговията и рестартите са спрени ръчно."
        Log "STOP.flag преход: липсваше -> създаден."
    } else {
        Notify info status "STOP.flag премахнат — watchdog-ът отново пуска терминал/engine."
        Log "STOP.flag преход: имаше -> премахнат."
    }
}
@{ stop = $stopNow } | ConvertTo-Json | Set-Content -Path $StateFile -Encoding UTF8

if (Test-Path $StopFlag) {
    Log "STOP.flag наличен — нищо не пускам."
    exit 0
}

# 1. Терминал
$term = Get-Process terminal64 -ErrorAction SilentlyContinue
if (-not $term) {
    Log "Терминалът не върви — стартирам portable MT5."
    Start-Process $Terminal
    Start-Sleep 90
    Notify warning system "Watchdog: терминалът беше спрян — стартирах portable MT5."
} else {
    Log "Терминалът върви (PID $($term.Id -join ','))."
}

# 2. Продуктов engine — НЕ се стартира автоматично (2026-09-14):
# на демо замърсява S5 валидацията, на live €150 обем-проверката му отказва всичко.
# Ролята „пазач“ я изпълнява S5 engine + preflight. Ръчно: START_ADMIRAL_BETA.cmd.
Log "Продуктовият engine не се пуска от watchdog (осъзнат избор — виж OPS_MAP)."

Log "Цикъл приключен."
exit 0
