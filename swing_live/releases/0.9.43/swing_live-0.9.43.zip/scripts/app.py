import sys
import threading
import time
import os
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "dashboard"))

PORT = 5123
URL = f"http://127.0.0.1:{PORT}"
ICON = BASE / "assets" / "demon-desktop-icon.png"


def serve() -> None:
    try:
        sys.path.insert(0, str(BASE / "engine"))
        import integrity
        ok, msg = integrity.verify_manifest(BASE)
        if not ok:
            print(msg)
            try:
                import telemetry
                telemetry.send_event("tamper", msg, force=True)
            except Exception:
                pass
            os._exit(3)
        import app as dashboard
        dashboard.app.run(host="127.0.0.1", port=PORT, debug=False,
                          use_reloader=False, threaded=True)
    except SystemExit:
        raise
    except Exception as exc:
        try:
            import telemetry
            telemetry.send_event("dashboard_crash", repr(exc), force=True)
        except Exception:
            pass
        os._exit(1)


def main() -> int:
    t = threading.Thread(target=serve, daemon=True)
    t.start()
    for _ in range(50):
        time.sleep(0.2)
        import urllib.request
        try:
            urllib.request.urlopen(URL, timeout=1)
            break
        except Exception:
            pass
    try:
        import webview
        webview.create_window("DEMON — център за управление", URL,
                              width=1440, height=900, min_size=(1024, 700))
        webview.start()
    except Exception:
        import subprocess
        subprocess.Popen(["cmd", "/c", f"start {URL}"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
