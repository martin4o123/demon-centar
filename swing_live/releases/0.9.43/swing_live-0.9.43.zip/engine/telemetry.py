"""Telemetry - изпращане на събития (грешки) към собственика.

Клиентската машина криптира събитието с публичния RSA ключ на издателя
(chained: AES-256-GCM payload + RSA-OAEP wrap на AES ключа) и го качва в
скрито хранилище през GitHub Contents API. Само собственикът с частния ключ
може да прочете съдържанието. Липса на токен/мрежа/грешка при качване =
мълчалив пропуск - основната програма никога не пада заради телеметрия.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import time
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
STATE_DIR = BASE / "logs"
CONFIG_PATH = BASE / "config" / "telemetry.json"
PUBLIC_KEY_JSON = BASE / "tools" / "publisher_public_key.json"
RATE_FILE = STATE_DIR / "telemetry_rate.json"


def machine_id() -> str:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\Microsoft\Cryptography") as k:
            guid, _ = winreg.QueryValueEx(k, "MachineGuid")
        return hashlib.sha256(str(guid).encode()).hexdigest()[:12]
    except Exception:
        return "unknown"


def _publisher_public_key():
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    info = json.loads(PUBLIC_KEY_JSON.read_text(encoding="utf-8"))
    return rsa.RSAPublicNumbers(int(info["exponent"]),
                                int(info["modulus_hex"], 16)).public_key(
        serialization.Encoding.PEM)


def _seal(payload: bytes) -> bytes:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    key = AESGCM.generate_key(bit_length=256)
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, payload, None)
    wrapped = _publisher_public_key().encrypt(
        key, padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                          algorithm=hashes.SHA256(), label=None))
    return base64.b64encode(wrapped + nonce + ct)


def _rate_limited(kind: str) -> bool:
    try:
        state = json.loads(RATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        state = {}
    now = time.time()
    if now - float(state.get(kind, 0)) < 3600:
        return True
    state[kind] = now
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        tmp = RATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(state), encoding="utf-8")
        tmp.replace(RATE_FILE)
    except Exception:
        pass
    return False


def _upload(path: str, content_b64: str, token: str, repo: str) -> bool:
    body = json.dumps({"message": "telemetry", "content": content_b64,
                       "branch": "main"}).encode()
    req = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/contents/{path}",
        data=body, method="PUT",
        headers={"Authorization": f"Bearer {token}",
                 "Accept": "application/vnd.github+json",
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        return resp.status in (200, 201)


def _load_config() -> tuple[str, str]:
    cfg_path = BASE / "config" / "telemetry.json"
    token, repo = "", ""
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        token, repo = str(cfg.get("token") or ""), str(cfg.get("repo") or "")
    except Exception:
        pass
    if not token:
        try:
            cfg = json.loads((BASE / "config" / "telemetry_owner.json")
                             .read_text(encoding="utf-8"))
            token, repo = str(cfg.get("token") or token), str(cfg.get("repo") or repo)
        except Exception:
            pass
    return token, repo


def send_event(kind: str, text: str, force: bool = False) -> bool:
    try:
        if not force and _rate_limited(kind):
            return False
        if not PUBLIC_KEY_JSON.exists():
            return False
        token, repo = _load_config()
        if not token or not repo:
            return False
        event = {"v": 1, "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                 "machine": machine_id(), "kind": kind, "text": text[:6000]}
        sealed = _seal(json.dumps(event, ensure_ascii=False).encode("utf-8"))
        name = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')}_{uuid.uuid4().hex[:8]}.bin"
        return _upload(f"events/{machine_id()}/{name}",
                       sealed.decode("ascii"), token, repo)
    except Exception:
        return False
