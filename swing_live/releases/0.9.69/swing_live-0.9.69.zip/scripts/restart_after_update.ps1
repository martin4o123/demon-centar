param(
  [string]$Base,
  [int]$StartEngine = 0
)
# Restart after update: waits for update_client to finish, stops the OLD python
# processes of this installation (dashboard + engine), starts them with the NEW code.
# ASCII only. Runs detached; never kills processes from other folders.

Start-Sleep -Seconds 3
$escaped = [regex]::Escape($Base.TrimEnd('\'))
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" |
  Where-Object { $_.CommandLine -and $_.CommandLine.Contains($Base) } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 2

$py = $null
try { $py = (& py -3.12 -c "import sys;print(sys.executable)" 2>$null) } catch {}
if (-not $py) { try { $py = (Get-Command python -ErrorAction Stop).Source } catch {} }
if (-not $py) { exit 1 }
$pyw = Join-Path (Split-Path $py) "pythonw.exe"
if (-not (Test-Path $pyw)) { $pyw = $py }

$app = Join-Path $Base "scripts\app.py"
if (Test-Path $app) {
  Start-Process -FilePath $pyw -ArgumentList "`"$app`"" -WorkingDirectory $Base -WindowStyle Hidden
}
if ($StartEngine -eq 1) {
  $eng = Join-Path $Base "engine\engine_s5.py"
  if (Test-Path $eng) {
    Start-Process -FilePath $pyw -ArgumentList "`"$eng`"" -WorkingDirectory $Base -WindowStyle Hidden
  }
}
