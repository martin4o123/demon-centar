@echo off
rem ============================================================
rem  ROBOT - DEMON control center (client template v2, 0.9.68)
rem  No argument = start. Usage: ROBOT start|stop|status|update|test|uninstall
rem ============================================================
setlocal
set "BASE=%~dp0"
set "STOP=%BASE%STOP.flag"

if "%~1"=="stop" goto STOP
if "%~1"=="status" goto STATUS
if "%~1"=="update" goto UPDATE
if "%~1"=="test" goto TEST
if "%~1"=="uninstall" goto UNINST

:START
if exist "%STOP%" del "%STOP%"
call :FINDPY
if not defined PYEXE goto NOPY
"%PYEXE%" -c "import flask, MetaTrader5, cryptography, webview" 2>/dev/null
if errorlevel 1 (
  echo [ROBOT] Installing missing libraries, 1-2 min...
  "%PYEXE%" -m pip install --quiet --disable-pip-version-check flask MetaTrader5 cryptography pywebview
)
netstat -ano | find ":5123" | find "LISTENING" >/dev/null
if not errorlevel 1 goto OPEN
start "" "%PYEXE%" "%BASE%scripts\app.py"
timeout /t 10 >/dev/null
netstat -ano | find ":5123" | find "LISTENING" >/dev/null
if errorlevel 1 goto NODEAD
:OPEN
echo [ROBOT] DEMON started. Dashboard: http://127.0.0.1:5123
exit /b 0

:FINDPY
set "PYEXE="
where py >/dev/null 2>/dev/null
if not errorlevel 1 (
  for /f "delims=" %%i in ('py -3.12 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
)
if not defined PYEXE (
  for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%i"
)
exit /b 0

:NOPY
echo [ROBOT] ERROR: Python 3.12 not found on this computer!
echo [ROBOT] Run DEMON-Setup.exe again - it installs Python automatically.
pause
exit /b 1

:NODEAD
echo [ROBOT] No response. Retrying after library repair...
"%PYEXE%" -m pip install --quiet --disable-pip-version-check flask MetaTrader5 cryptography pywebview 2>/dev/null
start "" "%PYEXE%" "%BASE%scripts\app.py"
timeout /t 12 >/dev/null
netstat -ano | find ":5123" | find "LISTENING" >/dev/null
if not errorlevel 1 goto OK2
echo.
echo [ROBOT] Still not running. REAL ERROR (screenshot it and send to the seller):
echo -------------------------------------------------------------------
"%PYEXE%" "%BASE%scripts\app.py" 2^>^&1
echo -------------------------------------------------------------------
echo.
pause
exit /b 1
:OK2
echo [ROBOT] DEMON started. Dashboard: http://127.0.0.1:5123
exit /b 0

:STOP
echo stop > "%STOP%"
echo [ROBOT] STOP.flag created - no new trades or restarts.
exit /b 0

:STATUS
call :FINDPY
if not defined PYEXE goto NOPY
"%PYEXE%" "%BASE%scripts\preflight.py"
exit /b 0

:UPDATE
call :FINDPY
if not defined PYEXE goto NOPY
"%PYEXE%" "%BASE%scripts\update_client.py" --apply
exit /b 0

:TEST
call :FINDPY
if not defined PYEXE goto NOPY
"%PYEXE%" "%BASE%scripts\selftest.py"
exit /b 0

:UNINST
powershell -NoProfile -ExecutionPolicy Bypass -File "%BASE%uninstall.ps1"
exit /b 0
