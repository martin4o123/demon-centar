                       
"""Demon — център за управления: локален дашборд (само 127.0.0.1:5123).

Страници със sidebar навигация: Табло (/), Готовност (/readiness), Сигнали
(/journal), Съобщения (/messages), Настройки (/settings), Логове (/logs),
Легенда (/legend).
Чете: state.json, performance journal, logs\\decisions.jsonl,
logs\\messages.jsonl, deals_journal.jsonl, лог файлове, STOP.flag,
продуктов heartbeat. MT5 е САМО read-only. Настройките (/settings) записват
engine\\config.json (с backup в backups\\) и event в decisions.jsonl.
Никакви външни ресурси; авто-опресняване само на Табло (30 s), Готовност
(30 s) и Съобщения (15 s). Всяка липсваща стойност се показва като „няма данни“.
"""

from __future__ import annotations

import html
import json
import os
import secrets as _secrets
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

                                                                                 
                                                                           
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_orig_run, _orig_popen = subprocess.run, subprocess.Popen


def _run_hidden(*args, **kwargs):
    kwargs.setdefault("creationflags", _NO_WINDOW)
    return _orig_run(*args, **kwargs)


def _popen_hidden(*args, **kwargs):
    kwargs.setdefault("creationflags", _NO_WINDOW)
    return _orig_popen(*args, **kwargs)


subprocess.run, subprocess.Popen = _run_hidden, _popen_hidden

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from flask import Flask, Response, redirect, request, session, url_for

BASE_DIR = Path(__file__).resolve().parent.parent
LOGS_DIR = BASE_DIR / "logs"
CONFIG_DIR_DASH = BASE_DIR / "config"
GATING_FILE = CONFIG_DIR_DASH / "gating.json"
SESSION_SECRET_FILE = CONFIG_DIR_DASH / "session_secret"
try:
    sys.path.insert(0, str(BASE_DIR / "engine"))
    import mt5_locate as _mt5loc
except Exception:
    _mt5loc = None
_LOCAL = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
PRODUCT_DIR = _LOCAL / "AdmiralBeta"  # legacy слой — само ако съществува на ТАЗИ машина
PRODUCT_LOGS = PRODUCT_DIR / "logs"
BACKUP_LOG = BASE_DIR / "logs" / "backup.log"  # бекъп задачата го пише тук;
# липсва на клиенти -> редът е „не се изисква"
STOP_FLAG = BASE_DIR / "STOP.flag"
QUIET_FLAG = BASE_DIR / "QUIET.flag"
_detected_term = _mt5loc.detect_mt5_terminal() if _mt5loc else None
MT5_TERMINAL = _detected_term or (PRODUCT_DIR / "mt5_portable" / "terminal64.exe")
MT5_PORTABLE = MT5_TERMINAL.parent
_detected_files = _mt5loc.detect_mt5_files_dir() if _mt5loc else None
MT5_FILES = _detected_files or (MT5_PORTABLE / "MQL5" / "Files")
MT5_EXPERT_LOGS = MT5_PORTABLE / "MQL5" / "Logs"
BRIDGE_EX5 = MT5_PORTABLE / "MQL5" / "Experts" / "AdmiralBetaBridge.ex5"
BRIDGE_EX5_SOURCE = PRODUCT_DIR / "AdmiralBetaBridge.ex5"
NOTIFY_CONFIG = CONFIG_DIR_DASH / "notify.json"
NEWS_PROVIDER_CONFIG = CONFIG_DIR_DASH / "news_provider.json"
NEWS_CACHE_DEFAULT = CONFIG_DIR_DASH / "news_cache.json"
SECRETS_FILE = PRODUCT_DIR / "config" / "secrets.dat"
AGENT_LOG = PRODUCT_LOGS / "agent.log"
LOCAL_VERSION_FILE = BASE_DIR / "VERSION.json"
DRIVE_ROOT = Path(r"G:\My Drive\AdmiralAI_Shared")
DRIVE_RELEASE_FILE = DRIVE_ROOT / "swing_live" / "RELEASE.json"
STATE_JSON = LOGS_DIR / "state.json"
TASKS_CACHE = LOGS_DIR / "tasks_cache.json"
TASK_NAMES = ["AdmiralSwing_Watchdog", "AdmiralSwing_Autostart",
              "AdmiralSwing_Backup", "AdmiralSwing_Performance",
              "AdmiralSwing_Research"]
ENGINE_CONFIG = BASE_DIR / "engine" / "config.json"
BACKUPS_DIR = BASE_DIR / "backups"
ASSETS = BASE_DIR / "assets"

app = Flask(__name__)

NA = "няма данни"
BG_KIND = {"deposit": "депозит", "withdrawal": "теглене", "credit": "кредит"}


                                                       

def _import_engine_module(name: str):
    import importlib.util
    spec = importlib.util.spec_from_file_location(name, BASE_DIR / "engine" / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


licensing = _import_engine_module("licensing")
auth = _import_engine_module("auth")
integrity = _import_engine_module("integrity")
notify = _import_engine_module("notify")
market_guard = _import_engine_module("market_guard")


def _session_secret() -> str:
    CONFIG_DIR_DASH.mkdir(parents=True, exist_ok=True)
    if not SESSION_SECRET_FILE.exists():
        SESSION_SECRET_FILE.write_text(_secrets.token_hex(32), encoding="ascii")
    return SESSION_SECRET_FILE.read_text(encoding="ascii").strip()


app.secret_key = _session_secret()
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
)


def _csrf_token() -> str:
    """Per-session token for local control POST actions."""
    token = session.get("_csrf_token")
    if not token:
        token = _secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


def _valid_csrf() -> bool:
    expected = str(session.get("_csrf_token") or "")
    supplied = str(request.form.get("csrf_token") or "")
    return bool(expected and supplied and _secrets.compare_digest(expected, supplied))


def gating_enabled() -> bool:
    """config\\gating.json {enabled:bool} — escape hatch за собственика (dev/owner).
    По подразбиране False на машината на собственика; клиентите го включват."""
    try:
        return bool(json.loads(GATING_FILE.read_text(encoding="utf-8")).get("enabled", False))
    except Exception:
        return False


PUBLIC_PATHS = {"/login", "/register", "/forgot", "/reset", "/activate", "/logo.png"}


@app.before_request
def gate():
    if not gating_enabled():
        return None
    path = request.path
    if path in PUBLIC_PATHS:
        return None
    if not session.get("user_email"):
        return redirect(url_for("login_page", next=path))
    ok, _reason = licensing.is_licensed()
    if not ok and path != "/activate":
        return redirect(url_for("activate_page"))
    return None


                               

def e(x) -> str:
    return html.escape(str(x))


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out = []
    try:
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except Exception:
        return []
    return out


def parse_ts(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def fmt_dt(value) -> str:
    dt = parse_ts(value)
    if dt is None:
        return NA
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def fmt_money(x) -> str:
    if x is None:
        return NA
    try:
        return f"{float(x):.2f} €"
    except (TypeError, ValueError):
        return NA


def fmt_pct(x) -> str:
    if x is None:
        return NA
    try:
        return f"{float(x):.2f}%"
    except (TypeError, ValueError):
        return NA


def mt5_read(fn):
    try:
        import MetaTrader5 as mt5
        if not mt5.initialize():
            return None
        try:
            return fn(mt5)
        finally:
            mt5.shutdown()
    except Exception:
        return None


def get_account():
    def _q(mt5):
        ai = mt5.account_info()
        if ai is None:
            return None
        return {"balance": float(ai.balance), "equity": float(ai.equity),
                "trade_mode": int(ai.trade_mode), "server": str(ai.server),
                "margin_mode": int(ai.margin_mode), "currency": str(ai.currency),
                "leverage": int(ai.leverage), "login": int(ai.login)}
    return mt5_read(_q)


def get_positions() -> list[dict] | None:
    def _q(mt5):
        pos = mt5.positions_get()
        if pos is None:
            return []
        out = []
        for p in pos:
            out.append({
                "symbol": p.symbol,
                "dir": "покупка" if p.type == 0 else "продажба",
                "lots": float(p.volume),
                "open_price": float(p.price_open),
                "sl": float(p.sl),
                "tp": float(p.tp),
                "pnl": float(p.profit),
                "age_hours": round((time.time() - float(getattr(p, "time_msec", 0) or p.time * 1000) / 1000.0) / 3600.0, 1),
            })
        return out
    return mt5_read(_q)


def task_presence() -> dict | None:
    cache = read_json(TASKS_CACHE)
    fresh = (cache or {}).get("fetched_at", 0) > time.time() - 900
    if not fresh:
        tasks = {}
        ok_any = False
        for name in TASK_NAMES:
            try:
                r = subprocess.run(["schtasks", "/query", "/tn", name, "/fo", "csv", "/nh"],
                                   capture_output=True, timeout=20, text=True,
                                   encoding="utf-8", errors="replace")
                if r.returncode == 0 and "Ready" in (r.stdout or ""):
                    tasks[name] = "Ready"
                elif r.returncode == 0:
                    tasks[name] = "съществува"
                else:
                    tasks[name] = "липсва"
                ok_any = True
            except Exception:
                tasks[name] = None
        if ok_any:
            try:
                LOGS_DIR.mkdir(parents=True, exist_ok=True)
                tmp = TASKS_CACHE.with_suffix(".tmp")
                tmp.write_text(json.dumps({"fetched_at": time.time(), "tasks": tasks},
                                          ensure_ascii=False), encoding="utf-8")
                tmp.replace(TASKS_CACHE)
            except Exception:
                pass
            return tasks
        return (cache or {}).get("tasks")
    return cache.get("tasks")


def last_backup_time() -> str:
    if not BACKUP_LOG.exists():
        return "не се изисква"
    try:
        lines = [l.strip() for l in BACKUP_LOG.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
        if not lines:
            return NA
        last = lines[-1]
        if last.startswith("[") and "]" in last:
            stamp = last[1:last.index("]")]
            try:
                dt = datetime.strptime(stamp, "%Y%m%d_%H%M")
                return dt.strftime("%Y-%m-%d %H:%M")
            except ValueError:
                return last
        return last
    except Exception:
        return NA


def heartbeat_age_minutes() -> float | None:
    hb = read_json(PRODUCT_LOGS / "beta_heartbeat.json")
    if not hb:
        return None
    dt = parse_ts(hb.get("time_utc"))
    if dt is None:
        return None
    return round((datetime.now(timezone.utc) - dt).total_seconds() / 60.0, 1)


                                      

def sparkline_svg() -> str:
    daily = read_json(LOGS_DIR / "equity_daily.json", {}) or {}
    points = []
    for day in sorted(daily):
        v = (daily[day] or {}).get("trading_equity_clean")
        if isinstance(v, (int, float)):
            points.append((day, float(v)))
    if len(points) < 2:
        return f'<p class="na">{NA}</p>'
    points = points[-60:]
    w, h, pad = 620, 130, 10
    vals = [v for _, v in points]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1.0
    step = (w - 2 * pad) / (len(points) - 1)
    xy = " ".join(
        f"{pad + i * step:.1f},{h - pad - (v - lo) / span * (h - 2 * pad):.1f}"
        for i, (_, v) in enumerate(points)
    )
    color = "#30a46c" if vals[-1] >= vals[0] else "#e5484d"
    return (
        f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img" '
        f'aria-label="Чист търговски equity" style="max-width:100%;height:auto">'
        f'<rect x="0" y="0" width="{w}" height="{h}" fill="#10131a" rx="8"/>'
        f'<polyline points="{xy}" fill="none" stroke="{color}" stroke-width="2"/>'
        f'<text x="{pad}" y="{pad + 8}" fill="#8b93a7" font-size="11">{hi:.2f} €</text>'
        f'<text x="{pad}" y="{h - pad - 2}" fill="#8b93a7" font-size="11">{lo:.2f} €</text>'
        f'<text x="{w - pad}" y="{h - pad - 2}" fill="#8b93a7" font-size="11" text-anchor="end">'
        f'{e(points[-1][0])}</text></svg>'
    )


def render_checks(checks) -> str:
    rows = []
    for c in checks or []:
        mark = "✅" if c.get("passed") else "❌"
        rows.append(
            f'<li><span class="mark">{mark}</span> '
            f'<b>{e(c.get("name", NA))}</b> — <span class="detail">{e(c.get("detail", NA))}</span></li>'
        )
    return "<ul class='checks'>" + "".join(rows) + "</ul>" if rows else ""


def render_decision_block(title: str, when: str, decision: str, reason: str,
                          symbols, extra="") -> str:
    parts = [f'<div class="card"><h3>{e(title)}</h3>']
    parts.append(f'<p class="muted">цикъл: {e(fmt_dt(when))} · решение: '
                 f'<b class="badge">{e(decision or NA)}</b></p>')
    if reason:
        parts.append(f'<p class="reason">{e(reason)}</p>')
    for s in symbols or []:
        result = s.get("result", NA)
        score = s.get("signal_score")
        parts.append(
            f'<div class="sym"><span class="symname">{e(s.get("symbol", NA))}</span> '
            f'<span class="badge">{e(result)}</span>'
            + (f' <span class="muted">скор {e(score)}/100</span>' if score is not None else "")
            + f'<p class="reason">{e(s.get("reason", ""))}</p>'
            + render_checks(s.get("checks"))
            + "</div>"
        )
    if extra:
        parts.append(extra)
    parts.append("</div>")
    return "".join(parts)


def section_account() -> str:
    acc = get_account()
    daily = read_json(LOGS_DIR / "equity_daily.json", {}) or {}
    today_key = max(daily.keys()) if daily else None
    today = daily.get(today_key) if today_key else None

    flows = read_jsonl(LOGS_DIR / "cashflows.jsonl")
    flow_rows = []
    for f in reversed(flows[-30:]):
        kind = BG_KIND.get(f.get("kind"), f.get("kind", NA))
        cls = {"депозит": "dep", "теглене": "wd", "кредит": "cr"}.get(kind, "cr")
        amt = f.get("amount")
        try:
            amt_txt = f"{float(amt):+.2f} €"
        except (TypeError, ValueError):
            amt_txt = NA
        flow_rows.append(
            f'<tr><td>{e(f.get("date", NA))}</td>'
            f'<td><span class="badge {cls}">{e(kind)}</span></td>'
            f'<td class="num">{e(amt_txt)}</td>'
            f'<td class="muted">{e(f.get("comment", ""))}</td></tr>')
    flows_html = (
        "<table><tr><th>дата</th><th>вид</th><th>сума</th><th>бележка</th></tr>"
        + "".join(flow_rows) + "</table>") if flow_rows else f'<p class="na">{NA}</p>'

    return f"""
<div class="card">
  <h3>Сметка</h3>
  <table class="kv">
    <tr><td>Баланс (MT5)</td><td class="num">{fmt_money((acc or {}).get("balance"))}</td></tr>
    <tr><td>Equity (MT5)</td><td class="num">{fmt_money((acc or {}).get("equity"))}</td></tr>
    <tr><td>Чист търговски equity</td><td class="num">{fmt_money((today or {}).get("trading_equity_clean"))}</td></tr>
    <tr><td>Връх (чист)</td><td class="num">{fmt_money((today or {}).get("peak_clean"))}</td></tr>
    <tr><td>Drawdown (чист)</td><td class="num">{fmt_pct((today or {}).get("dd_clean_pct"))}</td></tr>
    <tr><td>Депозити от понеделник</td><td class="num">{fmt_money((today or {}).get("deposits_wtd"))}</td></tr>
    <tr><td>Тегления от понеделник</td><td class="num">{fmt_money((today or {}).get("withdrawals_wtd"))}</td></tr>
  </table>
  <p class="muted">Снимка: {e(today_key or NA)} (дневен журнал, UTC) — депозитите/тегленията
  НЕ изкривяват чистата търговска крива.</p>
  {sparkline_svg()}
  <h4>Парични потоци</h4>
  {flows_html}
</div>"""


def section_position() -> str:
    positions = get_positions()
    if positions is None:
        body = f'<p class="na">{NA} (MT5 недостъпен)</p>'
    elif not positions:
        body = '<p class="ok">няма отворена позиция</p>'
    else:
                                                                               
        prot_by_sym = {}
        st = read_json(STATE_JSON) or {}
        for rec in ((st.get("position") or {}).get("all") or []):
            prot_by_sym[rec.get("symbol")] = rec
        rows = []
        for p in positions:
            rec = prot_by_sym.get(p["symbol"]) or {}
            r = rec.get("r")
            prot = rec.get("protection") or "—"
            prot_cls = "pos" if (prot and ("trail" in prot or "breakeven" in prot)) else "na"
            rows.append(
                f'<tr><td>{e(p["symbol"])}</td><td>{e(p["dir"])}</td>'
                f'<td class="num">{p["lots"]:.2f}</td>'
                f'<td class="num">{p["open_price"]:.5f}</td>'
                f'<td class="num">{p["sl"]:.5f}</td>'
                f'<td class="num">{p["tp"]:.5f}</td>'
                f'<td class="num {"neg" if p["pnl"] < 0 else "pos"}">{p["pnl"]:+.2f} €</td>'
                f'<td class="num">{f"{r:+.2f}R" if r is not None else NA}</td>'
                f'<td class="{prot_cls}">{e(prot)}</td>'
                f'<td class="num">{p["age_hours"]:.1f} ч</td></tr>')
        body = ("<table><tr><th>символ</th><th>посока</th><th>лотове</th><th>отваряне</th>"
                "<th>SL</th><th>TP</th><th>плаващ P&amp;L</th><th>резултат</th>"
                "<th>защита на печалбата</th><th>възраст</th></tr>"
                + "".join(rows) + "</table>")
    return f'<div class="card"><h3>Позиции</h3>{body}</div>'


def robot_state_card() -> str:
    state = read_json(STATE_JSON) or {}
    guards = state.get("guards") or {}
    mode = state.get("mode") or NA
    action = state.get("last_action") or NA
    last_cycle = state.get("last_cycle_utc")
    cycle_dt = parse_ts(last_cycle)
    if cycle_dt is not None:
        mins = round((datetime.now(timezone.utc) - cycle_dt).total_seconds() / 60.0, 1)
        cycle_txt = f"{fmt_dt(last_cycle)} (преди {mins} мин)"
        cycle_ok = mins < 15
    else:
        cycle_txt = NA
        cycle_ok = False
    paused = bool(guards.get("paused"))
    stop = STOP_FLAG.exists()
    rows = [
        ("Режим", f'<span class="badge {"errb" if mode == "live" else ""}">{e(mode)}</span>'),
        ("Тип сметка", e(state.get("account_mode") or NA)),
        ("Последен цикъл", f'{"✅" if cycle_ok else "❌"} {e(cycle_txt)}'),
        ("Последно действие", f'<span class="badge">{e(action)}</span>'),
        ("STOP.flag", '<span class="badge stopb">АКТИВЕН — спира стартирането</span>'
                      if stop else '<span class="badge okb">не е активен</span>'),
        ("Пауза", (f'<span class="badge wdb">паузиран</span> '
                   f'<span class="muted">{e(guards.get("paused_reason") or "")}</span>' if paused
                   else '<span class="badge okb">не</span>')),
        ("Поредни загуби", e(guards.get("consec_losses", NA))),
        ("Drawdown от връх", e(fmt_pct(guards.get("dd_from_peak_pct")))),
        ("News blackout", '<span class="badge wdb">активен</span>' if guards.get("news_blackout")
                         else '<span class="badge">не</span>'),
        ("Пазител", (f"{e(str(guards.get('guard_geo')))} · {e(str(guards.get('guard_velocity')))}"
                     + (' <span class="badge wdb">блекаут</span>'
                        if guards.get("guard_blackout_event") else "")
                     + (f' <span class="muted">риск x{float(guards.get("guard_risk_mult")):.2g}</span>'
                        if float(guards.get("guard_risk_mult") or 1.0) < 1.0 else ""))
                    if guards.get("guard_geo") is not None else e(NA)),
    ]
    trs = "".join(f'<tr><td>{e(k)}</td><td>{v}</td></tr>' for k, v in rows)
    return f'<div class="card"><h3>Състояние на робота</h3><table class="kv">{trs}</table></div>'


def last_decision_card() -> str:
    lines = read_jsonl(LOGS_DIR / "decisions.jsonl")
    cycle_lines = [l for l in lines if l.get("action")]
    if not cycle_lines:
        return (f'<div class="card"><h3>Последно решение</h3><p class="na">{NA} '
                f'(още няма записи в logs/decisions.jsonl)</p></div>')
    last = cycle_lines[-1]
    action = last.get("action") or {}
    symbols = last.get("symbols") or last.get("markets") or []
    return render_decision_block(
        "Последно решение на engine",
        last.get("ts") or last.get("time_utc"),
        action.get("type") or last.get("decision"),
        action.get("reason") or last.get("reason"), symbols)


                                                              

def bridge_instances_today() -> set[str]:
    """Активни графики с bridge: '(SYMBOL,TF)' стартове от последните 6 часа
    в днешния Expert лог. Един bridge пише статус за много символи —
    файловете не са мярка за брой графики."""
    today = MT5_EXPERT_LOGS / f"{datetime.now().strftime('%Y%m%d')}.log"
    if not today.exists():
        return set()
    try:
        text = today.read_bytes().decode("utf-16-le", errors="replace")
    except OSError:
        return set()
    import re
    cutoff = datetime.now().strftime("%H:%M:%S")
    cutoff_dt = datetime.now() - timedelta(hours=6)
    found: set[str] = set()
    for m in re.finditer(r"(\d{2}:\d{2}:\d{2})\S*\s+AdmiralBetaBridge \(([^)]+)\)\s+Admiral Bridge \S+ started", text):
        try:
            t = datetime.strptime(m.group(1), "%H:%M:%S").replace(
                year=cutoff_dt.year, month=cutoff_dt.month, day=cutoff_dt.day)
        except ValueError:
            continue
        if t >= cutoff_dt:
            found.add(m.group(2))
    return found


def bridge_symbols_live() -> set[str]:
    """Символи с жив статус файл (≤3 мин) — за справка, не за броене на графики."""
    cutoff = time.time() - 180
    found: set[str] = set()
    for p in MT5_FILES.glob("mt5_status_*.txt"):
        try:
            if p.stat().st_mtime < cutoff:
                continue
            sym = p.stem.replace("mt5_status_", "").strip().upper()
            if sym:
                found.add(sym)
        except OSError:
            continue
    return found


def newest_status_age_seconds() -> float | None:
    try:
        newest = max((p.stat().st_mtime for p in MT5_FILES.glob("mt5_status_*.txt")),
                     default=None)
    except Exception:
        return None
    return None if newest is None else max(0.0, time.time() - newest)


def windows_boot_time() -> datetime | None:
                                                                
                                                
    try:
        r = subprocess.run(["wmic", "os", "get", "lastbootuptime"],
                           capture_output=True, timeout=20, text=True,
                           encoding="utf-8", errors="replace")
        if r.returncode == 0:
            for line in r.stdout.splitlines():
                line = line.strip()
                if line and line[0].isdigit() and len(line) >= 14:
                    return datetime.strptime(line[:14], "%Y%m%d%H%M%S")
    except Exception:
        pass
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "$ms=[System.Environment]::TickCount64; "
             "(Get-Date).AddMilliseconds(-$ms).ToString('yyyy-MM-dd HH:mm:ss')"],
            capture_output=True, timeout=20, text=True,
            encoding="utf-8", errors="replace")
        if r.returncode == 0 and r.stdout.strip():
            return datetime.strptime(r.stdout.strip(), "%Y-%m-%d %H:%M:%S")
    except Exception:
        pass
    return None


def version_tuple(v) -> tuple:
    parts = []
    for chunk in str(v).split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def settings_checklist() -> list[tuple[str, str, str]]:
    import datetime as dt_mod
    rows: list[tuple[str, str, str]] = []
    legacy = _legacy_product_present()

    if not legacy:
                                                                            
                                                                              
        rows.append(("ℹ️", "Bridge инстанции",
                     "не се изисква — чиста инсталация (няма стар AdmiralBeta слой)"))
        rows.append(("ℹ️", "Статус файлове (mt5_status_*.txt)",
                     "не се изисква — bridge-ът е част от стария слой"))
    else:
                                                                      
        inst = bridge_instances_today()
        if len(inst) == 1:
            rows.append(("✅", "Bridge инстанции", f"точно 1 графика ({e(sorted(inst)[0])})"))
        elif len(inst) > 1:
            rows.append(("❌", "Bridge инстанции",
                         f"{len(inst)} графики: {e(', '.join(sorted(inst)))} — "
                         "премахни от излишните (остави само GBPUSD H1)"))
        else:
            rows.append(("⚠️", "Bridge инстанции",
                         "0 живи инстанции — bridge-ът не докладва (провери Algo Trading и прикачването на GBPUSD H1)"))

                                                           
        age = newest_status_age_seconds()
        market_open = datetime.now().weekday() < 5
        if age is None:
            rows.append(("⚠️", "Статус файлове (mt5_status_*.txt)",
                         "няма такива файлове — bridge-ът не публикува"))
        elif market_open:
            if age < 60:
                rows.append(("✅", "Статус файлове", f"най-нов файл преди {int(age)} s (пазар отворен)"))
            else:
                rows.append(("❌", "Статус файлове",
                             f"най-нов файл преди {int(age // 60)} мин при отворен пазар — "
                             "провери bridge/терминала"))
        else:
            rows.append(("ℹ️", "Статус файлове",
                         f"уикенд — най-нов файл преди {int(age // 60)} мин; при отворен пазар "
                         "пн-пт се очаква <60 s"))

                  
    if STOP_FLAG.exists():
        rows.append(("⚠️", "STOP.flag",
                     "АКТИВЕН — търговията/рестартите са спрени ръчно (нормално при поддръжка)"))
    else:
        rows.append(("✅", "STOP.flag", "не е активен"))

                               
    acc = get_account()
    if not acc:
        rows.append(("⚠️", "Сметка (MT5)", "няма данни — MT5 недостъпен"))
    else:
        problems = []
        if acc.get("trade_mode") != 2:
            problems.append("НЕ е REAL сметка")
        if "AdmiralsGroup" not in (acc.get("server") or ""):
            problems.append(f"сървърът е {acc.get('server')} (очаква се AdmiralsGroup)")
        if acc.get("margin_mode") != 2:
            problems.append("margin_mode НЕ е hedging (netting!)")
        icon = "❌" if problems else "✅"
        cur = acc.get("currency", "?")
        detail = (f"REAL · {e(acc.get('server', '?'))} · hedging · {e(cur)} · "
                  f"ливъридж 1:{acc.get('leverage', '?')} · login …{str(acc.get('login', ''))[-4:]}")
        if cur != "EUR":
            if not problems:
                icon = "⚠️"
            detail += " · валутата НЕ е EUR"
        if problems:
            detail += " — " + "; ".join(e(p) for p in problems)
        rows.append((icon, "Сметка", detail))

                                                           
    if legacy:
        hb_min = heartbeat_age_minutes()
        if hb_min is None:
            rows.append(("⚠️", "Heartbeat на продукта", NA))
        elif hb_min < 15:
            rows.append(("✅", "Heartbeat на продукта", f"свеж — преди {hb_min} мин"))
        else:
            rows.append(("❌", "Heartbeat на продукта", f"СТАР — преди {hb_min} мин"))

                              
    state = read_json(STATE_JSON)
    last_cycle = (state or {}).get("last_cycle_utc")
    if not last_cycle:
        rows.append(("ℹ️", "Моят engine (state.json)",
                     "няма пуснат търгуващ engine (очаква се докато няма одобрена стратегия)"))
    else:
        cdt = parse_ts(last_cycle)
        mins = round((datetime.now(timezone.utc) - cdt).total_seconds() / 60.0, 1) if cdt else None
        if mins is not None and mins < 15:
            rows.append(("✅", "Моят engine", f"цикъл преди {mins} мин"))
        else:
            rows.append(("❌", "Моят engine",
                         f"последен цикъл {fmt_dt(last_cycle)} ({mins} мин назад)"))

                       
    raw = last_backup_time()
    backup_fresh = False
    try:
        lines = [l.strip() for l in BACKUP_LOG.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
        stamp = lines[-1][1:lines[-1].index("]")] if lines and lines[-1].startswith("[") else None
        bdt = datetime.strptime(stamp, "%Y%m%d_%H%M") if stamp else None
        backup_fresh = bdt is not None and (datetime.now() - bdt) < dt_mod.timedelta(hours=25)
    except Exception:
        pass
    if backup_fresh:
        rows.append(("✅", "Последен бекъп", f"{e(raw)} (<25 ч)"))
    else:
        rows.append(("❌", "Последен бекъп", f"{e(raw)} — по-стар от 25 ч или неразпознат"))

                                                                                    
    local_ver = (read_json(LOCAL_VERSION_FILE) or {}).get("version")
    if not _is_owner_machine():
        remote_ver = None
        try:
            req = urllib.request.Request(
                "https://martin4o123.github.io/demon-centar/swing_live/RELEASE.json",
                headers={"User-Agent": "demon-panel/1"})
            with urllib.request.urlopen(req, timeout=10) as r:
                remote_ver = json.loads(r.read().decode("utf-8-sig")).get("version")
        except Exception:
            pass
        if remote_ver and local_ver and version_tuple(remote_ver) > version_tuple(local_ver):
            rows.append(("⬆️", "Версия",
                         f"наличен ъпдейт {e(remote_ver)} (локално {e(local_ver)}) — бутонът „Ъпдейт“ в Настройки"))
        else:
            rows.append(("✅", "Версия", f"актуална версия {e(local_ver or '?')}"))
    else:
        drive_rel = read_json(DRIVE_RELEASE_FILE)
        drive_ver = (drive_rel or {}).get("version")
        if not drive_rel:
            rows.append(("⚠️", "Версия (ъпдейт канал)",
                         "Drive swing_live\\RELEASE.json недостъпен — провери Google Drive for Desktop"))
        elif not local_ver:
            rows.append(("⚠️", "Версия", "няма локална VERSION.json"))
        elif version_tuple(drive_ver) > version_tuple(local_ver):
            rows.append(("⬆️", "Версия",
                         f"наличен ъпдейт {e(drive_ver)} (локално {e(local_ver)}) — ROBOT update"))
        else:
            rows.append(("✅", "Версия", f"актуална версия {e(local_ver)}"))


    if not _is_owner_machine():
        rows.append(("ℹ️", "Google Drive канал", "не се изисква — клиентите се обновяват през сайта"))
    elif DRIVE_ROOT.exists():
        rows.append(("✅", "Google Drive канал", e(str(DRIVE_ROOT))))
    else:
        rows.append(("❌", "Google Drive канал",
                     "G:\\My Drive\\AdmiralAI_Shared е недостъпен — провери Google Drive for Desktop"))

                                
    try:
        free = shutil.disk_usage("C:\\").free
        if free > 2 * 1024 ** 3:
            rows.append(("✅", "Диск C:", f"свободни {free / 1024 ** 3:.1f} GB (>2 GB)"))
        else:
            rows.append(("❌", "Диск C:", f"свободни {free / 1024 ** 3:.1f} GB — под 2 GB!"))
    except Exception:
        rows.append(("⚠️", "Диск C:", NA))

                  
    secrets_ok = SECRETS_FILE.exists()
    ok_recent = err_recent = 0
    last_line = ""
    try:
        cutoff = datetime.now() - dt_mod.timedelta(hours=24)
        for line in AGENT_LOG.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if len(line) < 10 or line[4:5] != "-":
                continue
            try:
                ldt = datetime.strptime(line[:19], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                continue
            last_line = line
            if ldt >= cutoff:
                if "Telegram не отговори" in line:
                    err_recent += 1
                else:
                    ok_recent += 1
    except Exception:
        pass
    if not _is_owner_machine():
        rows.append(("ℹ️", "Telegram", "по желание — Настройки → Telegram известия"))
    elif not secrets_ok:
        rows.append(("❌", "Telegram", f"липсва {e(str(SECRETS_FILE))}"))
    elif ok_recent > 0 and ok_recent >= err_recent:
        rows.append(("✅", "Telegram",
                     f"secrets.dat OK · последни 24 ч: {ok_recent} успеха / {err_recent} грешки"))
    else:
        detail = "провери мрежата/токена"
        if last_line:
            detail += f" — последен ред: {e(last_line[:80])}"
        rows.append(("⚠️", "Telegram",
                     f"{detail} (24 ч: {ok_recent} успеха / {err_recent} „Telegram не отговори“)"))

                
    boot = windows_boot_time()
    if boot is None:
        rows.append(("⚠️", "Uptime на машината", NA))
    else:
        age_days = (datetime.now() - boot).total_seconds() / 86400.0
        if age_days < 1:
            rows.append(("⚠️", "Uptime на машината",
                         f"заредена на {e(boot.strftime('%Y-%m-%d %H:%M'))} — след рестарт се "
                         "пуска само при логин; провери AdmiralSwing_Autostart"))
        else:
            rows.append(("✅", "Uptime на машината",
                         f"заредена на {e(boot.strftime('%Y-%m-%d %H:%M'))} "
                         f"({age_days:.1f} дни)"))

    return rows


def backup_is_fresh() -> bool:
    if not BACKUP_LOG.exists():
        return True
    import datetime as dt_mod
    try:
        lines = [l.strip() for l in BACKUP_LOG.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
        stamp = lines[-1][1:lines[-1].index("]")] if lines and lines[-1].startswith("[") else None
        bdt = datetime.strptime(stamp, "%Y%m%d_%H%M") if stamp else None
        return bdt is not None and (datetime.now() - bdt) < dt_mod.timedelta(hours=25)
    except Exception:
        return False


def _legacy_product_present() -> bool:
    """Старият AdmiralBeta слой (bridge EA, продуктов heartbeat, mt5_status файлове).
    На чисти клиентски инсталации го няма — S5 двигателят говори с MT5 директно
    през Python API и НЕ се нуждае от bridge. Проверките за него са 'не се изисква'."""
    return PRODUCT_DIR.exists()


def _legacy_pensioned() -> bool:
    """Старият слой е пенсиониран (стартовите му скриптове са DISABLED) — проверките
    за него са информативни, не аларми. Пази се от грешни ❌ на машината на собственика."""
    try:
        return any(PRODUCT_DIR.glob("START_ADMIRAL_BETA.cmd.DISABLED*"))
    except OSError:
        return False


def system_checks() -> list[dict]:
    """Компактни проверки за Таблото: bridge, heartbeat, статус файлове, бекъп."""
    checks: list[dict] = []
    legacy = _legacy_product_present()

    if not legacy:
        checks.append({"passed": True, "name": "Bridge инстанции",
                       "detail": "не се изисква — чиста инсталация (S5 говори с MT5 директно)"})
        checks.append({"passed": True, "name": "Продуктов heartbeat",
                       "detail": "не се изисква — старият слой не е инсталиран"})
        checks.append({"passed": True, "name": "Статус файлове (mt5_status_*.txt)",
                       "detail": "не се изисква — старият слой не е инсталиран"})
    elif _legacy_pensioned():
        checks.append({"passed": True, "name": "Bridge инстанции",
                       "detail": "не се изисква — старият слой е пенсиониран (S5 говори с MT5 директно)"})
        checks.append({"passed": True, "name": "Продуктов heartbeat",
                       "detail": "не се изисква — пенсиониран от 15.09, execution обезвреден 29.09"})
        checks.append({"passed": True, "name": "Статус файлове (mt5_status_*.txt)",
                       "detail": "не се изисква — пенсиониран слой"})
    else:
        inst = bridge_instances_today()
        if len(inst) == 1:
            checks.append({"passed": True, "name": "Bridge инстанции",
                           "detail": f"точно 1 ({sorted(inst)[0]})"})
        elif len(inst) > 1:
            checks.append({"passed": False, "name": "Bridge инстанции",
                           "detail": f"{len(inst)} инстанции: {', '.join(sorted(inst))}"})
        else:
            checks.append({"passed": False, "name": "Bridge инстанции",
                           "detail": "0 в днешния лог — не е прикачен на графика"})

        hb_min = heartbeat_age_minutes()
        if hb_min is None:
            checks.append({"passed": False, "name": "Продуктов heartbeat", "detail": NA})
        elif hb_min < 15:
            checks.append({"passed": True, "name": "Продуктов heartbeat",
                           "detail": f"преди {hb_min} мин"})
        else:
            checks.append({"passed": False, "name": "Продуктов heartbeat",
                           "detail": f"СТАР — преди {hb_min} мин"})

        age = newest_status_age_seconds()
        market_open = datetime.now().weekday() < 5
        if age is None:
            checks.append({"passed": False, "name": "Статус файлове (mt5_status_*.txt)",
                           "detail": "няма такива файлове"})
        elif market_open and age >= 60:
            checks.append({"passed": False, "name": "Статус файлове",
                           "detail": f"най-нов преди {int(age // 60)} мин при отворен пазар"})
        elif market_open:
            checks.append({"passed": True, "name": "Статус файлове",
                           "detail": f"най-нов преди {int(age)} s (пазар отворен)"})
        else:
            checks.append({"passed": True, "name": "Статус файлове",
                           "detail": f"уикенд — преди {int(age // 60)} мин"})

    raw = last_backup_time()
    if not BACKUP_LOG.exists():
        checks.append({"passed": True, "name": "Последен бекъп",
                       "detail": "не се изисква — задачата за бекъп не е създавана на тази машина"})
    elif backup_is_fresh():
        checks.append({"passed": True, "name": "Последен бекъп", "detail": f"{raw} (<25 ч)"})
    else:
        checks.append({"passed": False, "name": "Последен бекъп",
                       "detail": f"{raw} — по-стар от 25 ч или неразпознат"})
    return checks


def system_card() -> str:
    hb = read_json(PRODUCT_LOGS / "beta_heartbeat.json", {}) or {}
    legacy = _legacy_product_present()
    tasks = task_presence() if legacy else None
    if tasks:
        task_rows = "".join(
            f'<tr><td>{e(name)}</td><td>{"✅" if v in ("Ready", "съществува") else ("❌" if v == "липсва" else "?")} {e(v or NA)}</td></tr>'
            for name, v in tasks.items())
        tasks_html = f"<table>{task_rows}</table>"
    elif not legacy:
        tasks_html = '<p class="na">не се изисква — задачите се създават само при пълна инсталация</p>'
    else:
        tasks_html = f'<p class="na">{NA}</p>'
    if legacy and _legacy_pensioned():
        kv = f"""<table class="kv">
    <tr><td>Стар слой (AdmiralBeta)</td><td>пенсиониран от 15.09 — live авторизацията е отнета,
      режимът е demo; не се изисква от S5</td></tr>
    <tr><td>Последен бекъп</td><td>{e(last_backup_time())}</td></tr>
  </table>"""
    elif legacy:
        kv = f"""<table class="kv">
    <tr><td>Режим на продукта</td><td>{e(hb.get("account_mode", NA))} ·
      execution_enabled={e(hb.get("execution_enabled", NA))} · риск {e(hb.get("risk_percent", NA))}%</td></tr>
    <tr><td>Последен бекъп</td><td>{e(last_backup_time())}</td></tr>
  </table>"""
    else:
        kv = f"""<table class="kv">
    <tr><td>Последен бекъп</td><td>не се изисква</td></tr>
  </table>"""
    return f"""
<div class="card">
  <h3>Системни проверки</h3>
  {render_checks(system_checks())}
  {kv}
  <h4>Task Scheduler задачи</h4>
  {tasks_html}
</div>"""


                                                                             

                                                                               
_SOCIAL_DIR_BG = {"LONG": "SELL", "SHORT": "BUY"}


def _readiness_rows() -> list[dict]:
    """Връща 16 реда: {key,title,status(ok|fail|warn),problem,fix,detail}.
    Използва се и от /readiness, и от компактната карта на Таблото."""
    rows: list[dict] = []

               
    try:
        lic_ok, lic_reason = licensing.is_licensed()
    except Exception:
        lic_ok, lic_reason = False, "грешка при проверката"
    if lic_ok:
        rows.append({"key": "license", "title": "Лиценз", "status": "ok",
                     "detail": "лицензът е активен"})
    else:
        rows.append({"key": "license", "title": "Лиценз", "status": "fail",
                     "problem": f"лицензът не е активен ({lic_reason})",
                     "fix": "Въведи ключа за активация (Настройки)"})

                         
    if STOP_FLAG.exists():
        rows.append({"key": "stop_flag", "title": "STOP.flag липсва", "status": "fail",
                     "problem": "STOP.flag е активен — стартирането е спряно ръчно",
                     "fix": "Натисни бутона „Пусни системата“ — STOP.flag се премахва "
                            "автоматично и роботът стартира.",
                     "fix_action": "start"})
    else:
        rows.append({"key": "stop_flag", "title": "STOP.flag липсва", "status": "ok",
                     "detail": "не е активен"})

                                                       
    try:
        state_age = time.time() - STATE_JSON.stat().st_mtime
    except Exception:
        state_age = None
    if state_age is not None and state_age < 20 * 60:
        rows.append({"key": "robot", "title": "Роботът (S5) върви", "status": "ok",
                     "detail": f"state.json обновен преди {int(state_age // 60)} мин"})
    else:
        age_txt = NA if state_age is None else f"преди {int(state_age // 60)} мин"
        eng_hint = ""
        try:
            _ln = (LOGS_DIR / "engine_s5.log").read_text(
                encoding="utf-8", errors="replace").splitlines()
            _errs = [l for l in _ln if "ERROR" in l or "SafetyError" in l]
            if _errs:
                eng_hint = _errs[-1][-160:]
        except Exception:
            pass
        rows.append({"key": "robot", "title": "Роботът (S5) върви", "status": "fail",
                     "problem": (f"няма свеж запис в state.json ({age_txt})"
                                 + (f" — последна грешка на двигателя: {eng_hint}"
                                    if eng_hint else "")),
                     "fix": "Настройки → Система → „Рестартирай двигателя“. "
                            "Ако пак спре — причината е на страница Логове."})

                             
    mt5_running = False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq terminal64.exe", "/NH"],
                           capture_output=True, timeout=20, text=True)
        mt5_running = "terminal64.exe" in (r.stdout or "")
    except Exception:
        mt5_running = False
    if mt5_running:
        rows.append({"key": "mt5", "title": "MT5 терминалът върви", "status": "ok",
                     "detail": "terminal64.exe е в паметта"})
    else:
        rows.append({"key": "mt5", "title": "MT5 терминалът върви", "status": "fail",
                     "problem": "terminal64.exe не върви",
                     "fix": "Стартирай MT5 (Настройки → Bridge → бутон Стартирай MT5)"})

                                    
    cfg = read_json(ENGINE_CONFIG, {}) or {}
    mode = str(cfg.get("mode") or "").strip().lower()
    acc = get_account()
    if not acc:
        rows.append({"key": "account", "title": "Сметката отговаря на режима",
                     "status": "fail",
                     "problem": "няма връзка с MT5 — терминалът не е логнат",
                     "fix": "Терминалът не е логнат — пусни MT5 и се логни на сметката"})
    elif mode == "demo":
        demo_login = cfg.get("demo_login")
        if demo_login is not None and str(acc.get("login")) == str(demo_login):
            rows.append({"key": "account", "title": "Сметката отговаря на режима",
                         "status": "ok",
                         "detail": f"режим demo · логнат е login {acc.get('login')}"})
        else:
            rows.append({"key": "account", "title": "Сметката отговаря на режима",
                         "status": "fail",
                         "problem": (f"режимът е demo, но в MT5 е логнат login "
                                     f"{acc.get('login')} (очаква се {demo_login})"),
                         "fix": "Логни се на демо сметката в MT5"})
    elif mode == "live":
        live_server = str(cfg.get("live_server") or "")
        srv = str(acc.get("server") or "")
        is_real = int(acc.get("trade_mode", -1)) == 2
        if live_server and live_server.lower() in srv.lower():
            rows.append({"key": "account", "title": "Сметката отговаря на режима",
                         "status": "ok",
                         "detail": f"режим live · сървър {srv}"})
        elif not live_server and is_real:
            rows.append({"key": "account", "title": "Сметката отговаря на режима",
                         "status": "fail",
                         "problem": (f"режимът е live, терминалът е на реалната сметка "
                                     f"…{str(acc.get('login'))[-4:]} ({srv}), но live_server "
                                     f"не е записан в настройките"),
                         "fix": "Настройки → „Запази настройките“ — сървърът се засича "
                                "автоматично от MT5 — после „Рестартирай двигателя“"})
        elif not live_server:
            rows.append({"key": "account", "title": "Сметката отговаря на режима",
                         "status": "fail",
                         "problem": (f"режимът е live, но терминалът е на ДЕМО сметка "
                                     f"…{str(acc.get('login'))[-4:]} ({srv})"),
                         "fix": "Логни реалната сметка в MT5, после Настройки → „Запази“"})
        else:
            rows.append({"key": "account", "title": "Сметката отговаря на режима",
                         "status": "fail",
                         "problem": (f"режимът е live, но сървърът е "
                                     f"{srv or NA} (очаква се {live_server})"),
                         "fix": "Провери „Live сървър“ в Настройки — или изтрий полето и "
                                "запази, за да се засече наново от MT5"})
    else:
        rows.append({"key": "account", "title": "Сметката отговаря на режима",
                     "status": "fail",
                     "problem": "режимът не е избран (mode липсва в engine\\config.json)",
                     "fix": "Избери режим demo/live — Настройки"})

                               
    if _legacy_product_present() and not _legacy_pensioned():
        found, path = _bridge_status()
        if found:
            rows.append({"key": "bridge_file", "title": "Bridge файл инсталиран",
                         "status": "ok", "detail": f"намерен: {path}"})
        else:
            rows.append({"key": "bridge_file", "title": "Bridge файл инсталиран",
                         "status": "fail", "problem": f"липсва {path}",
                         "fix": "Bridge липсва — преинсталирай програмата"})

        inst = bridge_instances_today()
        if len(inst) == 1:
            rows.append({"key": "bridge_charts", "title": "Bridge на точно 1 графика",
                         "status": "ok", "detail": f"1 графика: {sorted(inst)[0]}"})
        elif len(inst) == 0:

            live = sorted(bridge_symbols_live())
            if live:
                rows.append({"key": "bridge_charts", "title": "Bridge на точно 1 графика",
                             "status": "warn",
                             "problem": ("няма „started“ ред в днешния лог, но bridge-ът "
                                         f"докладва на живо ({', '.join(live)})"),
                             "fix": "Bridge-ът работи — нормално, ако EA-то е пуснато от "
                                    "предишен ден. При съмнение: дръпни го наново на "
                                    "GBPUSD H1 и следи реда да стане зелен."})
            else:
                rows.append({"key": "bridge_charts", "title": "Bridge на точно 1 графика",
                             "status": "fail",
                             "problem": "0 живи инстанции — bridge-ът не докладва",
                             "fix": "Сложи AdmiralBetaBridge на GBPUSD H1 (Настройки → Bridge) и включи Algo Trading"})
        else:
            rows.append({"key": "bridge_charts", "title": "Bridge на точно 1 графика",
                     "status": "fail",
                     "problem": f"{len(inst)} графики: {', '.join(sorted(inst))}",
                     "fix": "Само ЕДНА графика моля — махни го от останалите (остави GBPUSD H1)"})

        age = newest_status_age_seconds()
        if age is not None and age < 300:
            rows.append({"key": "bridge_status", "title": "Bridge докладва наскоро",
                         "status": "ok", "detail": f"най-нов статус преди {int(age)} сек"})
        else:
            age_txt = NA if age is None else f"преди {int(age // 60)} мин"
            rows.append({"key": "bridge_status", "title": "Bridge докладва наскоро",
                         "status": "fail",
                         "problem": f"няма свеж mt5_status файл ({age_txt})",
                         "fix": "Включи Algo Trading в MT5 (бутон в горната лента)"})
    else:
        rows.append({"key": "bridge_status", "title": "Bridge докладва наскоро",
                     "status": "ok",
                     "detail": "не се изисква — S5 двигателят говори с MT5 директно "
                               "през Python API (няма bridge на чиста инсталация)"})

                                                                               
                                                                          
    try:
        import MetaTrader5 as _mt5
        if _mt5.initialize(str(MT5_TERMINAL)):
            _ti = _mt5.terminal_info()
            _mt5.shutdown()
            if _ti is None:
                rows.append({"key": "trade_api", "title": "Търговия през Python API",
                             "status": "warn", "problem": "terminal_info недостъпно",
                             "fix": "MT5 не отговаря на API заявката — рестартирай терминала"})
            elif bool(getattr(_ti, "tradeapi_disabled", False)):
                rows.append({"key": "trade_api", "title": "Търговия през Python API",
                             "status": "fail",
                             "problem": "в MT5 е включено „Disable algorithmic trading via "
                                        "external Python API“",
                             "fix": "MT5 → Tools → Options → Experts → махни отметката "
                                    "„Disable algorithmic trading via external Python API“ → OK. "
                                    "Без това роботът НЕ може да търгува, дори Algo Trading да е вкл."})
            elif not bool(_ti.trade_allowed):
                rows.append({"key": "trade_api", "title": "Търговия през Python API",
                             "status": "fail",
                             "problem": "Algo Trading е изключен или сметката е с инвеститорска парола",
                             "fix": "Натисни бутона „Algo Trading“ в горната лента на MT5 "
                                    "(или влез с главната парола)"})
            else:
                rows.append({"key": "trade_api", "title": "Търговия през Python API",
                             "status": "ok", "detail": "разрешена (Algo Trading + Python API)"})
        else:
            rows.append({"key": "trade_api", "title": "Търговия през Python API",
                         "status": "warn", "problem": "MT5 не се инициализира за проверка",
                         "fix": "Пусни MT5 терминала"})
    except Exception as _exc:
        rows.append({"key": "trade_api", "title": "Търговия през Python API",
                     "status": "warn", "problem": f"проверката не мина: {_exc}",
                     "fix": "Провери дали MT5 върви"})

                                                                  
    try:
        fetch_age = time.time() - (LOGS_DIR / "fetch_daily.log").stat().st_mtime
    except Exception:
        fetch_age = None
    if fetch_age is not None and fetch_age < 36 * 3600:
        rows.append({"key": "market_data", "title": "Данните за пазара са свежи",
                     "status": "ok",
                     "detail": f"fetch_daily.log преди {fetch_age / 3600:.1f} ч"})
    elif not _is_owner_machine():
        rows.append({"key": "market_data", "title": "Данните за пазара са свежи",
                     "status": "ok",
                     "detail": "не се изисква тук — двигателят чете баровете на живо от MT5 "
                               "(дневният кеш е за бектест на машината на собственика)"})
    else:
        rows.append({"key": "market_data", "title": "Данните за пазара са свежи",
                     "status": "fail",
                     "problem": "няма свежо изтегляне на дневни данни",
                     "fix": "Изчакай нощното обновяване или пусни scripts\\fetch_daily.py"})

                                                          
    raw_backup = last_backup_time()
    try:
        bdt = datetime.strptime(raw_backup, "%Y-%m-%d %H:%M")
    except Exception:
        bdt = None
    if bdt is not None and (datetime.now() - bdt) < timedelta(hours=48):
        rows.append({"key": "backup", "title": "Бекъпът работи", "status": "ok",
                     "detail": f"последен бекъп: {raw_backup}"})
    elif not _is_owner_machine():
        rows.append({"key": "backup", "title": "Бекъпът работи", "status": "ok",
                     "detail": "не се изисква на клиентска машина — инсталацията е "
                               "защитена през ъпдейт канала на собственика"})
    else:
        rows.append({"key": "backup", "title": "Бекъпът работи", "status": "fail",
                     "problem": f"последен бекъп: {raw_backup}",
                     "fix": "Провери задачата AdmiralSwing_Backup в Task Scheduler"})

                                                   
    tg = _notify_settings() or {}
    if tg.get("token") and tg.get("chat_id") and tg.get("enabled"):
        rows.append({"key": "telegram", "title": "Telegram известия", "status": "ok",
                     "detail": "АКТИВНИ — token + chat_id, известията са включени"})
    else:
        rows.append({"key": "telegram", "title": "Telegram известия", "status": "ok",
                     "detail": "изключени (не е въведен ключ) — по желание: "
                               "Настройки → Telegram известия"})

                                             
    if mode in ("demo", "live"):
        rows.append({"key": "mode", "title": "Режимът е избран", "status": "ok",
                     "detail": f"текущ режим: {mode}"})
    else:
        rows.append({"key": "mode", "title": "Режимът е избран", "status": "fail",
                     "problem": "mode липсва или е невалиден в engine\\config.json",
                     "fix": "Избери режим (demo/live) — Настройки"})

                                                                     
    news_key = _news_api_key()
    nb_on = bool((cfg.get("news_blackout") or {}).get("enabled"))
    news_path = Path(str((cfg.get("news_blackout") or {}).get("path") or NEWS_CACHE_DEFAULT))
    try:
        news_age = time.time() - news_path.stat().st_mtime
    except Exception:
        news_age = None
    if not nb_on:
        rows.append({"key": "news_cache", "title": "Новинарски кеш свеж", "status": "ok",
                     "detail": "блекаутът е ИЗКЛЮЧЕН — кешът не е нужен "
                               "(включва се от Настройки → News blackout)"})
    elif news_age is not None and news_age < 2 * 3600:
        src = "локален сбор" if news_key else "доставен през ъпдейт канала"
        rows.append({"key": "news_cache", "title": "Новинарски кеш свеж", "status": "ok",
                     "detail": f"АКТИВЕН — обновен преди {int(news_age // 60)} мин ({src})"})
    elif news_key:
        age_txt = NA if news_age is None else f"преди {news_age / 3600:.1f} ч"
        rows.append({"key": "news_cache", "title": "Новинарски кеш свеж", "status": "fail",
                     "problem": f"блекаутът е включен, но кешът е стар или липсва ({age_txt})",
                     "fix": "Провери задачата за новини / натисни „Провери сега“ в Настройки"})
    else:
        age_txt = NA if news_age is None else f"преди {news_age / 3600:.1f} ч"
        rows.append({"key": "news_cache", "title": "Новинарски кеш свеж", "status": "warn",
                     "problem": f"блекаутът е включен, но кешът още не е пристигнал ({age_txt})",
                     "fix": "Идва сам с часовата проверка за ъпдейт — или Настройки → "
                            "Система → „Ъпдейт“ за веднага"})

                                                                        
    try:
        _gk = json.loads((CONFIG_DIR_DASH / "guard_keys.json").read_text(encoding="utf-8"))
        guard_keys = any(str(v or "").strip() for v in _gk.values())
    except Exception:
        guard_keys = False

    try:
        guard_age = time.time() - (LOGS_DIR / "guard_state.json").stat().st_mtime
    except Exception:
        guard_age = None
    if not guard_keys:
        rows.append({"key": "guard_state", "title": "Пазителен слой свеж", "status": "ok",
                     "detail": "не е активиран на тази машина (няма API ключове) — "
                               "двигателят работи и без него"})
    elif guard_age is not None and guard_age < 2 * 3600:
        rows.append({"key": "guard_state", "title": "Пазителен слой свеж", "status": "ok",
                     "detail": f"АКТИВЕН — guard_state.json обновен преди {int(guard_age // 60)} мин"})
    else:
        age_txt = NA if guard_age is None else f"преди {guard_age / 3600:.1f} ч"
        rows.append({"key": "guard_state", "title": "Пазителен слой свеж", "status": "warn",
                     "problem": f"активиран е (има ключове), но няма свеж запис в "
                                f"guard_state.json ({age_txt})",
                     "fix": "Пусни събирача чрез бутона „Провери сега“ "
                            "(Настройки → Пазителен слой)"})

                                                                                         
    try:
        guard_events = json.loads(
            (LOGS_DIR / "guard_events.json").read_text(encoding="utf-8")).get("events") or []
    except Exception:
        guard_events = []
    if not guard_keys:
        rows.append({"key": "guard_ffcal", "title": "ForexFactory календар", "status": "ok",
                     "detail": "не е активиран на тази машина (няма API ключове)"})
    elif guard_events:
        now_utc = datetime.now(timezone.utc)
        high_48h = 0
        for ev in guard_events:
            if ev.get("impact") != "High":
                continue
            try:
                dt = datetime.fromisoformat(str(ev.get("ts_utc") or ""))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if 0 <= (dt - now_utc).total_seconds() <= 48 * 3600:
                    high_48h += 1
            except Exception:
                continue
        rows.append({"key": "guard_ffcal", "title": "ForexFactory календар", "status": "ok",
                     "detail": f"АКТИВЕН — {len(guard_events)} събития, {high_48h} High в следващите 48ч"})
    else:
        rows.append({"key": "guard_ffcal", "title": "ForexFactory календар",
                     "status": "fail" if _is_owner_machine() else "warn",
                     "problem": "активиран е (има ключове), но няма събития в guard_events.json",
                     "fix": "Провери връзката / натисни „Провери сега“ "
                            "(Настройки → Пазителен слой)"})

                                                                           
    try:
        pulse_doc = json.loads((LOGS_DIR / "social_pulse.json").read_text(encoding="utf-8"))
    except Exception:
        pulse_doc = {}
    pulse_dt = parse_ts((pulse_doc or {}).get("fetched_utc"))
    if not guard_keys:
        rows.append({"key": "social_pulse", "title": "Социален пулс", "status": "ok",
                     "detail": "не е активиран на тази машина (няма API ключове)"})
    elif pulse_dt is not None and (datetime.now(timezone.utc) - pulse_dt) < timedelta(hours=2):
        bias = market_guard.social_bias(LOGS_DIR)
        counts = (pulse_doc or {}).get("counts") or {}
        detail = (f"{len((pulse_doc or {}).get('posts') or [])} поста · "
                  f"BULL {int(counts.get('bull') or 0)} · BEAR {int(counts.get('bear') or 0)}")
        if bias.get("usable") and bias.get("crowd"):
            detail += (f" — crowd {bias['crowd']} ratio {bias.get('ratio')} "
                       f"(контрариан: само {_SOCIAL_DIR_BG.get(bias['crowd'], '?')} входове)")
        rows.append({"key": "social_pulse", "title": "Социален пулс", "status": "ok",
                     "detail": detail})
    else:
        rows.append({"key": "social_pulse", "title": "Социален пулс", "status": "warn",
                     "problem": "активиран е (има ключове), но няма свеж запис в "
                                "social_pulse.json (по-стар от 2 ч или липсва)",
                     "fix": "Натисни „Обнови сега“ (Настройки → Социален пулс) или изчакай "
                            "планираната задача"})

    return rows


def _readiness_counts(rows: list[dict]) -> tuple[int, int, int, int]:
    """(готови, warn, fail, total) — готови = total − fail (warn не блокира)."""
    total = len(rows)
    warn = sum(1 for r in rows if r.get("status") == "warn")
    fail = sum(1 for r in rows if r.get("status") == "fail")
    return total - fail, warn, fail, total


def readiness_card_compact() -> str:
    """Малка карта за Таблото: „Готовност: X/Y — детайли →". """
    rows = _readiness_rows()
    ready, warn, fail, total = _readiness_counts(rows)
    pct = round(ready / total * 100) if total else 0
    bar_cls = " fail" if fail else (" warn" if warn else "")
    chip = ('<span class="chip bad">не е готова</span>' if fail
            else '<span class="chip warn">готова</span>' if warn
            else '<span class="chip ok">готова</span>')
    return (f'<div class="card"><h3>Готовност</h3>'
            f'<p style="margin:2px 0 10px">Готовност: <b>{ready}/{total}</b> {chip}</p>'
            f'<div class="prog{bar_cls}"><div style="width:{pct}%"></div></div>'
            f'<p style="margin:12px 0 0"><a class="btn secondary" href="/readiness">'
            f'детайли →</a></p></div>')


_READINESS_CHIP = {
    "ok": '<span class="chip ok">готово</span>',
    "fail": '<span class="chip bad">проблем</span>',
    "warn": '<span class="chip warn">по желание</span>',
}


                                                          

CSS = """
:root{
  --bg:#0d0f14;--card:#161a23;--border:#232838;--text:#e6e9f0;--muted:#8b93a7;
  --accent:#e5484d;--ok:#30a46c;--warn:#f5a524;--err:#e5484d;--sidebar:#10131a;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:"Segoe UI",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif;
  background:var(--bg);color:var(--text);font-size:14px;line-height:1.45}
a{color:var(--accent)}
h1{font-size:20px;margin:0}
h2{font-size:16px;margin:20px 0 10px}
h3{margin:0 0 10px;font-size:15px}
h4{margin:14px 0 8px;font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
code{background:#0d1017;border:1px solid var(--border);border-radius:4px;padding:0 5px;font-size:12px}
pre{background:#0d1017;border:1px solid var(--border);border-radius:8px;padding:12px;overflow:auto;font-size:12px;line-height:1.5}
.layout{display:flex;min-height:100vh}
.sidebar{width:232px;flex:none;background:var(--sidebar);border-right:1px solid var(--border);
  display:flex;flex-direction:column;position:sticky;top:0;height:100vh}
.brand{display:flex;align-items:center;gap:11px;padding:16px 16px 14px;border-bottom:1px solid var(--border)}
.brand img{width:36px;height:36px;border-radius:8px}
.brand-name{font-weight:700;font-size:15px}
.brand-sub{color:var(--muted);font-size:11px}
.nav{display:flex;flex-direction:column;padding:10px 0;flex:1}
.nav a{display:flex;align-items:center;gap:10px;padding:9px 16px;color:var(--muted);
  text-decoration:none;font-size:13.5px;border-left:3px solid transparent}
.nav a:hover{color:var(--text);background:#141824}
.nav a.active{color:var(--text);border-left-color:var(--accent);background:#161a23}
.nav a svg{flex:none;opacity:.85}
.userbox{padding:12px 16px;border-top:1px solid var(--border);color:var(--muted);font-size:12px}
.ub-name{color:var(--text);font-weight:600;margin-bottom:5px}
.ub-links{display:flex;gap:14px;flex-wrap:wrap}
.ub-links a{color:var(--muted);text-decoration:none;display:flex;align-items:center;gap:5px}
.ub-links a:hover{color:var(--text)}
.main{flex:1;min-width:0;padding:20px 26px 30px}
.page-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;
  margin-bottom:18px;flex-wrap:wrap}
.stamp{color:var(--muted);font-size:12px}
.foot{color:var(--muted);font-size:12px;margin-top:24px;border-top:1px solid var(--border);padding-top:12px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-bottom:16px}
.span2{grid-column:1/-1}
@media(max-width:1100px){.grid{grid-template-columns:1fr}.span2{grid-column:auto}}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px 18px;margin:0 0 16px}
.grid>.card,.grid>.span2>.card{margin:0}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border-bottom:1px solid #1e2432;padding:6px 10px;text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:11.5px;text-transform:uppercase;letter-spacing:.4px}
tbody tr:hover td,tr:hover td{background:#181c27}
.kv td:first-child{color:var(--muted);width:46%}
.num{text-align:right;font-variant-numeric:tabular-nums}
.muted{color:var(--muted);font-size:12px}
.chip{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11.5px;font-weight:600}
.chip.ok{background:rgba(48,164,108,.14);color:var(--ok);border:1px solid rgba(48,164,108,.4)}
.chip.bad{background:rgba(229,72,77,.14);color:var(--err);border:1px solid rgba(229,72,77,.4)}
.chip.warn{background:rgba(245,165,36,.14);color:var(--warn);border:1px solid rgba(245,165,36,.4)}
ol.steps{margin:4px 0 0;padding-left:20px}
ol.steps li{margin:7px 0;line-height:1.5}
.na{color:var(--muted);font-style:italic}
.ok{color:var(--ok)}
.pos{color:var(--ok)}
.neg{color:#ff8589}
.badge{display:inline-block;background:#1d2330;border:1px solid var(--border);border-radius:6px;
  padding:1px 8px;font-size:11.5px;font-weight:600;color:var(--muted);white-space:nowrap}
.badge.dep{background:rgba(48,164,108,.14);border-color:rgba(48,164,108,.45);color:var(--ok)}
.badge.wd{background:rgba(229,72,77,.12);border-color:rgba(229,72,77,.45);color:#ff8589}
.badge.cr{background:rgba(245,165,36,.12);border-color:rgba(245,165,36,.4);color:var(--warn)}
.badge.okb{background:rgba(48,164,108,.14);border-color:rgba(48,164,108,.45);color:var(--ok)}
.badge.wdb{background:rgba(245,165,36,.12);border-color:rgba(245,165,36,.4);color:var(--warn)}
.badge.stopb{background:rgba(229,72,77,.12);border-color:rgba(229,72,77,.45);color:#ff8589}
.checks{list-style:none;margin:4px 0 8px;padding-left:2px;font-size:13px}
.checks li{margin:3px 0}
.mark{margin-right:6px}
.sym{border-top:1px dashed #232838;margin-top:8px;padding-top:8px}
.symname{font-weight:600;margin-right:8px}
.reason{color:#c3cadb;font-size:13px;margin:4px 0}
.banner{display:flex;gap:10px;align-items:flex-start;border:1px solid;border-radius:10px;
  padding:11px 14px;margin:0 0 16px;font-size:13.5px}
.banner svg{flex:none;margin-top:1px}
.banner.danger{background:rgba(229,72,77,.1);border-color:rgba(229,72,77,.5);color:#ffb3b5}
.banner.success{background:rgba(48,164,108,.1);border-color:rgba(48,164,108,.5);color:#9fe0bd}
.banner.warn{background:rgba(245,165,36,.08);border-color:rgba(245,165,36,.4);color:#ffd98a}
.banner ul{margin:4px 0 0;padding-left:18px}
.field{margin:0 0 14px}
.flabel{display:block;color:var(--muted);font-size:11.5px;font-weight:600;
  text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px}
input[type=text],input[type=email],input[type=password],input[type=number],select{
  width:100%;padding:9px 11px;background:#0d1017;border:1px solid var(--border);
  border-radius:8px;color:var(--text);font-size:14px;font-family:inherit}
input:focus,select:focus{outline:none;border-color:var(--accent)}
input[type=checkbox]{width:16px;height:16px;accent-color:var(--accent)}
.field-check{display:flex;align-items:center;gap:9px;margin:0 0 16px;font-size:13.5px}
.btn{display:inline-block;background:var(--accent);color:#fff;border:none;border-radius:8px;
  padding:9px 18px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit}
.btn:hover{filter:brightness(1.12)}
.btn.secondary{background:#1d2330;color:var(--text);border:1px solid var(--border)}
.btn-block{width:100%}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:0 14px}
.form{max-width:660px}
.tabs{display:flex;gap:6px;margin:0 0 14px;flex-wrap:wrap}
.tabs a{padding:6px 12px;border-radius:8px;border:1px solid var(--border);
  color:var(--muted);text-decoration:none;font-size:12.5px}
.tabs a.active{color:var(--text);border-color:var(--accent);background:rgba(229,72,77,.08)}
.logpre{max-height:540px;white-space:pre-wrap;word-break:break-word}
.feed{display:flex;flex-direction:column;gap:8px;margin-top:10px}
.msg{display:flex;gap:12px;padding:10px 12px;background:#12151f;border:1px solid #1e2432;border-radius:10px}
.msg.lvl-alert,.msg.lvl-error{border-color:rgba(229,72,77,.45)}
.msg.lvl-warning{border-color:rgba(245,165,36,.4)}
.msg-meta{flex:none;width:170px;display:flex;flex-direction:column;gap:4px}
.msg-ts{font-size:11px}
.msg-body{min-width:0}
.msg-cat{margin-top:3px;font-size:11px}
.checklist{display:flex;flex-direction:column}
.check-row{display:flex;gap:12px;padding:9px 4px;border-bottom:1px solid #1e2432;font-size:13px}
.check-row:last-child{border-bottom:none}
.check-ic{flex:none;width:22px;text-align:center}
.check-row.ok .check-name{color:var(--ok)}
.check-row.err .check-name{color:#ff8589}
.check-row.warn .check-name{color:var(--warn)}
.check-name{font-weight:600;margin-bottom:2px}
details.card summary{cursor:pointer;font-weight:600;font-size:14px;color:var(--text)}
.legend h2{margin:16px 0 8px}
.legend h3{margin:14px 0 6px;color:var(--muted)}
.legend h4{margin:10px 0 4px}
.legend hr{border:none;border-top:1px solid var(--border);margin:14px 0}
.auth-wrap{max-width:430px;margin:7vh auto 40px;padding:0 16px;
  display:flex;flex-direction:column;align-items:center;gap:18px}
.auth-brand{display:flex;align-items:center;gap:12px}
.auth-brand img{width:52px;height:52px;border-radius:12px}
.auth-name{font-size:22px;font-weight:700}
.auth-sub{color:var(--muted);font-size:12px}
.auth-card{width:100%}
.auth-card h3{margin-bottom:14px;font-size:17px}
.auth-foot{color:var(--muted);font-size:12px}
.auth-links{margin-top:14px;font-size:13px;color:var(--muted)}
.auth-links a{color:var(--muted)}
.auth-links a:hover{color:var(--text)}
@media(max-width:900px){
  .layout{flex-direction:column}
  .sidebar{width:100%;height:auto;position:static;border-right:none;border-bottom:1px solid var(--border)}
  .brand{padding:12px 14px}
  .nav{flex-direction:row;flex-wrap:wrap;padding:6px 8px}
  .nav a{border-left:none;border-bottom:3px solid transparent;padding:8px 10px}
  .nav a.active{border-bottom-color:var(--accent)}
  .userbox{border-top:none;padding:0 14px 10px}
  .main{padding:16px}
  .msg-meta{width:120px}
}

/* ---------- DEMON premium visual refresh (presentation only) ---------- */
:root{
  --bg:#070910;
  --bg-deep:#05070c;
  --card:rgba(18,24,38,.82);
  --card-solid:#121826;
  --card-hi:rgba(28,36,54,.88);
  --border:rgba(128,148,184,.16);
  --border-hi:rgba(229,72,77,.36);
  --text:#f3f6fb;
  --muted:#8f9bb2;
  --accent:#ef343d;
  --accent-hi:#ff5a61;
  --accent-deep:#9f171e;
  --ok:#35d58b;
  --warn:#ffba4a;
  --err:#ff5962;
  --sidebar:rgba(8,11,18,.93);
  --shadow:0 18px 55px rgba(0,0,0,.32);
  --glow:0 0 32px rgba(239,52,61,.16);
}

html{color-scheme:dark;scrollbar-color:#313b50 #090c13}
body{
  min-height:100vh;
  font-family:"Segoe UI Variable Display","Segoe UI",system-ui,-apple-system,sans-serif;
  background:
    radial-gradient(900px 620px at 88% -8%,rgba(239,52,61,.13),transparent 61%),
    radial-gradient(760px 560px at 35% 108%,rgba(52,82,148,.14),transparent 64%),
    linear-gradient(145deg,#070910 0%,#0a0e17 50%,#070910 100%);
  background-attachment:fixed;
  letter-spacing:.005em;
}
body::before{
  content:"";position:fixed;inset:0;pointer-events:none;z-index:-1;opacity:.38;
  background-image:linear-gradient(rgba(255,255,255,.012) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(255,255,255,.012) 1px,transparent 1px);
  background-size:44px 44px;
  mask-image:linear-gradient(to bottom,black,transparent 72%);
}
::selection{background:rgba(239,52,61,.42);color:#fff}
::-webkit-scrollbar{width:11px;height:11px}
::-webkit-scrollbar-track{background:#090c13}
::-webkit-scrollbar-thumb{background:#30394d;border:3px solid #090c13;border-radius:20px}
::-webkit-scrollbar-thumb:hover{background:#46516a}

a{color:#ff6a70;text-decoration-color:rgba(255,106,112,.38);text-underline-offset:3px}
h1,h2,h3{color:#fff;letter-spacing:-.018em}
h1{font-size:25px;font-weight:760;text-shadow:0 2px 18px rgba(0,0,0,.35)}
h2{font-size:18px}
h3{font-size:15.5px;font-weight:720;display:flex;align-items:center;gap:9px}
h3::before{content:"";width:3px;height:15px;border-radius:4px;background:linear-gradient(180deg,var(--accent-hi),var(--accent-deep));box-shadow:0 0 14px rgba(239,52,61,.5)}
h4{color:#aeb9cf;letter-spacing:.075em}

.layout{isolation:isolate}
.sidebar{
  width:258px;
  background:linear-gradient(180deg,rgba(11,15,25,.97),rgba(7,9,15,.95));
  border-right:1px solid rgba(128,148,184,.14);
  box-shadow:18px 0 60px rgba(0,0,0,.18);
  backdrop-filter:blur(18px) saturate(125%);
  z-index:5;
}
.sidebar::after{
  content:"";position:absolute;top:0;right:-1px;width:1px;height:180px;
  background:linear-gradient(to bottom,var(--accent),rgba(239,52,61,0));opacity:.72
}
.brand{padding:22px 20px 19px;gap:14px;border-bottom:1px solid rgba(128,148,184,.12);position:relative}
.brand::after{content:"";position:absolute;left:20px;right:20px;bottom:-1px;height:1px;background:linear-gradient(90deg,rgba(239,52,61,.7),transparent)}
.brand img{width:46px;height:46px;border-radius:12px;filter:drop-shadow(0 0 12px rgba(239,52,61,.38));transition:transform .2s ease,filter .2s ease}
.brand:hover img{transform:scale(1.04);filter:drop-shadow(0 0 18px rgba(239,52,61,.52))}
.brand-name{text-transform:uppercase;font-size:17px;font-weight:800;letter-spacing:.11em;color:#fff}
.brand-sub{margin-top:3px;font-size:10.5px;letter-spacing:.04em;color:#7f8ba2}
.nav{padding:15px 10px;gap:5px}
.nav a{
  position:relative;padding:11px 13px;border:1px solid transparent;border-left:none;border-radius:9px;
  color:#929db2;font-size:13.5px;transition:color .16s ease,background .16s ease,border-color .16s ease,transform .16s ease
}
.nav a::before{content:"";position:absolute;left:0;top:9px;bottom:9px;width:3px;border-radius:0 5px 5px 0;background:transparent}
.nav a:hover{color:#fff;background:rgba(255,255,255,.035);border-color:rgba(128,148,184,.10);transform:translateX(2px)}
.nav a.active{
  color:#fff;border-left-color:transparent;border-color:rgba(239,52,61,.20);
  background:linear-gradient(90deg,rgba(239,52,61,.17),rgba(239,52,61,.035) 78%);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 8px 24px rgba(0,0,0,.14)
}
.nav a.active::before{background:linear-gradient(180deg,var(--accent-hi),var(--accent-deep));box-shadow:0 0 15px rgba(239,52,61,.65)}
.nav a svg{opacity:.9;filter:drop-shadow(0 2px 4px rgba(0,0,0,.22))}
.nav a.active svg{color:#ff6067}
.userbox{padding:15px 20px;border-top-color:rgba(128,148,184,.12);background:rgba(255,255,255,.012)}

.main{padding:28px 34px 42px;max-width:1640px;margin:0 auto;width:100%}
.page-head{
  margin:-4px 0 24px;padding:15px 3px 18px;align-items:center;
  border-bottom:1px solid rgba(128,148,184,.13);position:relative
}
.page-head::after{content:"";position:absolute;bottom:-1px;left:0;width:150px;height:1px;background:linear-gradient(90deg,var(--accent),transparent);box-shadow:0 0 12px rgba(239,52,61,.35)}
.stamp{padding:6px 10px;border:1px solid rgba(128,148,184,.12);border-radius:20px;background:rgba(11,15,24,.55);color:#8490a7;font-variant-numeric:tabular-nums}
.foot{margin-top:34px;padding-top:16px;border-top-color:rgba(128,148,184,.12);color:#68748a}
.grid{gap:18px;margin-bottom:18px}

.card{
  position:relative;overflow:hidden;
  background:linear-gradient(145deg,rgba(22,29,44,.90),rgba(14,19,31,.88));
  border:1px solid rgba(128,148,184,.16);border-radius:16px;padding:19px 20px;margin-bottom:18px;
  box-shadow:0 16px 42px rgba(0,0,0,.22),inset 0 1px 0 rgba(255,255,255,.025);
  backdrop-filter:blur(15px) saturate(120%);
  transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease
}
.card::after{content:"";position:absolute;inset:0;pointer-events:none;background:radial-gradient(520px 180px at 92% -22%,rgba(239,52,61,.07),transparent 64%)}
.card:hover{border-color:rgba(141,161,196,.25);box-shadow:0 19px 52px rgba(0,0,0,.29),0 0 0 1px rgba(255,255,255,.012);transform:translateY(-1px)}
.card>*{position:relative;z-index:1}

table{font-size:13px}
th,td{border-bottom-color:rgba(128,148,184,.11);padding:8px 10px}
th{color:#8e9ab0;font-size:11px;letter-spacing:.075em}
tbody tr{transition:background .14s ease}
tbody tr:hover td,tr:hover td{background:rgba(255,255,255,.024)}
.kv td:first-child{color:#94a1b8}
.num{color:#f6f8fc;font-weight:600}
.muted{color:#8995ac}
.reason{color:#cad1df}

.badge{border-radius:999px;padding:2px 9px;background:rgba(119,139,174,.11);border-color:rgba(128,148,184,.18);color:#aeb8ca;box-shadow:inset 0 1px 0 rgba(255,255,255,.02)}
.badge.dep,.badge.okb{background:rgba(53,213,139,.11);border-color:rgba(53,213,139,.30);color:#55e2a0}
.badge.wd,.badge.stopb{background:rgba(255,89,98,.11);border-color:rgba(255,89,98,.32);color:#ff737b}
.badge.cr,.badge.wdb{background:rgba(255,186,74,.10);border-color:rgba(255,186,74,.29);color:#ffc761}
.ok,.pos{color:#4ee09b}.neg{color:#ff737b}

.sym{border-top-color:rgba(128,148,184,.16)}
.banner{border-radius:13px;padding:13px 15px;box-shadow:inset 0 1px 0 rgba(255,255,255,.02)}
.banner.danger{background:linear-gradient(90deg,rgba(255,89,98,.12),rgba(255,89,98,.045));border-color:rgba(255,89,98,.32)}
.banner.success{background:linear-gradient(90deg,rgba(53,213,139,.11),rgba(53,213,139,.04));border-color:rgba(53,213,139,.28)}
.banner.warn{background:linear-gradient(90deg,rgba(255,186,74,.11),rgba(255,186,74,.04));border-color:rgba(255,186,74,.28)}

input[type=text],input[type=email],input[type=password],input[type=number],select{
  background:rgba(5,8,14,.70);border-color:rgba(128,148,184,.19);border-radius:10px;padding:10px 12px;
  box-shadow:inset 0 2px 10px rgba(0,0,0,.18);transition:border-color .15s ease,box-shadow .15s ease
}
input:focus,select:focus{border-color:rgba(239,52,61,.70);box-shadow:0 0 0 3px rgba(239,52,61,.11),inset 0 2px 10px rgba(0,0,0,.18)}
.btn{
  border-radius:10px;padding:10px 19px;background:linear-gradient(135deg,var(--accent-hi),#cf222b 72%);
  border:1px solid rgba(255,111,117,.35);box-shadow:0 8px 24px rgba(200,25,34,.23),inset 0 1px 0 rgba(255,255,255,.20);
  transition:transform .15s ease,filter .15s ease,box-shadow .15s ease
}
.btn:hover{filter:brightness(1.08);transform:translateY(-1px);box-shadow:0 11px 30px rgba(200,25,34,.31),inset 0 1px 0 rgba(255,255,255,.22)}
.btn:active{transform:translateY(0)}
.btn.secondary{background:rgba(119,139,174,.10);border-color:rgba(128,148,184,.20);box-shadow:none}
.btn.danger{background:rgba(220,80,80,.16);border-color:rgba(220,80,80,.45);color:#ff9d9d;box-shadow:none}
.btn.danger:hover{background:rgba(220,80,80,.28)}
.tabs{gap:8px}
.tabs a{border-radius:999px;background:rgba(119,139,174,.055);transition:all .15s ease}
.tabs a:hover{color:#fff;background:rgba(119,139,174,.11);text-decoration:none}
.tabs a.active{border-color:rgba(239,52,61,.42);background:rgba(239,52,61,.12);box-shadow:0 0 16px rgba(239,52,61,.08)}
.msg{background:rgba(7,10,17,.52);border-color:rgba(128,148,184,.13);border-radius:12px}
.check-row{border-bottom-color:rgba(128,148,184,.11)}
details.card summary{padding:2px 0;color:#f2f5fa}
code,pre{background:rgba(5,8,14,.72);border-color:rgba(128,148,184,.15)}

.auth-wrap{margin-top:9vh;gap:22px}
.auth-brand img{width:64px;height:64px;border-radius:16px;filter:drop-shadow(0 0 18px rgba(239,52,61,.34))}
.auth-name{text-transform:uppercase;font-size:25px;font-weight:820;letter-spacing:.12em}
.auth-sub{letter-spacing:.05em}
.auth-card{box-shadow:0 26px 80px rgba(0,0,0,.40),0 0 55px rgba(239,52,61,.06)}

.control-card{
  position:relative;overflow:hidden;margin:0 0 18px;padding:21px 22px;
  background:linear-gradient(125deg,rgba(27,34,51,.96),rgba(13,18,30,.93) 62%,rgba(32,17,25,.90));
  border:1px solid rgba(239,52,61,.25);border-radius:17px;
  box-shadow:0 20px 56px rgba(0,0,0,.27),0 0 42px rgba(239,52,61,.055),inset 0 1px 0 rgba(255,255,255,.035)
}
.control-card::before{content:"";position:absolute;inset:0;pointer-events:none;background:radial-gradient(520px 240px at 100% 0,rgba(239,52,61,.13),transparent 68%)}
.control-card::after{content:"";position:absolute;left:0;top:21px;bottom:21px;width:3px;border-radius:0 5px 5px 0;background:linear-gradient(180deg,var(--accent-hi),var(--accent-deep));box-shadow:0 0 19px rgba(239,52,61,.60)}
.control-card>*{position:relative;z-index:1}
.control-head{display:flex;align-items:flex-start;justify-content:space-between;gap:24px}
.control-head h2{font-size:20px;margin:3px 0 5px}
.control-kicker{font-size:10px;font-weight:800;letter-spacing:.15em;color:#ff646b}
.control-copy{max-width:760px;margin:0;line-height:1.55}
.control-statuses{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap;min-width:220px}
.status-dot{display:inline-block;width:6px;height:6px;margin-right:4px;border-radius:50%;background:currentColor;box-shadow:0 0 9px currentColor;vertical-align:1px}
.control-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:18px}
.control-actions form{margin:0}
.control-actions .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px}
.control-start{background:linear-gradient(135deg,#31c982,#168a58 76%);border-color:rgba(85,226,160,.38);box-shadow:0 8px 25px rgba(25,157,99,.22),inset 0 1px 0 rgba(255,255,255,.18)}
.control-start:hover{box-shadow:0 11px 31px rgba(25,157,99,.30),inset 0 1px 0 rgba(255,255,255,.20)}
.control-stop{background:linear-gradient(135deg,#ff535c,#b51e27 76%)}
.btn:disabled{cursor:not-allowed;filter:saturate(.25);opacity:.45;box-shadow:none;transform:none}
.btn:disabled:hover{filter:saturate(.25);transform:none;box-shadow:none}
.control-notice{margin:17px 0 0}.control-notice pre{margin:9px 0 0;max-height:180px;white-space:pre-wrap}
.control-detail{margin-top:13px;color:#8793a9;font-size:12px}
.control-detail summary{cursor:pointer;width:max-content;transition:color .15s ease}
.control-detail summary:hover{color:#d5dbea}
.control-detail pre{margin:9px 0 0;max-height:180px;white-space:pre-wrap}

@media(max-width:1100px){.main{padding-left:24px;padding-right:24px}}
@media(max-width:900px){
  .sidebar{width:100%;box-shadow:0 14px 42px rgba(0,0,0,.20)}
  .sidebar::after{display:none}
  .brand{padding:14px 16px}.brand img{width:40px;height:40px}
  .nav{padding:7px 9px;gap:3px}.nav a{padding:9px 11px}.nav a::before{display:none}
  .nav a.active{box-shadow:inset 0 -2px 0 var(--accent)}
  .main{padding:20px 16px 30px}.page-head{padding-top:8px}.stamp{font-size:10.5px}
  .card{padding:16px;border-radius:13px}.msg-meta{width:120px}
  .control-head{flex-direction:column;gap:14px}.control-statuses{justify-content:flex-start;min-width:0}
}
@media(max-width:560px){
  h1{font-size:21px}.nav a{font-size:12px;gap:6px}.nav a svg{width:14px;height:14px}
  .stamp{width:100%;border-radius:8px}.msg{flex-direction:column}.msg-meta{width:auto}
  th,td{padding:7px 6px}
  .control-card{padding:18px 16px}.control-actions{align-items:stretch}.control-actions form{width:100%}.control-actions .btn{width:100%}
}

/* ---------- Готовност (/readiness) ---------- */
.row-ok,.row-fail,.row-warn{display:flex;gap:12px;align-items:flex-start;
  padding:10px 2px;border-bottom:1px solid rgba(128,148,184,.11)}
.row-ok:last-child,.row-fail:last-child,.row-warn:last-child{border-bottom:none}
.row-chip{flex:none;width:96px;padding-top:2px}
.row-body{min-width:0;flex:1}
.row-title{font-weight:650;margin-bottom:2px}
.row-ok .row-title{color:var(--ok)}
.row-fail .row-title{color:var(--err)}
.row-warn .row-title{color:var(--warn)}
.row-problem{color:#cad1df;font-size:12.5px;margin:3px 0 0}
.row-fix{color:#8995ac;font-size:12.5px;margin:3px 0 0}
.row-fix b{color:#aeb8ca;font-weight:600}
.stat{padding:14px 16px;text-align:center}
.stat-v{font-size:22px;font-weight:700;line-height:1.2}
.stat-v.ok{color:var(--ok)}.stat-v.err{color:var(--err)}.stat-v.warn{color:var(--warn)}
.stat-l{font-size:11.5px;margin-top:4px;text-transform:uppercase;letter-spacing:.4px}
td.ok{color:var(--ok)}td.err{color:var(--err)}
.prog{height:10px;border-radius:999px;background:rgba(119,139,174,.13);
  border:1px solid rgba(128,148,184,.16);overflow:hidden}
.prog>div{height:100%;border-radius:999px;background:linear-gradient(90deg,#31c982,#168a58);
  box-shadow:0 0 14px rgba(53,213,139,.45)}
.prog.fail>div{background:linear-gradient(90deg,#ff5962,#b51e27);box-shadow:0 0 14px rgba(255,89,98,.40)}
.prog.warn>div{background:linear-gradient(90deg,#ffba4a,#c47f16);box-shadow:0 0 14px rgba(255,186,74,.40)}
.readiness-big{font-size:32px;font-weight:800;letter-spacing:-.01em}
.readiness-big .muted{font-size:16px;font-weight:600}
"""

_ICONS = {
    "grid": '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    "activity": '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    "refresh": '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
    "chat": '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    "gear": '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    "file": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/>',
    "book": '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    "users": '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "logout": '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    "download": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    "warn": '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "check": '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
    "play": '<polygon points="5 3 19 12 5 21 5 3"/>',
    "power": '<path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/>',
    "key": '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/>',
    "square": '<rect x="4" y="4" width="16" height="16" rx="2"/>',
    "chart": '<line x1="3" y1="20" x2="21" y2="20"/><polyline points="3 16 8 10 12 13 16 6 21 9"/><circle cx="16" cy="6" r="1.6"/>',
}

NAV_ITEMS = [
    ("/", "Табло", "grid"),
    ("/readiness", "Готовност", "check"),
    ("/journal", "Сигнали", "activity"),
    ("/clients", "Клиенти", "users"),
    ("/analytics", "Аналитика", "chart"),
    ("/messages", "Съобщения", "chat"),
    ("/settings", "Настройки", "gear"),
    ("/logs", "Логове", "file"),
    ("/legend", "Легенда", "book"),
]


def icon(name: str, size: int = 16) -> str:
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" '
            f'stroke="currentColor" stroke-width="2" stroke-linecap="round" '
            f'stroke-linejoin="round" aria-hidden="true">{_ICONS.get(name, "")}</svg>')


def shell(content: str, active: str = "",
          title: str = "Demon — център за управления",
          refresh: int | None = None) -> Response:
    meta = f'<meta http-equiv="refresh" content="{refresh}">' if refresh else ""
    links = ""
    for href, label, ic in NAV_ITEMS:
        if href == "/clients" and not _is_owner_machine():
            continue
        cls = ' class="active"' if active == href else ""
        links += f'<a href="{href}"{cls}>{icon(ic)}{e(label)}</a>'
    userbox = ""
    if gating_enabled() and session.get("user_email"):
        extra = ""
        if session.get("user_admin"):
            extra = f'<a href="/users">{icon("users", 13)} Потребители</a>'
        userbox = (f'<div class="userbox"><div class="ub-name">'
                   f'{e(session.get("user_name") or session.get("user_email"))}</div>'
                   f'<div class="ub-links">{extra}'
                   f'<a href="/logout">{icon("logout", 13)} Изход</a></div></div>')
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    page = f"""<!doctype html>
<html lang="bg"><head><meta charset="utf-8">
{meta}
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)}</title><link rel="icon" type="image/png" href="/logo.png"><style>{CSS}</style></head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand"><img src="/logo.png" alt="Demon"><div>
      <div class="brand-name">Demon</div><div class="brand-sub">център за управления</div>
    </div></div>
    <nav class="nav">{links}</nav>
    {userbox}
  </aside>
  <main class="main">
    <div class="page-head"><h1>{e(title)}</h1>
      <div class="stamp">обновено {stamp} · само локално (127.0.0.1)</div></div>
    {content}
    <footer class="foot">Източници: продуктови логове (AdmiralBeta\\logs), logs\\ (performance
    journal, decisions.jsonl, messages.jsonl). MT5 достъпът е само за четене.</footer>
  </main>
</div>
</body></html>"""
    return Response(page, mimetype="text/html; charset=utf-8")


                                                              

def _form_page(title: str, inner: str) -> Response:
    page = f"""<!doctype html>
<html lang="bg"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)} · Demon</title><link rel="icon" type="image/png" href="/logo.png"><style>{CSS}</style></head>
<body>
<div class="auth-wrap">
  <div class="auth-brand"><img src="/logo.png" alt="Demon"><div>
    <div class="auth-name">Demon</div><div class="auth-sub">център за управления</div>
  </div></div>
  <div class="card auth-card">{inner}</div>
  <div class="auth-foot">само локално (127.0.0.1)</div>
</div>
</body></html>"""
    return Response(page, mimetype="text/html; charset=utf-8")


def _field(label: str, name: str, type_: str = "text", value: str = "") -> str:
    return (f'<div class="field"><label class="flabel" for="f-{e(name)}">{e(label)}</label>'
            f'<input id="f-{e(name)}" name="{e(name)}" type="{type_}" value="{e(value)}"></div>')


def _err(msg: str) -> str:
    if not msg:
        return ""
    return (f'<div class="banner danger">{icon("warn")}<div>{e(msg)}</div></div>')


def _submit(label: str) -> str:
    return f'<p style="margin:16px 0 0"><button type="submit" class="btn btn-block">{e(label)}</button></p>'


@app.route("/login", methods=["GET", "POST"])
def login_page() -> Response:
    err = ""
    if request.method == "POST":
        u = auth.verify_login(request.form.get("email", ""),
                              request.form.get("password", ""))
        if u:
            session.permanent = True
            session["user_email"] = u["email"]
            session["user_name"] = u["name"]
            session["user_admin"] = bool(u.get("admin"))
            nxt = request.args.get("next") or "/"
            return redirect(nxt if nxt.startswith("/") else "/")
        err = "Грешен имейл или парола."
    body = (f"<h3>Вход</h3>{_err(err)}"
            f'<form method="post">{_field("Имейл", "email", "email")}'
            f'{_field("Парола", "password", "password")}'
            f"{_submit('Влез')}</form>"
            '<p class="auth-links"><a href="/register">Регистрация</a> · '
            '<a href="/forgot">Забравена парола</a></p>')
    return _form_page("Вход", body)


@app.route("/register", methods=["GET", "POST"])
def register_page() -> Response:
    err = ""
    if request.method == "POST":
        try:
            u = auth.create_user(request.form.get("name", ""),
                                 request.form.get("email", ""),
                                 request.form.get("password", ""),
                                 request.form.get("password2", ""))
            session.permanent = True
            session["user_email"] = u["email"]
            session["user_name"] = u["name"]
            session["user_admin"] = bool(u.get("admin"))
            return redirect("/")
        except auth.AuthError as exc:
            err = str(exc)
    body = (f"<h3>Регистрация</h3>{_err(err)}"
            f'<form method="post">{_field("Име", "name")}'
            f'{_field("Имейл", "email", "email")}'
            f'{_field("Парола (мин. 8, буква+цифра)", "password", "password")}'
            f'{_field("Повтори паролата", "password2", "password")}'
            f"{_submit('Регистрирай се')}</form>"
            '<p class="auth-links"><a href="/login">← Обратно към входа</a></p>')
    return _form_page("Регистрация", body)


@app.route("/forgot", methods=["GET", "POST"])
def forgot_page() -> Response:
    err, ok = "", False
    if request.method == "POST":
        ok = auth.verify_reset(request.form.get("email", ""),
                               request.form.get("license_key", ""),
                               lambda k: licensing.license_tool.verify_key(k))
        if ok:
            session["reset_email"] = request.form.get("email", "").strip().lower()
        err = "" if ok else "Несъвпадение — провери имейла и ключа."
    if ok:
        body = (f"<h3>Смяна на паролата</h3>"
                f'<form method="post" action="/reset">'
                f'{_field("Нова парола", "password", "password")}'
                f'{_field("Повтори новата парола", "password2", "password")}'
                f"{_submit('Запази')}</form>")
        return _form_page("Смяна на парола", body)
    body = (f"<h3>Забравена парола</h3>{_err(err)}"
            '<p class="muted">Въведи регистрирания си имейл и лицензния си ключ '
            '(доказателство, че си ти).</p>'
            f'<form method="post">{_field("Имейл", "email", "email")}'
            f'{_field("Лицензен ключ", "license_key")}'
            f"{_submit('Продължи')}</form>"
            '<p class="auth-links"><a href="/login">← Обратно към входа</a></p>')
    return _form_page("Забравена парола", body)


@app.route("/reset", methods=["GET", "POST"])
def reset_page() -> Response:
    email = session.get("reset_email", "")
    err = ""
    if request.method == "POST" and email:
        try:
            auth.change_password(email, request.form.get("password", ""),
                                 request.form.get("password2", ""))
            session.pop("reset_email", None)
            body = ('<h3>Паролата е сменена</h3>'
                    '<p>Влезте с новата си парола.</p>'
                    '<p class="auth-links"><a href="/login">→ Към входа</a></p>')
            return _form_page("Паролата е сменена", body)
        except auth.AuthError as exc:
            err = str(exc)
    body = (f"<h3>Смяна на паролата</h3>{_err(err)}"
            '<p class="muted">Потвърден е само имейлът от предишната стъпка.</p>'
            f'<form method="post">{_field("Нова парола", "password", "password")}'
            f'{_field("Повтори новата парола", "password2", "password")}'
            f"{_submit('Запази')}</form>")
    return _form_page("Смяна на парола", body)


@app.route("/activate", methods=["GET", "POST"])
def activate_page() -> Response:
    msg = ""
    ok, reason = licensing.is_licensed()
    if request.method == "POST":
        ok2, why = licensing.activate(request.form.get("key", ""))
        if ok2:

            try:
                STOP_FLAG.unlink(missing_ok=True)
            except Exception:
                pass
            nxt = request.form.get("next") or ""
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else "/")
        msg = why
        ok, reason = licensing.is_licensed()
    body = (f"<h3>Активиране на лиценза</h3>"
            f'<p class="muted">Статус: {"активиран" if ok else e(reason)}</p>'
            f"{_err(msg)}"
            f'<form method="post">{_field("Лицензен ключ (DEMON-... или ASL-...)", "key")}'
            f"{_submit('Активирай')}</form>")
    return _form_page("Активиране", body)


@app.route("/users")
def users_page() -> Response:
    if not gating_enabled():
        return index()
    if not session.get("user_admin"):
        return Response("забранено (само admin)", status=403,
                        mimetype="text/plain; charset=utf-8")
    rows = "".join(
        f"<tr><td>{e(u['name'])}</td><td>{e(u['email'])}</td>"
        f"<td>{e(u['created_utc'])}</td><td>{'да' if u['admin'] else 'не'}</td></tr>"
        for u in auth.list_users())
    body = (f'<div class="card"><h3>Потребители на тази машина</h3>'
            f'<table><tr><th>Име</th><th>Имейл</th><th>Регистриран</th><th>Admin</th></tr>{rows}</table></div>')
    return shell(body, active="/users", title="Потребители")


@app.route("/logout")
def logout_page() -> Response:
    session.clear()
    return redirect("/login")


@app.route("/logo.png")
def logo() -> Response:
    from flask import send_file
    icon = ASSETS / "demon-desktop-icon.png"
    if not icon.exists():
        return Response(status=204)                                                   
    return send_file(icon, mimetype="image/png")


                             

CONTROL_ACTIONS = {"status", "start", "stop"}


def _find_engine_python() -> Path:
    """Python за двигателя — динамично: env override → py launcher → известни пътища.
    Твърдо кодиран път не се ползва — при клиент с друго потребителско име краши."""
    import os as _os
    env = _os.environ.get("DEMON_ENGINE_PYTHON", "").strip()
    if env and Path(env).exists():
        return Path(env)
    try:
        r = subprocess.run(["py", "-3.12", "-c", "import sys,sysconfig;print(sys.prefix)"],
                           capture_output=True, text=True, timeout=30)
        if r.returncode == 0 and r.stdout.strip():
            cand = Path(r.stdout.strip().strip()) / "pythonw.exe"
            if cand.exists():
                return cand
            cand2 = Path(r.stdout.strip().strip()) / "python.exe"
            if cand2.exists():
                return cand2
    except Exception:
        pass
    local = Path(_os.environ.get("LOCALAPPDATA", ""))
    for cand in (local / "Python" / "pythoncore-3.12-64" / "pythonw.exe",
                 local / "Programs" / "Python" / "Python312" / "pythonw.exe"):
        if cand.exists():
            return cand
    return Path(sys.executable)                                               


ENGINE_PYTHON = _find_engine_python()
ENGINE_SCRIPT = BASE_DIR / "engine" / "engine_s5.py"
_PIDS_CACHE: tuple[float, list[int]] = (0.0, [])


def _engine_pids(fresh: bool = False) -> list[int]:
    """PID-и на живите engine_s5.py процеси (10 s кеш; CIM, само python.exe/pythonw.exe).

    fresh=True заобикаля кеша — задължително при старт/стоп решения."""
    global _PIDS_CACHE
    now = time.time()
    if not fresh:
        ts, cached = _PIDS_CACHE
        if now - ts < 10:
            return list(cached)
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='pythonw.exe'\" "
          "| Where-Object { $_.CommandLine -like '*engine_s5.py*' } "
          "| Select-Object -ExpandProperty ProcessId")
    pids: list[int] = []
    try:
        out = subprocess.run([r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
                              "-NoProfile", "-NonInteractive", "-Command", ps],
                             capture_output=True, text=True, timeout=30,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        pids = [int(x) for x in out.stdout.split() if x.strip().isdigit()]
    except Exception:
        pass
    _PIDS_CACHE = (now, pids)
    return list(pids)


def _state_age_seconds() -> float | None:
    try:
        return time.time() - STATE_JSON.stat().st_mtime
    except OSError:
        return None


def _engine_status() -> tuple[str, str, bool]:
    """Статус на S5 двигателя: (етикет, детайл, върви_ли)."""
    pids = _engine_pids()
    flag = STOP_FLAG.exists()
    age = _state_age_seconds()
    age_txt = "няма state.json" if age is None else f"последен цикъл преди {int(age // 60)} мин"
    detail = (f"S5 engine процеси: {', '.join(str(p) for p in pids) or 'няма'}\n"
              f"STOP.flag: {'АКТИВЕН' if flag else 'липсва'}\n"
              f"state.json: {age_txt}")
    if pids and flag:
        return ("СПИРА", detail + "\n(STOP.flag е записан — процесът излиза след текущия цикъл)", False)
    if pids:
        fresh = age is not None and age < 1200
        return ("РАБОТИ" if fresh else "РАБОТИ (закъснял цикъл)"), detail, True
    return "СПРЯН", detail, False


def _engine_start() -> tuple[bool, str]:
    """Стартира S5 демона директно. Предполага, че STOP.flag вече е премахнат."""
    pids = _engine_pids(fresh=True)
    if pids:
        return True, f"S5 engine вече върви (PID {', '.join(map(str, pids))})."
    if not ENGINE_PYTHON.exists():
        return False, f"Липсва Python: {ENGINE_PYTHON}"
    try:
        subprocess.Popen([str(ENGINE_PYTHON), str(ENGINE_SCRIPT)],
                         cwd=str(BASE_DIR),
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as exc:
        return False, f"Демонът не можа да се стартира: {exc}"
    for _ in range(12):
        time.sleep(1)
        pids = _engine_pids(fresh=True)
        if pids:
            return True, f"S5 engine стартиран (PID {', '.join(map(str, pids))})."
    tail = ""
    try:
        log = LOGS_DIR / "engine_s5.log"
        if log.exists():
            lines = log.read_text(encoding="utf-8", errors="replace").splitlines()
            interesting = [l for l in lines if "ERROR" in l or "SafetyError" in l or "Traceback" in l]
            tail = "\n".join((interesting or lines)[-3:])
    except Exception:
        pass
    if tail:
        return False, ("Двигателят отказа да стартира. Последната грешка от лога:\n" + tail)
    return False, "Демонът не се появи след 12 s — виж logs\\engine_s5.log."


def _engine_stop() -> tuple[bool, str]:
    """Спира S5 процесите (STOP.flag се пише от извикващия)."""
    killed: list[str] = []
    for pid in _engine_pids(fresh=True):
        try:
            r = subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                               capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                killed.append(str(pid))
        except Exception:
            pass
    msg = "STOP.flag записан. "
    msg += f"Процеси спрени: {', '.join(killed)}." if killed else "Нямаше жив S5 процес."
    return True, msg


def control_panel() -> str:
    status_label, status_detail, is_running = _engine_status()
    status_cls = "okb" if is_running else ("stopb" if status_label == "СПРЯН" else "wdb")
    acc = get_account() or {}
    is_real = acc.get("trade_mode") == 2
    account_label = "REAL / LIVE" if is_real else "DEMO"
    account_cls = "stopb" if is_real else "okb"
    confirm_text = (
        "ВНИМАНИЕ: Това е REAL сметка. Ако защитите допуснат сигнал, може да се отвори "
        "позиция с истински пари. Сигурен ли си, че искаш да стартираш?"
        if is_real else
        "Ще стартираш системата на DEMO сметката. Продължаваме ли?"
    )
    notice = session.pop("_control_notice", None)
    notice_html = ""
    if isinstance(notice, dict):
        kind = notice.get("kind") if notice.get("kind") in {"success", "danger", "warn"} else "warn"
        notice_html = (f'<div class="banner {kind} control-notice"><div><b>{e(notice.get("title", "Резултат"))}</b>'
                       f'<pre>{e(notice.get("detail", ""))}</pre></div></div>')
    token = _csrf_token()
    return f"""
<div class="control-card">
  <div class="control-head">
    <div>
      <div class="control-kicker">УПРАВЛЕНИЕ НА ДВИГАТЕЛЯ</div>
      <h2>Търговска система</h2>
      <p class="muted control-copy">Старт/Стоп управляват S5 демона директно — без старата Beta. Спирането записва STOP.flag и спира процеса; отворена позиция не се затваря насила.</p>
    </div>
    <div class="control-statuses">
      <span class="badge {account_cls}">Сметка: {account_label}</span>
      <span class="badge {status_cls}"><span class="status-dot"></span> Engine: {status_label}</span>
    </div>
  </div>
  {notice_html}
  <div class="control-actions">
    <form method="post" action="/control/status">
      <input type="hidden" name="csrf_token" value="{e(token)}">
      <button class="btn secondary" type="submit">{icon("activity", 16)} Провери готовността</button>
    </form>
    <form method="post" action="/control/start" onsubmit="return confirm('{e(confirm_text)}')">
      <input type="hidden" name="csrf_token" value="{e(token)}">
      <button class="btn control-start" type="submit"{' disabled' if is_running else ''}>{icon("play", 16)} Стартирай системата</button>
    </form>
    <form method="post" action="/control/stop">
      <input type="hidden" name="csrf_token" value="{e(token)}">
      <button class="btn control-stop" type="submit"{' disabled' if not is_running else ''}>{icon("square", 16)} Спри новите сделки</button>
    </form>
  </div>
  <details class="control-detail"><summary>Технически статус</summary><pre>{e(status_detail)}</pre></details>
</div>"""


@app.route("/control/<action>", methods=["POST"])
def control_action(action: str) -> Response:
    if action not in CONTROL_ACTIONS:
        return Response("Непозната команда", status=404)
    if not _valid_csrf():
        return Response("Невалидна или изтекла сесия. Обнови страницата.", status=403)

    if action == "status":
        label, detail, _running = _engine_status()
        ok, title = True, f"Статус: Engine {label}"
    elif action == "stop":
        ok, detail = _engine_stop()
        try:
            STOP_FLAG.write_text("stop\n", encoding="ascii")
        except Exception as exc:
            ok = False
            detail += f"\nНе можа да се запише STOP.flag: {exc}"
        title = "Системата е спряна" if ok else "Спирането не завърши"
    else:
        try:
            STOP_FLAG.unlink(missing_ok=True)
        except Exception as exc:
            ok, detail = False, f"STOP.flag не можа да се премахне: {exc}"
        else:
            ok, detail = _engine_start()
            if not ok:
                try:
                    STOP_FLAG.write_text("stop\n", encoding="ascii")
                except Exception:
                    pass
        title = "Системата е стартирана" if ok else "Стартът не завърши"

    session["_control_notice"] = {
        "kind": "success" if ok else "danger",
        "title": title,
        "detail": detail,
    }
    nxt = request.form.get("next") or request.args.get("next") or ""
    if not (nxt.startswith("/") and not nxt.startswith("//")):
        nxt = ""
    return redirect(nxt or url_for("index"))

@app.route("/")
def index() -> Response:
    body = (
        control_panel()
        + '<div class="grid">'
        + robot_state_card()
        + readiness_card_compact()
        + section_position()
        + f'<div class="span2">{section_account()}</div>'
        + f'<div class="span2">{system_card()}</div>'
        + "</div>"
        + last_decision_card()
    )
    return shell(body, active="/", refresh=30)


@app.route("/readiness")
def readiness_page() -> Response:
    rows = _readiness_rows()
    ready, warn, fail, total = _readiness_counts(rows)
    pct = round(ready / total * 100) if total else 0
    bar_cls = " fail" if fail else (" warn" if warn else "")
    if fail:
        banner = (f'<div class="banner danger">{icon("warn", 18)}'
                  f'<div><b>Системата не е готова</b> — виж червените редове.</div></div>')
    else:
        banner = (f'<div class="banner success">{icon("check", 18)}'
                  f'<div><b>Всички задължителни проверки минават</b> — системата е готова.</div></div>')
    items = []
    token = _csrf_token()
    for r in rows:
        parts = [f'<div class="row-{r["status"]}"><span class="row-chip">'
                 f'{_READINESS_CHIP[r["status"]]}</span>',
                 f'<div class="row-body"><div class="row-title">{e(r["title"])}</div>']
        if r["status"] == "ok":
            if r.get("detail"):
                parts.append(f'<div class="row-problem">{e(r["detail"])}</div>')
        else:
            if r.get("problem"):
                parts.append(f'<div class="row-problem">{e(r["problem"])}</div>')
            parts.append(f'<div class="row-fix"><b>Какво да се направи:</b> {e(r.get("fix") or "")}</div>')
            if r.get("fix_action") == "start":
                parts.append(
                    f'<form method="post" action="/control/start" style="margin:8px 0 2px">'
                    f'<input type="hidden" name="csrf_token" value="{e(token)}">'
                    f'<input type="hidden" name="next" value="/readiness">'
                    f'<button class="btn control-start" type="submit">▶ Пусни системата</button>'
                    f'</form>')
        parts.append("</div></div>")
        items.append("".join(parts))
    body = (
        f'<div class="card"><h3>Обобщена готовност</h3>'
        f'<div class="readiness-big">{ready} <span class="muted">от</span> {total} '
        f'<span class="muted">готови</span></div>'
        f'<div class="prog{bar_cls}" style="margin:12px 0"><div style="width:{pct}%"></div></div>'
        f'<p class="muted">{fail} проблем(а) · {warn} предупреждение(я) · '
        f'авто-опресняване на 30 сек</p></div>'
        + banner
        + f'<div class="card"><h3>Чеклист</h3>{"".join(items)}</div>')
    return shell(body, active="/readiness", title="Готовност", refresh=30)


                                         

DEAL_TYPE_BG = {"BUY": "покупка", "SELL": "продажба", "BALANCE": "баланс"}
ACTION_BADGE = {"OPEN": "okb", "CLOSE": "wdb", "WAIT": ""}


def _journal_symbols(lines: list[dict]) -> list[str]:
    seen = set()
    for line in lines:
        for s in line.get("symbols") or []:
            sym = (s.get("symbol") or "").strip().upper()
            if sym:
                seen.add(sym)
    return sorted(seen)


                                                                                 
ENGINE_MAGIC = 750501


def _engine_deals() -> list[dict]:
    """ВСИЧКИ сделки на двигателя (magic) от жив MT5 history — не от остарели файлове."""

    def _q(mt5):
        from datetime import datetime as _dt, timedelta as _td
        # MT5 връща ПРАЗНА история при край далеч в бъдещето (2100) — затова край = сега+1д
        deals = mt5.history_deals_get(_dt(2020, 1, 1), _dt.now() + _td(days=1)) or []
        return [d for d in deals if int(d.magic) == ENGINE_MAGIC]

    return mt5_read(_q) or []


def _live_open_positions() -> list[dict]:
    """Отворени позиции на двигателя — живо, с R и защита."""
    tr_cfg_be = 0.5

    def _q(mt5):
        out = []
        for p in mt5.positions_get() or []:
            if int(p.magic) != ENGINE_MAGIC:
                continue
            buy = p.type == 0
            entry = float(p.price_open)
            sl = float(p.sl or 0.0)
                                                                                          
            risk = abs(entry - sl) if (sl and ((buy and sl < entry) or (not buy and sl > entry))) else 0.0
            if risk <= 0:
                st = read_json(STATE_JSON) or {}
                for rec in ((st.get("position") or {}).get("all") or []):
                    if rec.get("symbol") == p.symbol and rec.get("open_price"):
                        r0 = abs(float(rec["open_price"]) - float(rec.get("sl") or 0))
                        if r0 > 0:
                            risk = r0
                            break
            dist = (p.price_current - entry) if buy else (entry - p.price_current)
            r_now = dist / risk if risk > 0 else 0.0
            if sl:
                if (buy and sl >= entry) or (not buy and sl <= entry):
                    locked = abs(sl - entry)
                    prot = ("breakeven" if locked < risk * 0.01 or risk <= 0
                            else f"trail (+{locked / risk:.2f}R заключени)")
                else:
                    prot = f"без защита (BE на {tr_cfg_be:.1f}R)"
            else:
                prot = "НЯМА SL!"
            out.append({"symbol": p.symbol, "dir": "BUY" if buy else "SELL",
                        "lots": float(p.volume), "entry": entry, "sl": sl,
                        "current": float(p.price_current), "r": round(r_now, 2),
                        "pnl": round(float(p.profit), 2), "protection": prot})
        return out

    return mt5_read(_q) or []


def _live_closed_trades() -> list[dict]:
    """Затворени сделки от жив MT5 — сдвояване по position_id (сигурно)."""
    from datetime import datetime as _dt, timezone as _tz
    deals = _engine_deals()
    pos_map: dict[int, dict] = {}
    for d in deals:
        pid = int(d.position_id)
        rec = pos_map.setdefault(pid, {"symbol": d.symbol, "in": 0.0, "out": 0.0,
                                       "profit": 0.0, "time": "", "dir": ""})
        pnl = float(d.profit) + float(d.commission) + float(d.swap)
        rec["profit"] += pnl
        vol = float(d.volume)
        if int(d.entry) == 0:                  
            rec["in"] += vol
            rec["dir"] = "BUY" if d.type == 0 else "SELL"
        else:                                   
            rec["out"] += vol
        t = _dt.fromtimestamp(int(d.time), _tz.utc).isoformat()
        if t >= rec["time"]:
            rec["time"] = t
    return [t for t in pos_map.values() if t["out"] > 0 and t["symbol"]]


def _equity_points() -> list[tuple[str, float]]:
    """Дневна чиста печалба на ДВИГАТЕЛЯ (от първата му сделка) + плаващата на живо."""
    from datetime import datetime as _dt, timezone as _tz
    deals = _engine_deals()
    by_day: dict[str, float] = {}
    first_day = None
    for d in deals:
        if int(d.entry) != 0:                                      
            continue
        day = _dt.fromtimestamp(int(d.time), _tz.utc).date().isoformat()
        if first_day is None or day < first_day:
            first_day = day
    for d in deals:
        if int(d.entry) == 0:
            continue
        day = _dt.fromtimestamp(int(d.time), _tz.utc).date().isoformat()
        by_day[day] = by_day.get(day, 0.0) + float(d.profit) + float(d.commission) + float(d.swap)
    pts, cum = [], 0.0
    for day in sorted(by_day):
        cum += by_day[day]
        pts.append((day, round(cum, 2)))
    open_pos = _live_open_positions()
    if open_pos:
        floating = sum(p["pnl"] for p in open_pos)
        today = __import__("datetime").date.today().isoformat()
        if pts and pts[-1][0] == today:
            pts[-1] = (today, round(pts[-1][1] + floating, 2))
        else:
            pts.append((today, round((pts[-1][1] if pts else 0.0) + floating, 2)))
    return pts


def _equity_svg(pts: list[tuple[str, float]], w: int = 860, h: int = 240) -> str:
    if len(pts) < 2:
        return '<p class="muted">Няма достатъчно дневни данни за кривата — изчакай първата седмица.</p>'
    vals = [v for _, v in pts]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1.0
    pad = 14
    step = (w - 2 * pad) / (len(vals) - 1)
    xy = [(pad + i * step, h - pad - (v - lo) / span * (h - 2 * pad)) for i, v in enumerate(vals)]
    line = " ".join(f"{x:.1f},{y:.1f}" for x, y in xy)
    zero_y = h - pad - (0 - lo) / span * (h - 2 * pad) if lo < 0 else None
    area = f"{pad},{h-pad} {line} {pad + (len(vals)-1)*step:.1f},{h-pad}"
    grid = "".join(
        f'<line x1="{pad}" y1="{pad + i * (h - 2 * pad) / 4:.1f}" x2="{w - pad}" y2="{pad + i * (h - 2 * pad) / 4:.1f}" stroke="var(--border)" stroke-width="0.6"/>'
        for i in range(5))
    zero_ln = (f'<line x1="{pad}" y1="{zero_y:.1f}" x2="{w - pad}" y2="{zero_y:.1f}" '
               f'stroke="var(--warn)" stroke-width="1" stroke-dasharray="4 3"/>') if zero_y else ""
    up = vals[-1] >= vals[0]
    color = "var(--ok)" if up else "var(--err)"
    last_x, last_y = xy[-1]
    return (f'<svg viewBox="0 0 {w} {h}" style="width:100%;height:auto;display:block" '
            f'role="img" aria-label="Крива на търговската печалба">'
            f'{grid}{zero_ln}'
            f'<polygon points="{area}" fill="{color}" opacity="0.10"/>'
            f'<polyline points="{line}" fill="none" stroke="{color}" stroke-width="2"/>'
            f'<circle cx="{last_x:.1f}" cy="{last_y:.1f}" r="3.5" fill="{color}"/>'
            f'<text x="{pad}" y="{pad - 4}" fill="var(--muted)" font-size="11">{hi:+.2f} €</text>'
            f'<text x="{pad}" y="{h - 2}" fill="var(--muted)" font-size="11">{lo:+.2f} €</text>'
            f'</svg>')


def _position_map_svg(p: dict, w: int = 860, h: int = 130) -> str:
    """Карта на отворената позиция: SL — вход — текуща цена, с оцветени зони и стрелка
    в посоката на печалба. Да се вижда с един поглед кога печели и кога губи."""
    entry, cur, sl = float(p["entry"]), float(p["current"]), float(p.get("sl") or 0.0)
    buy = p["dir"] == "BUY"
    risk = abs(entry - sl) if sl else max(abs(entry) * 0.002, 1e-9)
    lo = min(entry, cur, sl if sl else entry) - risk * 0.45
    hi = max(entry, cur, sl if sl else entry) + risk * 0.45
    span = (hi - lo) or 1e-9

    def X(v: float) -> float:
        return 30 + (v - lo) / span * (w - 60)

    mid = h // 2 + 8
    x_entry, x_cur = X(entry), X(cur)
    # печелившата страна: за BUY над входа (дясно), за SELL под входа (ляво)
    if buy:
        win_x0, win_x1 = x_entry, X(hi)
        loss_x0, loss_x1 = X(lo), x_entry
        arrow = f'<path d="M {x_entry+8} {mid-16} L {min(x_cur, X(hi))-8} {mid-16} l -7 -4 m 7 4 l -7 4" stroke="var(--ok)" stroke-width="2" fill="none"/>'
        rule = "BUY — печелиш, когато цената РАСТЕ · губиш, когато пада"
    else:
        win_x0, win_x1 = X(lo), x_entry
        loss_x0, loss_x1 = x_entry, X(hi)
        arrow = f'<path d="M {x_entry-8} {mid-16} L {max(x_cur, X(lo))+8} {mid-16} l 7 -4 m -7 4 l 7 4" stroke="var(--ok)" stroke-width="2" fill="none"/>'
        rule = "SELL — печелиш, когато цената ПАДА · губиш, когато расте"
    zones = (f'<rect x="{win_x0:.1f}" y="{mid-9}" width="{win_x1-win_x0:.1f}" height="18" fill="var(--ok)" opacity="0.14"/>'
             f'<rect x="{loss_x0:.1f}" y="{mid-9}" width="{loss_x1-loss_x0:.1f}" height="18" fill="var(--err)" opacity="0.14"/>')
    axis = f'<line x1="{X(lo)}" y1="{mid}" x2="{X(hi)}" y2="{mid}" stroke="var(--border)" stroke-width="1.5"/>'
    sl_svg = ""
    if sl:
        x_sl = X(sl)
        sl_svg = (f'<line x1="{x_sl:.1f}" y1="{mid-16}" x2="{x_sl:.1f}" y2="{mid+16}" stroke="var(--err)" stroke-width="2.5"/>'
                  f'<text x="{x_sl:.1f}" y="{mid+30}" fill="var(--err)" font-size="11" text-anchor="middle">SL {sl:.5f}</text>')
    pnl = float(p.get("pnl") or 0.0)
    cur_col = "var(--ok)" if (cur - entry) * (1 if buy else -1) >= 0 else "var(--err)"
    marker = (f'<line x1="{x_entry:.1f}" y1="{mid-16}" x2="{x_entry:.1f}" y2="{mid+16}" stroke="var(--fg)" stroke-width="1.5" stroke-dasharray="3 3"/>'
              f'<text x="{x_entry:.1f}" y="{mid-34}" fill="var(--fg)" font-size="11" text-anchor="middle">вход {entry:.5f}</text>'
              f'<circle cx="{x_cur:.1f}" cy="{mid}" r="5" fill="{cur_col}"/>'
              f'<text x="{x_cur:.1f}" y="{mid+30}" fill="{cur_col}" font-size="11" text-anchor="middle">сега {cur:.5f} ({pnl:+.2f} €)</text>')
    return (f'<svg viewBox="0 0 {w} {h}" style="width:100%;height:auto;display:block;margin:4px 0 8px" '
            f'role="img" aria-label="Карта на позицията">'
            f'<text x="30" y="20" fill="var(--muted)" font-size="12">{e(p["symbol"])} · {e(p["dir"])} · {rule}</text>'
            f'{zones}{axis}{sl_svg}{marker}{arrow}</svg>')


def _engine_trades() -> list[dict]:
    """Затворени сделки на двигателя (magic 750501), сдвоени по символ:
    отваряща (BUY/SELL) + следваща срещуположна = затворена. Без position_id в
    журнала — затова сдвояването е по посока във времето."""
    deals = read_jsonl(LOGS_DIR / "deals_journal.jsonl")
    by_sym: dict[str, list[dict]] = {}
    for d in deals:
        if int(d.get("magic") or 0) != ENGINE_MAGIC or not (d.get("symbol") or ""):
            continue
        by_sym.setdefault(d["symbol"], []).append(d)

    def pnl(d: dict) -> float:
        return (float(d.get("profit") or 0) + float(d.get("commission") or 0)
                + float(d.get("swap") or 0))

    trades = []
    for sym, ds in by_sym.items():
        ds.sort(key=lambda d: d.get("time", ""))
        i = 0
        while i < len(ds):
            d = ds[i]
            nxt = ds[i + 1] if i + 1 < len(ds) else None
            if (nxt and d.get("type_name") in ("BUY", "SELL")
                    and nxt.get("type_name") in ("BUY", "SELL")
                    and nxt.get("type_name") != d.get("type_name")):
                trades.append({"symbol": sym, "dir": d.get("type_name", ""),
                               "profit": round(pnl(d) + pnl(nxt), 2),
                               "time": nxt.get("time", "")})
                i += 2
            else:
                i += 1
    return trades


def _stat_card(label: str, value: str, cls: str = "") -> str:
    return (f'<div class="card stat"><div class="stat-v {cls}">{e(value)}</div>'
            f'<div class="stat-l muted">{e(label)}</div></div>')


def _demo_gate_html() -> str:
    """Прогрес към live гейта: ≥30 демо сделки И expectancy > 0 (железно правило).
    Чете engine\\s5_state.json (closed_r — R множители на затворените сделки)."""
    try:
        ist = read_json(BASE_DIR / "engine" / "s5_state.json", {}) or {}
    except Exception:
        ist = {}
    cr = [float(x) for x in (ist.get("closed_r") or [])]
    n = len(cr)
    exp = (sum(cr[-20:]) / len(cr[-20:])) if cr else 0.0
    need_n, ok_exp = 30, exp > 0
    pct = min(100, round(n / need_n * 100))
    gate_ok = n >= need_n and ok_exp
    chip = ('<span class="chip ok">ГЕЙТЪТ Е МИНАТ</span>' if gate_ok
            else '<span class="chip warn">не е минат</span>')
    bar = (f'<div style="background:var(--border);border-radius:6px;height:10px;margin:8px 0">'
           f'<div style="width:{pct}%;height:100%;border-radius:6px;'
           f'background:{"var(--ok)" if gate_ok else "var(--accent)"}"></div></div>')
    return (f'<div class="card"><h3>{icon("shield", 18)} Демо гейт към live {chip}</h3>'
            f'<p>Затворени демо сделки: <b>{n} / {need_n}</b> · expectancy (последни 20): '
            f'<b>{exp:+.3f}R</b> (трябва &gt; 0)</p>{bar}'
            f'<p class="muted">Железното правило: реални пари само след {need_n} демо сделки '
            f'с положителен expectancy. Нулевите R са breakeven изходи — честни, не ги махам.</p></div>')


@app.route("/analytics")
def analytics_page() -> Response:
    pts = _equity_points()
    closed = sorted(_live_closed_trades(), key=lambda t: t["time"])
    open_pos = _live_open_positions()
    wins = [t for t in closed if t["profit"] > 0]
    losses = [t for t in closed if t["profit"] <= 0]
    gross_w = sum(t["profit"] for t in wins)
    gross_l = abs(sum(t["profit"] for t in losses))
    pf = gross_w / gross_l if gross_l > 0 else (float("inf") if gross_w > 0 else 0.0)
    exp_r = (gross_w - gross_l) / len(closed) if closed else 0.0
    eq_vals = [v for _, v in pts]
    peak, max_dd = 0.0, 0.0
    for v in eq_vals:
        peak = max(peak, v)
        max_dd = min(max_dd, v - peak)

    chart = _equity_svg(pts)
    cards = "".join([
        _stat_card("отворени сега", str(len(open_pos)), "warn" if open_pos else ""),
        _stat_card("затворени сделки", str(len(closed))),
        _stat_card("печеливши", f"{len(wins)} ({len(wins)/len(closed)*100:.0f}%)" if closed else "—", "ok"),
        _stat_card("profit factor", f"{pf:.2f}" if pf != float("inf") else "∞",
                   "ok" if pf >= 1.2 else ("warn" if pf >= 1.0 else "err")),
        _stat_card("средно на сделка", f"{exp_r:+.2f} €", "ok" if exp_r > 0 else "err"),
        _stat_card("чиста печалба", f"{(eq_vals[-1] if eq_vals else 0):+.2f} €",
                   "ok" if eq_vals and eq_vals[-1] > 0 else "err"),
    ])

                                          
    if open_pos:
        maps = "".join(_position_map_svg(p) for p in open_pos)
        orows = "".join(
            f'<tr><td>{e(p["symbol"])}</td><td>{e(p["dir"])}</td>'
            f'<td class="num">{p["entry"]:.5f}</td><td class="num">{p["current"]:.5f}</td>'
            f'<td class="num">{p["sl"]:.5f}</td>'
            f'<td class="num {"neg" if p["pnl"] < 0 else "pos"}">{p["pnl"]:+.2f} €</td>'
            f'<td class="num">{p["r"]:+.2f}R</td>'
            f'<td class="{"pos" if ("trail" in p["protection"] or "breakeven" in p["protection"]) else "na"}">'
            f'{e(p["protection"])}</td></tr>'
            for p in open_pos)
        open_html = (f'<div class="card"><h3>{icon("activity", 18)} Отворени позиции — живо</h3>{maps}'
                     f'<table><tr><th>Символ</th><th>Посока</th><th>Вход</th><th>Сега</th>'
                     f'<th>SL</th><th>P&amp;L</th><th>Резултат</th><th>Защита</th></tr>{orows}</table></div>')
    else:
        open_html = '<div class="card"><h3>Отворени позиции — живо</h3><p class="muted">Няма отворени позиции в момента.</p></div>'

                     
    monthly: dict[str, dict] = {}
    for t in closed:
        m = (t["time"] or "")[:7]
        if not m:
            continue
        rec = monthly.setdefault(m, {"n": 0, "pnl": 0.0, "w": 0})
        rec["n"] += 1
        rec["pnl"] += t["profit"]
        rec["w"] += 1 if t["profit"] > 0 else 0
    month_rows = "".join(
        f'<tr><td>{e(m)}</td><td>{r["n"]}</td><td>{r["w"]}</td>'
        f'<td class="{"ok" if r["pnl"] > 0 else "err"}">{r["pnl"]:+.2f} €</td></tr>'
        for m, r in sorted(monthly.items(), reverse=True)) or \
        '<tr><td colspan="4" class="muted">Още няма затворени сделки на двигателя.</td></tr>'

                                            
    jrows = "".join(
        f'<tr><td>{e((t["time"] or "")[:16].replace("T", " "))}</td>'
        f'<td>{e(t["symbol"])}</td><td>{e(t.get("dir", ""))}</td>'
        f'<td class="{"ok" if t["profit"] > 0 else "err"}">{t["profit"]:+.2f} €</td></tr>'
        for t in reversed(closed[-15:])) or \
        '<tr><td colspan="4" class="muted">Журналът се пълни с всяка затворена сделка.</td></tr>'

    body = (
        f'<div class="card"><h3>{icon("chart", 18)} Крива на търговската печалба '
        f'<span class="muted">(чисто от движението на пазара, без депозити)</span></h3>{chart}</div>'
        f'{_demo_gate_html()}'
        f'{open_html}'
        f'<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">{cards}</div>'
        f'<div class="card"><h3>Месечна разбивка</h3><table><tr><th>Месец</th><th>Сделки</th>'
        f'<th>Печеливши</th><th>P&amp;L</th></tr>{month_rows}</table></div>'
        f'<div class="card"><h3>Журнал на затворените сделки</h3>'
        f'<table><tr><th>Време</th><th>Символ</th><th>Посока</th><th>P&amp;L</th></tr>{jrows}</table></div>')
    return shell(body, active="/analytics", title="Аналитика", refresh=120)


def _read_inbox() -> list[dict]:
    inbox = LOGS_DIR / "telemetry_inbox.jsonl"
    rows: list[dict] = []
    if inbox.exists():
        for line in inbox.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    return rows


def _is_owner_machine() -> bool:
    """Само машината на собственика носи telemetry_owner.json (никога не се
    публикува в клиентския пакет). Страници като /clients са само за него."""
    return (BASE_DIR / "config" / "telemetry_owner.json").exists()


@app.route("/clients")
def clients_page() -> Response:
    if not _is_owner_machine():
        return redirect("/")
    rows = _read_inbox()
    by_machine: dict[str, list[dict]] = {}
    for r in rows:
        by_machine.setdefault(str(r.get("machine") or "?"), []).append(r)
    if not by_machine:
        body = ('<div class="card"><h3>Клиенти</h3>'
                '<p class="muted">Все още няма телеметрични събития. '
                'Когато клиентска машина докладва, тя се появява тук.</p></div>')
        return shell(body, active="/clients", title="Клиенти")
    cards = []
    for mid, evs in sorted(by_machine.items()):
        last = evs[-1]
        ago = NA
        mins = None
        try:
            from datetime import datetime as _dt
            ts = _dt.fromisoformat(str(last.get("ts", "")).replace("Z", "+00:00"))
            mins = (datetime.now(timezone.utc) - ts).total_seconds() / 60
            ago = ("току-що" if mins < 2 else
                   f"преди {int(mins)} мин" if mins < 120 else
                   f"преди {int(mins // 60)} ч" if mins < 2880 else
                   f"преди {int(mins // 1440)} дни")
        except Exception:
            pass
        # Dead-man пулс: selftest_ok е дневният „жив съм" на всяка машина.
        if mins is not None and mins > 50 * 60:
            state = f'<span class="chip bad">мълчи &gt;2 дни — провери я</span>'
        elif mins is not None and mins > 26 * 60:
            state = '<span class="chip warn">мълчи &gt;26 ч — пулсът ѝ закъснява</span>'
        elif last.get("kind") == "selftest_fail":
            state = '<span class="chip bad">проблем</span>'
        else:
            state = '<span class="chip ok">жива</span>'
        hist = "".join(
            f'<tr><td class="muted">{e((str(ev.get("ts", "")))[:16].replace("T", " "))}</td>'
            f'<td>{e(str(ev.get("kind", "?")))}</td>'
            f'<td>{e(str(ev.get("text", ""))[:180])}</td></tr>'
            for ev in reversed(evs[-12:]))
        cards.append(f"""
<div class="card">
  <h3>{icon("users", 18)} Машина <code>{e(mid)}</code> {state}</h3>
  <table class="kv">
    <tr><td>Последен контакт</td><td>{e(ago)} · {e(str(last.get("ts", ""))[:19].replace("T", " "))} UTC</td></tr>
    <tr><td>Събития общо</td><td>{len(evs)}</td></tr>
  </table>
  <table style="margin-top:8px"><tr><th>Час (UTC)</th><th>Вид</th><th>Съдържание</th></tr>{hist}</table>
</div>""")
    body = (f'<div class="card"><h3>Наблюдение на клиентите</h3>'
            f'<p class="muted">Последните доклади от клиентските машини '
            f'(грешки, пулсове, промени в настройките). Когато клиент се обади — '
            f'виж тук какво е пипал и му кажи точната стъпка.</p></div>'
            + "".join(cards))
    return shell(body, active="/clients", title="Клиенти", refresh=120)


@app.route("/journal")
def journal_page() -> Response:
    lines = read_jsonl(LOGS_DIR / "decisions.jsonl")
    deals = read_jsonl(LOGS_DIR / "deals_journal.jsonl")
    all_symbols = set(_journal_symbols(lines)) | {
        (d.get("symbol") or "").strip().upper() for d in deals if (d.get("symbol") or "").strip()}
    all_symbols = sorted(all_symbols)

    sym = request.args.get("symbol", "").strip().upper()
    if sym and sym not in all_symbols:
        sym = ""

    options = [f'<option value="">всички символи</option>'] + [
        f'<option value="{e(s)}"{" selected" if s == sym else ""}>{e(s)}</option>'
        for s in all_symbols]

    cycle_lines = [l for l in lines if l.get("action")]
    shown = list(reversed(cycle_lines[-100:]))
    if sym:
        shown = [l for l in shown
                 if any((s.get("symbol") or "").upper() == sym for s in (l.get("symbols") or []))]

    sig_rows = []
    for line in shown:
        action = line.get("action") or {}
        atype = action.get("type") or line.get("decision") or NA
        badge = ACTION_BADGE.get(str(atype).upper(), "")
        chips = ""
        for s in line.get("symbols") or []:
            score = s.get("signal_score")
            chips += (f'<span class="badge">{e(s.get("symbol", NA))} · '
                      f'{e(s.get("result", NA))}'
                      + (f' · {e(score)}/100' if score is not None else "")
                      + "</span> ")
        reason = action.get("reason") or line.get("reason") or ""
        sig_rows.append(
            f'<tr><td class="muted" style="white-space:nowrap">{e(fmt_dt(line.get("ts") or line.get("time_utc")))}</td>'
            f'<td><span class="badge {badge}">{e(atype)}</span></td>'
            f'<td>{e(reason)}</td><td>{chips}</td></tr>')
    signals_html = (
        "<table><tr><th>време</th><th>действие</th><th>причина</th><th>символи</th></tr>"
        + "".join(sig_rows) + "</table>") if sig_rows else f'<p class="na">{NA}</p>'

    deal_shown = list(reversed(deals[-100:]))
    if sym:
        deal_shown = [d for d in deal_shown if (d.get("symbol") or "").upper() == sym]
    deal_rows = []
    for d in deal_shown:
        tname = str(d.get("type_name") or "")
        kind = DEAL_TYPE_BG.get(tname, tname or NA)
        profit = d.get("profit")
        try:
            pnl_txt = f"{float(profit):+.2f} €"
            pnl_cls = "pos" if float(profit) >= 0 else "neg"
        except (TypeError, ValueError):
            pnl_txt = NA
            pnl_cls = ""
        deal_rows.append(
            f'<tr><td class="muted" style="white-space:nowrap">{e(fmt_dt(d.get("time")))}</td>'
            f'<td>{e(d.get("ticket", NA))}</td>'
            f'<td>{e(d.get("symbol") or "—")}</td>'
            f'<td><span class="badge">{e(kind)}</span></td>'
            f'<td class="num {pnl_cls}">{e(pnl_txt)}</td>'
            f'<td class="muted">{e(d.get("comment", ""))}</td></tr>')
    deals_html = (
        "<table><tr><th>време</th><th>ticket</th><th>символ</th><th>вид</th>"
        "<th>печалба</th><th>бележка</th></tr>"
        + "".join(deal_rows) + "</table>") if deal_rows else f'<p class="na">{NA}</p>'

    script = """<script>
document.addEventListener('DOMContentLoaded',function(){
var s=document.getElementById('symSel');if(s){s.addEventListener('change',function(){
var v=s.value;location.href=v?'/journal?symbol='+encodeURIComponent(v):'/journal';});}
});</script>"""

    body = f"""
<div class="card">
  <h3>Сигнали</h3>
  <p><select id="symSel" style="max-width:220px">{"".join(options)}</select>
     <span class="muted">последни {len(shown)} записа от decisions.jsonl</span></p>
  {signals_html}
</div>
<div class="card">
  <h3>Сделки</h3>
  <p class="muted">последни {len(deal_shown)} записа от deals_journal.jsonl</p>
  {deals_html}
</div>
{script}"""
    return shell(body, active="/journal", title="Сигнали")


                                 

MSG_LEVEL_BADGE = {"info": "", "warning": "wdb", "alert": "stopb", "error": "stopb"}


def telegram_status_badge() -> str:
    try:
        tg = (json.loads((BASE_DIR / "config" / "notify.json").read_text(encoding="utf-8"))
              ).get("telegram") or {}
    except Exception:
        tg = {}
    if tg.get("enabled") and (tg.get("token") or "").strip() \
            and str(tg.get("chat_id") or "").strip():
        return '<span class="badge okb">Telegram: включен</span>'
    if tg.get("enabled"):
        return '<span class="badge wdb">Telegram: включен, но липсват token/chat_id</span>'
    return ('<span class="badge">Telegram: изключен</span> '
            '<span class="muted">конфиг: config\\notify.json</span>')


@app.route("/messages")
def messages_page() -> Response:
    rows = read_jsonl(LOGS_DIR / "messages.jsonl")[-100:][::-1]
    relay = telegram_status_badge()
    if not rows:
        feed = f'<p class="na">няма съобщения още</p>'
    else:
        items = []
        for r in rows:
            lvl = r.get("level", "info")
            badge = MSG_LEVEL_BADGE.get(lvl, "")
            items.append(
                f'<div class="msg lvl-{e(lvl)}"><div class="msg-meta">'
                f'<span><span class="badge {badge}">{e(lvl)}</span></span>'
                f'<span class="muted msg-ts">{e(fmt_dt(r.get("ts")))}</span></div>'
                f'<div class="msg-body">{e(r.get("text", ""))}'
                f'<div class="muted msg-cat">{e(r.get("category", ""))}</div></div></div>')
        feed = f'<div class="feed">{"".join(items)}</div>'
    body = (f'<div class="card"><h3>Съобщения</h3>{relay} '
            f'<span class="muted">последни {len(rows)}</span>{feed}</div>')
    return shell(body, active="/messages", title="Съобщения", refresh=15)


                                 

SETTINGS_GUIDANCE = """
<h4>1. Нов акаунт — правилно отваряне</h4>
<ul>
  <li>Admirals <b>реална</b> сметка (не демо).</li>
  <li>MT5 в <b>hedging</b> режим (не netting).</li>
  <li>Валута по възможност <b>EUR</b>.</li>
  <li>Ливъридж <b>30:1</b> е ОК за 0.01 лот (маржин ≈ €33/позиция EURUSD).</li>
</ul>

<h4>2. Bridge инсталация</h4>
<ul>
  <li>Точно <b>1 графика GBPUSD H1</b>.</li>
  <li>За Live собственикът задава ръчно <code>InpEnableLiveOrders=true</code>
      (по подразбиране false).</li>
  <li>Бутон <b>Algo Trading ВКЛ</b>.</li>
  <li>Премахни всяка втора инстанция (иначе двойни поръчки — OPS_MAP §7.1).</li>
</ul>

<h4>3. Live активиране в Control Center</h4>
<ol>
  <li>Спри engine и затвори позиции.</li>
  <li>Провери login / type / server.</li>
  <li>Избери риск профил.</li>
  <li>Напиши <b>РАЗБИРАМ LIVE РИСКА</b>.</li>
  <li>„Провери готовността“.</li>
  <li>Стартирай.</li>
</ol>

<h4>4. Риск профил според баланса</h4>
<table>
  <tr><th>Баланс</th><th>Профил</th><th>Бележка</th></tr>
  <tr><td>&lt; €500</td><td>—</td><td>продуктът е <b>ПАЗАЧ</b> (обем-проверката правилно
      отказва — не е бъг)</td></tr>
  <tr><td>€500–1k</td><td>low · 0.25%</td><td>първи live стъпки</td></tr>
  <tr><td>€1k–5k</td><td>low/medium · 0.5%</td><td>след стабилни резултати</td></tr>
  <tr><td>&gt; €5k</td><td>по преценка</td><td>high 1% само след 60+ сделки с PF ≥ 1.2</td></tr>
</table>

<h4>5. Swing-live engine (когато бъде одобрена стратегия)</h4>
<ul>
  <li>Риск/сделка = загуба до SL при 0.01 лот ÷ баланс
      (пример: SL 25 пипса EURUSD = €2.50 → при €150 = <b>1.7%</b>).</li>
  <li>Максимум <b>1–2 позиции</b> едновременно.</li>
  <li><b>Weekly stop −8%</b>.</li>
  <li><b>6 поредни загуби = стоп</b> — преглед на стратегията.</li>
</ul>

<h4>6. Машината</h4>
<ul>
  <li>Windows <b>без sleep</b> при работа (от админ:
      <code>powercfg /change standby-timeout-ac 0</code>).</li>
  <li><b>Google Drive for Desktop</b> винаги пуснат (ъпдейт канала живее там).</li>
  <li><code>ROBOT.bat status</code> всеки ден.</li>
</ul>
"""


def _parse_symbols(raw: str) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for part in raw.split(","):
        s = part.strip().upper()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _log_settings_event(mode: str, risk: float, lot: float, cyc: int,
                        symbols: list[str], news: bool) -> None:
    try:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        event = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
            "type": "settings_change",
            "source": "dashboard",
            "changed_by": session.get("user_email") or "local",
            "changes": {"mode": mode, "risk_pct": risk, "max_lot": lot,
                        "cycle_seconds": cyc, "symbols": symbols,
                        "news_blackout": news},
        }
        with (LOGS_DIR / "decisions.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False) + "\n")
    except OSError:
        pass
    try:
        import importlib.util as _ilu
        _spec = _ilu.spec_from_file_location(
            "telemetry", BASE_DIR / "engine" / "telemetry.py")
        _tel = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(_tel)
        _tel.send_event("settings_change",
                        f"настройки: mode={mode} риск={risk}% lot={lot} "
                        f"цикъл={cyc}s символи={','.join(symbols)} "
                        f"news={'on' if news else 'off'}")
    except Exception:
        pass


def render_checklist() -> str:
    cls_map = {"✅": "ok", "❌": "err", "⚠️": "warn", "ℹ️": "", "⬆️": ""}
    items = []
    for icn, name, detail in settings_checklist():
        cls = cls_map.get(icn, "")
        items.append(
            f'<div class="check-row {cls}"><span class="check-ic">{icn}</span>'
            f'<div><div class="check-name">{e(name)}</div>'
            f'<div class="muted">{detail}</div></div></div>')
    return f'<div class="checklist">{"".join(items)}</div>'


SETTINGS_JS = """<script>
document.addEventListener('DOMContentLoaded',function(){
var s=document.getElementById('modeSel'),w=document.getElementById('liveWarn');
if(s&&w){s.addEventListener('change',function(){w.style.display=s.value==='live'?'':'none';});}
});
</script>"""


                                 

def _bridge_status() -> tuple[bool, str]:
    """Намира инсталирания bridge .ex5; връща (намерен, път)."""
    if BRIDGE_EX5.exists():
        return True, str(BRIDGE_EX5)
    if BRIDGE_EX5_SOURCE.exists():
        return True, str(BRIDGE_EX5_SOURCE)
    return False, str(BRIDGE_EX5)


def _notify_settings() -> dict:
    """Чете config\\notify.json -> telegram секция ({} при липса/грешка)."""
    try:
        cfg = json.loads(NOTIFY_CONFIG.read_text(encoding="utf-8"))
        return dict(cfg.get("telegram") or {})
    except Exception:
        return {}


def _mask_token(token: str) -> str:
    """Маскира токен: първите 8 + … + последните 4 символа."""
    token = token.strip()
    if not token:
        return ""
    if len(token) <= 12:
        return token[:2] + "…"
    return token[:8] + "…" + token[-4:]


def _news_api_key() -> str:
    """Чете config\\news_provider.json -> gnews_api_key ("" при липса/грешка)."""
    try:
        data = json.loads(NEWS_PROVIDER_CONFIG.read_text(encoding="utf-8"))
        return str(data.get("gnews_api_key") or "").strip()
    except Exception:
        return ""


GUARD_KEYS_CONFIG = CONFIG_DIR_DASH / "guard_keys.json"


def _guard_keys() -> dict:
    """Чете config\\guard_keys.json -> {"newsapi_key","finnhub_key"} ("" при липса)."""
    keys = {"newsapi_key": "", "finnhub_key": ""}
    try:
        data = json.loads(GUARD_KEYS_CONFIG.read_text(encoding="utf-8"))
        for k in keys:
            keys[k] = str(data.get(k) or "").strip()
    except Exception:
        pass
    return keys


def _guard_state_doc() -> dict:
    """logs\\guard_state.json ({} при липса/грешка)."""
    try:
        return json.loads((LOGS_DIR / "guard_state.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


_FETCH_GUARD = None
def _fetch_guard():
    """scripts\\fetch_guard.py като модул (събирачът на пазителния слой)."""
    global _FETCH_GUARD
    if _FETCH_GUARD is None:
        scripts_dir = str(BASE_DIR / "scripts")
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        import fetch_guard as fg
        _FETCH_GUARD = fg
    return _FETCH_GUARD


_FETCH_NEWS = None
def _fetch_news():
    """scripts\\fetch_news.py като модул (събирачът на новини за кеша)."""
    global _FETCH_NEWS
    if _FETCH_NEWS is None:
        scripts_dir = str(BASE_DIR / "scripts")
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        import fetch_news as fn
        _FETCH_NEWS = fn
    return _FETCH_NEWS


_FETCH_SOCIAL = None
def _fetch_social():
    """scripts\\fetch_social.py като модул (събирачът на социалния пулс)."""
    global _FETCH_SOCIAL
    if _FETCH_SOCIAL is None:
        scripts_dir = str(BASE_DIR / "scripts")
        if scripts_dir not in sys.path:
            sys.path.insert(0, scripts_dir)
        import fetch_social as fs
        _FETCH_SOCIAL = fs
    return _FETCH_SOCIAL


@app.route("/settings", methods=["GET", "POST"])
def settings_page() -> Response:
    cfg = read_json(ENGINE_CONFIG, {}) or {}
    errors: list[str] = []
    autodetect_notes: list[str] = []
    saved = False

    mode = str(cfg.get("mode") or "demo")
    risk_s = str(cfg.get("risk_pct") if cfg.get("risk_pct") is not None else "0.25")
    lot_s = str(cfg.get("max_lot") if cfg.get("max_lot") is not None else "0.05")
    cyc_s = str(cfg.get("cycle_seconds") if cfg.get("cycle_seconds") is not None else "900")
    sym_s = ", ".join(cfg.get("symbols") or [])
    news = bool((cfg.get("news_blackout") or {}).get("enabled"))
    demo_login_s = str(cfg.get("demo_login") or "")
    live_server = str(cfg.get("live_server") or "")

    # Какво е закачено в MT5 точно сега (за автозасичане и подсказка във формата)
    try:
        acc_now = get_account()
    except Exception:
        acc_now = None
    if request.method == "GET" and acc_now:
        # предпопълване само на ПРАЗНИ полета от живия терминал
        if not live_server and int(acc_now["trade_mode"]) == 2:
            live_server = str(acc_now["server"])
        if not demo_login_s and int(acc_now["trade_mode"]) != 2:
            demo_login_s = str(acc_now["login"])
    mt5_hint = ("няма връзка с терминала" if not acc_now else
                f"сметка …{str(acc_now['login'])[-4:]} · {acc_now['server']} · "
                f"{'РЕАЛНА' if int(acc_now['trade_mode']) == 2 else 'ДЕМО'}")

    if request.method == "POST":
        mode = request.form.get("mode", "")
        risk_s = (request.form.get("risk_pct") or "").strip()
        lot_s = (request.form.get("max_lot") or "").strip()
        cyc_s = (request.form.get("cycle_seconds") or "").strip()
        sym_s = request.form.get("symbols") or ""
        news = bool(request.form.get("news_blackout"))
        demo_login_s = (request.form.get("demo_login") or "").strip()
        live_server = (request.form.get("live_server") or "").strip()

        risk = lot = cyc = None
        demo_login = None
        symbols: list[str] = []
        if mode not in ("demo", "live"):
            errors.append("Режимът трябва да е demo или live.")
        if demo_login_s:
            try:
                demo_login = int(demo_login_s)
            except ValueError:
                errors.append("Демо логинът трябва да е цяло число (номерът на демо сметката).")

        # Автозасичане от MT5 — клиентът не рови във файлове: празните полета за
        # избрания режим се взимат от терминала, който е закачен в момента.
        need_live = mode == "live" and not live_server
        need_demo = mode == "demo" and demo_login is None and not demo_login_s \
            and not cfg.get("demo_login")
        if need_live or need_demo:
            if acc_now is None:
                errors.append("MT5 не отговаря — не мога да засека сметката автоматично. "
                              "Стартирай терминала или попълни полетата ръчно.")
            elif need_live:
                if int(acc_now["trade_mode"]) == 2:
                    live_server = str(acc_now["server"])
                    autodetect_notes.append(
                        f"Live сървърът е засечен от MT5: {live_server} "
                        f"(сметка …{str(acc_now['login'])[-4:]})")
                else:
                    errors.append(
                        f"Терминалът сега е на ДЕМО сметка …{str(acc_now['login'])[-4:]} "
                        f"({acc_now['server']}) — за live логни реалната сметка в MT5 "
                        f"и запази пак.")
            else:
                if int(acc_now["trade_mode"]) != 2:
                    demo_login = int(acc_now["login"])
                    autodetect_notes.append(f"Демо логинът е засечен от MT5: {demo_login}")
                else:
                    errors.append(
                        f"Терминалът сега е на РЕАЛНА сметка …{str(acc_now['login'])[-4:]} — "
                        f"за demo режим логни демо сметката в MT5 и запази пак.")
        if mode == "demo" and demo_login is None and not demo_login_s and cfg.get("demo_login"):
            demo_login = int(cfg["demo_login"])
        if live_server and len(live_server) < 3:
            errors.append("Името на live сървъра изглежда твърде късо — копирай го точно от MT5.")
        try:
            risk = float(risk_s.replace(",", "."))
            if not 0.05 <= risk <= 2.0:
                errors.append("Риск % на сделка трябва да е между 0.05 и 2.")
        except ValueError:
            errors.append("Риск % на сделка трябва да е число.")
        try:
            lot = float(lot_s.replace(",", "."))
            if lot <= 0:
                errors.append("Макс. лот трябва да е положително число.")
        except ValueError:
            errors.append("Макс. лот трябва да е число.")
        try:
            cyc = int(cyc_s)
            if cyc < 60:
                errors.append("Цикълът (секунди) трябва да е ≥ 60.")
        except ValueError:
            errors.append("Цикълът трябва да е цяло число.")
        symbols = _parse_symbols(sym_s)
        if not symbols:
            errors.append("Въведи поне един символ (разделени със запетая).")

        if not errors:
            new_cfg = dict(cfg)
            new_cfg.update(mode=mode, risk_pct=risk, max_lot=lot,
                           cycle_seconds=cyc, symbols=symbols,
                           demo_login=demo_login,
                           live_server=live_server or None)
            nb = dict(new_cfg.get("news_blackout") or {})
            nb["enabled"] = bool(news)
            new_cfg["news_blackout"] = nb
            try:
                BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
                if ENGINE_CONFIG.exists():
                    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    shutil.copy2(ENGINE_CONFIG, BACKUPS_DIR / f"config_{stamp}.json")
                tmp = ENGINE_CONFIG.with_name("config.json.tmp")
                tmp.write_text(json.dumps(new_cfg, ensure_ascii=False, indent=2) + "\n",
                               encoding="utf-8")
                tmp.replace(ENGINE_CONFIG)
                _log_settings_event(mode, risk, lot, cyc, symbols, bool(news))
                cfg = new_cfg
                saved = True
            except OSError as exc:
                errors.append(f"Записът в config.json се провали: {exc}")

    err_html = ""
    if errors:
        err_html = (f'<div class="banner danger">{icon("warn")}<div><b>Грешки:</b><ul>'
                    + "".join(f"<li>{e(m)}</li>" for m in errors)
                    + "</ul></div></div>")
    ok_html = ""
    if saved:
        note = (" " + " · ".join(autodetect_notes) + ".") if autodetect_notes else ""
        ok_html = (f'<div class="banner success">{icon("check")}<div><b>Настройките са '
                   f'запазени.{e(note)}</b> Двигателят ги чете само при старт — ако върви, '
                   f'натисни „Рестартирай двигателя“ в картата Система, за да влязат в сила.'
                   f'</div></div>')
    tg_html = ""
    tg_arg = request.args.get("tg")
    if tg_arg == "saved":
        tg_html = (f'<div class="banner success">{icon("check")}<div><b>Telegram '
                   f'настройките са запазени.</b></div></div>')
    elif tg_arg == "ok":
        tg_html = (f'<div class="banner success">{icon("check")}<div><b>Тестовото '
                   f'съобщение е изпратено в Telegram.</b></div></div>')
    elif tg_arg == "err":
        tg_html = (f'<div class="banner danger">{icon("warn")}<div><b>Telegram:</b> '
                   f'{e(request.args.get("msg") or "Неизвестна грешка.")}</div></div>')
    news_html = ""
    news_arg = request.args.get("news")
    if news_arg == "saved":
        news_html = (f'<div class="banner success">{icon("check")}<div><b>GNews '
                     f'ключът е запазен.</b></div></div>')
    elif news_arg == "ok":
        news_html = (f'<div class="banner success">{icon("check")}<div><b>Проверката '
                     f'на GNews мина:</b> {e(request.args.get("msg") or "")}</div></div>')
    elif news_arg == "err":
        news_html = (f'<div class="banner danger">{icon("warn")}<div><b>GNews:</b> '
                     f'{e(request.args.get("msg") or "Неизвестна грешка.")}</div></div>')
    guard_html = ""
    guard_arg = request.args.get("guard")
    if guard_arg == "saved":
        guard_html = (f'<div class="banner success">{icon("check")}<div><b>Ключовете на '
                      f'пазителния слой са запазени.</b></div></div>')
    elif guard_arg == "ok":
        guard_html = (f'<div class="banner success">{icon("check")}<div><b>Проверката на '
                      f'пазителя мина:</b> {e(request.args.get("msg") or "")}</div></div>')
    elif guard_arg == "err":
        guard_html = (f'<div class="banner danger">{icon("warn")}<div><b>Пазителен слой:</b> '
                      f'{e(request.args.get("msg") or "Неизвестна грешка.")}</div></div>')
    social_html = ""
    social_arg = request.args.get("social")
    if social_arg == "ok":
        social_html = (f'<div class="banner success">{icon("check")}<div><b>Социалният пулс '
                       f'е проверен:</b> {e(request.args.get("msg") or "")}</div></div>')
    elif social_arg == "err":
        social_html = (f'<div class="banner danger">{icon("warn")}<div><b>Социален пулс:</b> '
                       f'{e(request.args.get("msg") or "Неизвестна грешка.")}</div></div>')
    live_style = "" if mode == "live" else ' style="display:none"'
    sys_notice = session.pop("_control_notice", None)
    sys_notice_html = ""
    if isinstance(sys_notice, dict):
        nkind = sys_notice.get("kind") if sys_notice.get("kind") in {
            "success", "danger", "warn"} else "warn"
        sys_notice_html = (f'<div class="banner {nkind}">{icon("check")}<div><b>'
                           f'{e(sys_notice.get("title", "Готово"))}</b> '
                           f'{e(sys_notice.get("detail", ""))}</div></div>')
    live_banner = (
        f'<div class="banner danger" id="liveWarn"{live_style}>'
        f'{icon("warn")}<div><b>Жива търговия</b> — риск от реални загуби. '
        f'Увери се, че сметката, рискът и bridge настройките са правилни, '
        f'преди да запазиш.</div></div>')
    bridge_banner = (
        f'<div class="banner warn">{icon("warn")}<div><b>Bridge:</b> сложи '
        f'<code>AdmiralBetaBridge.ex5</code> само на <b>1 графика (GBPUSD H1)</b> и '
        f'<code>InpEnableDemoOrders=false</code>.</div></div>')

    bridge_found, bridge_path = _bridge_status()
    bridge_state = ('<span class="chip ok">инсталиран</span>' if bridge_found
                    else '<span class="chip bad">липсва</span>')
    bridge_card = f"""
<div class="card">
  <h3>Bridge към MT5</h3>
  <p class="muted">Bridge е малка програма (Expert Advisor), която стои на една графика в
  MT5 и докладва на таблото какво става в терминала. Статус: {bridge_state}</p>
  <p style="margin:6px 0 14px">Файл: <code>{e(bridge_path)}</code></p>
  <form method="post" action="/settings/bridge/open-folder" style="display:inline-block;margin:0 8px 14px 0">
    <button type="submit" class="btn secondary">{icon("file", 14)} Отвори папката</button></form>
  <form method="post" action="/settings/bridge/start-mt5" style="display:inline-block;margin:0 0 14px 0">
    <button type="submit" class="btn secondary">{icon("check", 14)} Стартирай MT5</button></form>
  <ol class="steps">
    <li>Натисни <b>Стартирай MT5</b> (или го отвори сам).</li>
    <li>В MT5: <b>Navigator</b> (Ctrl+N) → <b>Expert Advisors</b> → плъзни
        <b>AdmiralBetaBridge</b> върху графика <b>GBPUSD, H1</b> — само върху една графика.</li>
    <li>Натисни <b>F7</b> върху графиката → раздел <b>Inputs</b> →
        <code>InpEnableDemoOrders=false</code> → OK.</li>
    <li>Включи <b>Algo Trading</b> (бутонът в горната лента на MT5) — иначе bridge мълчи.</li>
  </ol>
  <p class="muted">След 1–2 минути редът „Bridge" в Таблото трябва да стане зелен.</p>
</div>"""

    tg_cfg = _notify_settings()
    tg_enabled = bool(tg_cfg.get("enabled"))
    tg_token = str(tg_cfg.get("token") or "").strip()
    tg_chat = str(tg_cfg.get("chat_id") or "").strip()
    if tg_enabled and tg_token and tg_chat:
        tg_state = '<span class="chip ok">активни</span>'
    elif tg_enabled:
        tg_state = '<span class="chip bad">включени, но липсват token/chat_id</span>'
    else:
        tg_state = '<span class="chip bad">изключени</span>'
    telegram_card = f"""
<div class="card">
  <h3>Telegram известия</h3>
  <p class="muted">Получавай съобщения от робота (сделки, грешки, статус) директно в
  Telegram. Правиш бот така: в Telegram отвори <b>@BotFather</b>, пиши
  <code>/newbot</code>, следвай стъпките и копирай получения токен тук. За chat_id:
  напиши нещо на новия бот, после отвори <b>@userinfobot</b> и копирай числото тук.
  Статус: {tg_state}</p>
  <form method="post" action="/settings/telegram/save" class="form">
    <div class="field"><label class="flabel" for="f-tg-token">Bot token (от @BotFather)</label>
      <input id="f-tg-token" type="password" name="token" value="{e(_mask_token(tg_token))}"
             autocomplete="off"></div>
    <div class="field"><label class="flabel" for="f-tg-chat">Chat ID (от @userinfobot)</label>
      <input id="f-tg-chat" type="text" name="chat_id" value="{e(tg_chat)}"></div>
    <div class="field-check">
      <input type="checkbox" name="enabled" id="f-tg-en"{" checked" if tg_enabled else ""}>
      <label for="f-tg-en">Активни известия</label></div>
    <p style="margin:18px 0 0"><button type="submit" class="btn">Запази</button></p>
  </form>
  <form method="post" action="/settings/telegram/test" style="display:inline-block;margin:14px 8px 14px 0">
    <button type="submit" class="btn secondary">{icon("chat", 14)} Изпрати тест</button></form>
  <p class="muted">Токенът се показва маскиран; за смяна постави новия, а празното поле
  запазва текущия. „Изпрати тест" праща пробно съобщение и показва резултата горе.</p>
</div>"""

    gnews_key = _news_api_key()
    news_state = ('<span class="chip ok">ключ наличен</span>' if gnews_key
                  else '<span class="chip bad">ключ липсва</span>')
    news_card = f"""
<div class="card">
  <h3>Новинарски източник (GNews)</h3>
  <p class="muted">Програмата следи икономическите новини и може да спира новите сделки
  около важни събития (Fed, ECB, CPI…). Източникът е GNews — безплатен ключ от:
  <a href="https://gnews.io" target="_blank">gnews.io</a> → „Регистрирай се" →
  Dashboard → API key (Free план: 100 заявки/ден — достатъчно).
  Статус: {news_state}</p>
  <form method="post" action="/settings/news/save" class="form">
    <div class="field"><label class="flabel" for="f-gnews-key">GNews API ключ</label>
      <input id="f-gnews-key" type="password" name="gnews_api_key" value="{e(_mask_token(gnews_key))}"
             autocomplete="off"></div>
    <p style="margin:18px 0 0"><button type="submit" class="btn">Запази</button></p>
  </form>
  <form method="post" action="/settings/news/test" style="display:inline-block;margin:14px 8px 14px 0">
    <button type="submit" class="btn secondary">{icon("activity", 14)} Провери сега</button></form>
  <p class="muted">Ключът се показва маскиран; за смяна постави новия, а празното поле
  запазва текущия. „Провери сега" тества връзката с GNews (без запис на кеша) и показва
  броя новини горе.</p>
</div>"""

    gk = _guard_keys()
    newsapi_key, finnhub_key = gk["newsapi_key"], gk["finnhub_key"]
    guard_state = _guard_state_doc()
    try:
        guard_age = time.time() - (LOGS_DIR / "guard_state.json").stat().st_mtime
    except Exception:
        guard_age = None
    if guard_age is not None and guard_age < 2 * 3600:
        guard_state_txt = (f"<span class=\"chip ok\">свеж</span> "
                           f"geo={e(str(guard_state.get('geo_level') or 'няма'))} · "
                           f"velocity={e(str(guard_state.get('velocity') or 'няма'))}")
    else:
        guard_state_txt = '<span class="chip bad">няма свеж запис — пусни „Провери сега“</span>'
    guard_card = f"""
<div class="card">
  <h3>Пазителен слой (новини и риск)</h3>
  <p class="muted">Пазителят сваля ForexFactory календара (без ключ) и спира новите сделки
  15 мин преди → 30 мин след High-impact събития; по ключ може и геополитически риск
  (при HIGH се намаля рискът, при EXTREME/CRISIS търговията спира) и news velocity.
  Безплатни ключове: <a href="https://newsapi.org" target="_blank">newsapi.org</a>
  (Free план: 100 заявки/ден — достатъчно за 30 мин цикъл) и
  <a href="https://finnhub.io" target="_blank">finnhub.io</a> (Free план).
  Състояние: {guard_state_txt}</p>
  <form method="post" action="/settings/guard/save" class="form">
    <div class="field"><label class="flabel" for="f-newsapi-key">NewsAPI ключ (по избор)</label>
      <input id="f-newsapi-key" type="password" name="newsapi_key" value="{e(_mask_token(newsapi_key))}"
             autocomplete="off"></div>
    <div class="field"><label class="flabel" for="f-finnhub-key">Finnhub ключ (по избор)</label>
      <input id="f-finnhub-key" type="password" name="finnhub_key" value="{e(_mask_token(finnhub_key))}"
             autocomplete="off"></div>
    <p style="margin:18px 0 0"><button type="submit" class="btn">Запази</button></p>
  </form>
  <form method="post" action="/settings/guard/test" style="display:inline-block;margin:14px 8px 14px 0">
    <button type="submit" class="btn secondary">{icon("activity", 14)} Провери сега</button></form>
  <p class="muted">Ключовете се показват маскирани; празно поле запазва текущия. „Провери сега"
  пуска събирача без запис и показва geo/velocity/брой събития. Task Scheduler може да пуска
  scripts\\fetch_guard.py на всеки 30 мин за постоянен запис в logs.</p>
</div>"""

    pulse_doc = read_json(LOGS_DIR / "social_pulse.json") or {}
    pulse_dt = parse_ts(pulse_doc.get("fetched_utc"))
    if pulse_dt is not None:
        pulse_age_min = round((datetime.now(timezone.utc) - pulse_dt).total_seconds() / 60.0, 1)
        pulse_fresh = pulse_age_min < 120
    else:
        pulse_age_min, pulse_fresh = None, False
    pulse_counts = pulse_doc.get("counts") or {}
    if pulse_fresh:
        pulse_state_txt = (f'<span class="chip ok">свеж</span> преди {pulse_age_min} мин')
    else:
        pulse_state_txt = '<span class="chip bad">няма свеж запис</span>'
    pulse_bias = market_guard.social_bias(LOGS_DIR)
    pulse_bias_txt = (f"BULL {int(pulse_counts.get('bull') or 0)} · "
                      f"BEAR {int(pulse_counts.get('bear') or 0)}")
    if pulse_bias.get("usable") and pulse_bias.get("crowd"):
        pulse_bias_txt += (f' — <span class="badge wdb">crowd {e(str(pulse_bias["crowd"]))} '
                           f'ratio {e(str(pulse_bias.get("ratio")))}</span> '
                           f'<span class="muted">контрариан: само '
                           f'{e(_SOCIAL_DIR_BG.get(pulse_bias["crowd"], "?"))} входове, риск x0.75</span>')
    social_card = f"""
<div class="card">
  <h3>Социален пулс (Twitter/RSS)</h3>
  <p class="muted">Следи безплатно forex squawk акаунти в Twitter (през Nitter RSS огледала)
  и RSS новини (FXStreet, ForexLive, DailyFX) плюс Reddit — без ключове. Натрупаният
  crowd bias (BULL vs BEAR) действа контрарианно върху посоката на входовете и свива
  риска при консенсус. Състояние: {pulse_state_txt}</p>
  <table class="kv">
    <tr><td>Постове</td><td>{e(str(len(pulse_doc.get("posts") or [])))}</td></tr>
    <tr><td>Bias</td><td>{pulse_bias_txt}</td></tr>
  </table>
  <form method="post" action="/settings/social/refresh" style="display:inline-block;margin:14px 8px 14px 0">
    <button type="submit" class="btn secondary">{icon("activity", 14)} Обнови сега</button></form>
  <p class="muted">„Обнови сега" пуска събирача без запис и показва резултата горе.
  За постоянен запис в logs\\social_pulse.json планирай задача в Task Scheduler
  (scripts\\fetch_social.py) — тогава engine-ът чете bias-а всеки цикъл.</p>
</div>"""

    mode_opts = (f'<option value="demo"{" selected" if mode == "demo" else ""}>Демо (demo)</option>'
                 f'<option value="live"{" selected" if mode == "live" else ""}>Жива (live)</option>')

    body = f"""
{ok_html}{err_html}{tg_html}{news_html}{guard_html}{social_html}{sys_notice_html}
{_system_card()}
{_license_card()}
<div class="card">
  <h3>Настройки на engine</h3>
  <form method="post" class="form">
    <div class="field"><label class="flabel" for="modeSel">Режим</label>
      <select name="mode" id="modeSel">{mode_opts}</select></div>
    <div class="grid2">
      <div class="field"><label class="flabel" for="f-dlogin">Демо логин (за demo режим)</label>
        <input id="f-dlogin" type="number" name="demo_login" step="1" min="0"
               value="{e(demo_login_s)}" placeholder="празно = засича се от MT5"></div>
      <div class="field"><label class="flabel" for="f-lsrv">Live сървър (задължително за live)</label>
        <input id="f-lsrv" type="text" name="live_server"
               value="{e(live_server)}" placeholder="празно = засича се от MT5"></div>
    </div>
    <p class="muted" style="margin:2px 0 10px">MT5 сега: {e(mt5_hint)}. Ако полетата са празни,
      при „Запази" се засичат автоматично от терминала — за live трябва MT5 да е логнат
      в реалната сметка. Двигателят пуска само ако терминалът съвпада с това име —
      при несъответствие отказва с 0 поръчки.</p>
    <div class="grid2">
      <div class="field"><label class="flabel" for="f-risk">Риск % на сделка (0.05–2)</label>
        <input id="f-risk" type="number" name="risk_pct" step="0.05" min="0.05" max="2"
               value="{e(risk_s)}"></div>
      <div class="field"><label class="flabel" for="f-lot">Макс. лот</label>
        <input id="f-lot" type="number" name="max_lot" step="0.01" min="0.01"
               value="{e(lot_s)}"></div>
      <div class="field"><label class="flabel" for="f-cyc">Цикъл (секунди, ≥60)</label>
        <input id="f-cyc" type="number" name="cycle_seconds" step="1" min="60"
               value="{e(cyc_s)}"></div>
    </div>
    <div class="field"><label class="flabel" for="f-sym">Символи (разделени със запетая)</label>
      <input id="f-sym" type="text" name="symbols" value="{e(sym_s)}"></div>
    <div class="field-check">
      <input type="checkbox" name="news_blackout" id="f-nb"{" checked" if news else ""}>
      <label for="f-nb">News blackout (без нови сделки около икономически новини)</label></div>
    <p style="margin:18px 0 0"><button type="submit" class="btn">Запази настройките</button></p>
  </form>
  {live_banner}
  {bridge_banner}
</div>
{bridge_card}
{telegram_card}
{news_card}
{guard_card}
{social_card}
<div class="card">
  <h3>Препоръчителни настройки</h3>
  <p class="muted">Жива проверка на средата (bridge, heartbeat, статус файлове, бекъпи,
  сметка, версия и др.)</p>
  {render_checklist()}
</div>
<details class="card">
  <summary>Допълнителни насоки (акаунт, bridge, live активиране, риск профил)</summary>
  {SETTINGS_GUIDANCE}
</details>
{SETTINGS_JS}"""
    return shell(body, active="/settings", title="Настройки", refresh=None)


@app.route("/settings/bridge/open-folder", methods=["POST"])
def bridge_open_folder() -> Response:
    found, path = _bridge_status()
    folder = str(Path(path).parent) if found else str(BRIDGE_EX5.parent)
    try:
        subprocess.Popen(["explorer.exe", folder])
    except OSError:
        pass
    return redirect(url_for("settings_page"))


@app.route("/settings/bridge/start-mt5", methods=["POST"])
def bridge_start_mt5() -> Response:
    term = MT5_PORTABLE / "terminal64.exe"
    if term.exists():
        try:
            subprocess.Popen([str(term)], cwd=str(MT5_PORTABLE))
        except OSError:
            pass
    return redirect(url_for("settings_page"))


SYSTEM_ACTIONS_HTML = ""


@app.route("/settings/system/shutdown", methods=["POST"])
def system_shutdown() -> Response:
    ok, detail = _engine_stop()
    try:
        STOP_FLAG.write_text("stop\n", encoding="ascii")
    except OSError as exc:
        ok, detail = False, f"{detail} STOP.flag не можа да се запише: {exc}"
    try:
        QUIET_FLAG.write_text("quiet\n", encoding="ascii")
    except OSError:
        pass
    session["_control_notice"] = {
        "kind": "success" if ok else "danger",
        "title": "Системата е изключена" if ok else "Изключването не завърши",
        "detail": detail + " Нищо няма да стартира автоматично, докато не натиснеш "
                           "„Автоматичен старт на всичко“.",
    }
    return redirect(url_for("settings_page"))


@app.route("/settings/system/start-all", methods=["POST"])
def system_start_all() -> Response:
    STOP_FLAG.unlink(missing_ok=True)
    QUIET_FLAG.unlink(missing_ok=True)
    started = []
    term = MT5_PORTABLE / "terminal64.exe"
    if term.exists():
        try:
            subprocess.Popen([str(term)], cwd=str(MT5_PORTABLE))
            started.append("MT5")
        except OSError:
            pass
    ok, detail = _engine_start()
    if ok:
        started.append("двигател")
    session["_control_notice"] = {
        "kind": "success" if ok else "danger",
        "title": "Системата стартира",
        "detail": f"Автоматичните проверки са активни. Стартирано: "
                  f"{', '.join(started) or 'нищо още'}. {detail}",
    }
    return redirect(url_for("settings_page"))


@app.route("/settings/system/flatten", methods=["POST"])
def system_flatten() -> Response:
    """Авариен стоп: STOP.flag (спира нови сделки) + пазарно затваряне на ВСИЧКИ
    позиции на двигателя (magic). За моменти, в които собственикът иска плоско — сега."""
    try:
        STOP_FLAG.write_text("stop\n", encoding="ascii")
    except OSError:
        pass

    def _close_all(mt5):
        out = []
        for p in (mt5.positions_get() or []):
            if int(p.magic) != ENGINE_MAGIC:
                continue
            req_type = mt5.ORDER_TYPE_SELL if p.type == 0 else mt5.ORDER_TYPE_BUY
            tick = mt5.symbol_info_tick(p.symbol)
            if tick is None:
                out.append((p.symbol, False, "няма тик"))
                continue
            price = float(tick.bid if req_type == mt5.ORDER_TYPE_SELL else tick.ask)
            ok, msg = False, "няма отговор"
            for filling in (mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_FOK):
                req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": p.symbol,
                       "volume": float(p.volume), "type": req_type,
                       "position": int(p.ticket), "price": price, "deviation": 20,
                       "magic": ENGINE_MAGIC, "comment": "S5-flatten",
                       "type_time": mt5.ORDER_TIME_GTC, "type_filling": filling}
                res = mt5.order_send(req)
                if res is not None and int(res.retcode) in (10008, 10009):
                    ok, msg = True, f"@{getattr(res, 'price', price)}"
                    break
                msg = f"retcode={getattr(res, 'retcode', None)} {getattr(res, 'comment', '')}"
            out.append((p.symbol, ok, msg))
        return out

    closed = mt5_read(_close_all)
    if closed is None:
        session["_control_notice"] = {
            "kind": "danger", "title": "Аварийното затваряне не достигна MT5",
            "detail": "STOP.flag е активен (нови сделки спрени), но MT5 не отговори — "
                      "провери терминала и затвори ръчно при нужда."}
        return redirect(url_for("settings_page"))
    ok_list = [f"{s} {m}" for s, ok, m in closed if ok]
    bad_list = [f"{s} ({m})" for s, ok, m in closed if not ok]
    summary = (f"Затворени: {len(ok_list)}"
               + (f" ({', '.join(ok_list)})" if ok_list else "")
               + (f" · НЕУСПЕШНИ: {', '.join(bad_list)}" if bad_list else ""))
    notify.append("alert" if bad_list else "warning", "system",
                  f"АВАРИЕН ФЛАТЕН от таблото: {summary or 'нямаше отворени'}")
    try:
        import importlib.util as _ilu
        _spec = _ilu.spec_from_file_location(
            "telemetry", BASE_DIR / "engine" / "telemetry.py")
        _tel = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(_tel)
        _tel.send_event("flatten", f"авариен флатен: {summary or 'нямаше отворени позиции'}",
                        force=True)
    except Exception:
        pass
    session["_control_notice"] = {
        "kind": "danger" if bad_list else "success",
        "title": "Авариен стоп изпълнен" if not bad_list else "Флатен с ПРОБЛЕМИ",
        "detail": (summary if closed else "Нямаше отворени позиции на двигателя. ")
                  + " STOP.flag е активен — системата няма да стартира сама; "
                    "върни я с „Автоматичен старт на всичко“."}
    return redirect(url_for("settings_page"))


@app.route("/settings/system/restart-engine", methods=["POST"])
def system_restart_engine() -> Response:
    """Рестарт само на S5 демона — нужно е след смяна на engine\\config.json
    (демонът чете конфигурацията при старт). Уважава STOP.flag."""
    ok_stop, detail_stop = _engine_stop()
    time.sleep(2)
    if STOP_FLAG.exists():
        session["_control_notice"] = {
            "kind": "warn", "title": "Двигателят е спрян",
            "detail": ("STOP.flag е активен — двигателят няма да тръгне, докато не "
                       "натиснеш „Автоматичен старт на всичко“. " + detail_stop)}
        return redirect(url_for("settings_page"))
    ok_start, detail_start = _engine_start()
    session["_control_notice"] = {
        "kind": "success" if (ok_stop and ok_start) else "danger",
        "title": "Двигателят е рестартиран" if ok_start else "Рестартът не завърши",
        "detail": f"{detail_stop} {detail_start}",
    }
    return redirect(url_for("settings_page"))


@app.route("/settings/system/update", methods=["POST"])
def system_update() -> Response:
    import subprocess
    try:
        subprocess.Popen(
            ["py", "-3.12", str(BASE_DIR / "scripts" / "update_client.py"),
             "--apply"], cwd=str(BASE_DIR),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        session["_control_notice"] = {
            "kind": "success", "title": "Ъпдейтът тръгна",
            "detail": ("Проверявам за нова версия във фонов режим (1-2 минути). "
                       "Ако има такава, програмата се рестартира сама. "
                       "Обнови страницата след 2 минути.")}
    except Exception as exc:
        session["_control_notice"] = {
            "kind": "danger", "title": "Ъпдейтът не тръгна",
            "detail": f"{exc} — опитай през ROBOT update в командния прозорец."}
    return redirect(url_for("settings_page"))


@app.route("/settings/system/quiet-toggle", methods=["POST"])
def system_quiet_toggle() -> Response:
    if QUIET_FLAG.exists():
        QUIET_FLAG.unlink(missing_ok=True)
        msg = ("Автоматичните проверки са ВКЛЮЧЕНИ отново. Програмата следи и "
               "възстановява MT5/двигателя при нужда.")
        kind = "success"
    else:
        QUIET_FLAG.write_text("quiet\n", encoding="ascii")
        msg = ("Пауза на автоматичните проверки. Можеш да затвориш MT5 — "
               "програмата няма да го търси и стартира. Търговията не се бърка.")
        kind = "warn"
    session["_control_notice"] = {"kind": kind, "title": "Готово", "detail": msg}
    return redirect(url_for("settings_page"))


def _license_card() -> str:
    ok, reason = licensing.is_licensed()
    state = ('<span class="chip ok">активиран</span>' if ok else
             f'<span class="chip bad">неактивиран</span>')
    detail = "" if ok else f'<p class="muted">Статус: {e(reason)}</p>'
    return f"""
<div class="card">
  <h3>{icon("key", 18)} Лиценз</h3>
  <p>Състояние: {state}</p>
  {detail}
  <p class="muted">Получи ли нов ключ от продавача — въведи го тук (целия,
  без прекъсване). Старият ключ можеш да замениш по всяко време.</p>
  <form method="post" action="/activate">
    <input type="hidden" name="next" value="/settings">
    <div class="field"><label class="flabel">Лицензен ключ (DEMON-... или ASL-...)</label>
      <input type="text" name="key" style="width:100%" autocomplete="off"></div>
    <p style="margin:12px 0 0"><button type="submit" class="btn">Активирай</button></p>
  </form>
</div>"""


def _system_card() -> str:
    quiet = QUIET_FLAG.exists()
    stopped = STOP_FLAG.exists()
    state = ("<span class=\"chip bad\">изключена</span>" if stopped else
             ("<span class=\"chip warn\">пауза на проверките</span>" if quiet else
              "<span class=\"chip ok\">активна</span>"))
    quiet_label = "Включи автоматичните проверки" if quiet else \
        "Спри автоматичните проверки (затварям MT5 сам)"
    return f"""
<div class="card">
  <h3>{icon("power", 18)} Система</h3>
  <p>Състояние: {state}</p>
  <form method="post" action="/settings/system/start-all" style="display:inline-block;margin:0 8px 10px 0">
    <button type="submit" class="btn">Автоматичен старт на всичко</button></form>
  <form method="post" action="/settings/system/update" style="display:inline-block;margin:0 8px 10px 0">
    <button type="submit" class="btn secondary">{icon("refresh", 15)} Ъпдейт</button></form>
  <form method="post" action="/settings/system/restart-engine" style="display:inline-block;margin:0 8px 10px 0">
    <button type="submit" class="btn secondary">{icon("refresh", 15)} Рестартирай двигателя</button></form>
  <form method="post" action="/settings/system/quiet-toggle" style="display:inline-block;margin:0 8px 10px 0">
    <button type="submit" class="btn secondary">{e(quiet_label)}</button></form>
  <form method="post" action="/settings/system/shutdown" style="display:inline-block;margin:0 8px 10px 0"
        onsubmit="return confirm('Системата спира напълно — двигател, MT5 проверки, всичко. Потвърждаваш?')">
    <button type="submit" class="btn danger">Изключи системата</button></form>
  <form method="post" action="/settings/system/flatten" style="display:inline-block;margin:0 0 10px 0"
        onsubmit="return confirm('АВАРИЕН СТОП: затваряш ВСИЧКИ отворени позиции на пазарна цена И спираш системата. Сигурен ли си?')">
    <button type="submit" class="btn danger">⚠ Затвори всичко и спри</button></form>
  <p class="muted">„Ъпдейт“ проверява за нова версия и я инсталира (1–2 минути,
  програмата се рестартира сама). „Старт на всичко“ връща системата в нормален
  режим. Паузата е за моментите, когато искаш да затвориш MT5 без програмата
  да го отваря наново.</p>
</div>"""


@app.route("/settings/telegram/save", methods=["POST"])
def telegram_save() -> Response:
    cfg = read_json(NOTIFY_CONFIG, {}) or {}
    tg = dict(cfg.get("telegram") or {})
    current_token = str(tg.get("token") or "").strip()
    token = (request.form.get("token") or "").strip()
    if not token or (current_token and token == _mask_token(current_token)):
                                                                                 
        token = current_token
    tg["token"] = token
    tg["chat_id"] = (request.form.get("chat_id") or "").strip()
    tg["enabled"] = bool(request.form.get("enabled"))
    cfg["telegram"] = tg
    try:
        NOTIFY_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        tmp = NOTIFY_CONFIG.with_name("notify.json.tmp")
        tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")
        tmp.replace(NOTIFY_CONFIG)
    except OSError as exc:
        return redirect(url_for("settings_page", tg="err",
                                msg=f"Записът в config\\notify.json се провали: {exc}"))
    return redirect(url_for("settings_page", tg="saved"))


@app.route("/settings/telegram/test", methods=["POST"])
def telegram_test() -> Response:
    notify.ensure_config()
    row = notify.append("info", "system", "Тест от Demon център за управления")
    tg = notify.telegram_settings()
    if not tg.get("enabled"):
        err = ("известията са изключени — маркирай „Активни известия“, натисни "
               "„Запази“ и пробвай пак.")
    else:
        err = notify.relay(row)
        if err:
            notify.append("warning", "system",
                          f"Telegram тест не е изпратен: {err}")
    if err:
        return redirect(url_for("settings_page", tg="err", msg=err))
    return redirect(url_for("settings_page", tg="ok"))


@app.route("/settings/news/save", methods=["POST"])
def news_save() -> Response:
    current = _news_api_key()
    key = (request.form.get("gnews_api_key") or "").strip()
    if not key or (current and key == _mask_token(current)):
                                                                                
        key = current
    try:
        NEWS_PROVIDER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        tmp = NEWS_PROVIDER_CONFIG.with_name("news_provider.json.tmp")
        tmp.write_text(json.dumps({"gnews_api_key": key}, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")
        tmp.replace(NEWS_PROVIDER_CONFIG)
    except OSError as exc:
        return redirect(url_for("settings_page", news="err",
                                msg=f"Записът в config\\news_provider.json се провали: {exc}"))
    return redirect(url_for("settings_page", news="saved"))


@app.route("/settings/news/test", methods=["POST"])
def news_test() -> Response:
    key = _news_api_key()
    if not key:
        return redirect(url_for("settings_page", news="err",
                                msg="липсва GNews API ключ — въведи го, натисни "
                                    "„Запази“ и пробвай пак."))
    ok, msg = _fetch_news().check_key(key)
    if not ok:
        return redirect(url_for("settings_page", news="err", msg=msg))
    return redirect(url_for("settings_page", news="ok", msg=msg))


@app.route("/settings/guard/save", methods=["POST"])
def guard_save() -> Response:
    keys = _guard_keys()
    for field in ("newsapi_key", "finnhub_key"):
        val = (request.form.get(field) or "").strip()
        current = keys[field]
        if not val or (current and val == _mask_token(current)):
                                                                                    
            val = current
        keys[field] = val
    try:
        GUARD_KEYS_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        tmp = GUARD_KEYS_CONFIG.with_name("guard_keys.json.tmp")
        tmp.write_text(json.dumps(keys, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")
        tmp.replace(GUARD_KEYS_CONFIG)
    except OSError as exc:
        return redirect(url_for("settings_page", guard="err",
                                msg=f"Записът в config\\guard_keys.json се провали: {exc}"))
    return redirect(url_for("settings_page", guard="saved"))


@app.route("/settings/guard/test", methods=["POST"])
def guard_test() -> Response:
    ok, msg = _fetch_guard().check_now()
    if not ok:
        return redirect(url_for("settings_page", guard="err", msg=msg))
    return redirect(url_for("settings_page", guard="ok", msg=msg))


@app.route("/settings/social/refresh", methods=["POST"])
def social_refresh() -> Response:
    """„Обнови сега" — пуска fetch_social без запис (--check логика) и показва банер."""
    ok, msg = _fetch_social().check_now()
    if not ok:
        return redirect(url_for("settings_page", social="err", msg=msg))
    return redirect(url_for("settings_page", social="ok", msg=msg))


                              

LOG_FILES = {
    "engine": ("engine_s5.log", LOGS_DIR / "engine_s5.log"),
    "watchdog": ("watchdog.log", LOGS_DIR / "watchdog.log"),
    "fetch": ("fetch_daily.log", LOGS_DIR / "fetch_daily.log"),
}
LOG_TITLES = {"engine": "Engine (S5)", "watchdog": "Watchdog", "fetch": "Fetch daily"}


def _log_key() -> str:
    key = request.args.get("file", "engine")
    return key if key in LOG_FILES else "engine"


@app.route("/logs")
def logs_page() -> Response:
    key = _log_key()
    label, path = LOG_FILES[key]
    tabs = "".join(
        f'<a href="/logs?file={k}"{" class=\"active\"" if k == key else ""}>'
        f'{e(LOG_TITLES[k])}</a>'
        for k in LOG_FILES)
    download = ""
    if path.exists():
        download = (f'<p style="margin:0 0 12px"><a class="btn secondary" '
                    f'href="/logs/download?file={key}">{icon("download", 14)} '
                    f'Свали целия {e(label)}</a></p>')
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""
        lines = text.splitlines()
        tail = "\n".join(lines[-200:])
        if not tail.strip():
            pre = f'<p class="na">{NA} (празен файл)</p>'
        else:
            pre = (f'<pre class="logpre">{e(tail)}</pre>'
                   f'<p class="muted">последни {min(200, len(lines))} от {len(lines)} реда</p>')
    else:
        pre = f'<p class="na">{NA} — файлът липсва ({e(label)})</p>'
    body = (f'<div class="card"><h3>Логове</h3><div class="tabs">{tabs}</div>'
            f"{download}{pre}</div>")
    return shell(body, active="/logs", title="Логове")


@app.route("/logs/download")
def logs_download() -> Response:
    from flask import send_file
    key = _log_key()
    label, path = LOG_FILES[key]
    if not path.exists():
        return Response(f"файлът липсва: {label}", status=404,
                        mimetype="text/plain; charset=utf-8")
    return send_file(path, as_attachment=True, download_name=label)


                                                     

def md_inline(text: str) -> str:
    import re
    text = e(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    return text


def md_to_html(md: str) -> str:
    import re
    out: list[str] = []
    para: list[str] = []
    list_type = None
    table: list[str] = []
    in_code = False
    code_lines: list[str] = []

    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + md_inline(" ".join(x.strip() for x in para)) + "</p>")
            para = []

    def flush_list():
        nonlocal list_type
        if list_type:
            out.append(f"</{list_type}>")
            list_type = None

    def flush_table():
        nonlocal table
        if not table:
            return

        def cells(line):
            return [c.strip() for c in line.strip().strip("|").split("|")]

        head = cells(table[0])
        rest = table[1:]
        if rest:
            sep = cells(rest[0])
            if sep and all(set(c) <= set("-: ") for c in sep) and any("-" in c for c in sep):
                rest = rest[1:]
        parts = ["<table><thead><tr>"
                 + "".join(f"<th>{md_inline(c)}</th>" for c in head)
                 + "</tr></thead><tbody>"]
        for r in rest:
            parts.append("<tr>" + "".join(f"<td>{md_inline(c)}</td>" for c in cells(r))
                         + "</tr>")
        parts.append("</tbody></table>")
        out.append("".join(parts))
        table = []

    for raw in md.splitlines():
        line = raw.rstrip()
        if in_code:
            if line.strip().startswith("```"):
                out.append("<pre>" + e("\n".join(code_lines)) + "</pre>")
                code_lines = []
                in_code = False
            else:
                code_lines.append(line)
            continue
        if line.strip().startswith("```"):
            flush_para(); flush_list(); flush_table()
            in_code = True
            continue
        if not line.strip():
            flush_para(); flush_list(); flush_table()
            continue
        m = re.match(r"^(#{1,4})\s+(.*)$", line.strip())
        if m:
            flush_para(); flush_list(); flush_table()
            n = min(len(m.group(1)) + 1, 4)
            out.append(f"<h{n}>{md_inline(m.group(2))}</h{n}>")
            continue
        if re.match(r"^\s*(-{3,}|\*{3,})\s*$", line):
            flush_para(); flush_list(); flush_table()
            out.append("<hr>")
            continue
        if line.lstrip().startswith("|"):
            flush_para(); flush_list()
            table.append(line)
            continue
        m = re.match(r"^\s*[-*]\s+(.*)$", line)
        if m:
            flush_para(); flush_table()
            if list_type != "ul":
                flush_list()
                out.append("<ul>")
                list_type = "ul"
            out.append("<li>" + md_inline(m.group(1)) + "</li>")
            continue
        m = re.match(r"^\s*\d+\.\s+(.*)$", line)
        if m:
            flush_para(); flush_table()
            if list_type != "ol":
                flush_list()
                out.append("<ol>")
                list_type = "ol"
            out.append("<li>" + md_inline(m.group(1)) + "</li>")
            continue
        flush_list(); flush_table()
        para.append(line)
    if in_code and code_lines:
        out.append("<pre>" + e("\n".join(code_lines)) + "</pre>")
    flush_para(); flush_list(); flush_table()
    return "\n".join(out)


@app.route("/legend")
def legend() -> Response:
    path = BASE_DIR / "LEGEND.md"
    md = None
    if path.exists():
        try:
            md = path.read_text(encoding="utf-8")
        except Exception:
            md = None
    if not md:
        body = ('<div class="card"><h2>Легенда</h2>'
                f'<p class="na">Легендата липсва (LEGEND.md)</p></div>')
    else:
        body = (f'<div class="card legend"><h2>Легенда</h2>{md_to_html(md)}'
                '<p class="muted">Източник: LEGEND.md.</p></div>')
    return shell(body, active="/legend", title="Легенда")


if __name__ == "__main__":
                                                                     
    _ok, _msg = integrity.verify_manifest(BASE_DIR)
    if not _ok:
        print(_msg)
        sys.exit(3)
    try:
        app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5123")), threaded=True)
    except OSError:
                                                                    
        sys.exit(0)
    except Exception as exc:
        try:
            LOGS_DIR.mkdir(parents=True, exist_ok=True)
            (LOGS_DIR / "dashboard_error.log").write_text(
                f"{datetime.now(timezone.utc).isoformat()} {exc}\n",
                encoding="utf-8")
        except Exception:
            pass
        try:
            sys.path.insert(0, str(BASE_DIR / "engine"))
            import telemetry
            telemetry.send_event("dashboard_crash", repr(exc), force=True)
        except Exception:
            pass
        sys.exit(0)
