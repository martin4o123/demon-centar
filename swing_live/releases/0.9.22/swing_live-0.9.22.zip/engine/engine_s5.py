# -*- coding: utf-8 -*-
"""S5 production engine — RSI-2 дневна реверсия (Connors), USDJPY + EURUSD.

Репликира ТОЧНО тестваната симулация scripts/backtest_75.py --s5:
  - RSI(2) с Wilder smoothing, имплементиран като pandas ewm(alpha=1/2, adjust=False)
    (начална стойност = първа валидна стойност, рекурсия y = a*x + (1-a)*y_prev) —
    идентично на wilder() в backtest_75.py;
  - LONG: предишен затворен D1 close > EMA200(D1) и RSI(2) < 10 -> вход при отваряне
    на следващия D1 бар (market поръчка на отварянето). SHORT огледално (RSI(2) > 90);
  - SL = clamp(0.75 x ATR14(D1), 40, 80) пипса, защитна поръчка при брокера; БЕЗ TP;
  - изходи (приоритет): SL (брокер) -> на затворен D1 бар: RSI(2) > 55 / < 45,
    или 7 дни, или преди уикенд (петък >= 21:00 сървърно = live еквивалент на
    sim-правилото „изход на последния бар преди гап > 26ч");
  - max 1 позиция общо; cooldown 24ч след изход, per symbol+direction;
  - спред филтър: spread <= 0.05 x ATR14(D1) на сигналния бар; без нови входове
    петък след 20:00 сървърно; новинарски блекаут от news_cache.json (по избор);
    пазителен слой (гео риск/блекаут около High събития/sentiment/социален пулс)
    чрез engine\\market_guard.py от logs\\guard_state.json + logs\\guard_events.json
    + logs\\sentiment.json + logs\\social_pulse.json.

Сигурност: mode dry = само наблюдение; mode demo = реални поръчки САМО ако
Режими (config "mode"):
  "dry"  — без поръчки, само наблюдение/лог.
  "demo" — реални поръчки; бял списък: account_info().login == demo_login
           (несъответствие -> SafetyError exit, 0 поръчки).
  "live" — реални поръчки; бял списък: account_info().server съдържа live_server
           (напр. AdmiralsGroup-Live; демо сървър -> SafetyError exit, 0 поръчки).

CLI: --dry-run-now (read-only таблица, без писане) | --once (един цикъл) | демон (15 мин).

State contract: engine\\state_contract.md (logs\\state.json + logs\\decisions.jsonl).
Нотификации: engine\\notify.py при наличност, иначе append fallback в logs\\messages.jsonl.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import logging.handlers
import socket
import sys
import time as _time
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
ENGINE_DIR = BASE_DIR / "engine"
LOGS_DIR = BASE_DIR / "logs"
CONFIG_PATH = ENGINE_DIR / "config.json"
STOP_FLAG = BASE_DIR / "STOP.flag"
KILL_SWITCH = ENGINE_DIR / "KILL.switch"
STATE_JSON = LOGS_DIR / "state.json"
DECISIONS_JSONL = LOGS_DIR / "decisions.jsonl"
INTERNAL_STATE = ENGINE_DIR / "s5_state.json"

SINGLE_INSTANCE_PORT = 5125   # държи се от демона; втора инстанция се отказва
_single_instance_socket = None


def acquire_single_instance() -> bool:
    """Резервира 127.0.0.1:5125 — само един S5 daemon на машината."""
    global _single_instance_socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", SINGLE_INSTANCE_PORT))
    except OSError:
        sock.close()
        return False
    _single_instance_socket = sock
    return True

MAGIC = 750501           # маркер на позициите на този engine
COMMENT = "S5"
SYMBOLS = ["USDJPY", "EURUSD"]
PIP_DIGITS = (3, 5)      # 3/5-цифрени инструменти: pip = 10 x point

LOG = logging.getLogger("engine_s5")

# пазителен слой (гео риск/блекаут/sentiment) — чисти функции; при липса/грешка
# engine-ът върви без него, просто без пазителни ограничения
try:
    if str(ENGINE_DIR) not in sys.path:
        sys.path.insert(0, str(ENGINE_DIR))
    import market_guard
except Exception:
    market_guard = None

# ============================ конфигурация ==================================
DEFAULT_CONFIG = {
    "mode": "dry",                    # "dry" | "demo" | "live"
    "demo_login": None,               # demo: поръчки само на този логин
    "live_server": None,              # live: поръчки само ако сървърът го съдържа
    "terminal_path": r"C:\Users\mgeor\AppData\Local\AdmiralBeta\mt5_portable\terminal64.exe",
    "symbols": SYMBOLS,
    "risk_pct": 0.25,                 # % от equity за риск до SL
    "max_lot": 0.05,
    "cycle_seconds": 900,             # 15 мин цикъл
    "sl_mult": 0.75, "sl_min_pips": 40.0, "sl_max_pips": 80.0,
    "rsi_entry_long": 10.0, "rsi_entry_short": 90.0,
    "rsi_exit_long": 55.0, "rsi_exit_short": 45.0,
    "h1_layer": {                     # вътредневен pullback слой (D1 тренд + RSI(2,H1))
        "enabled": False,             # бектест 2023-09→2026-09: PF 1.56 (посл. 12 м. PF 1.90)
        "symbols": [],                # само двойки с PF>=1.3 в симулацията
        "risk_pct": 0.15,             # по-нисък риск от D1 слоя (къси задръжки)
        "rsi_entry_long": 10.0, "rsi_entry_short": 90.0,
        "rsi_exit_long": 55.0, "rsi_exit_short": 45.0,
        "max_hours": 48,
    },
    "max_days": 7,
    "spread_atr_max": 0.05,
    "friday_cutoff_hour": 20,         # без нови входове петък след 20:00 сървърно
    "friday_exit_hour": 21,           # затваряне на отворената позиция петък >= 21:00
    "cooldown_hours": 24,
    "trailing": {                     # „анти-загуба": местене на SL към печалба
        "enabled": True,
        "breakeven_r": 0.5,           # >= 0.5R -> SL на entry (безпарична)
        "trail_start_r": 1.0,         # >= 1.0R -> SL след цената
        "trail_frac": 0.5,            # дял от нереализираната печалба, заключен в SL
    },
    "guards": {
        "max_daily_loss_pct": 2.0,    # реализирана загуба за деня -> без нови входове
        "max_peak_dd_pct": 8.0,       # спад от върха -> пауза до ръчен resume
        "consec_losses_kill": 6,      # поредни загуби -> kill switch
        "expectancy_window": 20,      # прозорец за expectancy
        "expectancy_throttle_r": 0.0, # expectancy_20 < 0 -> риск x 0.5
        "expectancy_pause_r": -0.15,  # expectancy_20 < -0.15R -> пауза + аларма
        "throttle_factor": 0.5,
    },
    "news_blackout": {
        "enabled": False,
        "window_hours": 3,
        "keywords": ["fed", "fomc", "ecb", "cpi", "inflation", "interest rate",
                     "central bank", "payroll", "nfp", "rate decision",
                     "monetary policy", "jobs report", "boe", "boj",
                     "rate hike", "rate cut"],
        "path": r"C:\Users\mgeor\AppData\Local\AdmiralBeta\config\news_cache.json",
    },
}


def load_config() -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))  # deep copy
    if CONFIG_PATH.exists():
        user = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        def merge(a, b):
            for k, v in (b or {}).items():
                if isinstance(v, dict) and isinstance(a.get(k), dict):
                    merge(a[k], v)
                else:
                    a[k] = v
        merge(cfg, user)
    return cfg


# ============================ нотификации ===================================
def _load_notify():
    try:
        spec = importlib.util.spec_from_file_location("engine_notify", ENGINE_DIR / "notify.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.send
    except Exception:
        return None


_NOTIFY_SEND = None
def notify(level: str, category: str, text: str) -> None:
    """notify.py при наличност, иначе fallback append в logs\\messages.jsonl (същата схема)."""
    global _NOTIFY_SEND
    if _NOTIFY_SEND is None:
        _NOTIFY_SEND = _load_notify() or False
    if _NOTIFY_SEND:
        try:
            _NOTIFY_SEND(level, category, text)
            return
        except Exception:
            pass
    try:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        row = {"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
               "level": level, "category": category, "text": text}
        with (LOGS_DIR / "messages.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception:
        LOG.exception("notify fallback fail")


# ============================ индикатори (огледало на sim) ==================
def ema_adjust_false(values, n: int):
    """pandas ewm(span=n, adjust=False): първа стойност = първи вход, после рекурсия."""
    alpha = 2.0 / (n + 1.0)
    out = []
    ema = None
    for v in values:
        ema = v if ema is None else alpha * v + (1 - alpha) * ema
        out.append(ema)
    return out


def wilder_adjust_false(values, n: int, min_periods: int):
    """pandas ewm(alpha=1/n, adjust=False, min_periods=n) — както wilder() в backtest_75.py."""
    alpha = 1.0 / n
    out = []
    ema = None
    valid = 0
    for v in values:
        if v is None:
            out.append(None)
            continue
        valid += 1
        ema = v if ema is None else alpha * v + (1 - alpha) * ema
        out.append(ema if valid >= min_periods else None)
    return out


def rsi2(closes) -> list:
    """RSI(2) с Wilder smoothing — огледално на build_features_s5."""
    deltas = [None] + [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [None if d is None else max(d, 0.0) for d in deltas]
    losses = [None if d is None else max(-d, 0.0) for d in deltas]
    ag = wilder_adjust_false(gains, 2, 2)
    al = wilder_adjust_false(losses, 2, 2)
    out = []
    for g, l in zip(ag, al):
        if g is None or l is None:
            out.append(None)
        elif l == 0.0 and g == 0.0:
            out.append(None)          # pandas: NaN
        elif l == 0.0:
            out.append(100.0)         # pandas: 100 - 100/inf = 100
        elif g == 0.0:
            out.append(0.0)
        else:
            out.append(100.0 - 100.0 / (1.0 + g / l))
    return out


def atr14(highs, lows, closes) -> list:
    """ATR14 Wilder (ewm alpha=1/14, adjust=False, min_periods=14) — огледално на add_d1."""
    trs = [None]
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i],
                 abs(highs[i] - closes[i - 1]),
                 abs(lows[i] - closes[i - 1]))
        trs.append(tr)
    return wilder_adjust_false(trs, 14, 14)


def clamp_sl_pips(atr_value: float, pip_size: float, sl_mult=0.75,
                  lo=40.0, hi=80.0) -> float:
    """SL = clamp(sl_mult x ATR14(D1), 40, 80) пипса — както в run_s5."""
    if atr_value <= 0 or pip_size <= 0:
        return lo
    return round(float(min(max(sl_mult * atr_value / pip_size, lo), hi)), 6)


# ============================ пазачи ========================================
class SafetyError(Exception):
    """Твърдо спиране: несъответствие на бялия списък / опасна конфигурация."""


def guard_check_white_list(cfg: dict, login: int, server: str | None = None) -> None:
    mode = cfg["mode"]
    if mode == "demo":
        demo_login = cfg.get("demo_login")
        if not demo_login:
            raise SafetyError("mode=demo, но demo_login не е зададен — отказ")
        if int(login) != int(demo_login):
            raise SafetyError(f"mode=demo, но логинът е {login} != demo_login {demo_login} — ОТКАЗ")
    elif mode == "live":
        live_server = cfg.get("live_server")
        if not live_server:
            raise SafetyError("mode=live, но live_server не е зададен — отказ")
        if not server or live_server.lower() not in str(server).lower():
            raise SafetyError(
                f"mode=live, но сървърът е {server!r} (очаква се '{live_server}') — ОТКАЗ: "
                "терминалът не е на реална сметка")


def guard_risk_throttle(cfg: dict, closed_r: list) -> float:
    """Rolling expectancy: след >= window сделки, expectancy < 0 -> риск x0.5; < -0.15R -> 0 (пауза)."""
    g = cfg["guards"]
    w = int(g["expectancy_window"])
    if len(closed_r) < w:
        return 1.0
    exp20 = sum(closed_r[-w:]) / w
    if exp20 < float(g["expectancy_pause_r"]):
        return 0.0
    if exp20 < float(g["expectancy_throttle_r"]):
        return float(g["throttle_factor"])
    return 1.0


# ============================ sizing ========================================
def compute_lot(equity: Decimal, risk_pct: float, sl_pips: float,
                pip_value_lot: Decimal, vol_min: float, vol_max: float,
                vol_step: float, max_lot: float, verify_fn=None) -> tuple[float | None, str]:
    """lot = риск / (SL_pips x pip_value); под на step; clamp [min, min(max_lot, vol_max)].
    verify_fn(lot) -> Decimal загуба при SL; свиваме, докато загубата <= риск x 1.1.
    Връща (lot, причина). None = пропуск (мин. лотът надвишава риска)."""
    risk_amount = equity * Decimal(str(risk_pct)) / Decimal("100")
    denom = Decimal(str(sl_pips)) * pip_value_lot
    if denom <= 0:
        return None, "pip_value=0"
    raw = risk_amount / denom
    cap = min(float(vol_max), float(max_lot))
    lot = min(float(raw), cap)
    lot = max(lot, float(vol_min))
    # floor към step отгоре-надолу, после издут нагоре към min ако е под него
    steps = int(lot / vol_step)
    lot = round(steps * vol_step, 8)
    if lot < vol_min:
        lot = float(vol_min)
    if verify_fn is not None:
        while lot > float(vol_min) + 1e-12:
            loss = verify_fn(lot)
            if loss <= risk_amount * Decimal("1.1"):
                break
            lot = round(lot - vol_step, 8)
        loss = verify_fn(lot)
        if loss > risk_amount * Decimal("1.1"):
            return None, (f"мин. лот {vol_min} надвишава риска "
                          f"({loss} > {risk_amount * Decimal('1.1')} EUR)")
    return lot, "ok"


# ============================ вътрешно състояние ============================
def load_internal() -> dict:
    default = {"day": None, "day_start_equity": None, "peak_equity": None,
               "consec_losses": 0, "closed_r": [], "paused": False, "paused_reason": None,
               "cooldowns": {}, "last_bar": {}, "cycle_id": 0, "open": None}
    try:
        if INTERNAL_STATE.exists():
            d = json.loads(INTERNAL_STATE.read_text(encoding="utf-8"))
            default.update(d)
    except Exception:
        LOG.exception("internal state read fail — почиствам")
    return default


def save_internal(st: dict) -> None:
    tmp = INTERNAL_STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(INTERNAL_STATE)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def write_state_json(cfg, mode_label, pos_view, guards, last_action, symbols):
    state = {
        "version": 1,
        "mode": mode_label,                 # dry | live (контрактен enum)
        "account_mode": cfg["mode"],        # dry | demo — реалността на сметката
        "symbols": symbols,
        "position": pos_view,
        "guards": guards,
        "last_cycle_utc": utc_now().isoformat(timespec="seconds"),
        "last_action": last_action,
    }
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    tmp = STATE_JSON.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(STATE_JSON)


def append_decision(row: dict) -> None:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    with DECISIONS_JSONL.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")


# ============================ MT5 обвивка ===================================
class MT5Shim:
    """Тънка обвивка за тестваемост; всичко mt5 минава през нея."""

    def __init__(self, cfg):
        import MetaTrader5 as mt5
        self.mt5 = mt5
        self.cfg = cfg

    def connect(self):
        ok = self.mt5.initialize()
        if not ok:
            ok = self.mt5.initialize(path=self.cfg.get("terminal_path"))
        if not ok:
            raise SafetyError(f"MT5 initialize fail: {self.mt5.last_error()}")
        # всички търгувани двойки трябва да са видими в Market Watch
        syms = list(self.cfg.get("symbols") or [])
        h1 = (self.cfg.get("h1_layer") or {})
        syms += [s for s in (h1.get("symbols") or []) if s not in syms]
        for s in syms:
            try:
                self.mt5.symbol_select(s, True)
            except Exception:
                LOG.warning("symbol_select(%s) не мина", s)
        info = self.mt5.account_info()
        if info is None:
            raise SafetyError("account_info() = None — терминалът не е логнат?")
        return info

    def shutdown(self):
        try:
            self.mt5.shutdown()
        except Exception:
            pass

    def symbol_info(self, sym):
        si = self.mt5.symbol_info(sym)
        if si is None:
            raise SafetyError(f"symbol_info({sym}) = None")
        return si

    def tick(self, sym):
        return self.mt5.symbol_info_tick(sym)

    def rates_d1(self, sym, n=400):
        return self.mt5.copy_rates_from_pos(sym, self.mt5.TIMEFRAME_D1, 0, n)

    def rates_h1(self, sym, n=400):
        return self.mt5.copy_rates_from_pos(sym, self.mt5.TIMEFRAME_H1, 0, n)

    def positions(self, sym=None):
        if sym:
            return self.mt5.positions_get(symbol=sym) or ()
        return self.mt5.positions_get() or ()

    def account(self):
        return self.mt5.account_info()

    def order_send(self, req):
        return self.mt5.order_send(req)

    def modify_sl(self, position_ticket, sym, sl, tp):
        """Смяна на SL/TP на отворена позиция (TRADE_ACTION_SLTP). Връща резултата."""
        mt5 = self.mt5
        req = {
            "action": mt5.TRADE_ACTION_SLTP,
            "symbol": sym,
            "position": int(position_ticket),
            "sl": float(sl),
            "tp": float(tp or 0.0),
        }
        return self.order_send(req)

    def history_deals(self, pos_id):
        try:
            return self.mt5.history_deals_get(position=pos_id) or ()
        except Exception:
            return ()


def pip_size_of(info) -> float:
    point = float(info.point)
    return point * 10.0 if int(info.digits) in PIP_DIGITS else point


def server_offset_from_bars(rates) -> int:
    """Сървърният ъфсет (s) спрямо UTC = UTC-остатъкът на отварянето на D1 бара
    (баровете отварят в 00:00 сървърно). 21ч -> UTC+3, 22ч -> UTC+2."""
    t = int(rates[-1]["time"]) if len(rates) else int(_time.time())
    return t % 86400


def news_blackout_active(cfg) -> bool:
    nb = cfg.get("news_blackout") or {}
    if not nb.get("enabled"):
        return False
    try:
        path = Path(nb.get("path") or "")
        if not path.exists():
            return False
        data = json.loads(path.read_text(encoding="utf-8"))
        now = utc_now()
        kw = [k.lower() for k in nb.get("keywords", [])]
        for item in data.get("items", []):
            try:
                pub = datetime.fromisoformat(item["published_utc"])
            except Exception:
                continue
            hours = abs((now - pub).total_seconds()) / 3600.0
            if hours <= float(nb.get("window_hours", 3)):
                text = (item.get("title", "") + " " + item.get("summary", "")).lower()
                if any(k in text for k in kw):
                    return True
        return False
    except Exception:
        return False


# ============================ главен цикъл ==================================
class Engine:
    def __init__(self, cfg, shim=None, write=True):
        self.cfg = cfg
        self.shim = shim or MT5Shim(cfg)
        self.write = write
        self.acc = None
        self.ist = load_internal()

    # ---------- помощни ----------
    def equity(self) -> Decimal:
        return Decimal(str(self.acc.equity)).quantize(Decimal("0.01"))

    def server_dt(self, rates) -> datetime:
        off = server_offset_from_bars(rates)
        return datetime.fromtimestamp(int(_time.time()) + off, timezone.utc)

    # ---------- позиция ----------
    def find_engine_position(self):
        for sym in self.cfg["symbols"]:
            for p in self.shim.positions(sym):
                if int(p.magic) == MAGIC or str(p.comment).startswith(COMMENT):
                    return p
        return None

    def adopt_or_close(self, pos):
        """Idempotent restart: позиция от MT5 с наш magic -> осиновяваме в internal."""
        if self.ist.get("open") and int(self.ist["open"].get("ticket", 0)) == int(pos.ticket):
            return
        LOG.warning("осиновявам съществуваща MT5 позиция %s %s %.2f (ticket %s)",
                    pos.symbol, "BUY" if pos.type == 0 else "SELL", pos.volume, pos.ticket)
        self.ist["open"] = {
            "ticket": int(pos.ticket), "sym": pos.symbol,
            "dir": "BUY" if pos.type == 0 else "SELL",
            "lots": float(pos.volume), "entry": float(pos.price_open),
            "sl": float(pos.sl),
            "risk_amount": float((self.ist.get("open") or {}).get("risk_amount") or 0.0),
            "opened_bar": int(pos.time),
        }
        if self.write:
            save_internal(self.ist)

    def close_position(self, pos, price: float, reason: str, dry_label=""):
        """Пазарно затваряне (demo) или лог (dry). Връща (ok, msg)."""
        req_type = self.shim.mt5.ORDER_TYPE_SELL if pos.type == 0 else self.shim.mt5.ORDER_TYPE_BUY
        if self.cfg["mode"] == "dry" or not self.write:
            return True, f"[DRY] затваряне {pos.symbol} @ {price:.5f} ({reason})"
        tick = self.shim.tick(pos.symbol)
        price = float(tick.bid if req_type == self.shim.mt5.ORDER_TYPE_SELL else tick.ask)
        req = {
            "action": self.shim.mt5.TRADE_ACTION_DEAL,
            "symbol": pos.symbol, "volume": float(pos.volume), "type": req_type,
            "position": int(pos.ticket), "price": price, "deviation": 20,
            "magic": MAGIC, "comment": f"{COMMENT}-close", "type_time": self.shim.mt5.ORDER_TIME_GTC,
            "type_filling": self._filling(pos.symbol),
        }
        res = self.shim.order_send(req)
        if res is None or res.retcode not in (10008, 10009):
            msg = f"затваряне FAIL {pos.symbol}: retcode={getattr(res,'retcode',None)} {getattr(res,'comment','')}"
            notify("alert", "system", f"S5: {msg}")
            return False, msg
        return True, f"затворено {pos.symbol} @ {price:.5f} ({reason})"

    def _filling(self, sym):
        si = self.shim.symbol_info(sym)
        fm = int(getattr(si, "filling_mode", 0))
        if fm & 2:
            return self.shim.mt5.ORDER_FILLING_IOC
        return self.shim.mt5.ORDER_FILLING_FOK

    # ---------- журнал/reconcile ----------
    def record_close(self, sym, r_value, pnl_eur, reason):
        self.ist["closed_r"] = (self.ist.get("closed_r") or []) + [round(float(r_value), 4)]
        self.ist["closed_r"] = self.ist["closed_r"][-200:]
        if r_value < 0:
            self.ist["consec_losses"] = int(self.ist.get("consec_losses", 0)) + 1
        else:
            self.ist["consec_losses"] = 0
        kill = int(self.cfg["guards"]["consec_losses_kill"])
        if self.ist["consec_losses"] >= kill:
            self.ist["paused"] = True
            self.ist["paused_reason"] = f"kill switch: {self.ist['consec_losses']} поредни загуби"
            try:
                KILL_SWITCH.write_text(utc_now().isoformat(), encoding="utf-8")
            except Exception:
                pass
            notify("alert", "system",
                   f"S5 KILL SWITCH: {self.ist['consec_losses']} поредни загуби. "
                   f"Пауза до ръчно изтриване на {KILL_SWITCH.name}.")

    def reconcile(self, pos):
        """Ако internal казва „отворена", а в MT5 я няма -> приключена; записваме я."""
        op = self.ist.get("open")
        if not op:
            return
        if pos is not None and int(pos.ticket) == int(op.get("ticket")):
            return
        deals = self.shim.history_deals(int(op["ticket"]))
        dirn = op.get("dir")
        outs = [d for d in deals if float(d.volume) > 0 and
                ((d.type == 1 and dirn == "BUY") or (d.type == 0 and dirn == "SELL"))]
        pnl = Decimal("0")
        if outs:
            d = outs[-1]
            pnl = Decimal(str(d.profit)) + Decimal(str(d.commission)) + Decimal(str(d.swap))
        pnl = pnl.quantize(Decimal("0.01"))
        risk = Decimal(str(op.get("risk_amount") or 0))
        r_value = float(pnl / risk) if risk > 0 else 0.0
        reason = "SL" if pnl < 0 else "EXIT"
        self.record_close(op["sym"], r_value, pnl, reason)
        self.ist["cooldowns"][f"{op['sym']}|{op['dir']}"] = int(_time.time()) + self.cfg["cooldown_hours"] * 3600
        self.ist["open"] = None
        notify("info", "trade", f"S5: приключена {op['sym']} {op['dir']} pnl={pnl}€ R={r_value:+.2f} ({reason})")
        if self.write:
            save_internal(self.ist)

    # ---------- сигнали ----------
    def evaluate_symbol(self, sym):
        """Връща dict с индикатори за последния ЗАТВОРЕН D1 бар + сигнала."""
        rates = self.shim.rates_d1(sym)
        if rates is None or len(rates) < 210:
            return None
        closes = [float(r["close"]) for r in rates]
        highs = [float(r["high"]) for r in rates]
        lows = [float(r["low"]) for r in rates]
        ema200 = ema_adjust_false(closes, 200)
        atr = atr14(highs, lows, closes)
        rsi = rsi2(closes)
        now_utc = _time.time()
        closed_idx = [i for i in range(len(rates)) if int(rates[i]["time"]) + 86400 <= now_utc]
        if not closed_idx:
            return None
        i = closed_idx[-1]
        return {
            "bar_time": int(rates[i]["time"]), "close": closes[i],
            "ema200": ema200[i], "atr": atr[i], "rsi2": rsi[i],
            "prev_bar_time": int(rates[i - 1]["time"]) if i > 0 else None,
        }

    def signal(self, ev, sym):
        """(dir, checks) — dir: 'BUY'|'SELL'|None. Огледално на run_s5."""
        checks = []
        if ev is None or ev["rsi2"] is None or ev["ema200"] is None or ev["atr"] is None:
            checks.append({"name": "Данни", "passed": False,
                           "detail": "няма затворен D1 бар с валидни RSI(2)/EMA200/ATR"})
            return None, checks
        c, e, r = ev["close"], ev["ema200"], ev["rsi2"]
        long_ok = c > e and r < self.cfg["rsi_entry_long"]
        short_ok = c < e and r > self.cfg["rsi_entry_short"]
        checks.append({"name": "Тренд (EMA200)", "passed": True,
                       "detail": f"close {c:.5f} vs EMA200 {e:.5f} -> "
                                 f"{'лонг режим' if c > e else 'шорт режим' if c < e else 'равни'}"})
        checks.append({"name": "RSI(2) реверсия", "passed": bool(long_ok or short_ok),
                       "detail": f"RSI(2)={r:.2f}; лонг <{self.cfg['rsi_entry_long']:.0f} / "
                                 f"шорт >{self.cfg['rsi_entry_short']:.0f}"})
        if long_ok:
            return "BUY", checks
        if short_ok:
            return "SELL", checks
        return None, checks

    # ---------- H1 pullback слой (D1 тренд + RSI(2) на H1) ----------
    def evaluate_h1(self, sym):
        """RSI(2) върху последния ЗАТВОРЕН H1 бар. Трендът/ATR идват от D1 оценката."""
        rates = self.shim.rates_h1(sym, 300)
        if rates is None or len(rates) < 60:
            return None
        closes = [float(r["close"]) for r in rates]
        rsi = rsi2(closes)
        now_utc = _time.time()
        closed_idx = [i for i in range(len(rates)) if int(rates[i]["time"]) + 3600 <= now_utc]
        if not closed_idx:
            return None
        i = closed_idx[-1]
        bar_rsi = rsi[i]
        if bar_rsi is None or not (0 <= bar_rsi <= 100):
            return None
        return {"bar_time": int(rates[i]["time"]), "rsi2": bar_rsi}

    def signal_h1(self, h1ev, d1ev):
        """(dir, checks) — D1 задава посока, H1 RSI(2) дава входа."""
        h = self.cfg["h1_layer"]
        checks = []
        if h1ev is None or d1ev is None or d1ev["rsi2"] is None:
            checks.append({"name": "Данни", "passed": False,
                           "detail": "няма затворен H1 бар с валиден RSI(2)"})
            return None, checks
        c, e = d1ev["close"], d1ev["ema200"]
        r = h1ev["rsi2"]
        if e is None:
            checks.append({"name": "Тренд (EMA200 D1)", "passed": False,
                           "detail": "няма EMA200(D1)"})
            return None, checks
        long_ok = c > e and r < float(h["rsi_entry_long"])
        short_ok = c < e and r > float(h["rsi_entry_short"])
        regime = "лонг режим" if c > e else "шорт режим" if c < e else "равни"
        checks.append({"name": "Тренд (EMA200 D1)", "passed": True,
                       "detail": f"D1 close {c:.5f} vs EMA200 {e:.5f} -> {regime}"})
        checks.append({"name": "RSI(2) H1 pullback", "passed": bool(long_ok or short_ok),
                       "detail": f"RSI(2,H1)={r:.2f}; лонг <{float(h['rsi_entry_long']):.0f} / "
                                 f"шорт >{float(h['rsi_entry_short']):.0f}"})
        if long_ok:
            return "BUY", checks
        if short_ok:
            return "SELL", checks
        return None, checks

    def _manage_h1(self, pos, op, dir_buy):
        """Изходи за H1 слой: RSI(2,H1) кръстосва 55/45 или изтичат max_hours. SL е при брокера."""
        sym = pos.symbol
        h1ev = self.evaluate_h1(sym)
        if h1ev is not None:
            r = h1ev["rsi2"]
            h = self.cfg["h1_layer"]
            crossed = r > float(h["rsi_exit_long"]) if dir_buy else r < float(h["rsi_exit_short"])
            if crossed:
                price = float(self.shim.tick(sym).bid if dir_buy else self.shim.tick(sym).ask)
                ok, msg = self.close_position(pos, price, "RSI-H1")
                if ok:
                    self._after_close(pos, "RSI-H1")
                return msg
        opened = op.get("opened_utc")
        if opened:
            try:
                hours = (utc_now() - datetime.fromisoformat(opened)).total_seconds() / 3600
            except ValueError:
                hours = 0
            if hours >= float(self.cfg["h1_layer"]["max_hours"]):
                price = float(self.shim.tick(sym).bid if dir_buy else self.shim.tick(sym).ask)
                ok, msg = self.close_position(pos, price, "TIME-H1")
                if ok:
                    self._after_close(pos, "TIME-H1")
                return msg
        return None

    # ---------- вход ----------
    def try_open(self, sym, direction, ev, risk_pct=None, layer="d1"):
        info = self.shim.symbol_info(sym)
        tick = self.shim.tick(sym)
        pip = pip_size_of(info)
        sl_pips = clamp_sl_pips(ev["atr"], pip, self.cfg["sl_mult"],
                                self.cfg["sl_min_pips"], self.cfg["sl_max_pips"])
        spread_price = float(info.spread) * float(info.point)
        atr = ev["atr"]
        if spread_price > self.cfg["spread_atr_max"] * atr:
            return None, (f"спред {spread_price:.5f} > {self.cfg['spread_atr_max']:.2f} x ATR {atr:.5f}")
        throttle = guard_risk_throttle(self.cfg, self.ist.get("closed_r") or [])
        if throttle == 0.0:
            return None, "expectancy пауза (< -0.15R за 20 сделки)"
        equity = self.equity()
        # risk_pct x expectancy throttle x пазителен слой (гео/velocity) — локално, cfg не се пипа
        guard_mult = getattr(self, "_guard_risk_mult", None)
        guard_mult = float(guard_mult) if guard_mult is not None else 1.0
        risk_pct = float(risk_pct if risk_pct is not None else self.cfg["risk_pct"]) * throttle * guard_mult
        # pip стойност за 1 лот през tick_value/tick_size
        tick_value = Decimal(str(info.trade_tick_value))
        tick_size = Decimal(str(info.trade_tick_size))
        pip_value_lot = tick_value * (Decimal(str(pip)) / tick_size) if tick_size > 0 else Decimal("0")
        price = float(tick.ask if direction == "BUY" else tick.bid)
        sl_dist = sl_pips * pip
        sl_price = price - sl_dist if direction == "BUY" else price + sl_dist
        digits = int(info.digits)
        sl_price = round(sl_price, digits)

        def verify_fn(lot):
            mt5 = self.shim.mt5
            otype = mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL
            pnl = self.shim.mt5.order_calc_profit(otype, sym, lot, price, sl_price)
            if pnl is None:
                return Decimal("999999")
            return abs(Decimal(str(pnl)))

        lot, why = compute_lot(equity, risk_pct, sl_pips, pip_value_lot,
                               float(info.volume_min), float(info.volume_max),
                               float(info.volume_step), float(self.cfg["max_lot"]),
                               verify_fn=verify_fn)
        if lot is None:
            return None, f"обем отказан: {why}"
        if self.cfg["mode"] == "dry" or not self.write:
            risk_amount = equity * Decimal(str(risk_pct)) / Decimal("100")
            notify("info", "trade", f"[DRY] поръчка {direction} {sym} {lot:.2f} "
                                    f"@(риск {risk_amount}€, SL {sl_price:.5f}) — симулация, без поръчка")
            return {"dry": True, "symbol": sym, "direction": direction, "lots": lot,
                    "price": price, "sl": sl_price, "sl_pips": sl_pips,
                    "risk_amount": float(risk_amount)}, f"[DRY] поръчка {direction} {sym} {lot:.2f}"
        # реална поръчка (demo, whitelist вече проверен)
        mt5 = self.shim.mt5
        otype = mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL
        req = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": sym, "volume": float(lot),
            "type": otype, "price": price, "sl": float(sl_price), "tp": 0.0,
            "deviation": 20, "magic": MAGIC, "comment": COMMENT,
            "type_time": mt5.ORDER_TIME_GTC, "type_filling": self._filling(sym),
        }
        res = self.shim.order_send(req)
        if res is None or res.retcode not in (10008, 10009):
            msg = f"поръчка FAIL {sym}: retcode={getattr(res, 'retcode', None)} {getattr(res, 'comment', '')}"
            # не спамирай: едно известие на 30 мин при повтарящи се откази
            now = _time.time()
            if now - float(self.ist.get("last_order_fail_ts", 0)) > 1800:
                self.ist["last_order_fail_ts"] = now
                hint = ""
                if getattr(res, "retcode", None) == 10027:
                    hint = (" — MT5 AutoTrading е ИЗКЛЮЧЕН: отвори терминала и натисни "
                            "бутона „Algo Trading“ в лентата с инструменти!")
                notify("alert", "system", f"S5: {msg}{hint}")
            return None, msg
        risk_amount = equity * Decimal(str(risk_pct)) / Decimal("100")
        self.ist["open"] = {
            "ticket": int(res.order), "sym": sym, "direction": direction, "lots": float(lot),
            "entry": float(price), "sl": float(sl_price), "risk_amount": float(risk_amount),
            "opened_bar": ev["bar_time"], "opened_utc": utc_now().isoformat(timespec="seconds"),
            "layer": layer,
        }
        if self.write:
            save_internal(self.ist)
        notify("info", "trade", f"S5: отворена {direction} {sym} {lot:.2f} @ {price:.5f} "
                                f"SL {sl_price:.5f} (риск {risk_amount}€, слой {layer})")
        return self.ist["open"], f"отворена {direction} {sym} {lot:.2f} [{layer}]"

    # ---------- управление на отворена ----------
    @staticmethod
    def _sl_better(sl: float, ref: float, dir_buy: bool) -> bool:
        """sl по-изгоден от ref? (BUY: по-висок; SELL: по-нисък)"""
        return sl > ref if dir_buy else sl < ref

    @staticmethod
    def _sl_at_or_beyond(sl: float, ref: float, dir_buy: bool) -> bool:
        """sl вече на/отвъд ref в посока на печалба? Без SL (0.0) -> False."""
        if not sl:
            return False
        return sl >= ref if dir_buy else sl <= ref

    @staticmethod
    def _decimals(x: float) -> int:
        """Брой значещи цифри след десетичната запетая в repr (fallback за нормализация)."""
        return len(repr(float(x)).partition(".")[2].rstrip("0"))

    def _apply_trailing(self, pos):
        """Breakeven + trailing SL по R. Модифицира само при реална промяна; грешките са WARNING."""
        tr = self.cfg.get("trailing") or {}
        if not tr.get("enabled"):
            return
        op = self.ist.get("open") or {}
        sym = pos.symbol
        dir_buy = pos.type == 0
        tick = self.shim.tick(sym)
        if tick is None:
            return
        price = float(tick.bid if dir_buy else tick.ask)
        entry = float(op.get("entry") or pos.price_open)
        risk_dist = abs(entry - float(op.get("sl") or 0.0))
        if risk_dist <= 0:
            return
        profit = (price - entry) if dir_buy else (entry - price)
        r = profit / risk_dist
        cur_sl = float(pos.sl or 0.0)
        new_sl = None
        # breakeven: вдигаме SL на entry, ако още не е там
        if r >= float(tr.get("breakeven_r", 0.5)) and \
                not self._sl_at_or_beyond(cur_sl, entry, dir_buy):
            new_sl = entry
        # trail: SL държи trail_frac от нереализираната печалба
        if r >= float(tr.get("trail_start_r", 1.0)):
            frac = float(tr.get("trail_frac", 0.5))
            cand = entry + frac * (price - entry) if dir_buy else entry - frac * (entry - price)
            ref = new_sl if new_sl is not None else cur_sl
            if self._sl_better(cand, ref, dir_buy):
                new_sl = cand
        if new_sl is None:
            return
        # нормализация към digits на символа (изискване на брокера); fallback от цените
        try:
            dec = int(getattr(self.shim.symbol_info(sym), "digits", 0) or 0)
        except Exception:
            dec = 0
        if dec <= 0:
            dec = max(self._decimals(price), self._decimals(entry), self._decimals(cur_sl))
        new_sl = round(new_sl, dec)
        if not self._sl_better(new_sl, cur_sl, dir_buy):
            return
        if self.cfg["mode"] == "dry" or not self.write:
            LOG.info("[DRY] trailing SL %s -> %.5f (%.2fR)", sym, new_sl, r)
            return
        res = self.shim.modify_sl(int(pos.ticket), sym, new_sl, float(pos.tp or 0.0))
        if res is None or res.retcode not in (10008, 10009):
            LOG.warning("trailing SL modify FAIL %s: retcode=%s %s",
                        sym, getattr(res, "retcode", None), getattr(res, "comment", ""))
            return
        notify("info", "trade", f"S5: {sym} trailing SL -> {new_sl:.5f} ({r:.2f}R)")

    def manage_position(self, pos, ev_map, server_now):
        """SL е при брокера. Тук: trailing, RSI изход, 7 дни, петък. Връща действие или None."""
        op = self.ist.get("open") or {}
        sym = pos.symbol
        ev = ev_map.get(sym)
        dir_buy = pos.type == 0
        self._apply_trailing(pos)
        # петък изход
        fri = server_now.weekday() == 4 and server_now.hour >= int(self.cfg["friday_exit_hour"])
        if fri:
            ok, msg = self.close_position(pos, float(self.shim.tick(sym).bid if dir_buy else self.shim.tick(sym).ask),
                                          "FRI", dry_label="[DRY] ")
            if ok:
                self._after_close(pos, "FRI")
            return msg
        # H1 pullback слой: собствени изходи (RSI-H1 кръст / 48ч), без D1 правила
        if op.get("layer") == "h1":
            return self._manage_h1(pos, op, dir_buy)
        if ev is None or ev["rsi2"] is None:
            return None
        rsi_exit = ev["rsi2"] > self.cfg["rsi_exit_long"] if dir_buy else ev["rsi2"] < self.cfg["rsi_exit_short"]
        if rsi_exit:
            price = float(self.shim.tick(sym).bid if dir_buy else self.shim.tick(sym).ask)
            ok, msg = self.close_position(pos, price, "RSI")
            if ok:
                self._after_close(pos, "RSI")
            return msg
        # изход след 7 дневни бара (броим само баровете на същия символ след opened_bar)
        bars_held = 0
        rates = self.shim.rates_d1(sym, 12)
        if rates is not None and op.get("opened_bar"):
            bars_held = sum(1 for r in rates if int(r["time"]) > int(op["opened_bar"]))
        if bars_held >= int(self.cfg["max_days"]):
            price = float(self.shim.tick(sym).bid if dir_buy else self.shim.tick(sym).ask)
            ok, msg = self.close_position(pos, price, "TIME")
            if ok:
                self._after_close(pos, "TIME")
            return msg
        return None

    def _after_close(self, pos, reason):
        op = self.ist.get("open") or {}
        sym = op.get("sym", pos.symbol)
        dirn = op.get("dir") or ("BUY" if pos.type == 0 else "SELL")
        deals = self.shim.history_deals(int(pos.ticket))
        pnl = Decimal("0")
        for d in deals:
            if float(d.volume) > 0 and int(d.entry) != 0 and d.type in (0, 1):
                pnl += Decimal(str(d.profit)) + Decimal(str(d.commission)) + Decimal(str(d.swap))
        # приемаме само изходната сделка: последната срещуположна
        outs = [d for d in deals if float(d.volume) > 0 and ((d.type == 1 and dirn == "BUY") or (d.type == 0 and dirn == "SELL"))]
        if outs:
            d = outs[-1]
            pnl = Decimal(str(d.profit)) + Decimal(str(d.commission)) + Decimal(str(d.swap))
        pnl = pnl.quantize(Decimal("0.01"))
        risk = Decimal(str(op.get("risk_amount") or 0))
        r_value = float(pnl / risk) if risk > 0 else 0.0
        self.record_close(sym, r_value, pnl, reason)
        layer = op.get("layer") or "d1"
        cd_hours = float((self.cfg.get("h1_layer") or {}).get("cooldown_hours", 4)
                         if layer == "h1" else self.cfg["cooldown_hours"])
        self.ist["cooldowns"][f"{sym}|{dirn}"] = int(_time.time()) + int(cd_hours * 3600)
        self.ist["open"] = None
        notify("info", "trade", f"S5: затворена {sym} {dirn} по {reason}: pnl={pnl}€ R={r_value:+.2f}")
        if self.write:
            save_internal(self.ist)

    # ---------- пазачи ----------
    def guards_state(self, equity: Decimal, server_today: str) -> dict:
        g = self.cfg["guards"]
        gs = {"stop_flag": STOP_FLAG.exists(),
              "max_risk_per_trade_pct": float(self.cfg["risk_pct"]),
              "max_daily_dd_pct": float(g["max_daily_loss_pct"]),
              "max_total_dd_pct": float(g["max_peak_dd_pct"]),
              "cooldown_until_utc": None,
              "session_ok": True, "spread_ok": True, "data_fresh": True,
              "paused": bool(self.ist.get("paused")),
              "paused_reason": self.ist.get("paused_reason"),
              "consec_losses": int(self.ist.get("consec_losses", 0)),
              "expectancy_20": None,
              "daily_realized_pct": None,
              "dd_from_peak_pct": None,
              "news_blackout": news_blackout_active(self.cfg)}
        cr = self.ist.get("closed_r") or []
        w = int(g["expectancy_window"])
        if len(cr) >= w:
            gs["expectancy_20"] = round(sum(cr[-w:]) / w, 4)
        # дневен реализиран P&L
        if self.ist.get("day") != server_today:
            self.ist["day"] = server_today
            self.ist["day_start_equity"] = float(equity)
        day_start = Decimal(str(self.ist.get("day_start_equity") or equity))
        daily = equity - day_start
        gs["daily_realized_pct"] = round(float(daily / day_start * 100), 3) if day_start > 0 else 0.0
        # пиков спад
        peak = Decimal(str(self.ist.get("peak_equity") or equity))
        if equity > peak:
            peak = equity
            self.ist["peak_equity"] = float(peak)
        dd = float((peak - equity) / peak * 100) if peak > 0 else 0.0
        gs["dd_from_peak_pct"] = round(dd, 3)
        if dd >= float(g["max_peak_dd_pct"]) and not self.ist.get("paused"):
            self.ist["paused"] = True
            self.ist["paused_reason"] = f"спад от върха {dd:.1f}% >= {g['max_peak_dd_pct']}%"
            notify("alert", "system", f"S5 ПАУЗА: {self.ist['paused_reason']}. Ръчен resume (state.json paused=false).")
        # cooldown най-ранен
        cds = {k: v for k, v in (self.ist.get("cooldowns") or {}).items() if v and v > _time.time()}
        self.ist["cooldowns"] = cds
        if cds:
            soon = min(cds.values())
            gs["cooldown_until_utc"] = datetime.fromtimestamp(soon, timezone.utc).isoformat(timespec="seconds")
        return gs

    def entries_blocked(self, gs: dict, sym=None, direction=None) -> str | None:
        """Връща причина ако входовете са блокирани, иначе None."""
        if gs["stop_flag"]:
            return "STOP.flag активен"
        if self.ist.get("paused"):
            return f"пауза: {self.ist.get('paused_reason')}"
        if gs["daily_realized_pct"] is not None and gs["daily_realized_pct"] <= -float(self.cfg["guards"]["max_daily_loss_pct"]):
            return f"дневен реализиран спад {gs['daily_realized_pct']}% <= -{self.cfg['guards']['max_daily_loss_pct']}%"
        if gs["news_blackout"]:
            return "новинарски блекаут"
        if sym and direction:
            cd = (self.ist.get("cooldowns") or {}).get(f"{sym}|{direction}", 0)
            if cd and cd > _time.time():
                left = (cd - _time.time()) / 3600.0
                return f"cooldown още {left:.1f}ч"
        return None

    # ---------- цикъл ----------
    def run_cycle(self) -> dict:
        acc = self.acc
        if acc is None:
            acc = self.shim.connect()
            self.acc = acc
        guard_check_white_list(self.cfg, acc.login, getattr(acc, "server", None))
        equity = self.equity()

        pos = self.find_engine_position()
        self.reconcile(pos)
        if pos is not None:
            self.adopt_or_close(pos)

        # индикатори
        ev_map = {}
        for sym in self.cfg["symbols"]:
            try:
                ev_map[sym] = self.evaluate_symbol(sym)
            except Exception:
                LOG.exception("evaluate %s fail", sym)
                ev_map[sym] = None

        # сървърно време от USDJPY барове
        try:
            rates = self.shim.rates_d1(self.cfg["symbols"][0], 5)
            server_now = self.server_dt(rates)
        except Exception:
            server_now = utc_now()
        server_today = server_now.strftime("%Y-%m-%d")

        gs = self.guards_state(equity, server_today)

        # ── пазителен слой: snapshot преди входната логика ──
        # блекаут около High събития / гео риск множител / sentiment + social посока
        snap = None
        guard_risk_mult = 1.0
        guard_sentiment_dir = guard_sentiment_note = None
        guard_social_dir = guard_social_note = None
        social_bias_doc: dict = {"usable": False}
        if market_guard is not None:
            try:
                snap = market_guard.guard_snapshot(LOGS_DIR)
                guard_risk_mult = float(market_guard.risk_multiplier(snap))
                guard_sentiment_dir = market_guard.sentiment_allowed_direction(LOGS_DIR)
                guard_sentiment_note = market_guard.sentiment_note(LOGS_DIR)
                social_bias_doc = market_guard.social_bias(LOGS_DIR)
                guard_social_dir = market_guard.social_allowed_direction(LOGS_DIR)
                guard_social_note = market_guard.social_note(LOGS_DIR)
            except Exception:
                LOG.exception("пазителен слой: грешка — цикълът продължава без него")
                snap, guard_risk_mult = None, 1.0
                guard_sentiment_dir = guard_sentiment_note = None
                guard_social_dir = guard_social_note = None
                social_bias_doc = {"usable": False}
        guard_blackout = (market_guard.blackout_due_to_events(snap, utc_now())
                          if (snap is not None and market_guard is not None) else None)
        # единно „разрешена посока" от двата контрариан филтъра (sentiment + social)
        allowed_dirs = {"BUY", "SELL"}
        dir_notes: list[str] = []
        if guard_sentiment_dir in ("BUY", "SELL"):
            allowed_dirs &= {guard_sentiment_dir}
            if guard_sentiment_note:
                dir_notes.append(guard_sentiment_note)
        if guard_social_dir in ("BUY_only", "SELL_only"):
            allowed_dirs &= {guard_social_dir.split("_")[0]}
            if guard_social_note:
                dir_notes.append(guard_social_note)
        if allowed_dirs == {"BUY", "SELL"}:
            guard_allowed_dir = None            # няма ограничение на посоката
        elif len(allowed_dirs) == 1:
            guard_allowed_dir = next(iter(allowed_dirs))
        else:
            guard_allowed_dir = "NONE"          # конфликт sentiment vs social — нищо не мина
        # crowd консенсус от социалния пулс -> допълнителен риск множител x0.75
        if social_bias_doc.get("usable") and social_bias_doc.get("crowd"):
            guard_risk_mult = min(guard_risk_mult,
                                  float(getattr(market_guard, "SOCIAL_RISK_MULT", 0.75)))
        gs["guard_geo"] = snap.get("geo_level") if snap else None
        gs["guard_velocity"] = snap.get("velocity") if snap else None
        gs["guard_blackout_event"] = guard_blackout
        gs["guard_risk_mult"] = guard_risk_mult
        gs["guard_social"] = (social_bias_doc.get("crowd")
                              if social_bias_doc.get("usable") else None)
        self._guard_risk_mult = guard_risk_mult

        if self.write:
            save_internal(self.ist)

        last_action = "WAIT"
        action_reason = "няма setup"
        symbol_rows = []

        # 1) управление на отворена позиция
        if pos is not None:
            msg = self.manage_position(pos, ev_map, server_now)
            if msg:
                last_action = "CLOSE"
                action_reason = msg
            else:
                last_action = "HOLD"
                action_reason = f"държим {pos.symbol}"

        # 2) входове (само ако нямаме позиция след мениджмънта)
        pos2 = self.find_engine_position()
        fri_cut = server_now.weekday() == 4 and server_now.hour >= int(self.cfg["friday_cutoff_hour"])
        block = self.entries_blocked(gs)
        if block is None and snap is not None:
            if guard_blackout:
                block = guard_blackout            # High събитие наблизо -> без нови входове
            elif guard_risk_mult <= 0.0:
                block = (f"пазителен слой: гео риск {gs['guard_geo']} — "
                         f"търговията е спряна")
        for sym in self.cfg["symbols"]:
            ev = ev_map.get(sym)
            direction, checks = self.signal(ev, sym)
            result = "WAIT"
            if pos2 is not None:
                if pos2.symbol == sym:
                    result = "HOLD" if last_action == "HOLD" else "EXIT"
            elif direction is not None:
                result = "BLOCKED"
                if block:
                    checks.append({"name": "Пазачи", "passed": False, "detail": block})
                    action_reason = block
                elif fri_cut:
                    checks.append({"name": "Петък cut-off", "passed": False,
                                   "detail": f"сървърно {server_now.strftime('%H:%M')} >= {self.cfg['friday_cutoff_hour']}:00 петък — без нови входове"})
                else:
                    cd_block = self.entries_blocked(gs, sym, direction)
                    if cd_block:
                        checks.append({"name": "Cooldown", "passed": False, "detail": cd_block})
                    elif guard_allowed_dir == "NONE":
                        checks.append({"name": "Посока (пазител)", "passed": False,
                                       "detail": "; ".join(dir_notes) +
                                                 " — противоположни изисквания, без нови входове"})
                        action_reason = "конфликт sentiment vs социален пулс"
                    elif guard_allowed_dir and direction != guard_allowed_dir:
                        if len(dir_notes) > 1:
                            name = "Посока (пазител)"
                        elif guard_social_dir:
                            name = "Социален пулс (контрариан)"
                        else:
                            name = "Sentiment (контрариан)"
                        checks.append({"name": name, "passed": False,
                                       "detail": "; ".join(dir_notes) + " — "
                                                 f"пазителят пропуска само {guard_allowed_dir}"})
                        action_reason = (guard_sentiment_note or guard_social_note
                                         or "филтър на посоката")
                    else:
                        opened, why = self.try_open(sym, direction, ev)
                        checks.append({"name": "Изпълнение", "passed": opened is not None, "detail": why})
                        if opened:
                            result = "ENTER"
                            last_action = "OPEN_LONG" if direction == "BUY" else "OPEN_SHORT"
                            action_reason = why
                            pos2 = self.find_engine_position()
            elif ev is not None and ev["rsi2"] is not None:
                pass
            else:
                result = "BLOCKED"
            symbol_rows.append({"symbol": sym, "result": result,
                                "expected_direction": direction or "-",
                                "signal_score": round(ev["rsi2"], 1) if ev and ev["rsi2"] is not None else None,
                                "reason": checks[-1]["detail"] if checks else "-",
                                "checks": checks})

        # 3) H1 pullback слой (само ако сме празни; споделя единствената позиция с D1 слоя)
        h1cfg = self.cfg.get("h1_layer") or {}
        if (pos2 is None and h1cfg.get("enabled") and h1cfg.get("symbols")
                and block is None and not fri_cut):
            h1_block_extra = None
            if snap is not None:
                if guard_blackout:
                    h1_block_extra = guard_blackout
                elif guard_risk_mult <= 0.0:
                    h1_block_extra = f"пазителен слой: гео риск {gs['guard_geo']}"
            for sym in h1cfg["symbols"]:
                if pos2 is not None:
                    break
                try:
                    d1ev = self.evaluate_symbol(sym)
                    h1ev = self.evaluate_h1(sym)
                except Exception:
                    LOG.exception("evaluate_h1 %s fail", sym)
                    continue
                direction, checks = self.signal_h1(h1ev, d1ev)
                result = "WAIT"
                if direction is not None:
                    result = "BLOCKED"
                    if h1_block_extra:
                        checks.append({"name": "Пазачи", "passed": False, "detail": h1_block_extra})
                        action_reason = h1_block_extra
                    else:
                        cd_block = self.entries_blocked(gs, sym, direction)
                        if cd_block:
                            checks.append({"name": "Cooldown", "passed": False, "detail": cd_block})
                        elif guard_allowed_dir == "NONE":
                            checks.append({"name": "Посока (пазител)", "passed": False,
                                           "detail": "; ".join(dir_notes) +
                                                     " — противоположни изисквания, без нови входове"})
                        elif guard_allowed_dir and direction != guard_allowed_dir:
                            checks.append({"name": "Посока (пазител)", "passed": False,
                                           "detail": "; ".join(dir_notes) +
                                                     f" — пазителят пропуска само {guard_allowed_dir}"})
                        elif d1ev is None or d1ev["atr"] is None:
                            checks.append({"name": "Данни", "passed": False,
                                           "detail": "няма D1 ATR за SL"})
                        else:
                            opened, why = self.try_open(
                                sym, direction, d1ev,
                                risk_pct=float(h1cfg.get("risk_pct", 0.15)), layer="h1")
                            checks.append({"name": "Изпълнение", "passed": opened is not None,
                                           "detail": why})
                            if opened:
                                result = "ENTER"
                                last_action = "OPEN_LONG" if direction == "BUY" else "OPEN_SHORT"
                                action_reason = why
                                pos2 = self.find_engine_position()
                symbol_rows.append({"symbol": f"{sym}·H1", "result": result,
                                    "expected_direction": direction or "-",
                                    "signal_score": round(h1ev["rsi2"], 1) if h1ev else None,
                                    "reason": checks[-1]["detail"] if checks else "-",
                                    "checks": checks})

        if last_action == "WAIT" and block:
            action_reason = block

        # позиция за state.json
        pos_view = {"open": bool(pos is not None and (self.ist.get("open") or pos)),
                    "symbol": None, "direction": None, "lots": None, "open_price": None,
                    "sl": None, "tp": None, "opened_utc": None, "floating_pnl": None,
                    "magic": MAGIC if pos is not None else None}
        if pos is not None:
            pos_view.update({"symbol": pos.symbol,
                             "direction": "BUY" if pos.type == 0 else "SELL",
                             "lots": float(pos.volume), "open_price": float(pos.price_open),
                             "sl": float(pos.sl), "tp": float(pos.tp) or None,
                             "opened_utc": datetime.fromtimestamp(int(pos.time), timezone.utc).isoformat(timespec="seconds"),
                             "floating_pnl": round(float(pos.profit), 2)})

        if self.write:
            self.ist["cycle_id"] = int(self.ist.get("cycle_id", 0)) + 1
            save_internal(self.ist)
            mode_label = self.cfg["mode"]
            write_state_json(self.cfg, mode_label, pos_view, gs, last_action, self.cfg["symbols"])
            append_decision({
                "ts": utc_now().isoformat(timespec="seconds"),
                "mode": mode_label,
                "account_mode": self.cfg["mode"],
                "cycle_id": self.ist["cycle_id"],
                "action": {"type": last_action, "reason": action_reason},
                "symbols": symbol_rows,
                "guards_snapshot": {k: gs[k] for k in
                                    ("stop_flag", "paused", "spread_ok", "session_ok", "data_fresh")},
            })
        return {"action": last_action, "reason": action_reason, "guards": gs,
                "symbols": symbol_rows, "position": pos_view, "equity": float(equity)}


# ============================ входни точки ==================================
def setup_logging():
    if LOG.handlers:          # идемпотентно: main() и cmd_daemon() викат едно и също
        return
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    h = logging.handlers.RotatingFileHandler(LOGS_DIR / "engine_s5.log", maxBytes=5 * 1024 * 1024, backupCount=1, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOG.setLevel(logging.INFO)
    LOG.addHandler(h)
    LOG.addHandler(logging.StreamHandler(sys.stdout))


def print_table(rows, equity):
    print(f"\n=== S5 статус @ {utc_now().isoformat(timespec='seconds')} | equity {equity:.2f} ===")
    print(f"{'символ':8} {'close':>10} {'EMA200':>10} {'RSI(2)':>7} {'ATR':>9} {'сигнал':>7}  последна проверка")
    for r in rows:
        ev = r.get("ev")
        if ev:
            print(f"{r['symbol']:8} {ev['close']:>10.5f} {ev['ema200']:>10.5f} "
                  f"{ev['rsi2'] if ev['rsi2'] is not None else float('nan'):>7.2f} {ev['atr']:>9.5f} "
                  f"{r.get('signal') or '-':>7}  {r.get('detail', '')}")
        else:
            print(f"{r['symbol']:8} {'-':>10} {'-':>10} {'-':>7} {'-':>9} {'-':>7}  няма данни")


def cmd_dry_run_now(cfg):
    """Read-only: пазарна таблица + решение, БЕЗ писане и БЕЗ поръчки."""
    eng = Engine(cfg, write=False)
    eng.acc = eng.shim.connect()
    LOG.info("DRY-RUN срещу логин %s (read-only)", eng.acc.login)
    rows = []
    equity = float(eng.equity())
    for sym in cfg["symbols"]:
        ev = eng.evaluate_symbol(sym)
        direction, checks = eng.signal(ev, sym)
        spread_str = ""
        try:
            info = eng.shim.symbol_info(sym)
            tick = eng.shim.tick(sym)
            pip = pip_size_of(info)
            spread_price = float(info.spread) * float(info.point)
            atr = ev["atr"] if ev else None
            ok = atr and spread_price <= cfg["spread_atr_max"] * atr
            spread_str = (f"спред {spread_price:.5f} ({spread_price/pip:.1f}п) vs "
                          f"0.05xATR={cfg['spread_atr_max']*atr:.5f} -> {'OK' if ok else 'БЛОК'}")
            sl_pips = clamp_sl_pips(atr, pip, cfg["sl_mult"], cfg["sl_min_pips"], cfg["sl_max_pips"]) if atr else None
        except Exception as exc:
            spread_str = f"грешка: {exc}"
            sl_pips = None
        rows.append({"symbol": sym, "ev": ev, "signal": direction,
                     "detail": spread_str + (f"; SL={sl_pips:.0f}п" if sl_pips else "")})
    print_table(rows, equity)
    sig = [r for r in rows if r["signal"]]
    if sig:
        r = sig[0]
        print(f"\nРЕШЕНИЕ: {r['signal']} {r['symbol']} (dry — без поръчка). {r['detail']}")
    else:
        print("\nРЕШЕНИЕ: WAIT (няма валиден RSI(2) setup).")
    eng.shim.shutdown()
    return 0


def cmd_once(cfg):
    if STOP_FLAG.exists():
        print(f"STOP.flag съществува — изход 0 без действие ({STOP_FLAG})")
        return 0
    eng = Engine(cfg, write=True)
    try:
        eng.acc = eng.shim.connect()
        out = eng.run_cycle()
        print(f"[once] action={out['action']} reason={out['reason']} equity={out['equity']}")
    except SafetyError as exc:
        print(f"[once] SafetyError: {exc}", file=sys.stderr)
        return 2
    finally:
        eng.shim.shutdown()
    return 0


def _gating_enabled() -> bool:
    """config\\gating.json {enabled:bool} — при включен gating демонът иска валиден лиценз."""
    try:
        return bool(json.loads((BASE_DIR / "config" / "gating.json").read_text(encoding="utf-8"))
                    .get("enabled", False))
    except Exception:
        return False


def _licensing_check() -> tuple[bool, str]:
    try:
        spec = importlib.util.spec_from_file_location("licensing", ENGINE_DIR / "licensing.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.is_licensed()
    except Exception as exc:
        return False, f"лицензната проверка не може да мине: {exc}"


def cmd_daemon(cfg):
    setup_logging()
    if STOP_FLAG.exists():
        print(f"STOP.flag съществува — изход 0 без действие ({STOP_FLAG})")
        return 0
    # фаза 2: лицензен гейт (демонът е пазен; --once/--dry-run-now са read-only и минават)
    if _gating_enabled():
        ok, reason = _licensing_check()
        if not ok:
            LOG.error("gating: няма валиден лиценз (%s) — демонът не стартира", reason)
            notify("alert", "system", f"S5 engine спрян от лицензния гейт: {reason}")
            return 2
    LOG.info("S5 daemon старт; mode=%s symbols=%s", cfg["mode"], cfg["symbols"])
    if not acquire_single_instance():
        LOG.error("втори S5 daemon? порт %s е зает — отказ без цикъл", SINGLE_INSTANCE_PORT)
        notify("warning", "system", "S5: опит за втора инстанция на демона — отказано")
        return 0
    notify("info", "system", f"S5 engine daemon старт (mode={cfg['mode']})")
    eng = Engine(cfg, write=True)
    try:
        eng.acc = eng.shim.connect()
        guard_check_white_list(cfg, eng.acc.login, getattr(eng.acc, "server", None))
        while True:
            if STOP_FLAG.exists():
                LOG.info("STOP.flag — излизам")
                notify("warning", "system", "S5 engine: STOP.flag — демонът спира")
                break
            try:
                out = eng.run_cycle()
                LOG.info("цикъл action=%s reason=%s", out["action"], out["reason"])
            except SafetyError:
                raise
            except Exception:
                LOG.exception("цикъл грешка (не пада)")
            _time.sleep(int(cfg["cycle_seconds"]))
    except SafetyError as exc:
        notify("alert", "system", f"S5 SafetyError: {exc}")
        LOG.error("SafetyError: %s", exc)
        return 2
    finally:
        eng.shim.shutdown()
    return 0


def main() -> int:
    setup_logging()
    ap = argparse.ArgumentParser(description="S5 RSI-2 production engine")
    ap.add_argument("--once", action="store_true", help="един цикъл")
    ap.add_argument("--dry-run-now", action="store_true", help="read-only пазарна таблица, без писане")
    args = ap.parse_args()
    cfg = load_config()
    if KILL_SWITCH.exists():
        # kill switch е файлов: блокира старта докато не е изтрит
        print(f"KILL.switch съществува ({KILL_SWITCH}) — изтрий го за resume. Изход 0.")
        return 0
    if args.dry_run_now:
        return cmd_dry_run_now(cfg)
    if args.once:
        return cmd_once(cfg)
    return cmd_daemon(cfg)


if __name__ == "__main__":
    sys.exit(main())
