# -*- coding: utf-8 -*-
"""Размер на позицията по Кели + корелационен пазач (Renaissance практики, консервативни).

kelly_multiplier(): дробен Кели от последните N затворени R-муктипликации.
  f* = W − (1−W)/R  (W=печеливши дял, R=avg_win/avg_loss)
  Мултипликатор спрямо базовия риск = clamp(fraction·f* / base_risk, min, max).
  f* ≤ 0 → min (намаляваме риск при липса на edge).
  С ≤10 сделки в прозореца → 1.0 (няма статистика, не гадаем).

CORR: реални корелации на дневните възвращаемости 2012–2026 (data_cache).
exposure_overlap(): корелация × посоки; |overlap| ≥ праг = удвоен риск.
"""
from __future__ import annotations

# дневни възвращаемости, 14 г., изчислени от data_cache (scripts/research_ensemble.py)
CORR = {
    ("GBPUSD", "AUDUSD"): 0.59, ("GBPUSD", "USDCAD"): -0.50,
    ("GBPUSD", "XAUUSD"): 0.34,
    ("AUDUSD", "USDCAD"): -0.68, ("AUDUSD", "EURNZD"): -0.45,
    ("AUDUSD", "XAUUSD"): 0.42,
    ("USDJPY", "EURUSD"): -0.48,
    ("USDCAD", "EURNZD"): 0.30, ("USDCAD", "XAUUSD"): -0.30,
    ("EURCHF", "EURNZD"): 0.16, ("GBPUSD", "EURCHF"): 0.10,
    ("EURNZD", "XAUUSD"): -0.13, ("EURCHF", "XAUUSD"): -0.10,
}


def _corr(a: str, b: str) -> float:
    if a == b:
        return 1.0
    return CORR.get((a, b), CORR.get((b, a), 0.0))


def kelly_multiplier(closed_r: list[float] | None, window: int = 30,
                     fraction: float = 0.25, base_risk: float = 0.008,
                     mult_min: float = 0.5, mult_max: float = 1.5) -> float:
    """Мултипликатор върху базовия risk_pct. Консервативен (дробен Кели)."""
    rs = [float(x) for x in (closed_r or [])][-window:]
    if len(rs) < 10:
        return 1.0
    wins = [x for x in rs if x > 0]
    losses = [x for x in rs if x <= 0]
    if len(wins) < 3 or len(losses) < 3:
        return 1.0
    W = len(wins) / len(rs)
    R = (sum(wins) / len(wins)) / abs(sum(losses) / len(losses))
    if R <= 0:
        return mult_min
    f = W - (1.0 - W) / R
    if f <= 0:
        return mult_min
    mult = fraction * f / base_risk
    return max(mult_min, min(mult_max, mult))


def exposure_overlap(new_sym: str, new_dir: int, open_pos: list[dict],
                     threshold: float = 0.5) -> tuple[bool, str]:
    """Връща (блокирано ли, причина). open_pos: [{'symbol','dir'}], dir=+1 BUY/−1 SELL."""
    for p in open_pos:
        c = _corr(new_sym, p["symbol"])
        overlap = c * new_dir * int(p["dir"])
        if abs(overlap) >= threshold:
            bg = "една и съща" if overlap > 0 else "противоположна но еквивалентна"
            return True, (f"корелационен пазач: {new_sym}×{p['symbol']} "
                          f"(r={c:+.2f}, {bg} USD експозиция)")
    return False, ""
