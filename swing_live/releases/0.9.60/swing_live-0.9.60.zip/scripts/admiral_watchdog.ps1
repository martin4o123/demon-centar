# Admiral Swing Live — watchdog
# Стартира portable MT5 + engine ако не вървят. Уважава STOP.flag.
# Пише лог в D:\AIRobot\admiral_swing_live\logs\watchdog.log
# Нотификации през engine\notify.py (STOP.flag преходи + рестарти).

$Base    = "D:\AIRobot\admiral_swing_live"
$Product = "C:\Users\mgeor\AppData\Local\AdmiralBeta"
$StopFlag = Join-Path $Base "STOP.flag"
$LogDir  = Join-Path $Base "logs"
$LogFile = Join-Path $LogDir "watchdog.log"
$Terminal = Join-Path $Product "mt5_portable\terminal64.exe"
$EngineStart = Join-Path $Product "START_ADMIRAL_BETA.cmd"
$Heartbeat = Join-Path $Product "logs\beta_heartbeat.json"
$NotifyPy = Join-Path $Base "engine\notify.py"
$StateFile = Join-Path $LogDir ".watchdog_state"

New-Item -ItemType Directory -Force $LogDir | Out-Null

function Log($msg) {
    $line = "{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
}

function Notify($level, $category, $text) {
    try {
        & py -3.12 $NotifyPy --level $level --category $category --text $text 2>$null | Out-Null
    } catch {}
}

# --- STOP.flag преходи: съобщение само при СМЯНА на състоянието ---
$stopNow = Test-Path $StopFlag
$prevStop = $null
if (Test-Path $StateFile) {
    try { $prevStop = [bool]((Get-Content $StateFile -Raw | ConvertFrom-Json).stop) } catch {}
}
if ($null -ne $prevStop -and $prevStop -ne $stopNow) {
    if ($stopNow) {
        Notify warning status "STOP.flag създаден — търговията и рестартите са спрени ръчно."
        Log "STOP.flag преход: липсваше -> създаден."
    } else {
        Notify info status "STOP.flag премахнат — watchdog-ът отново пуска терминал/engine."
        Log "STOP.flag преход: имаше -> премахнат."
    }
}
@{ stop = $stopNow } | ConvertTo-Json | Set-Content -Path $StateFile -Encoding UTF8

if (Test-Path $StopFlag) {
    Log "STOP.flag наличен — нищо не пускам."
    exit 0
}

$QuietFlag = Join-Path $Base "QUIET.flag"
if (Test-Path $QuietFlag) {
    Log "QUIET.flag наличен — пауза на автоматичните проверки (клиентът управлява MT5 ръчно). Излизам."
    exit 0
}

# 1. Терминал
$term = Get-Process terminal64 -ErrorAction SilentlyContinue
if (-not $term) {
    if ([System.Environment]::UserInteractive) {
        Log "Терминалът не върви — стартирам portable MT5."
        Start-Process $Terminal
        Start-Sleep 90
        Notify warning system "Watchdog: терминалът беше спрян — стартирах portable MT5."
    } else {
        Log "Терминалът не върви, но съм в неинтерактивна сесия (S4U) — НЕ пускам MT5 тук (ще е невидим и bridge-ът спира). Само записвам."
        Notify warning system "Watchdog: MT5 спрян, а задачата е фонова — стартирай MT5 ръчно при първа възможност."
    }
} else {
    # Мъртъв терминал в чужда сесия (напр. S4U/сесия 0) — върви, но няма прозорец
    # и потребителят не може да го види/ползва. Рестартираме го в текущата сесия.
    $mySess = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
    foreach ($p in $term) {
        try {
            $pinfo = Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)" -ErrorAction Stop
            if ($pinfo.SessionId -ne $mySess) {
                Log "Терминалът върви в НЕВИДИМА сесия $($pinfo.SessionId) (PID $($p.Id)) — спирам го и го пускам тук (сесия $mySess)."
                Stop-Process -Id $p.Id -Force -ErrorAction Stop
                Start-Sleep 3
                if ([System.Environment]::UserInteractive) {
                    Start-Process $Terminal
                    Notify warning system "Watchdog: MT5 беше пуснат невидимо (сесия $($pinfo.SessionId)) — рестартирах го в твоята сесия."
                } else {
                    Notify warning system "Watchdog: MT5 върви невидимо (сесия $($pinfo.SessionId)) — стартирай го ръчно, за да се види."
                }
            } else {
                Log "Терминалът върви нормално (PID $($p.Id), сесия $mySess)."
            }
        } catch {
            Log "Терминалът върви (PID $($p.Id)) — проверката на сесията не мина: $($_.Exception.Message)"
        }
    }
}

# 2. Продуктов engine — НЕ се стартира автоматично (2026-09-14):
# на демо замърсява S5 валидацията, на live €150 обем-проверката му отказва всичко.
# Ролята „пазач“ я изпълнява S5 engine + preflight.
# 2026-09-15: START_ADMIRAL_BETA.cmd е преименуван на .DISABLED-20260915 —
# старата Beta при демо сметка пишеше STOP.flag и убиваше цялата система.
# Старт/стоп на S5: бутоните в таблото (директно engine_s5.py, single-instance lock порт 5125).
Log "Продуктовият engine не се пуска от watchdog (осъзнат избор — виж OPS_MAP)."

Log "Цикъл приключен."
exit 0
