"""Локатор на MT5 терминала и неговата MQL5\\Files папка — без втвърдени пътища.

Ред на засичане (първото съществуващо печели):
  1. env DEMON_MT5_TERMINAL
  2. конфигуриран път (ако съществува на тази машина)
  3. %LOCALAPPDATA%\\AdmiralBeta\\mt5_portable\\terminal64.exe (portable инсталация)
  4. Стандартни инсталации в Program Files (Admirals)
  5. Работещ процес terminal64.exe (точен път от ОС)

MQL5\\Files: при portable е до exe-то; при нормална инсталация е в
%APPDATA%\\MetaQuotes\\Terminal\\<hash>\\MQL5\\Files — hash папката се намира през
origin.txt (сочи инсталационната папка на терминала).
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

POWERSHELL = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"


def localappdata() -> Path:
    return Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))


def _running_terminal() -> tuple[Path | None, bool]:
    """(път до exe на работещия терминал, portable ли е) — или (None, False)."""
    try:
        r = subprocess.run(
            [POWERSHELL, "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" "
             "| Select-Object -First 1 ExecutablePath, CommandLine "
             "| ForEach-Object { $_.ExecutablePath + '||' + $_.CommandLine }"],
            capture_output=True, text=True, timeout=20)
        out = (r.stdout or "").strip().splitlines()
        if out and "||" in out[0]:
            exe, cmd = out[0].split("||", 1)
            exe = exe.strip()
            if exe and Path(exe).exists():
                return Path(exe), "/portable" in cmd.lower()
    except Exception:
        pass
    return None, False


def detect_mt5_terminal(configured: str | None = None) -> Path | None:
    """Път до terminal64.exe или None. Никога не връща несъществуващ конфигуриран път."""
    cands: list[Path] = []
    env = (os.environ.get("DEMON_MT5_TERMINAL") or "").strip()
    if env:
        cands.append(Path(env))
    if configured:
        cands.append(Path(configured))
    la = localappdata()
    cands.append(la / "AdmiralBeta" / "mt5_portable" / "terminal64.exe")
    cands.append(Path(r"C:\Program Files\Admirals Group MT5 Terminal\terminal64.exe"))
    cands.append(Path(r"C:\Program Files (x86)\Admirals Group MT5 Terminal\terminal64.exe"))
    for c in cands:
        try:
            if c.exists():
                return c
        except OSError:
            continue
    exe, _ = _running_terminal()
    return exe


def detect_mt5_files_dir(configured: str | None = None) -> Path | None:
    """MQL5\\Files на АКТИВНИЯ терминал (portable → до exe; иначе MetaQuotes hash)."""
    exe, portable = _running_terminal()
    if exe and portable:
        return exe.parent / "MQL5" / "Files"
    if exe and not portable:
        # нормална инсталация: hash папката чрез origin.txt
        term_root = Path(os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming")) \
            / "MetaQuotes" / "Terminal"
        try:
            for d in term_root.iterdir():
                origin = d / "origin.txt"
                try:
                    if origin.exists() and origin.read_text(
                            encoding="utf-8", errors="ignore").strip().lower() \
                            == str(exe.parent).lower():
                        return d / "MQL5" / "Files"
                except OSError:
                    continue
        except OSError:
            pass
    # fallback: според засечения (може и неработещ) терминал
    t = detect_mt5_terminal(configured)
    if t:
        return t.parent / "MQL5" / "Files"
    return None
