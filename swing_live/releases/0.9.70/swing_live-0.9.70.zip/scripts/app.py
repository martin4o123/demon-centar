import sys
import threading
import time
import os
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "dashboard"))

PORT = 5123
URL = f"http://127.0.0.1:{PORT}"
ICON = BASE / "assets" / "demon-desktop-icon.png"


def _ensure_update_task() -> None:
    try:
        import subprocess
        check = subprocess.run(
            ["schtasks", "/query", "/tn", "DemonCenter_Update"],
            capture_output=True, timeout=15)
        if check.returncode == 0:
            return
        py = sys.executable
        subprocess.run(
            ["schtasks", "/create", "/tn", "DemonCenter_Update", "/f",
             "/tr", f'"{py}" "{BASE}\\scripts\\update_client.py" --apply',
             "/sc", "daily", "/st", "09:47"],
            capture_output=True, timeout=20)
    except Exception:
        pass


def serve() -> None:
    try:
        sys.path.insert(0, str(BASE / "engine"))
        import integrity
        ok, msg = integrity.verify_manifest(BASE)
        if not ok:
            print(msg)
            try:
                import telemetry
                telemetry.send_event("tamper", msg, force=True)
            except Exception:
                pass
            os._exit(3)
        import app as dashboard
        dashboard.app.run(host="127.0.0.1", port=PORT, debug=False,
                          use_reloader=False, threaded=True)
    except SystemExit:
        raise
    except Exception as exc:
        try:
            import telemetry
            telemetry.send_event("dashboard_crash", repr(exc), force=True)
        except Exception:
            pass
        os._exit(1)


def _scrub_owner_only_files() -> None:
    """Премахва owner-only файлове, останали на клиентски машини от стари пакети
    (съдържат пътища към машината на собственика). НИКОГА не на owner машината —
    там тези инструменти са нужни (познава се по config/telemetry_owner.json)."""
    try:
        if (BASE / "config" / "telemetry_owner.json").exists():
            return
        names = ("publish_update.py", "telemetry_mailman.py", "health_check.py",
                 "health_watch.ps1", "admiral_watchdog.ps1", "admiral_autostart.cmd",
                 "backup_daily.cmd", "auto_research.py", "auto_research.cmd",
                 "backtest_75.py", "_bt_rsi_variants.py", "make_shortcuts.ps1",
                 "make_shortcuts_debug.ps1", "shortcuts.json", "license_manager.cmd",
                 "ollama_serve.cmd", "activate_client.cmd",
                 "_bt_h1.py", "_bt_variants.py", "_smoke_control_test.py",
                 "research_ensemble.py", "train_regime.py", "fetch_daily.py",
                 "license_tool.cmd")
        for n in names:
            try:
                (BASE / "scripts" / n).unlink(missing_ok=True)
            except OSError:
                pass
        # owner-only документи, останали от стари пакети
        for n in ("OPS_MAP.md",):
            try:
                (BASE / n).unlink(missing_ok=True)
            except OSError:
                pass
        try:
            (BASE / "engine" / "state_contract.md").unlink(missing_ok=True)
        except OSError:
            pass
    except Exception:
        pass


def main() -> int:
    threading.Thread(target=_ensure_update_task, daemon=True).start()
    threading.Thread(target=_scrub_owner_only_files, daemon=True).start()
    t = threading.Thread(target=serve, daemon=True)
    t.start()
    for _ in range(50):
        time.sleep(0.2)
        import urllib.request
        try:
            urllib.request.urlopen(URL, timeout=1)
            break
        except Exception:
            pass
    try:
        import webview
        webview.create_window("DEMON — център за управление", URL,
                              width=1440, height=900, min_size=(1024, 700))
        webview.start()
    except Exception:
        import subprocess
        subprocess.Popen(["cmd", "/c", f"start {URL}"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
